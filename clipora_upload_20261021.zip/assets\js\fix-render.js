// ============================================================
// V9.181.0: PERBAIKAN OTOMATIS (Render & Auto-Load)
// ============================================================
(function() {
    "use strict";

    // 1. TIMPA FUNGSI SHOWCONFIRM YANG RUSAK
    window.showConfirm = function(opts) {
        return Promise.resolve(confirm((opts.title || "Konfirmasi") + "\n\n" + (opts.message || "")));
    };

    // 2. AUTO-LOAD PROJECT DARI URL ?project=...
    setTimeout(function() {
        var urlParams = new URLSearchParams(window.location.search);
        var projectId = urlParams.get("project");
        if (projectId) {
            // V9.181.1: Bersihkan karakter aneh di URL (misal: ")", ".", spasi)
            projectId = projectId.replace(/[^a-fA-F0-9\-]/g, "");
        }
        
        if (projectId && window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) {
            console.log("[FixRender] Memuat proyek:", projectId);
            
            fetch("http://localhost:3000/api/autoclip-projects/" + projectId, {
                headers: { "Authorization": "Bearer " + window.CLIPORA_AUTH.token }
            })
            .then(res => res.json())
            .then(data => {
                if (!data.success || !data.project) return;
                
                var project = data.project;
                var clipsJson = project.clips_json;
                if (typeof clipsJson === 'string') clipsJson = JSON.parse(clipsJson);
                
                if (!clipsJson || clipsJson.length === 0) return;

                // Bangun ulang state
                if (!window.__TL_STATE) window.__TL_STATE = {};
                window.__TL_STATE.timeline = clipsJson;
                window.__TL_STATE.pool = [];
                window.__TL_STATE.analysisId = projectId;
                window.__TL_STATE._projectId = projectId;
                
                // URL Video
                var videoUrl = "http://localhost:3000/api/autoclip-projects/" + projectId + "/video?token=" + encodeURIComponent(window.CLIPORA_AUTH.token);
                window.currentVideoUrl = videoUrl;
                window.__TL_STATE.videoUrl = videoUrl;

                // Render timeline & pasang video
                if (typeof renderTimeline === "function") renderTimeline();
                if (typeof renderPool === "function") renderPool();
                
                var videos = document.querySelectorAll("video");
                videos.forEach(function(v) { v.src = videoUrl; v.load(); });
                
                // Sembunyikan halaman upload, tampilkan editor
                var uploadZone = document.getElementById("acUploadZone");
                if (uploadZone) uploadZone.style.display = "none";
                var editor = document.getElementById("acTimelineEditor");
                if (editor) editor.classList.add("active");
                var prog = document.getElementById("acProgress");
                if (prog) prog.style.display = "none";
                
                console.log("[FixRender] ✅ Proyek berhasil dimuat ulang!");
            })
            .catch(err => console.warn("[FixRender] Gagal load:", err));
        }
    }, 2500); // Delay agar CLIPORA_AUTH siap

    // 3. FUNGSI RENDER DARURAT
    window.emergencyRender = async function() {
        var st = window.__TL_STATE;
        if (!st || !st.timeline || st.timeline.length === 0) {
            alert("Tidak ada klip untuk dirender.");
            return;
        }
        
        var clips = [...st.timeline, ...st.pool];
        if (!confirm("Render " + clips.length + " klip sekarang?")) return;

        var token = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || "";
        var analysisId = st.analysisId || st._projectId;
        var preset = document.getElementById("acPreset")?.value || "1080p";
        
        for (var i = 0; i < clips.length; i++) {
            var clip = clips[i];
            console.log("[" + (i+1) + "/" + clips.length + "] Merender Klip #" + clip.id + "...");
            
            try {
                var res = await fetch("http://localhost:3000/api/render-clip/" + analysisId + "/" + clip.id, {
                    method: "POST",
                    headers: {
                        "Authorization": "Bearer " + token,
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        preset: preset,
                        vertical_crop: false,
                        enable_burn_subtitle: true,
                        caption_style: "clean",
                        culture_region: "id"
                    })
                });
                var data = await res.json();
                if (data.success) {
                    console.log("✅ Klip #" + clip.id + " selesai.");
                } else {
                    console.error("❌ Klip #" + clip.id + " gagal: " + (data.error || "Unknown"));
                }
            } catch (e) {
                console.error("❌ Error: " + e.message);
            }
        }
        alert("Render selesai! Silakan cek folder results/.");
    };

    console.log("[FixRender] ✅ Modul perbaikan aktif (V9.181.0)");
})();