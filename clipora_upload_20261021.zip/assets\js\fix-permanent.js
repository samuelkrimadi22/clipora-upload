﻿// ============================================================
// V9.250.0: PERBAIKAN PERMANEN (Upload, Panel, Proses, Render)
// ============================================================
(function() {
    // V9.271.0: PENGAMAN GLOBAL - Pastikan semua elemen ada sebelum akses .style
    var _safeStyle = function(element, prop, value) {
        if (element && element.style) {
            element.style[prop] = value;
        }
    };
    "use strict";

    // 1. PAKSA SHOWCONFIRM
    window.showConfirm = function(opts) {
        return Promise.resolve(confirm((opts.title || "Konfirmasi") + "\n\n" + (opts.message || "")));
    };

    // 2. PAKSA TOMBOL UPLOAD
    function forceUpload() {
        var btn = document.getElementById("acPickBtn");
        var zone = document.getElementById("acUploadZone");
        var input = document.getElementById("acFileInput");
        if (!input) return;

        if (btn && !btn.dataset.forced) {
            btn.dataset.forced = "true";
            btn.onclick = function(e) {
                e.preventDefault(); e.stopPropagation();
                input.click();
                console.log("✅ Tombol Upload dipaksa!");
            };
        }
        if (zone && !zone.dataset.forced) {
            zone.dataset.forced = "true";
            zone.onclick = function(e) {
                if (e.target.id !== "acFileInput") {
                    e.preventDefault(); e.stopPropagation();
                    input.click();
                }
            };
        }
    }

    // 3. PAKSA PANEL BISA DITUTUP
    function forcePanel() {
        var headers = document.querySelectorAll(".ac-settings-header, .ac-panel-header, .ac-card-header, .ac-settings .ac-header");
        headers.forEach(function(h) {
            if (h.dataset.forced) return;
            h.dataset.forced = "true";
            h.style.cursor = "pointer";
            h.onclick = function(e) {
                if (e.target.closest("button") || e.target.closest(".toggle")) return;
                var content = h.parentElement.querySelector(".ac-settings-body, .ac-panel-body, .ac-card-body, .ac-content");
                if (content) {
                    content.style.display = (content.style.display === "none") ? "block" : "none";
                } else {
                    var parent = h.parentElement;
                    if (parent.children.length > 1) {
                        var body = parent.children[1];
                        body.style.display = (body.style.display === "none") ? "block" : "none";
                    }
                }
            };
        });
    }

    // 4. PAKSA TOMBOL PROSES VIDEO
    function forceProcess() {
        var btn = document.getElementById("acProsesBtn");
        var input = document.getElementById("acFileInput");
        if (!btn || btn.dataset.forced) return;
        if (!input) return;

        btn.dataset.forced = "true";
        btn.onclick = function(e) {
            e.preventDefault(); e.stopPropagation();
            if (!input.files || input.files.length === 0) {
                alert("Silakan pilih video terlebih dahulu.");
                return;
            }
            var file = input.files[0];
            console.log("✅ Tombol Proses diklik, memulai upload:", file.name);

            var _pg = document.getElementById("acProgress"); if (_pg) _pg.style.display = "block";
            var progressText = document.getElementById("acProgressText");
            if (progressText) progressText.textContent = "Mengupload video...";

            var prosesWrapper = document.getElementById("acProsesWrapper");
            if (prosesWrapper) prosesWrapper.style.display = "none";
            var previewWrap = document.getElementById("acVideoPreviewWrap");
            if (previewWrap) previewWrap.style.display = "none";

            // Panggil fungsi upload asli jika tersedia
            if (typeof uploadAndAnalyze === "function") {
                uploadAndAnalyze(file);
            } else {
                // Fallback manual upload
                var fd = new FormData();
                fd.append("video", file);
                fd.append("target_clips", document.getElementById("acTargetClips")?.value || "5");
                fd.append("preset", document.getElementById("acPreset")?.value || "1080p");
                var token = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || "";
                fetch("http://localhost:3000/api/auto-clip", {
                    method: "POST",
                    headers: { "Authorization": "Bearer " + token },
                    body: fd
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        console.log("✅ Analisis selesai:", data.totalClips, "klip");
                        // Simpan state
                        var allClips = (data.clips || []).map(function(c) {
                            return {
                                id: c.id, start: c.start, end: c.end, duration: c.duration,
                                score: c.score, preview_text: c.preview_text || "", thumbnailUrl: c.thumbnailUrl || null
                            };
                        });
                        window.__TL_STATE = {
                            timeline: allClips, pool: [], initial: [...allClips],
                            analysisId: data.analysisId, _projectId: data.analysisId,
                            videoUrl: URL.createObjectURL(file)
                        };
                        // Sembunyikan upload
                        (document.getElementById("acUploadZone") || {}).style.display = "none";
                        (document.querySelector(".ac-settings") || {}).style.display = "none";
                        (document.getElementById("acProgress") || {}).style.display = "none";
                        // Tampilkan timeline
                        var _ed = document.getElementById("acTimelineEditor"); if (_ed) { _ed.classList.add("active"); _ed.style.display = "block"; }
                        document.body.classList.add("ac-timeline-active");
                        if (typeof renderTimeline === "function") renderTimeline();
                        if (typeof renderPool === "function") renderPool();
                        var videos = document.querySelectorAll("video");
                        videos.forEach(function(v) { v.src = window.__TL_STATE.videoUrl; v.load(); });
                        setTimeout(function() {
    // V9.271.0: PENGAMAN GLOBAL - Pastikan semua elemen ada sebelum akses .style
    var _safeStyle = function(element, prop, value) {
        if (element && element.style) {
            element.style[prop] = value;
        }
    }; if (editor) editor.scrollIntoView({ behavior: "smooth" }); }, 500);
                    } else {
                        alert("Gagal: " + (data.error || "Unknown"));
                    }
                })
                .catch(err => alert("Error: " + err.message));
            }
        };
        console.log("✅ Tombol Proses Video dipaksa!");
    }

    // 5. PAKSA TOMBOL RENDER
    function forceRender() {
        var btnAll = document.getElementById("tlRenderAllBtn");
        if (!btnAll || btnAll.dataset.forced) return;
        btnAll.dataset.forced = "true";
        btnAll.onclick = function(e) {
            e.preventDefault(); e.stopPropagation();
            if (typeof window.emergencyRender === "function") {
                window.emergencyRender();
            } else {
                alert("Fungsi render tidak tersedia. Silakan refresh.");
            }
        };
        console.log("✅ Tombol Render dipaksa!");
    }

    // 6. FUNGSI RENDER DARURAT
    window.emergencyRender = async function() {
        var st = window.__TL_STATE;
        if (!st || !st.timeline || st.timeline.length === 0) {
            alert("Tidak ada klip. Silakan upload video baru.");
            return;
        }
        var clips = [...st.timeline, ...st.pool];
        if (!confirm("Render " + clips.length + " klip sekarang?")) return;
        var token = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || "";
        var analysisId = st.analysisId || st._projectId;
        var preset = document.getElementById("acPreset")?.value || "1080p";

        for (var i = 0; i < clips.length; i++) {
            var clip = clips[i];
            console.log("[" + (i+1) + "/" + clips.length + "] Merender Klip #" + clip.id + "...");
            try {
                var res = await fetch("http://localhost:3000/api/render-clip/" + analysisId + "/" + clip.id, {
                    method: "POST",
                    headers: { "Authorization": "Bearer " + token, "Content-Type": "application/json" },
                    body: JSON.stringify({
                        preset: preset, vertical_crop: false,
                        enable_burn_subtitle: true, caption_style: "clean",
                        culture_region: "id"
                    })
                });
                var data = await res.json();
                if (data.success) console.log("✅ Klip #" + clip.id + " selesai: " + data.filename);
                else console.error("❌ Klip #" + clip.id + " gagal: " + (data.error || "Unknown"));
            } catch (e) {
                console.error("❌ Error: " + e.message);
            }
        }
        alert("Render selesai! Silakan cek folder results/.");
    };

    // 7. JALANKAN SEMUA FUNGSI
    document.addEventListener("DOMContentLoaded", function() {
        forceUpload();
        forcePanel();
        forceProcess();
        forceRender();
        setInterval(function() {
    // V9.271.0: PENGAMAN GLOBAL - Pastikan semua elemen ada sebelum akses .style
    var _safeStyle = function(element, prop, value) {
        if (element && element.style) {
            element.style[prop] = value;
        }
    };
            forceUpload();
            forcePanel();
            forceProcess();
            forceRender();
        }, 2000);
    });

    console.log("[V9.250.0] Perbaikan Permanen Aktif!");
})();