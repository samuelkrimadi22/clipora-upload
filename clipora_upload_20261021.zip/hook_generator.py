# ============================================================
# AI Hook Generator — V9.181.2 (AUTO_RETRY_503)
# AI Hook Generator — V9.181.1
# Generate judul + hook + caption otomatis dari transcript
# Pakai google-genai (library baru, non-deprecated)
# ============================================================
import os
import json
import sys
import re
from pathlib import Path
from typing import Optional, Dict, List

# Load .env otomatis
try:
    from dotenv import load_dotenv
    # Cari .env di folder yang sama
    env_path = Path(__file__).parent / ".env"
    if env_path.exists():
        load_dotenv(env_path)
        print(f"[HookGen] Loaded .env dari {env_path}", file=sys.stderr)
    else:
        # Fallback: cari di parent
        load_dotenv()
        print(f"[HookGen] Loaded .env (fallback)", file=sys.stderr)
except ImportError:
    print("[HookGen] python-dotenv tidak terinstall, pakai os.environ", file=sys.stderr)

# Coba import google-genai (baru)
try:
    from google import genai
    from google.genai import types
    HAS_GENAI = True
except ImportError:
    HAS_GENAI = False
    print("[HookGen] google-genai tidak terinstall. Jalankan: pip install google-genai", file=sys.stderr)

# ============================================================
# KONFIGURASI
# ============================================================
# V9.186.0: MULTI-KEY ROTATION
API_KEYS = []
for _i in range(1, 11):
    _name = "GEMINI_API_KEY" if _i == 1 else f"GEMINI_API_KEY_{_i}"
    _k = os.environ.get(_name, "").strip()
    if _k and _k != "YOUR_API_KEY_HERE":
        API_KEYS.append(_k)

GEMINI_API_KEY = API_KEYS[0] if API_KEYS else ""
_current_idx = 0
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.0-flash")

_client = None


def _get_client():
    """Return Gemini client pakai key yang aktif (rotasi)."""
    if not HAS_GENAI:
        print("[HookGen] google-genai tidak tersedia", file=sys.stderr)
        return None

    if not API_KEYS:
        print("[HookGen] Tidak ada API key di .env", file=sys.stderr)
        return None

    try:
        return genai.Client(api_key=API_KEYS[_current_idx])
    except Exception as e:
        print(f"[HookGen] Error init client: {e}", file=sys.stderr)
        return None


def _rotate_key():
    """Pindah ke key berikutnya (rotasi)."""
    global _current_idx
    _current_idx = (_current_idx + 1) % len(API_KEYS)
    print(f"[KeyRotate] → Key #{_current_idx + 1}/{len(API_KEYS)}", file=sys.stderr)


SYSTEM_PROMPT = """Kamu adalah content creator viral Indonesia yang expert dalam:
- Membuat judul YouTube/TikTok yang bikin orang klik
- Menulis hook 3 detik pertama yang bikin orang berhenti scroll
- Menulis caption media sosial yang engaging

Kamu paham psikologi audiens Indonesia:
- Suka judul yang bikin penasaran (curiosity gap)
- Suka angka & spesifik ("5 cara...", "3 rahasia...")
- Suka emosi (kaget, sedih, lucu, inspiratif)
- Suka relatability ("Kamu pasti pernah...")

Output HARUS dalam format JSON valid tanpa teks tambahan.
"""


def _build_prompt(transcript: str, title_hint: str = "", max_judul: int = 10) -> str:
    transcript_trim = transcript[:4000] if len(transcript) > 4000 else transcript
    hint_part = f"\nHint dari creator: {title_hint}" if title_hint else ""

    return f"""Analisis transcript video ini dan generate konten viral.{hint_part}

TRANSCRIPT:
\"\"\"
{transcript_trim}
\"\"\"

Generate JSON dengan struktur PERSIS seperti ini:

{{
  "judul": [
    "Judul 1 (max 60 char, catchy)",
    "... ({max_judul} judul total)"
  ],
  "hook": [
    "Hook 1 (max 15 kata, bikin berhenti scroll)",
    "... (5 hook total)"
  ],
  "caption": [
    {{
      "platform": "tiktok",
      "text": "Caption TikTok (max 150 char) engaging",
      "hashtags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"]
    }},
    {{
      "platform": "instagram",
      "text": "Caption IG (max 200 char) + emoji",
      "hashtags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"]
    }},
    {{
      "platform": "youtube",
      "text": "Deskripsi YouTube (max 300 char)",
      "hashtags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"]
    }}
  ],
  "topik_utama": "Topik utama video dalam 5-10 kata",
  "target_audiens": "Target audiens video ini",
  "mood": "Mood video (inspiratif/lucu/edukatif/sedih)"
}}

PENTING:
- Output HARUS JSON valid (bisa di-parse json.loads)
- JANGAN ada teks tambahan di luar JSON
- JANGAN pakai markdown code block
- Judul & hook dalam bahasa Indonesia natural
- Hashtag tanpa spasi
"""


def generate_hooks(
    transcript: str,
    title_hint: str = "",
    max_judul: int = 10,
) -> Optional[Dict]:
    if not transcript or len(transcript.strip()) < 20:
        print("[HookGen] Transcript terlalu pendek", file=sys.stderr)
        return None

    client = _get_client()
    if not client:
        return None

    prompt = _build_prompt(transcript, title_hint, max_judul)

    try:
        print(f"[HookGen] Generating hooks... ({len(transcript)} char)", file=sys.stderr)

        # V9.186.0: MULTI-KEY ROTATION + 503 RETRY
        import time
        max_retries = len(API_KEYS) * 2   # cukup untuk rotate semua key
        response = None
        last_error = None

        for attempt in range(1, max_retries + 1):
            try:
                client = _get_client()   # ambil key aktif
                response = client.models.generate_content(
                    model=GEMINI_MODEL,
                    contents=f"{SYSTEM_PROMPT}\n\n{prompt}",
                    config=types.GenerateContentConfig(
                        temperature=0.9,
                        top_p=0.95,
                        max_output_tokens=4096,
                    ),
                )
                if attempt > 1:
                    print(f"[HookGen] Berhasil di attempt {attempt} (key #{_current_idx + 1})", file=sys.stderr)
                break
            except Exception as e_retry:
                last_error = e_retry
                err_str = str(e_retry)

                # 429 = quota habis → rotate key
                if "429" in err_str or "RESOURCE_EXHAUSTED" in err_str:
                    print(f"[HookGen] Key #{_current_idx + 1} quota habis, rotate...", file=sys.stderr)
                    _rotate_key()
                    time.sleep(1)
                    continue

                # 503 = server overload → retry key sama
                if "503" in err_str or "UNAVAILABLE" in err_str or "high demand" in err_str:
                    if attempt < max_retries:
                        wait_time = 3 * (attempt % 3 + 1)
                        print(f"[HookGen] 503 overload, retry dalam {wait_time}s...", file=sys.stderr)
                        time.sleep(wait_time)
                        continue

                # Error lain → raise
                print(f"[HookGen] Error fatal: {err_str[:200]}", file=sys.stderr)
                raise

        if response is None:
            raise last_error or Exception("Gagal setelah retry")

        text = response.text.strip()
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        text = text.strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            print(f"[HookGen] JSON parse error: {e}", file=sys.stderr)
            print(f"[HookGen] Raw (500 char): {text[:500]}", file=sys.stderr)
            return None

        required_keys = ["judul", "hook", "caption"]
        for key in required_keys:
            if key not in data:
                print(f"[HookGen] Missing key: {key}", file=sys.stderr)
                return None

        print(f"[HookGen] OK — {len(data.get('judul', []))} judul, "
              f"{len(data.get('hook', []))} hook, "
              f"{len(data.get('caption', []))} caption", file=sys.stderr)

        return data

    except Exception as e:
        print(f"[HookGen] Error: {e}", file=sys.stderr)
        return None


def generate_hooks_from_words(words: List[Dict]) -> Optional[Dict]:
    if not words:
        return None
    transcript = " ".join([w.get("word", "") for w in words])
    return generate_hooks(transcript)


# ============================================================
# TEST
# ============================================================
if __name__ == "__main__":
    # Debug: cek API key
    if GEMINI_API_KEY:
        print(f"[DEBUG] GEMINI_API_KEY: {GEMINI_API_KEY[:15]}... ({len(GEMINI_API_KEY)} char)", file=sys.stderr)
    else:
        print(f"[DEBUG] GEMINI_API_KEY KOSONG", file=sys.stderr)

    test_transcript = """
    Halo semua, hari ini saya mau share 5 cara untuk meningkatkan produktivitas.
    Pertama, buat to-do list setiap pagi. Kedua, teknik pomodoro 25 menit kerja 5 menit istirahat.
    Ketiga, hindari multitasking. Keempat, olahraga rutin. Kelima, tidur cukup 7-8 jam.
    Dengan 5 cara ini, saya berhasil ningkatin produktivitas 2x lipat dalam 1 bulan.
    """

    print("\n=== Test AI Hook Generator ===\n")
    result = generate_hooks(test_transcript)

    if result:
        print("\n=== HASIL ===\n")
        print("JUDUL:")
        for i, j in enumerate(result.get("judul", []), 1):
            print(f"  {i}. {j}")

        print("\nHOOK:")
        for i, h in enumerate(result.get("hook", []), 1):
            print(f"  {i}. {h}")

        print("\nCAPTION:")
        for c in result.get("caption", []):
            print(f"  [{c.get('platform')}] {c.get('text')}")
            print(f"  Tags: {' '.join(c.get('hashtags', []))}\n")

        print(f"Topik: {result.get('topik_utama')}")
        print(f"Target: {result.get('target_audiens')}")
        print(f"Mood: {result.get('mood')}")
    else:
        print("GAGAL generate hooks")
