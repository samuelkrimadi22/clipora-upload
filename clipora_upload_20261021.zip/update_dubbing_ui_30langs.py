﻿from pathlib import Path

fp = Path("C:/xampp/htdocs/clipora/assets/js/dubbing-ui.js")
content = fp.read_text(encoding="utf-8-sig")

if "V9.183.2: DYNAMIC_LANGS" in content:
    print("[SKIP] Dynamic langs sudah ada")
    exit(0)

# Cari blok dropdown bahasa yang hardcoded
old_lang_select = '''      '<select id="acDubbingLang" style="width:100%;padding:10px 12px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#e8e8ef;font-size:13px;font-family:inherit;cursor:pointer;">' +
      '<option value="jawa">🇮🇩 Jawa</option>' +
      '<option value="sunda">🇮🇩 Sunda</option>' +
      '<option value="melayu">🇲🇾 Melayu</option>' +
      '<option value="id">🇮🇩 Indonesia</option>' +
      "</select>";'''

new_lang_select = '''      '<select id="acDubbingLang" style="width:100%;padding:10px 12px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#e8e8ef;font-size:13px;font-family:inherit;cursor:pointer;">' +
      '<option value="">Loading bahasa...</option>' +
      "</select>";'''

if old_lang_select in content:
    content = content.replace(old_lang_select, new_lang_select, 1)
    print("[OK] Dropdown bahasa diubah jadi placeholder")
else:
    print("[WARN] Pattern dropdown bahasa tidak ketemu persis — cek manual")
    # Coba pattern lebih longgar
    import re
    pattern = r"'<select id=\"acDubbingLang\"[^>]*>' \+\s*'<option[^']*>[^<]*</option>' \+\s*'<option[^']*>[^<]*</option>' \+\s*'<option[^']*>[^<]*</option>' \+\s*'<option[^']*>[^<]*</option>' \+\s*\"</select>\""
    if re.search(pattern, content):
        content = re.sub(pattern, new_lang_select, content, count=1)
        print("[OK] Dropdown diubah dengan regex")

# Tambah fungsi _loadLanguages kalau belum ada
if "_loadLanguages" not in content:
    marker = "  // ============================================================\n  // MODAL\n  // ============================================================"
    idx = content.find(marker)
    
    if idx < 0:
        # Coba marker lain
        marker = "  function openModal() {"
        idx = content.find(marker)
    
    if idx > 0:
        new_func = '''  // ============================================================
  // V9.183.2: DYNAMIC_LANGS - Load bahasa dari API
  // ============================================================
  function _loadLanguages() {
    var url = _getApiUrl() + "/api/dubbing/languages";
    var token = _getToken();

    fetch(url, {
      headers: { Authorization: "Bearer " + token },
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        if (!data.success || !data.languages) return;

        var select = document.getElementById("acDubbingLang");
        if (!select) return;

        // Group: native vs fallback
        var nativeLangs = data.languages.filter(function (l) {
          return l.native;
        });
        var fallbackLangs = data.languages.filter(function (l) {
          return !l.native;
        });

        var html = "";

        // Native group
        if (nativeLangs.length > 0) {
          html += '<optgroup label="⭐ Suara Asli (' + nativeLangs.length + ' bahasa)">';
          nativeLangs.forEach(function (l) {
            html += '<option value="' + l.code + '">' + l.name + "</option>";
          });
          html += "</optgroup>";
        }

        // Fallback group
        if (fallbackLangs.length > 0) {
          html += '<optgroup label="🔊 Suara Indonesia (fallback — ' + fallbackLangs.length + ' bahasa)">';
          fallbackLangs.forEach(function (l) {
            html += '<option value="' + l.code + '">' + l.name + "</option>";
          });
          html += "</optgroup>";
        }

        select.innerHTML = html;
        console.log("[DubbingUI] Loaded " + data.languages.length + " languages (" + nativeLangs.length + " native + " + fallbackLangs.length + " fallback)");
      })
      .catch(function (e) {
        console.warn("[DubbingUI] Load languages error:", e.message);
        // Fallback ke hardcoded minimal
        var select = document.getElementById("acDubbingLang");
        if (select) {
          select.innerHTML =
            '<option value="jawa">🇮🇩 Jawa</option>' +
            '<option value="sunda">🇮🇩 Sunda</option>' +
            '<option value="melayu">🇲🇾 Melayu</option>' +
            '<option value="id">🇮🇩 Indonesia</option>';
        }
      });
  }


'''
        content = content[:idx] + new_func + content[idx:]
        print("[OK] Fungsi _loadLanguages() ditambahkan")

# Panggil _loadLanguages() di openModal
if "// Load bahasa dari API" not in content:
    marker2 = "    document.body.appendChild(modal);"
    idx2 = content.find(marker2)
    if idx2 > 0:
        end_of_line = content.find("\n", idx2) + 1
        content = content[:end_of_line] + "\n    // Load bahasa dari API (V9.183.2)\n    _loadLanguages();\n" + content[end_of_line:]
        print("[OK] Panggilan _loadLanguages() ditambahkan")

fp.write_text(content, encoding="utf-8")
print("[SAVED] dubbing-ui.js diupdate")
