// V9.671.0: Theme orange projects.php — fix edit outline + stat cards
(function() {
  'use strict';

  function applyTheme() {
    document.querySelectorAll('a.prj-btn, button.prj-btn, .prj-btn').forEach(function(el) {
      if (el.dataset.v671 === 'true') return;
      el.dataset.v671 = 'true';
      var t = (el.textContent || '').trim().toLowerCase();

      if (t.indexOf('preview') !== -1) {
        el.classList.add('v671-preview');
      } else if (t.indexOf('edit') !== -1) {
        el.classList.add('v671-edit');
      } else if (t.indexOf('hapus') !== -1 || t.indexOf('delete') !== -1) {
        el.classList.add('v671-delete');
      } else if (t.indexOf('baru') !== -1 || t.indexOf('new') !== -1 || t.indexOf('create') !== -1) {
        el.classList.add('v671-new');
      }
    });

    var s = document.querySelector('#prjSearch, .prj-search');
    if (s && s.dataset.v671 !== 'true') {
      s.dataset.v671 = 'true';
      s.classList.add('v671-search');
    }

    // Stat cards — wrap inner
    document.querySelectorAll('[class*="stat" i]').forEach(function(el) {
      if (el.dataset.v671 === 'true') return;
      if (el.tagName === 'DIV' && el.querySelector('[class*="stat"]')) return; // skip parent
      el.dataset.v671 = 'true';
      el.classList.add('v671-stat');
    });
  }

  function injectCSS() {
    if (document.getElementById('v671-css')) return;

    var css = ''
      // Preview — orange solid
      + '.v671-preview { background: linear-gradient(135deg, #f59e0b, #d97706) !important; background-image: linear-gradient(135deg, #f59e0b, #d97706) !important; color: #fff !important; border: 1.5px solid transparent !important; box-shadow: 0 4px 14px rgba(245,158,11,0.4) !important; font-weight: 700 !important; }'
      + '.v671-preview:hover { transform: translateY(-2px) !important; box-shadow: 0 8px 24px rgba(245,158,11,0.6) !important; }'
      // EDIT — orange OUTLINE (transparan)
      + '.v671-edit, .v671-edit * { '
      + '  background: transparent !important; '
      + '  background-image: none !important; '
      + '  background-color: transparent !important; '
      + '  color: #f59e0b !important; '
      + '  border-color: rgba(245,158,11,0.6) !important; '
      + '  box-shadow: none !important; '
      + '  font-weight: 700 !important; '
      + '  text-shadow: none !important; '
      + '}'
      + '.v671-edit { border: 1.5px solid rgba(245,158,11,0.6) !important; border-radius: 8px !important; }'
      + '.v671-edit:hover, .v671-edit:hover * { background: rgba(245,158,11,0.15) !important; background-image: none !important; }'
      + '.v671-edit:hover { border-color: #f59e0b !important; transform: translateY(-2px) !important; box-shadow: 0 4px 12px rgba(245,158,11,0.2) !important; }'
      // Delete — red
      + '.v671-delete, .v671-delete * { background: rgba(239,68,68,0.1) !important; background-image: none !important; color: #ef4444 !important; border-color: rgba(239,68,68,0.4) !important; box-shadow: none !important; }'
      + '.v671-delete { border: 1.5px solid rgba(239,68,68,0.4) !important; }'
      + '.v671-delete:hover, .v671-delete:hover * { background: rgba(239,68,68,0.2) !important; }'
      // Proyek Baru — orange solid
      + '.v671-new { background: linear-gradient(135deg, #fbbf24, #f59e0b, #d97706) !important; background-image: linear-gradient(135deg, #fbbf24, #f59e0b, #d97706) !important; color: #fff !important; border: none !important; box-shadow: 0 6px 20px rgba(245,158,11,0.45) !important; font-weight: 800 !important; }'
      + '.v671-new:hover { transform: translateY(-2px) scale(1.02) !important; box-shadow: 0 10px 28px rgba(245,158,11,0.65) !important; }'
      // Search
      + '.v671-search { border-color: rgba(245,158,11,0.3) !important; }'
      + '.v671-search:focus { border-color: #f59e0b !important; box-shadow: 0 0 0 4px rgba(245,158,11,0.18) !important; outline: none !important; }'
      // STAT CARDS — RAPI (border atas gradient, bukan kiri)
      + '[class*="stat-card" i], [class*="prj-stat" i] { '
      + '  border: 1px solid rgba(255,255,255,0.08) !important; '
      + '  border-top: 3px solid #f59e0b !important; '
      + '  border-radius: 12px !important; '
      + '  background: linear-gradient(180deg, rgba(245,158,11,0.08) 0%, rgba(245,158,11,0.02) 100%) !important; '
      + '}'
      // Hapus border kiri dari CSS lama
      + '[class*="stat" i] { border-left: none !important; }'
      + '[class*="stat-card" i] i, [class*="stat" i] .fa, [class*="stat" i] .fas { color: #f59e0b !important; }'
      + '[class*="stat" i] .stat-number, [class*="stat" i] .stat-value { color: #f59e0b !important; font-weight: 800 !important; }'
      // Card hover
      + '.prj-card, [class*="prj-card"], [class*="project-card"] { transition: all 0.3s ease !important; }'
      + '.prj-card:hover, [class*="prj-card"]:hover { border-color: rgba(245,158,11,0.5) !important; transform: translateY(-4px) !important; box-shadow: 0 16px 40px rgba(245,158,11,0.2) !important; }'
      // Icon judul
      + 'h1 i, h2 i, h3 i, .fa-folder, .fa-folder-open { color: #f59e0b !important; }'
      // DRAFT badge
      + '[class*="draft" i] { background: linear-gradient(135deg, #f59e0b, #d97706) !important; color: #fff !important; }'
      // Scrollbar
      + '::-webkit-scrollbar-thumb { background: rgba(245,158,11,0.4) !important; }';

    var style = document.createElement('style');
    style.id = 'v671-css';
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);
  }

  injectCSS();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyTheme);
  } else {
    applyTheme();
  }
  [300, 800, 1500, 3000].forEach(function(ms) { setTimeout(applyTheme, ms); });

  console.log('[V9.671.0] Projects theme loaded');
})();