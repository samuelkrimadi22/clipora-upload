// ============================================================
// PANDUAN AWAL - V9.1.0 + V9.31.0: Ganti text
// Welcome modal + Interactive Tour (Spotlight + Tooltip)
// ============================================================
(function() {
    'use strict';

    const API = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.apiUrl) || '/api';
    const TOKEN = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || '';
    const IS_LOGGED_IN = window.CLIPORA_AUTH && window.CLIPORA_AUTH.isLoggedIn;
    const IS_ADMIN = window.CLIPORA_AUTH && window.CLIPORA_AUTH.isAdmin;

    if (!IS_LOGGED_IN || !TOKEN) return;
    if (IS_ADMIN) {
        console.log('👑 [Onboarding] Skip — admin');
        return;
    }

    if (window.__ONBOARDING_INIT__) return;
    window.__ONBOARDING_INIT__ = true;

    const overlay = document.getElementById('onboardingOverlay');
    if (!overlay) {
        console.warn('⚠️ [Onboarding] Overlay tidak ditemukan');
        return;
    }

    let _status = null;
    let _shownThisSession = false;

    // ============================================================
    // TOUR STEPS DEFINITION
    // ============================================================
    const TOUR_STEPS = [
        {
            id: 'upload',
            selector: '#uploadArea',
            title: '📤 Upload Video Anda',
            body: 'Drag & drop video ke sini, atau klik untuk pilih dari komputer. Maksimal <strong>500 MB</strong> per video.',
            position: 'bottom'
        },
        {
            id: 'mode',
            selector: '#contentCreatorMode, .mode-selector, #aggressiveness',
            title: '🎯 Pilih Mode Potong',
            body: 'Mode <strong>Content Creator</strong> memotong maksimal — video jadi paling padat. Cocok untuk TikTok/Reels.',
            position: 'bottom'
        },
        {
            id: 'subtitle',
            selector: '#enableBurnSubtitle, #generateSubtitle',
            title: '💬 Burn Subtitle',
            body: 'Aktifkan untuk <strong>menempelkan subtitle ke video</strong>. Otomatis dari audio — akurat dengan AI.',
            position: 'bottom'
        },
        {
            id: 'rapikan',
            selector: '#rapikanBtn',
            title: '🚀 Mulai Rapikan!',
            body: 'Klik tombol ini untuk memulai. AI akan <strong>menganalisis, memotong, dan merapikan</strong> video Anda dalam hitungan detik.',
            position: 'top'
        },
        {
            id: 'progress',
            selector: '#progressContainer',
            title: '📊 Progress Real-time',
            body: 'Pantau progress analisis di sini. Anda bisa <strong>membatalkan</strong> kapan saja kalau berubah pikiran.',
            position: 'top',
            fallback: true
        }
    ];

    // ============================================================
    // API CALL
    // ============================================================
    async function fetchStatus() {
        try {
            const r = await fetch(API + '/user/onboarding', {
                headers: { 'Authorization': 'Bearer ' + TOKEN },
                cache: 'no-store'
            });
            const d = await r.json();
            return d.success ? d : null;
        } catch (e) {
            console.warn('[Onboarding] Fetch error:', e.message);
            return null;
        }
    }

    async function markStep(step) {
        try {
            const r = await fetch(API + '/user/onboarding/step', {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + TOKEN,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ step })
            });
            const d = await r.json();
            return d.success ? d : null;
        } catch (e) {
            console.warn('[Onboarding] Mark step error:', e.message);
            return null;
        }
    }

    // ============================================================
    // WELCOME MODAL
    // ============================================================
    function showModal() {
        if (_shownThisSession) return;
        _shownThisSession = true;
        overlay.style.display = 'flex';
        requestAnimationFrame(() => overlay.classList.add('active'));
        console.log('🎉 [Onboarding] Welcome modal shown');
    }

    function hideModal() {
        overlay.classList.remove('active');
        setTimeout(() => overlay.style.display = 'none', 300);
    }

    // ============================================================
    // TOUR ENGINE
    // ============================================================
    const Tour = {
        currentStep: 0,
        active: false,
        elements: {
            overlay: null,
            backdrop: null,
            spotlight: null,
            tooltip: null,
        },
        target: null,
        raf: null,

        init() {
            // Buat DOM elemen
            const overlayEl = document.createElement('div');
            overlayEl.className = 'tour-overlay';
            overlayEl.innerHTML = `
                <div class="tour-backdrop"></div>
                <svg class="tour-spotlight" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
                    <defs>
                        <mask id="tourMask">
                            <rect width="100%" height="100%" fill="white"/>
                            <rect id="tourHole" x="0" y="0" width="0" height="0" rx="12" fill="black"/>
                        </mask>
                    </defs>
                    <rect width="100%" height="100%" fill="rgba(0,0,0,0.7)" mask="url(#tourMask)"/>
                </svg>
            `;
            document.body.appendChild(overlayEl);

            this.elements.overlay = overlayEl;
            this.elements.backdrop = overlayEl.querySelector('.tour-backdrop');
            this.elements.spotlight = overlayEl.querySelector('.tour-spotlight');

            // Buat tooltip
            const tooltipEl = document.createElement('div');
            tooltipEl.className = 'tour-tooltip';
            tooltipEl.innerHTML = `
                <div class="tour-header">
                    <span class="tour-step-count">Step <span id="tourStepNum">1</span> / ${TOUR_STEPS.length}</span>
                    <button class="tour-close" title="Tutup tour">&times;</button>
                </div>
                <h4 class="tour-title" id="tourTitle">-</h4>
                <p class="tour-body" id="tourBody">-</p>
                <div class="tour-progress-mini">
                    <div class="tour-progress-mini-fill" id="tourProgressFill" style="width:20%"></div>
                </div>
                <div class="tour-actions">
                    <button class="tour-btn-skip" id="tourBtnSkip">Lewati</button>
                    <button class="tour-btn-prev" id="tourBtnPrev" style="display:none;">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </button>
                    <button class="tour-btn-next" id="tourBtnNext">
                        Lanjut <i class="fas fa-arrow-right"></i>
                    </button>
                    <div class="tour-dots" id="tourDots"></div>
                </div>
            `;
            document.body.appendChild(tooltipEl);
            this.elements.tooltip = tooltipEl;

            // Bind events
            tooltipEl.querySelector('.tour-close').addEventListener('click', () => this.skip());
            tooltipEl.querySelector('#tourBtnSkip').addEventListener('click', () => this.skip());
            tooltipEl.querySelector('#tourBtnPrev').addEventListener('click', () => this.prev());
            tooltipEl.querySelector('#tourBtnNext').addEventListener('click', () => this.next());
            this.elements.backdrop.addEventListener('click', (e) => {
                // Klik di luar = skip
                if (e.target === this.elements.backdrop) this.skip();
            });

            // Resize handling
            window.addEventListener('resize', () => {
                if (this.active) this.updatePosition();
            });
        },

        renderDots() {
            const dots = this.elements.tooltip.querySelector('#tourDots');
            dots.innerHTML = TOUR_STEPS.map((_, i) =>
                `<span class="${i === this.currentStep ? 'active' : ''}"></span>`
            ).join('');
        },

        start() {
            if (this.active) return;
            this.active = true;
            this.currentStep = 0;
            this.elements.overlay.classList.add('active');
            this.show();
            console.log('🎬 [Tour] Started');
        },

        show() {
            const step = TOUR_STEPS[this.currentStep];
            if (!step) return this.finish();

            // Cari target element
            const targets = step.selector.split(',').map(s => s.trim());
            let el = null;
            for (const sel of targets) {
                el = document.querySelector(sel);
                if (el) break;
            }

            // Kalau tidak ketemu dan step punya fallback, skip
            if (!el) {
                if (step.fallback) {
                    console.log(`⚠️ [Tour] Target tidak ditemukan untuk "${step.id}" — skip`);
                    return this.next();
                }
                // Tampilkan tooltip di tengah layar
                el = null;
            }

            this.target = el;

            // Update tooltip content
            this.elements.tooltip.querySelector('#tourStepNum').textContent = this.currentStep + 1;
            this.elements.tooltip.querySelector('#tourTitle').textContent = step.title;
            this.elements.tooltip.querySelector('#tourBody').innerHTML = step.body;
            this.elements.tooltip.querySelector('#tourProgressFill').style.width =
                `${((this.currentStep + 1) / TOUR_STEPS.length) * 100}%`;

            // Prev button
            const prevBtn = this.elements.tooltip.querySelector('#tourBtnPrev');
            prevBtn.style.display = this.currentStep > 0 ? 'inline-flex' : 'none';

            // Next button text
            const nextBtn = this.elements.tooltip.querySelector('#tourBtnNext');
            const isLast = this.currentStep === TOUR_STEPS.length - 1;
            nextBtn.innerHTML = isLast
                ? 'Selesai <i class="fas fa-check"></i>'
                : 'Lanjut <i class="fas fa-arrow-right"></i>';

            this.renderDots();

            // Show tooltip
            this.elements.tooltip.classList.add('active');

            // Scroll target into view
            if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                // Tunggu scroll selesai, baru update posisi
                setTimeout(() => this.updatePosition(), 400);
                setTimeout(() => this.updatePosition(), 800);
            } else {
                // Tengah layar
                this.elements.tooltip.style.top = '50%';
                this.elements.tooltip.style.left = '50%';
                this.elements.tooltip.style.transform = 'translate(-50%, -50%)';
                this.elements.tooltip.setAttribute('data-arrow', 'none');
                this.clearSpotlight();
            }
        },

        updatePosition() {
            if (!this.elements.tooltip.classList.contains('active')) return;

            const step = TOUR_STEPS[this.currentStep];
            const el = this.target;

            if (!el) {
                this.clearSpotlight();
                return;
            }

            const rect = el.getBoundingClientRect();
            const tooltip = this.elements.tooltip;
            const hole = this.elements.overlay.querySelector('#tourHole');

            // Update spotlight hole (dengan padding)
            const pad = 8;
            hole.setAttribute('x', rect.left - pad);
            hole.setAttribute('y', rect.top - pad);
            hole.setAttribute('width', rect.width + pad * 2);
            hole.setAttribute('height', rect.height + pad * 2);

            // Tampilkan elemen di atas overlay
            el.classList.add('tour-target');

            // Posisi tooltip
            const ttRect = tooltip.getBoundingClientRect();
            let top, left, arrow = step.position || 'bottom';

            if (arrow === 'bottom') {
                top = rect.bottom + 16;
                left = rect.left + rect.width / 2 - ttRect.width / 2;
            } else if (arrow === 'top') {
                top = rect.top - ttRect.height - 16;
                left = rect.left + rect.width / 2 - ttRect.width / 2;
            } else if (arrow === 'right') {
                top = rect.top + rect.height / 2 - ttRect.height / 2;
                left = rect.right + 16;
            } else if (arrow === 'left') {
                top = rect.top + rect.height / 2 - ttRect.height / 2;
                left = rect.left - ttRect.width - 16;
            }

            // Boundary check
            const vw = window.innerWidth;
            const vh = window.innerHeight;
            const margin = 12;

            if (left < margin) left = margin;
            if (left + ttRect.width > vw - margin) left = vw - ttRect.width - margin;
            if (top < margin) top = margin;
            if (top + ttRect.height > vh - margin) top = vh - ttRect.height - margin;

            tooltip.style.top = top + 'px';
            tooltip.style.left = left + 'px';
            tooltip.style.transform = '';
            tooltip.setAttribute('data-arrow', arrow);
        },

        clearSpotlight() {
            const hole = this.elements.overlay.querySelector('#tourHole');
            if (hole) {
                hole.setAttribute('x', -1000);
                hole.setAttribute('y', -1000);
                hole.setAttribute('width', 0);
                hole.setAttribute('height', 0);
            }
        },

        next() {
            // Hapus class dari target lama
            if (this.target) this.target.classList.remove('tour-target');

            if (this.currentStep < TOUR_STEPS.length - 1) {
                this.currentStep++;
                this.show();
            } else {
                this.finish();
            }
        },

        prev() {
            if (this.target) this.target.classList.remove('tour-target');

            if (this.currentStep > 0) {
                this.currentStep--;
                this.show();
            }
        },

        async finish() {
            console.log('✅ [Tour] Finished');

            // Mark completed
            await markStep('tour_completed');

            // Hide
            this.destroy();
            showConfetti();
        },

        async skip() {
            console.log('⏭️ [Tour] Skipped');
            await markStep('tour_skipped');
            this.destroy();
        },

        destroy() {
            if (this.target) this.target.classList.remove('tour-target');
            this.elements.tooltip.classList.remove('active');
            this.elements.overlay.classList.remove('active');

            setTimeout(() => {
                if (this.elements.overlay.parentNode) this.elements.overlay.remove();
                if (this.elements.tooltip.parentNode) this.elements.tooltip.remove();
            }, 300);

            this.active = false;
        }
    };

    // ============================================================
    // CONFETTI
    // ============================================================
    function showConfetti() {
        const colors = ['#f59e0b', '#d97706', '#22c55e', '#06b6d4', '#8b5cf6', '#ec4899'];
        const container = document.createElement('div');
        container.className = 'tour-confetti';
        document.body.appendChild(container);

        for (let i = 0; i < 60; i++) {
            const piece = document.createElement('div');
            piece.className = 'confetti-piece';
            piece.style.left = Math.random() * 100 + '%';
            piece.style.background = colors[Math.floor(Math.random() * colors.length)];
            piece.style.animationDelay = (Math.random() * 0.5) + 's';
            piece.style.animationDuration = (2.5 + Math.random() * 1.5) + 's';
            piece.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
            piece.style.width = (6 + Math.random() * 8) + 'px';
            piece.style.height = piece.style.width;
            container.appendChild(piece);
        }

        setTimeout(() => {
            if (container.parentNode) container.remove();
        }, 4500);
    }

    // ============================================================
    // ACTIONS
    // ============================================================
    window.onboardingStart = async function() {
        await markStep('welcome_seen');
        hideModal();
        setTimeout(() => Tour.start(), 400);
        console.log('🎬 [Onboarding] Tour started');
    };

    window.onboardingSkip = async function() {
        await markStep('tour_skipped');
        hideModal();
        console.log('⏭️ [Onboarding] Skipped');
    };

    // ============================================================
    // INIT
    // ============================================================
    async function init() {
        // Init tour engine
        Tour.init();

        const status = await fetchStatus();
        if (!status) return;
        _status = status;

        const o = status.onboarding;
        const shouldShowWelcome = !o.welcome_seen && !o.tour_completed && !o.tour_skipped;

        if (shouldShowWelcome) {
            setTimeout(showModal, 800);
        } else if (o.welcome_seen && !o.tour_completed && !o.tour_skipped) {
            // Welcome sudah dilihat, tour belum selesai
            // Bisa resume tour kalau mau
            console.log('ℹ️ [Onboarding] Welcome seen, tour belum selesai');
        } else {
            console.log('✅ [Onboarding] Completed');
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    window.__onboarding = {
        fetchStatus,
        markStep,
        startTour: () => Tour.start(),
        getStatus: () => _status,
    };
})();