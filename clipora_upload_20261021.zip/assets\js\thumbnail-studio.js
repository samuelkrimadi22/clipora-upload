/* ============================================================
   THUMBNAIL STUDIO — V1.0.0
   Client-side editor pakai Fabric.js
   ============================================================ */
(function () {
    'use strict';

    const state = {
        canvas: null,
        bgImage: null,
        titleText: null,
        subtitleText: null,
        currentColor: '#ffffff',
        currentFont: 'Bebas Neue',
        currentPos: 'middle',
        bgEnabled: false,
        bgColor: '#000000',
        // V9.139.1: PAKET B v2
        currentTemplate: 'bold',
        sizeMultiplier: 1.0,
        strokeWidth: 4,
        currentW: 1280,
        currentH: 720,
    };

    // ============================================================
    // INIT CANVAS
    // ============================================================
    function initCanvas() {
        const wrap = document.getElementById('tsCanvasWrap');
        const canvasEl = document.getElementById('tsCanvas');
        if (!wrap || !canvasEl) return;

        state.canvas = new fabric.Canvas('tsCanvas', {
            width: state.currentW,
            height: state.currentH,
            backgroundColor: '#000',
        });

        // Bikin canvas responsive (scale down biar muat)
        resizeCanvasForDisplay();
        window.addEventListener('resize', resizeCanvasForDisplay);
    }

    function resizeCanvasForDisplay() {
        // V9.140.6: CSS SCALE - canvas tetap ukuran asli, CSS yang scale
        if (!state.canvas) return;
        // Tidak set zoom, biarkan CSS handle
        state.canvas.renderAll();
    }

    // ============================================================
    // UPLOAD FOTO
    // ============================================================
    function handleUpload(file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            fabric.Image.fromURL(e.target.result, function (img) {
                if (!state.canvas) return;

                // Tampilkan canvas, sembunyikan empty state
                document.getElementById('tsEmptyState').style.display = 'none';
                document.getElementById('tsCanvasWrap').classList.add('active'); // V9.141.1

                // Fit image ke canvas (cover)
                const cw = state.currentW;
                const ch = state.currentH;
                const iw = img.width;
                const ih = img.height;
                const scale = Math.max(cw / iw, ch / ih);
                img.set({
                    scaleX: scale,
                    scaleY: scale,
                    left: (cw - iw * scale) / 2,
                    top: (ch - ih * scale) / 2,
                    selectable: false,
                    evented: false,
                });

                state.canvas.clear();
                state.canvas.add(img);
                state.bgImage = img;

                // Add text overlay
                addTexts();

                state.canvas.renderAll();
                document.getElementById('tsDownloadBtn').disabled = false;

                // Resize display
                resizeCanvasForDisplay();
            });
        };
        reader.readAsDataURL(file);
    }

    // ============================================================
    // ADD / UPDATE TEXT
    // ============================================================
    function addTexts() {
        if (!state.canvas) return;

        const titleVal = document.getElementById('tsTitle').value || '';
        const subVal = document.getElementById('tsSubtitle').value || '';

        // Remove existing texts
        if (state.titleText) state.canvas.remove(state.titleText);
        if (state.subtitleText) state.canvas.remove(state.subtitleText);

        // V9.138.0: FASE 2 - hitung posisi Y berdasarkan preset
        let titleY, subY;
        if (state.currentPos === 'top') {
            titleY = state.currentH * 0.20;
            subY = state.currentH * 0.32;
        } else if (state.currentPos === 'bottom') {
            titleY = state.currentH * 0.70;
            subY = state.currentH * 0.83;
        } else { // middle
            titleY = state.currentH * 0.45;
            subY = state.currentH * 0.58;
        }

        // V9.138.0: FASE 2 - background config
        const bgProps = state.bgEnabled ? {
            backgroundColor: state.bgColor,
            padding: Math.round(state.currentW * 0.02),
        } : {};

        // Title (bold, besar)
        state.titleText = new fabric.Textbox(titleVal, Object.assign({
            left: state.currentW / 2,
            top: titleY,
            originX: 'center',
            originY: 'center',
            width: state.currentW * 0.85,
            fontFamily: state.currentFont + ', sans-serif',
            fontSize: Math.round(state.currentW * 0.09 * state.sizeMultiplier),
            fontWeight: 'bold',
            fill: state.currentColor,
            stroke: '#000',
            strokeWidth: state.strokeWidth,
            // V9.140.3: PAKET C v4 - interactive
            selectable: true,
            evented: true,
            hasControls: true,
            hasBorders: true,
            transparentCorners: false,
            cornerColor: '#f59e0b',
            cornerSize: 12,
            cornerStyle: 'circle',
            borderColor: '#f59e0b',
            paintFirst: 'stroke',
            textAlign: 'center',
            shadow: 'rgba(0,0,0,0.8) 2px 2px 6px',
        }, bgProps));

        // Subtitle (kecil, di bawah)
        if (subVal) {
            state.subtitleText = new fabric.Textbox(subVal, Object.assign({
                left: state.currentW / 2,
                top: subY,
                originX: 'center',
                originY: 'center',
                width: state.currentW * 0.85,
                fontFamily: 'Poppins, sans-serif',
                fontSize: Math.round(state.currentW * 0.035 * state.sizeMultiplier),
                fontWeight: 'bold',
                fill: '#ffffff',
                stroke: '#000',
                strokeWidth: 3,
                paintFirst: 'stroke',
                textAlign: 'center',
                shadow: 'rgba(0,0,0,0.8) 2px 2px 4px',
            }, bgProps));
        }

        state.canvas.add(state.titleText);
        if (state.subtitleText) state.canvas.add(state.subtitleText);
        state.canvas.renderAll();
    }

    function updateTexts() {
        if (!state.canvas) return;
        const titleVal = document.getElementById('tsTitle').value || '';
        const subVal = document.getElementById('tsSubtitle').value || '';

        if (state.titleText) {
            state.titleText.set('text', titleVal);
        }
        if (state.subtitleText) {
            state.subtitleText.set('text', subVal);
        }
        state.canvas.renderAll();
    }

    function updateColor(color) {
        state.currentColor = color;
        if (state.titleText) {
            state.titleText.set('fill', color);
        }
        if (state.canvas) state.canvas.renderAll();
    }

    // ============================================================
    // CHANGE ASPECT RATIO
    // ============================================================
    function changeAspect(w, h) {
        state.currentW = w;
        state.currentH = h;

        if (state.bgImage) {
            // Re-upload logic — simplest: clear & re-add
            const imgSrc = state.bgImage._element ? state.bgImage._element.src : null;
            if (imgSrc) {
                fabric.Image.fromURL(imgSrc, function (img) {
                    const cw = w, ch = h;
                    const iw = img.width, ih = img.height;
                    const scale = Math.max(cw / iw, ch / ih);
                    img.set({
                        scaleX: scale, scaleY: scale,
                        left: (cw - iw * scale) / 2,
                        top: (ch - ih * scale) / 2,
                        selectable: false, evented: false,
                    });
                    state.canvas.clear();
                    state.canvas.add(img);
                    state.bgImage = img;
                    addTexts();
                    // V9.140.6: keep canvas internal size
                    state.canvas.setDimensions({ width: cw, height: ch });
                    resizeCanvasForDisplay();
                });
            }
        } else {
            state.canvas.setDimensions({ width: w, height: h });
            resizeCanvasForDisplay();
        }
    }

    // ============================================================
    // DOWNLOAD
    // ============================================================
    function download() {
        if (!state.canvas) return;

        // Temporarily reset zoom for full-res export
        const prevZoom = state.canvas.getZoom();
        state.canvas.setZoom(1);
        state.canvas.setDimensions({ width: state.currentW, height: state.currentH });
        state.canvas.renderAll();

        const dataURL = state.canvas.toDataURL({
            format: 'png',
            quality: 1,
            multiplier: 1,
        });

        // Restore
        state.canvas.setZoom(prevZoom);
        resizeCanvasForDisplay();

        // Trigger download
        const a = document.createElement('a');
        a.href = dataURL;
        a.download = 'thumbnail-' + Date.now() + '.png';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    }

    // ============================================================
    // EVENT LISTENERS
    // ============================================================
    function bindEvents() {
        document.getElementById('tsFileInput')?.addEventListener('change', function (e) {
            const file = e.target.files && e.target.files[0];
            if (file) handleUpload(file);
        });

        document.getElementById('tsTitle')?.addEventListener('input', updateTexts);
        document.getElementById('tsSubtitle')?.addEventListener('input', updateTexts);

        document.querySelectorAll('.ts-color-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                document.querySelectorAll('.ts-color-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                updateColor(btn.dataset.color);
            });
        });

        document.querySelectorAll('.ts-aspect-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                document.querySelectorAll('.ts-aspect-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                changeAspect(parseInt(btn.dataset.w), parseInt(btn.dataset.h));
            });
        });

        // V9.138.0: FASE 2 - Font selector
        document.getElementById('tsFont')?.addEventListener('change', function (e) {
            state.currentFont = e.target.value;
            addTexts();
        });

        // V9.138.0: FASE 2 - Position preset
        document.querySelectorAll('.ts-pos-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                document.querySelectorAll('.ts-pos-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                state.currentPos = btn.dataset.pos;
                addTexts();
            });
        });

        // V9.138.0: FASE 2 - Background toggle
        document.getElementById('tsBgEnabled')?.addEventListener('change', function (e) {
            state.bgEnabled = e.target.checked;
            const row = document.getElementById('tsBgColorRow');
            if (row) {
                row.style.opacity = state.bgEnabled ? '1' : '0.4';
                row.style.pointerEvents = state.bgEnabled ? 'auto' : 'none';
            }
            addTexts();
        });

        // V9.138.0: FASE 2 - Background color
        document.querySelectorAll('.ts-bgcolor-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                document.querySelectorAll('.ts-bgcolor-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                state.bgColor = btn.dataset.bg;
                addTexts();
            });
        });

        // V9.138.0: FASE 2 - Custom color picker
        // Tambah tombol "+" ke color row pertama
        const firstColorRow = document.querySelector('.ts-color-row');
        if (firstColorRow && !firstColorRow.querySelector('.custom-picker')) {
            const pickerBtn = document.createElement('button');
            pickerBtn.className = 'ts-color-btn custom-picker';
            pickerBtn.title = 'Pilih warna kustom';
            firstColorRow.appendChild(pickerBtn);

            const nativeColor = document.createElement('input');
            nativeColor.type = 'color';
            nativeColor.value = state.currentColor;
            nativeColor.style.display = 'none';
            firstColorRow.appendChild(nativeColor);

            pickerBtn.addEventListener('click', function () {
                nativeColor.click();
            });

            nativeColor.addEventListener('input', function (e) {
                state.currentColor = e.target.value;
                document.querySelectorAll('.ts-color-btn').forEach(b => b.classList.remove('active'));
                pickerBtn.classList.add('active');
                updateColor(state.currentColor);
            });
        }

        document.getElementById('tsDownloadBtn')?.addEventListener('click', download);

        // Drag & drop pada canvas area
        const dropZone = document.querySelector('.ts-canvas-area');
        if (dropZone) {
            dropZone.addEventListener('dragover', function (e) {
                e.preventDefault();
                dropZone.style.borderColor = '#f59e0b';
            });
            dropZone.addEventListener('dragleave', function () {
                dropZone.style.borderColor = 'rgba(255,255,255,0.08)';
            });
            dropZone.addEventListener('drop', function (e) {
                e.preventDefault();
                dropZone.style.borderColor = 'rgba(255,255,255,0.08)';
                const file = e.dataTransfer.files && e.dataTransfer.files[0];
                if (file && file.type.startsWith('image/')) handleUpload(file);
            });
        }
    }

    // ============================================================
    // BOOT
    // ============================================================
    document.addEventListener('DOMContentLoaded', function () {
        initCanvas();
        bindEvents();
        console.log('[ThumbnailStudio] Ready v1.0.0');
    });

    window.ThumbnailStudio = { state, download };

// ============================================================
// V9.139.1: PAKET B v2 - APPEND MODULE (safe)
// ============================================================
(function() {
    'use strict';

    const TEMPLATES = {
        minimalist: { font: 'Poppins', color: '#ffffff', bgEnabled: false, position: 'bottom', sizeMultiplier: 0.7, strokeWidth: 0 },
        bold:       { font: 'Bebas Neue', color: '#fbbf24', bgEnabled: false, position: 'middle', sizeMultiplier: 1.0, strokeWidth: 4 },
        tiktok:     { font: 'Poppins', color: '#ec4899', bgEnabled: true, bgColor: '#000000', position: 'top', sizeMultiplier: 1.1, strokeWidth: 3 },
        podcast:    { font: 'Poppins', color: '#ffffff', bgEnabled: true, bgColor: '#000000', position: 'bottom', sizeMultiplier: 0.85, strokeWidth: 0 },
        gaming:     { font: 'Anton', color: '#fbbf24', bgEnabled: false, position: 'middle', sizeMultiplier: 1.2, strokeWidth: 6 },
    };

    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            if (!window.ThumbnailStudio || !window.ThumbnailStudio.state) {
                console.warn('[PaketB] ThumbnailStudio not ready');
                return;
            }

            const state = window.ThumbnailStudio.state;
            console.log('[PaketB] Ready v2');

            // -- Apply template --
            function applyTemplate(name) {
                const tpl = TEMPLATES[name];
                if (!tpl) return;

                state.currentTemplate = name;
                state.currentFont = tpl.font;
                state.currentColor = tpl.color;
                state.currentPos = tpl.position;
                state.sizeMultiplier = tpl.sizeMultiplier;
                state.strokeWidth = tpl.strokeWidth;
                state.bgEnabled = tpl.bgEnabled || false;
                if (tpl.bgColor) state.bgColor = tpl.bgColor;

                // Sync UI
                const fontSel = document.getElementById('tsFont');
                if (fontSel) fontSel.value = tpl.font;

                const sizeSlider = document.getElementById('tsSizeSlider');
                if (sizeSlider) {
                    sizeSlider.value = Math.round(tpl.sizeMultiplier * 100);
                    const sv = document.getElementById('tsSizeVal');
                    if (sv) sv.textContent = Math.round(tpl.sizeMultiplier * 100) + '%';
                }
                const strokeSlider = document.getElementById('tsStrokeSlider');
                if (strokeSlider) {
                    strokeSlider.value = tpl.strokeWidth;
                    const sv = document.getElementById('tsStrokeVal');
                    if (sv) sv.textContent = tpl.strokeWidth + 'px';
                }

                document.querySelectorAll('.ts-pos-btn').forEach(b => {
                    b.classList.toggle('active', b.dataset.pos === tpl.position);
                });

                const bgToggle = document.getElementById('tsBgEnabled');
                if (bgToggle) {
                    bgToggle.checked = state.bgEnabled;
                    const row = document.getElementById('tsBgColorRow');
                    if (row) {
                        row.style.opacity = state.bgEnabled ? '1' : '0.4';
                        row.style.pointerEvents = state.bgEnabled ? 'auto' : 'none';
                    }
                }

                document.querySelectorAll('.ts-color-btn').forEach(b => {
                    b.classList.toggle('active', b.dataset.color === tpl.color);
                });

                // Trigger re-render
                if (window.ThumbnailStudio.state && window.ThumbnailStudio.state.canvas) {
                    const evt = new Event('change');
                    document.getElementById('tsTitle')?.dispatchEvent(evt);
                    document.getElementById('tsSubtitle')?.dispatchEvent(evt);
                }

                console.log('[PaketB] Template: ' + name);
            }

            window.ThumbnailStudio.applyTemplate = applyTemplate;

            // -- Bind template buttons --
            document.querySelectorAll('.ts-template-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.ts-template-btn').forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                    applyTemplate(btn.dataset.tpl);
                });
            });

            // -- Bind size slider --
            document.getElementById('tsSizeSlider')?.addEventListener('input', function(e) {
                state.sizeMultiplier = e.target.value / 100;
                const sv = document.getElementById('tsSizeVal');
                if (sv) sv.textContent = e.target.value + '%';
                document.getElementById('tsTitle')?.dispatchEvent(new Event('input'));
            });

            // -- Bind stroke slider --
            document.getElementById('tsStrokeSlider')?.addEventListener('input', function(e) {
                state.strokeWidth = parseInt(e.target.value);
                const sv = document.getElementById('tsStrokeVal');
                if (sv) sv.textContent = e.target.value + 'px';
                document.getElementById('tsTitle')?.dispatchEvent(new Event('input'));
            });

            // -- Bind reset --
            document.getElementById('tsResetBtn')?.addEventListener('click', function() {
                document.getElementById('tsTitle').value = 'JUDUL VIDEO';
                document.getElementById('tsSubtitle').value = 'Subtitle di sini';
                document.querySelectorAll('.ts-template-btn').forEach(b => b.classList.remove('active'));
                document.querySelector('.ts-template-btn[data-tpl="bold"]')?.classList.add('active');
                applyTemplate('bold');
            });
        }, 300);
    });
})();

// ============================================================
// V9.140.3: PAKET C v4 - APPEND MODULE (safe, emoji icons)
// ============================================================
(function() {
    'use strict';

    const BORDERS = {
        none:    { color: 'transparent', width: 0 },
        simple:  { color: '#ffffff', width: 8 },
        black:   { color: '#000000', width: 8 },
        rounded: { color: '#ffffff', width: 8, radius: 40 },
        neon:    { color: '#f59e0b', width: 10, radius: 15, glow: true },
        vintage: { color: '#fef3c7', width: 12 },
        pink:    { color: '#ec4899', width: 8 },
        blue:    { color: '#3b82f6', width: 8 },
        green:   { color: '#10b981', width: 8 },
        thick:   { color: '#ffffff', width: 20 },
    };

    const EMOJI = {
        star: '⭐', heart: '❤️', fire: '🔥', bolt: '⚡',
        check: '✅', times: '❌', arrow: '➡️', play: '▶️',
        gift: '🎁', crown: '👑', bell: '🔔', like: '👍',
    };

    let borderRect = null;

    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            if (!window.ThumbnailStudio || !window.ThumbnailStudio.state) {
                console.warn('[PaketC] ThumbnailStudio not ready');
                return;
            }
            const state = window.ThumbnailStudio.state;
            console.log('[PaketC] Ready v4');

            // -- Border --
            function applyBorder(name) {
                if (!state.canvas) return;

                if (borderRect) {
                    state.canvas.remove(borderRect);
                    borderRect = null;
                }

                const b = BORDERS[name];
                if (!b || name === 'none') {
                    state.canvas.renderAll();
                    console.log('[PaketC] Border: none');
                    return;
                }

                const inset = b.width / 2 + 4;
                const rect = new fabric.Rect({
                    left: inset,
                    top: inset,
                    width: state.currentW - inset * 2,
                    height: state.currentH - inset * 2,
                    fill: 'transparent',
                    stroke: b.color,
                    strokeWidth: b.width,
                    rx: b.radius || 0,
                    ry: b.radius || 0,
                    selectable: false,
                    evented: false,
                    shadow: b.glow ? 'rgba(245,158,11,0.8) 0 0 20px' : null,
                });

                borderRect = rect;
                state.canvas.add(rect);
                state.canvas.sendToBack(rect);
                if (state.bgImage) state.canvas.bringToFront(state.bgImage);
                state.canvas.sendToBack(rect);
                if (state.titleText) state.canvas.bringToFront(state.titleText);
                if (state.subtitleText) state.canvas.bringToFront(state.subtitleText);

                state.canvas.renderAll();
                console.log('[PaketC] Border: ' + name);
            }

            // -- Icon --
            function addIcon(name) {
                if (!state.canvas) return;

                const emoji = EMOJI[name] || '⭐';
                const size = Math.round(state.currentW * 0.12);

                const icon = new fabric.Text(emoji, {
                    left: state.currentW * 0.82,
                    top: state.currentH * 0.18,
                    originX: 'center',
                    originY: 'center',
                    fontFamily: 'Segoe UI Emoji, Apple Color Emoji, sans-serif',
                    fontSize: size,
                    selectable: true,
                    evented: true,
                    hasControls: true,
                    hasBorders: true,
                    transparentCorners: false,
                    cornerColor: '#f59e0b',
                    cornerSize: 12,
                    cornerStyle: 'circle',
                    borderColor: '#f59e0b',
                });

                state.canvas.add(icon);
                state.canvas.setActiveObject(icon);
                state.canvas.renderAll();
                console.log('[PaketC] Icon: ' + name + ' ' + emoji);
            }

            window.ThumbnailStudio.applyBorder = applyBorder;
            window.ThumbnailStudio.addIcon = addIcon;

            // -- Bind border --
            document.querySelectorAll('.ts-border-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.ts-border-btn').forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                    applyBorder(btn.dataset.border);
                });
            });

            // -- Bind icon --
            document.querySelectorAll('.ts-icon-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    addIcon(btn.dataset.icon);
                });
            });

            // -- Double-click text edit --
            if (state.canvas) {
                state.canvas.on('mouse:dblclick', function(opt) {
                    if (opt.target && (opt.target === state.titleText || opt.target === state.subtitleText)) {
                        const newText = prompt('Edit text:', opt.target.text);
                        if (newText !== null) {
                            opt.target.set('text', newText);
                            state.canvas.renderAll();
                        }
                    }
                });
            }

        }, 500);
    });
})();

// ============================================================
// V9.141.7: REDESIGN JS - sidebar + action bar
// ============================================================
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            if (!window.ThumbnailStudio) return;
            console.log('[Redesign] Ready');

            // --- Sidebar scroll navigation ---
            document.querySelectorAll('.ts-sidebar-btn[data-scroll]').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.ts-sidebar-btn').forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');

                    const target = btn.dataset.scroll;
                    const panelBody = document.getElementById('tsPanelBody');
                    if (!panelBody) return;

                    // Cari section di panel yang cocok
                    const sections = panelBody.querySelectorAll('.ts-section');
                    const labelMap = {
                        upload: 'upload',
                        template: 'template',
                        text: 'text',
                        color: 'warna',
                        border: 'border',
                        icon: 'icon',
                    };
                    const keyword = labelMap[target] || target;

                    sections.forEach(sec => {
                        const label = sec.querySelector('.ts-label');
                        if (label && label.textContent.toLowerCase().includes(keyword)) {
                            sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                    });
                });
            });

            // --- Sidebar Reset ---
            document.getElementById('tsSidebarReset')?.addEventListener('click', function() {
                const resetBtn = document.getElementById('tsResetBtn');
                if (resetBtn) resetBtn.click();
            });

            // --- Sidebar Download ---
            document.getElementById('tsSidebarDownload')?.addEventListener('click', function() {
                const dlBtn = document.getElementById('tsDownloadBtn');
                if (dlBtn) dlBtn.click();
            });

            // --- Main action bar: Download ---
            document.getElementById('tsMainDownloadBtn')?.addEventListener('click', function() {
                const dlBtn = document.getElementById('tsDownloadBtn');
                if (dlBtn) dlBtn.click();
            });

            // --- Show action bar saat foto di-upload ---
            const canvasWrap = document.getElementById('tsCanvasWrap');
            const actionsBar = document.getElementById('tsCanvasActions');
            if (canvasWrap && actionsBar) {
                const observer = new MutationObserver(function() {
                    if (canvasWrap.classList.contains('active')) {
                        actionsBar.style.display = 'flex';
                    } else {
                        actionsBar.style.display = 'none';
                    }
                });
                observer.observe(canvasWrap, { attributes: true, attributeFilter: ['class'] });
            }
        }, 700);
    });
})();

// ============================================================
// V9.141.9: REDESIGN v2 JS - DOM injection (100% safe)
// ============================================================
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            const wrap = document.querySelector('.ts-wrap');
            if (!wrap) {
                console.warn('[Redesign v2] .ts-wrap tidak ketemu');
                return;
            }

            // Tandai wrap dengan class baru
            wrap.classList.add('ts-v2');
            console.log('[Redesign v2] Init');

            // ============================================================
            // 1. INJECT SIDEBAR (kiri)
            // ============================================================
            const sidebar = document.createElement('aside');
            sidebar.className = 'ts-sidebar';
            sidebar.innerHTML = [
                '<button class="ts-sidebar-btn active" data-scroll="upload" title="Upload">',
                '  <i class="fas fa-cloud-upload-alt"></i>',
                '</button>',
                '<button class="ts-sidebar-btn" data-scroll="template" title="Template">',
                '  <i class="fas fa-th-large"></i>',
                '</button>',
                '<button class="ts-sidebar-btn" data-scroll="text" title="Text">',
                '  <i class="fas fa-font"></i>',
                '</button>',
                '<button class="ts-sidebar-btn" data-scroll="warna" title="Warna">',
                '  <i class="fas fa-palette"></i>',
                '</button>',
                '<button class="ts-sidebar-btn" data-scroll="border" title="Border">',
                '  <i class="fas fa-border-all"></i>',
                '</button>',
                '<button class="ts-sidebar-btn" data-scroll="icon" title="Icon">',
                '  <i class="fas fa-icons"></i>',
                '</button>',
                '<div class="ts-sidebar-divider"></div>',
                '<button class="ts-sidebar-btn" id="tsSidebarReset" title="Reset">',
                '  <i class="fas fa-undo"></i>',
                '</button>',
                '<button class="ts-sidebar-btn" id="tsSidebarDownload" title="Download">',
                '  <i class="fas fa-download"></i>',
                '</button>',
            ].join('');

            wrap.insertBefore(sidebar, wrap.firstChild);

            // ============================================================
            // 2. WRAP PANEL BODY (dengan header + body + footer)
            // ============================================================
            const panel = wrap.querySelector('.ts-panel');
            if (panel) {
                // Cari h3 existing
                const h3 = panel.querySelector('h3');
                const panelHTML = [];

                // Header baru
                const header = document.createElement('div');
                header.className = 'ts-panel-header';
                header.innerHTML = '<h3><i class="fas fa-paint-brush"></i> Thumbnail Studio</h3>';

                // Body wrapper
                const body = document.createElement('div');
                body.className = 'ts-panel-body';
                body.id = 'tsPanelBody';

                // Footer wrapper (untuk tombol Download)
                const footer = document.createElement('div');
                footer.className = 'ts-panel-footer';

                // Pindahkan semua child panel (kecuali h3) ke body
                const children = Array.from(panel.children);
                children.forEach(function(child) {
                    if (child.tagName === 'H3') return;
                    body.appendChild(child);
                });

                // Kalau h3 ada, hapus
                if (h3) h3.remove();

                // Cari tombol Download (di body) — pindahkan ke footer
                const dlBtn = body.querySelector('#tsDownloadBtn');
                if (dlBtn) {
                    // Bungkus di footer
                    footer.appendChild(dlBtn);
                }

                // Append header + body + footer ke panel
                panel.appendChild(header);
                panel.appendChild(body);
                if (footer.children.length > 0) {
                    panel.appendChild(footer);
                }
                console.log('[Redesign v2] Panel wrapped');
            }

            // ============================================================
            // 3. TAMBAH ACTION BAR DI BAWAH CANVAS
            // ============================================================
            const canvasArea = wrap.querySelector('.ts-canvas-area');
            if (canvasArea) {
                const actionBar = document.createElement('div');
                actionBar.className = 'ts-canvas-actions';
                actionBar.id = 'tsCanvasActions';
                actionBar.style.display = 'none';
                actionBar.innerHTML = [
                    '<button class="ts-download-btn" id="tsMainDownloadBtn" style="width:auto;padding:10px 20px">',
                    '  <i class="fas fa-download"></i> Download PNG',
                    '</button>',
                ].join('');
                canvasArea.appendChild(actionBar);
                console.log('[Redesign v2] Action bar added');
            }

            // ============================================================
            // 4. EVENT: Sidebar scroll navigation
            // ============================================================
            sidebar.querySelectorAll('.ts-sidebar-btn[data-scroll]').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    sidebar.querySelectorAll('.ts-sidebar-btn').forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');

                    const keyword = btn.dataset.scroll;
                    const body = document.getElementById('tsPanelBody');
                    if (!body) return;

                    const sections = body.querySelectorAll('.ts-section');
                    sections.forEach(function(sec) {
                        const label = sec.querySelector('.ts-label');
                        if (label && label.textContent.toLowerCase().includes(keyword)) {
                            sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                    });
                });
            });

            // Reset via sidebar
            sidebar.querySelector('#tsSidebarReset')?.addEventListener('click', function() {
                document.getElementById('tsResetBtn')?.click();
            });

            // Download via sidebar
            sidebar.querySelector('#tsSidebarDownload')?.addEventListener('click', function() {
                document.getElementById('tsDownloadBtn')?.click();
            });

            // Download via action bar
            document.getElementById('tsMainDownloadBtn')?.addEventListener('click', function() {
                document.getElementById('tsDownloadBtn')?.click();
            });

            // ============================================================
            // 5. SHOW ACTION BAR saat canvas aktif
            // ============================================================
            const canvasWrap = document.getElementById('tsCanvasWrap');
            const actionBar = document.getElementById('tsCanvasActions');
            if (canvasWrap && actionBar) {
                // Cek initial state
                if (canvasWrap.classList.contains('active') || canvasWrap.style.display === 'block') {
                    actionBar.style.display = 'flex';
                }
                // Observe perubahan
                const observer = new MutationObserver(function() {
                    const isVisible = canvasWrap.classList.contains('active') ||
                                      canvasWrap.style.display === 'block';
                    actionBar.style.display = isVisible ? 'flex' : 'none';
                });
                observer.observe(canvasWrap, { attributes: true, attributeFilter: ['class', 'style'] });
            }

            console.log('[Redesign v2] Ready');
        }, 700);
    });
})();
})();
