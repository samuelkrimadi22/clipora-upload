/* projects.js — V1.2.0 (thumbnail pakai <img src> simple) */
(function () {
    const container = document.getElementById("prjContainer");
    if (!container) return;

    let allProjects = [];
    let currentProject = null;

    function getAuthHeaders() {
        const h = { "Content-Type": "application/json" };
        if (typeof AUTH_TOKEN !== "undefined" && AUTH_TOKEN)
            h["Authorization"] = "Bearer " + AUTH_TOKEN;
        return h;
    }

    function escHtml(s) {
        return String(s == null ? "" : s)
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    }

    function fmtDate(iso) {
        if (!iso) return "-";
        const d = new Date(iso);
        const diff = (Date.now() - d) / 1000;
        if (diff < 60) return "baru saja";
        if (diff < 3600) return Math.floor(diff / 60) + " menit lalu";
        if (diff < 86400) return Math.floor(diff / 3600) + " jam lalu";
        if (diff < 604800) return Math.floor(diff / 86400) + " hari lalu";
        return d.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
    }

    function thumbUrl(id) {
        const t = (typeof AUTH_TOKEN !== "undefined" && AUTH_TOKEN) ? AUTH_TOKEN : "";
        return "http://localhost:3000/api/projects/" + encodeURIComponent(id) + "/thumbnail?token=" + encodeURIComponent(t);
    }
    function videoUrl(id) {
        const t = (typeof AUTH_TOKEN !== "undefined" && AUTH_TOKEN) ? AUTH_TOKEN : "";
        return "/api/projects/" + encodeURIComponent(id) + "/video?token=" + encodeURIComponent(t);
    }

    // ============================================================
    // MODAL PREVIEW
    // ============================================================
    function ensureModal() {
        if (document.getElementById("prjPreviewModal")) return;

        const modal = document.createElement("div");
        modal.id = "prjPreviewModal";
        modal.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,0.85);backdrop-filter:blur(8px);z-index:9999;display:none;align-items:center;justify-content:center;padding:20px;";
        modal.innerHTML = `
            <div style="background:#0f0f18;border:1px solid rgba(139,92,246,0.3);border-radius:16px;max-width:900px;width:100%;overflow:hidden;box-shadow:0 30px 80px rgba(0,0,0,0.7);">
                <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 20px;border-bottom:1px solid rgba(255,255,255,0.08);">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <i class="fas fa-video" style="color:#a78bfa;"></i>
                        <strong id="prjPreviewTitle" style="color:#fff;font-size:0.95rem;">Preview</strong>
                    </div>
                    <button id="prjPreviewClose" style="background:none;border:none;color:#94a3b8;cursor:pointer;font-size:1.2rem;padding:6px 10px;border-radius:6px;">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div style="background:#000;position:relative;">
                    <video id="prjPreviewVideo" controls playsinline style="width:100%;max-height:70vh;display:block;background:#000;"></video>
                </div>
                <div style="padding:14px 20px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
                    <div style="font-size:0.8rem;color:#94a3b8;" id="prjPreviewMeta"></div>
                    <div style="display:flex;gap:10px;">
                        <button id="prjPreviewEdit" style="padding:10px 20px;border:none;border-radius:8px;background:linear-gradient(135deg,#8b5cf6,#06b6d4);color:#fff;font-weight:700;font-size:0.85rem;cursor:pointer;font-family:inherit;">
                            <i class="fas fa-folder-open"></i> Buka di Editor
                        </button>
                        <button id="prjPreviewDownload" style="padding:10px 18px;border:1px solid rgba(255,255,255,0.15);border-radius:8px;background:rgba(255,255,255,0.05);color:#e8e8ef;font-weight:600;font-size:0.85rem;cursor:pointer;font-family:inherit;">
                            <i class="fas fa-download"></i> Download
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        document.getElementById("prjPreviewClose").onclick = closeModal;
        modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });
        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape" && modal.style.display === "flex") closeModal();
        });
    }

    function openModal(project) {
        ensureModal();
        currentProject = project;

        const modal = document.getElementById("prjPreviewModal");
        const video = document.getElementById("prjPreviewVideo");
        document.getElementById("prjPreviewTitle").textContent = project.name || "Preview";
        document.getElementById("prjPreviewMeta").textContent =
            (project.status || "draft").toUpperCase() +
            (project.segment_count ? " • " + project.segment_count + " segmen" : "") +
            (project.translate_target ? " • " + project.translate_target.toUpperCase() : "");

        video.src = videoUrl(project.id);
        modal.style.display = "flex";
        video.play().catch(() => {});

        document.getElementById("prjPreviewEdit").onclick = () => {
            window.location.href = "index.php?project=" + encodeURIComponent(project.id);
        };
        document.getElementById("prjPreviewDownload").onclick = () => {
            const a = document.createElement("a");
            a.href = videoUrl(project.id);
            a.download = (project.name || "project") + ".mp4";
            a.click();
        };
    }

    function closeModal() {
        const modal = document.getElementById("prjPreviewModal");
        const video = document.getElementById("prjPreviewVideo");
        if (video) { video.pause(); video.src = ""; }
        if (modal) modal.style.display = "none";
        currentProject = null;
    }

    // ============================================================
    // RENDER CARD
    // ============================================================
    function renderCard(p) {
        const status = p.status || "draft";
        const lang = p.translate_target ? `<span><i class="fas fa-language"></i> ${escHtml(p.translate_target.toUpperCase())}</span>` : "";

        return `
            <div class="prj-card" data-id="${escHtml(p.id)}">
                <div class="prj-thumb prj-thumb-clickable" data-id="${escHtml(p.id)}"
                     style="cursor:pointer;position:relative;padding:0;overflow:hidden;height:140px;background:linear-gradient(135deg,rgba(139,92,246,0.3),rgba(6,182,212,0.2));display:flex;align-items:center;justify-content:center;">
                    <img class="prj-thumb-img" src="${thumbUrl(p.id)}" alt="${escHtml(p.name)}"
                         style="width:100%;height:100%;object-fit:cover;display:block;position:absolute;inset:0;"
                         onerror="this.style.display='none'; this.parentElement.querySelector('.prj-thumb-fallback').style.display='flex';">
                    <div class="prj-thumb-fallback" style="display:none;position:absolute;inset:0;align-items:center;justify-content:center;">
                        <i class="fas fa-video" style="font-size:2.4rem;color:rgba(255,255,255,0.5);"></i>
                    </div>
                    <div class="prj-thumb-play" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.35);opacity:0;transition:0.2s;z-index:2;">
                        <i class="fas fa-play-circle" style="font-size:3rem;color:#fff;text-shadow:0 2px 12px rgba(0,0,0,0.7);"></i>
                    </div>
                    <div class="prj-thumb-badge ${status}" style="position:absolute;top:10px;right:10px;z-index:3;padding:4px 10px;border-radius:20px;font-size:0.7rem;font-weight:700;background:rgba(0,0,0,0.7);text-transform:uppercase;letter-spacing:0.5px;color:${status === 'rendered' ? '#22c55e' : '#94a3b8'};">${status}</div>
                </div>
                <div class="prj-body">
                    <div class="prj-name" title="${escHtml(p.name)}">${escHtml(p.name)}</div>
                    <div class="prj-meta">
                        <span><i class="fas fa-clock"></i> ${fmtDate(p.updated_at)}</span>
                        ${p.segment_count ? `<span><i class="fas fa-scissors"></i> ${p.segment_count}</span>` : ""}
                        ${lang}
                    </div>
                    <div class="prj-actions">
                        <button class="prj-btn prj-btn-open prj-btn-preview" data-id="${escHtml(p.id)}" style="flex:1;">
                            <i class="fas fa-play"></i> Preview
                        </button>
                        <a class="prj-btn prj-btn-open" href="index.php?project=${escHtml(p.id)}" style="flex:1;">
                            <i class="fas fa-folder-open"></i> Edit
                        </a>
                        <button class="prj-btn prj-btn-del" data-id="${escHtml(p.id)}" data-name="${escHtml(p.name)}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    function render() {
        const q = (document.getElementById("prjSearch")?.value || "").trim().toLowerCase();
        const list = q ? allProjects.filter(p => (p.name || "").toLowerCase().includes(q)) : allProjects;

        if (!allProjects.length) {
            container.innerHTML = `
                <div class="prj-empty">
                    <i class="fas fa-folder-open"></i>
                    <h3>Belum ada proyek</h3>
                    <p>Mulai buat video pertama kamu</p>
                    <a href="index.php"><i class="fas fa-plus"></i> Buat Proyek Baru</a>
                </div>`;
            document.getElementById("prjStats").style.display = "none";
            return;
        }

        if (!list.length) {
            container.innerHTML = `<div class="prj-empty"><i class="fas fa-search"></i><h3>Tidak ada hasil</h3><p>Coba kata kunci lain</p></div>`;
            return;
        }

        container.innerHTML = `<div class="prj-grid">${list.map(renderCard).join("")}</div>`;
        document.getElementById("prjStats").style.display = "flex";
    }

    async function loadProjects() {
    try {
        console.log("🔍 [Projects] Mengambil data dari server...");
        const res = await fetch("http://localhost:3000/api/projects", { 
            headers: getAuthHeaders(), 
            credentials: "include" 
        });
        
        console.log("📥 [Projects] Response status:", res.status);
        
        const data = await res.json();
        console.log("📦 [Projects] Data dari server:", data);
        
        if (!res.ok || !data.success) {
            throw new Error(data.error || ("HTTP " + res.status));
        }

        allProjects = data.projects || [];
        console.log(`✅ [Projects] Ditemukan ${allProjects.length} proyek`);
        
        if (allProjects.length > 0) {
            allProjects.forEach(p => console.log("  - Proyek:", p.name, "| ID:", p.id));
        }

        document.getElementById("prjTotal").textContent = allProjects.length;
        document.getElementById("prjDraft").textContent = allProjects.filter(p => (p.status || "draft") === "draft").length;
        document.getElementById("prjRendered").textContent = allProjects.filter(p => p.status === "rendered").length;

        render();
    } catch (e) {
        console.error("❌ [Projects] Error:", e);
        container.innerHTML = `<div class="prj-empty"><i class="fas fa-exclamation-triangle" style="color:#ef4444;"></i><h3>Gagal memuat</h3><p>${escHtml(e.message)}</p></div>`;
    }
}

    async function deleteProject(id, name) {
        const ok = await (window.showConfirm ? window.showConfirm({
            title: "🗑️ Hapus Proyek?",
            message: `Yakin hapus "${name}"? File video juga akan dihapus permanen.`,
            type: "warning",
            okText: "Ya, Hapus",
            cancelText: "Batal",
        }) : confirm(`Hapus "${name}"?`));
        if (!ok) return;

        try {
            const res = await fetch("http://localhost:3000/api/projects/" + id, { method: "DELETE", headers: getAuthHeaders(), credentials: "include" });
            const data = await res.json();
            if (!res.ok || !data.success) throw new Error(data.error || "Gagal hapus");
            allProjects = allProjects.filter(p => p.id !== id);
            render();
        } catch (e) {
            console.error("[Projects] Delete:", e);
            if (typeof toastError === "function") toastError(e.message);
            else alert(e.message);
        }
    }

    document.getElementById("prjSearch")?.addEventListener("input", render);

    container.addEventListener("click", (e) => {
        const delBtn = e.target.closest(".prj-btn-del");
        if (delBtn) {
            e.preventDefault();
            deleteProject(delBtn.dataset.id, delBtn.dataset.name);
            return;
        }
        const previewBtn = e.target.closest(".prj-btn-preview, .prj-thumb-clickable");
        if (previewBtn) {
            e.preventDefault();
            const id = previewBtn.dataset.id;
            const proj = allProjects.find(p => p.id === id);
            if (proj) openModal(proj);
        }
    });

    container.addEventListener("mouseover", (e) => {
        const thumb = e.target.closest(".prj-thumb-clickable");
        if (thumb) {
            const play = thumb.querySelector(".prj-thumb-play");
            if (play) play.style.opacity = "1";
        }
    });
    container.addEventListener("mouseout", (e) => {
        const thumb = e.target.closest(".prj-thumb-clickable");
        if (thumb) {
            const play = thumb.querySelector(".prj-thumb-play");
            if (play) play.style.opacity = "0";
        }
    });

    loadProjects();
    console.log("[Projects] Init OK (v1.2.0)");
})();
