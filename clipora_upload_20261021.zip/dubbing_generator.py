# ============================================================
# AI Dubbing Generator — V9.183.0
# Generate voice over bahasa daerah dari subtitle/transcript
# Support: Indonesia, Jawa, Sunda, Melayu (Edge-TTS)
# ============================================================
import os
import sys
import json
import re
import asyncio
import subprocess
import uuid
from pathlib import Path

try:
    import edge_tts
    HAS_EDGE_TTS = True
except ImportError:
    HAS_EDGE_TTS = False
    print("[Dubbing] edge-tts tidak terinstall", file=sys.stderr)


# ============================================================
# KONFIGURASI SUARA
# ============================================================
# Mapping bahasa → voice Edge-TTS
VOICE_MAP = {
    "indonesia": {
        "male": "id-ID-ArdiNeural",
        "female": "id-ID-GadisNeural",
    },
    "jawa": {
        "male": "jv-ID-DimasNeural",
        "female": "jv-ID-SitiNeural",
    },
    "sunda": {
        "male": "su-ID-JajangNeural",
        "female": "su-ID-TutiNeural",
    },
    "melayu": {
        "male": "ms-MY-OsmanNeural",
        "female": "ms-MY-YasminNeural",
    },
    # Fallback untuk bahasa daerah lain
    # (untuk bahasa yang belum ada di Edge-TTS, pakai Indonesia dulu)
}

# Mapping kode bahasa dari Clipora → voice language
LANG_TO_VOICE_LANG = {
    "id": "indonesia",
    "jawa": "jawa",
    "jawa_timur": "jawa",
    "sunda": "sunda",
    "sunda_banten": "sunda",
    "melayu": "melayu",
    "melayu_papua": "indonesia",  # fallback dulu
    "melayu_ambon": "indonesia",
    # Bahasa lain fallback ke Indonesia
}

# ============================================================
# HELPER: Dapatkan Voice
# ============================================================
def get_voice(lang_code, gender="female"):
    """Dapatkan nama voice Edge-TTS dari kode bahasa."""
    voice_lang = LANG_TO_VOICE_LANG.get(lang_code, "indonesia")
    voice_dict = VOICE_MAP.get(voice_lang, VOICE_MAP["indonesia"])
    return voice_dict.get(gender, voice_dict["female"])


# ============================================================
# CORE: Generate Audio dari Text
# ============================================================
async def _tts_async(text, voice, output_path, rate="+0%", pitch="+0Hz"):
    """Generate audio dari text via Edge-TTS (async)."""
    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await communicate.save(output_path)


def text_to_speech(text, lang_code="jawa", gender="female", output_path=None, rate="+0%"):
    """
    Generate audio dari text dalam bahasa tertentu.
    
    Args:
        text: Text yang akan di-TTS
        lang_code: Kode bahasa (jawa, sunda, melayu, dll)
        gender: 'male' atau 'female'
        output_path: Path output MP3. Kalau None, auto-generate
        rate: Kecepatan bicara ("+0%", "-10%", "+20%")
    
    Returns:
        Path file audio (MP3) atau None kalau gagal
    """
    if not HAS_EDGE_TTS:
        print("[Dubbing] edge-tts tidak tersedia", file=sys.stderr)
        return None

    if not text or not text.strip():
        print("[Dubbing] Text kosong", file=sys.stderr)
        return None

    voice = get_voice(lang_code, gender)

    if output_path is None:
        output_path = f"dubbing_{uuid.uuid4().hex[:8]}.mp3"

    try:
        print(f"[Dubbing] TTS: {len(text)} char → {voice}", file=sys.stderr)
        asyncio.run(_tts_async(text, voice, output_path, rate=rate))

        if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            size_kb = os.path.getsize(output_path) / 1024
            print(f"[Dubbing] OK: {output_path} ({size_kb:.1f} KB)", file=sys.stderr)
            return output_path
        else:
            print(f"[Dubbing] File output kosong", file=sys.stderr)
            return None
    except Exception as e:
        print(f"[Dubbing] Error: {e}", file=sys.stderr)
        return None


# ============================================================
# ADVANCED: Generate Multi-Segment (untuk Subtitle)
# ============================================================
def generate_dubbing_from_segments(segments, lang_code="jawa", gender="female", output_dir=None):
    """
    Generate dubbing dari multiple segments (subtitle).
    
    Args:
        segments: List of dict {text, start, end}
        lang_code: Kode bahasa
        gender: 'male' atau 'female'
        output_dir: Directory untuk output
    
    Returns:
        dict {success, audio_files: [paths], total_duration, error}
    """
    if not segments:
        return {"success": False, "error": "Segments kosong"}

    if output_dir is None:
        output_dir = "temp"
    
    os.makedirs(output_dir, exist_ok=True)

    audio_files = []
    for i, seg in enumerate(segments):
        text = seg.get("text", "").strip()
        if not text:
            continue

        output_path = os.path.join(output_dir, f"seg_{i:03d}_{uuid.uuid4().hex[:6]}.mp3")
        result = text_to_speech(text, lang_code, gender, output_path)

        if result:
            audio_files.append({
                "path": result,
                "start": seg.get("start", 0),
                "end": seg.get("end", 0),
                "text": text,
            })

    return {
        "success": len(audio_files) > 0,
        "audio_files": audio_files,
        "count": len(audio_files),
        "error": None if audio_files else "Tidak ada audio yang dihasilkan",
    }


# ============================================================
# ADVANCED: Merge Audio dengan Video (via FFmpeg)
# ============================================================
def merge_audio_with_video(video_path, audio_path, output_path, 
                            original_volume=0.3, dubbing_volume=1.0):
    """
    Merge audio dubbing dengan video (ganti audio asli).
    
    Args:
        video_path: Path video source
        audio_path: Path audio dubbing (MP3)
        output_path: Path output video
        original_volume: Volume audio asli (0.0 = mute, 1.0 = full)
        dubbing_volume: Volume audio dubbing (1.0 = normal)
    
    Returns:
        dict {success, output_path, error}
    """
    try:
        # FFmpeg command
        # -i video: input video
        # -i audio: input audio dubbing
        # -filter_complex: mix audio
        #   [0:a]volume=0.3[orig]
        #   [1:a]volume=1.0[dub]
        #   [orig][dub]amix=inputs=2:duration=first[out]
        cmd = [
            "ffmpeg", "-y",
            "-i", video_path,
            "-i", audio_path,
            "-filter_complex",
            f"[0:a]volume={original_volume}[orig];[1:a]volume={dubbing_volume}[dub];[orig][dub]amix=inputs=2:duration=first[out]",
            "-map", "0:v",
            "-map", "[out]",
            "-c:v", "copy",
            "-c:a", "aac",
            "-shortest",
            output_path
        ]

        print(f"[Dubbing] FFmpeg merge...", file=sys.stderr)
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

        if result.returncode == 0 and os.path.exists(output_path):
            size_mb = os.path.getsize(output_path) / (1024 * 1024)
            print(f"[Dubbing] OK: {output_path} ({size_mb:.1f} MB)", file=sys.stderr)
            return {"success": True, "output_path": output_path, "error": None}
        else:
            print(f"[Dubbing] FFmpeg error: {result.stderr[:500]}", file=sys.stderr)
            return {"success": False, "error": result.stderr[:500]}
    except Exception as e:
        print(f"[Dubbing] Error: {e}", file=sys.stderr)
        return {"success": False, "error": str(e)}


# ============================================================
# LIST AVAILABLE VOICES
# ============================================================
def list_available_languages():
    """List bahasa yang tersedia untuk dubbing. V9.183.1: EXPAND_29_LANGS"""
    return [
        # ============================================================
        # NATIVE EDGE-TTS (suara asli)
        # ============================================================
        {"code": "id",            "name": "Indonesia",     "voice": "id-ID", "gender": "both", "available": True, "native": True},
        {"code": "jawa",          "name": "Jawa",          "voice": "jv-ID", "gender": "both", "available": True, "native": True},
        {"code": "jawa_timur",    "name": "Jawa Timur",    "voice": "jv-ID", "gender": "both", "available": True, "native": True},
        {"code": "sunda",         "name": "Sunda",         "voice": "su-ID", "gender": "both", "available": True, "native": True},
        {"code": "sunda_banten",  "name": "Sunda Banten",  "voice": "su-ID", "gender": "both", "available": True, "native": True},
        {"code": "melayu",        "name": "Melayu",        "voice": "ms-MY", "gender": "both", "available": True, "native": True},

        # ============================================================
        # FALLBACK (suara Indonesia)
        # ============================================================
        {"code": "batak",         "name": "Batak",          "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "minang",        "name": "Minang",         "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "palembang",     "name": "Palembang",      "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "aceh",          "name": "Aceh",           "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "lampung",       "name": "Lampung",        "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "komering",      "name": "Komering",       "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "nias",          "name": "Nias",           "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "rejang",        "name": "Rejang",         "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "betawi",        "name": "Betawi",         "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "bugis",         "name": "Bugis",          "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "makassar",      "name": "Makassar",       "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "toraja",        "name": "Toraja",         "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "gorontalo",     "name": "Gorontalo",      "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "tolaki",        "name": "Tolaki",         "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "banjar",        "name": "Banjar",         "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "dayak_ngaju",   "name": "Dayak Ngaju",    "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "kutai",         "name": "Kutai",          "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "bali",          "name": "Bali",           "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "sasak",         "name": "Sasak",          "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "bima",          "name": "Bima",           "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "sumbawa",       "name": "Sumbawa",        "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "manggarai",     "name": "Manggarai",      "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "melayu_ambon",  "name": "Melayu Ambon",   "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
        {"code": "melayu_papua",  "name": "Melayu Papua",   "voice": "id-ID", "gender": "both", "available": True, "native": False, "fallback": "id"},
    ]


