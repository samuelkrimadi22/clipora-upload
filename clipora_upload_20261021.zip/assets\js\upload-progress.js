/**
 * upload-progress.js — V8.9.22
 * Upload file dengan progress tracking + minimum display time.
 */
(function() {
    'use strict';
    if (window.uploadWithProgress) return;

    window.uploadWithProgress = function(url, formData, options = {}) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            const {
                onProgress = null,
                onUploadComplete = null,
                headers = {},
                timeoutMs = 30 * 60 * 1000,
                abortRef = null,
            } = options;

            // V8.9.22: Smooth progress — interpolasi step demi step
            let lastSentPercent = 0;
            let smoothTimer = null;

            function sendSmoothProgress(targetPercent, extra = {}) {
                if (!onProgress) return;

                // Cancel timer lama
                if (smoothTimer) clearTimeout(smoothTimer);

                // Kalau naik drastis, animasi bertahap biar user lihat
                const step = () => {
                    if (lastSentPercent >= targetPercent) {
                        lastSentPercent = targetPercent;
                        return;
                    }
                    // Naik max 8% per 80ms → smooth
                    lastSentPercent = Math.min(targetPercent, lastSentPercent + 8);
                    onProgress({
                        loaded: 0,
                        total: 0,
                        percent: lastSentPercent,
                        loadedMB: extra.loadedMB || '...',
                        totalMB: extra.totalMB || '...',
                    });
                    if (lastSentPercent < targetPercent) {
                        smoothTimer = setTimeout(step, 80);
                    }
                };
                step();
            }

            // ============ Upload progress (real) ============
            xhr.upload.addEventListener('progress', (e) => {
                if (e.lengthComputable) {
                    const rawPercent = Math.round((e.loaded / e.total) * 100);
                    const loadedMB = (e.loaded / 1024 / 1024).toFixed(1);
                    const totalMB = (e.total / 1024 / 1024).toFixed(1);

                    // Panggil onProgress dengan smooth interpolation
                    sendSmoothProgress(rawPercent, { loadedMB, totalMB });

                    // Simpan info MB terakhir untuk dipakai setelah 100%
                    window.__LAST_UPLOAD_MB__ = `${loadedMB} MB / ${totalMB} MB`;
                }
            });

            // ============ Upload selesai (semua bytes terkirim) ============
            xhr.upload.addEventListener('load', () => {
                // V8.9.22: Force tampilkan 100% minimal 1.5 detik
                if (onProgress) {
                    // Set paksa ke 100%
                    lastSentPercent = 100;
                    onProgress({
                        loaded: 0,
                        total: 0,
                        percent: 100,
                        loadedMB: '...',
                        totalMB: '...',
                    });
                }

                // Delay 1.5 detik sebelum kabari main.js bahwa upload selesai
                // Biar user SEMPAT lihat "100%"
                setTimeout(() => {
                    if (onUploadComplete) onUploadComplete();
                }, 1500);
            });

            // ============ Response dari server ============
            xhr.addEventListener('load', () => {
                if (smoothTimer) clearTimeout(smoothTimer);
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (xhr.status >= 200 && xhr.status < 300) {
                        resolve({ status: xhr.status, data: response });
                    } else {
                        const err = new Error(response.error || `HTTP ${xhr.status}`);
                        err.status = xhr.status;
                        err.response = response;
                        reject(err);
                    }
                } catch (e) {
                    reject(new Error('Invalid JSON response: ' + xhr.responseText.slice(0, 200)));
                }
            });

            xhr.addEventListener('error', () => {
                if (smoothTimer) clearTimeout(smoothTimer);
                reject(new Error('Network error saat upload — cek koneksi internet'));
            });

            xhr.addEventListener('timeout', () => {
                if (smoothTimer) clearTimeout(smoothTimer);
                reject(new Error('Upload timeout — koneksi terlalu lambat atau server tidak respon'));
            });

            xhr.addEventListener('abort', () => {
                if (smoothTimer) clearTimeout(smoothTimer);
                const err = new Error('Upload dibatalkan');
                err.aborted = true;
                reject(err);
            });

            // ============ Send ============
            xhr.open('POST', url);
            xhr.timeout = timeoutMs;

            for (const [k, v] of Object.entries(headers)) {
                try { xhr.setRequestHeader(k, v); } catch (e) {}
            }

            if (abortRef && typeof abortRef === 'object') {
                abortRef.xhr = xhr;
            }

            xhr.send(formData);
        });
    };

    console.log('📤 [UploadProgress] Utility loaded (V8.9.22 — smooth)');
})();