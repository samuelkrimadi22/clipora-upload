# V9.180.80: PYTHON_CULTURE
# V9.180.21: CULTURE_ENDPOINTS
#!/usr/bin/env python3
# python_server.py Ã¢â‚¬â€ Clipora V8.9.20 Persistent AI Server
# Load model SEKALI, reuse berkali-kali untuk hemat 100+ detik per job
import os
import sys
import json
import traceback
from pathlib import Path

# V8.7.0: AI Voice Over (edge-tts)
try:
    import asyncio
    import edge_tts

    HAS_EDGE_TTS = True
except ImportError:
    HAS_EDGE_TTS = False
    edge_tts = None


# V8.7.0: Multi-bahasa Translate
try:
    from deep_translator import GoogleTranslator, MyMemoryTranslator

    HAS_TRANSLATOR = True
except ImportError:
    HAS_TRANSLATOR = False
    GoogleTranslator = None
    MyMemoryTranslator = None

# Fix Windows encoding
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

# Add current dir to import path
sys.path.insert(0, str(Path(__file__).parent))

# V8.9.20: Lock untuk render (masih dipakai di /render & /render-clip)
import threading
from contextlib import nullcontext as _nullcontext  # V8.9.22
_job_lock = threading.Lock()  # Only used for /render (full render)

# ==== Flask check ====
try:
    from flask import Flask, request, jsonify
except ImportError:
    print("[ERROR] Flask tidak terinstall.", file=sys.stderr)
    print("        Jalankan: pip install flask", file=sys.stderr)
    sys.exit(1)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = None

from werkzeug.exceptions import HTTPException
import datetime as _dt
import numpy as _np

def _json_safe(obj):
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    elif isinstance(obj, (_dt.datetime, _dt.date)):
        return obj.isoformat()
    elif isinstance(obj, _np.ndarray):
        return obj.tolist()
    elif isinstance(obj, _np.integer):
        return int(obj)
    elif isinstance(obj, _np.floating):
        return float(obj)
    elif hasattr(obj, 'item'):
        return obj.item()
    return obj

@app.errorhandler(HTTPException)
def handle_http_exception(e):
    return jsonify({"success": False, "error": e.description, "code": e.code}), e.code

@app.errorhandler(Exception)
def handle_generic_exception(e):
    import traceback
    tb = traceback.format_exc()
    print(f"[ERROR] {tb}", file=sys.stderr)
    return jsonify({"success": False, "error": str(e), "trace": tb}), 500


# ============================================================
# WARMUP Ã¢â‚¬â€ Load model SEKALI di startup
# ============================================================
print("=" * 60, file=sys.stderr)
print("Ã°Å¸ÂÂ Clipora Python AI Server V8.9.20 Ã¢â‚¬â€ Starting", file=sys.stderr)
print("=" * 60, file=sys.stderr)

try:
    import process_video_v8 as pv

    print("[Warmup] Ã¢Å“â€¦ Module process_video_v8 imported", file=sys.stderr)
    print(
        f"[Warmup]    Version: {getattr(pv, '__version__', 'V8.9.20')}", file=sys.stderr
    )
    print(
        f"[Warmup]    RapidFuzz: {getattr(pv, 'HAS_RAPIDFUZZ', False)}", file=sys.stderr
    )
    print(
        f"[Warmup]    SpellCheck: {getattr(pv, 'HAS_SPELLCHECK', False)}",
        file=sys.stderr,
    )
except Exception as e:
    print(f"[Warmup] Ã¢ÂÅ’ Failed to import: {e}", file=sys.stderr)
    traceback.print_exc()
    sys.exit(1)

try:
    import thumbnail_ai as tai
    HAS_THUMBNAIL_AI = True
    print("[Warmup] Ã¢Å“â€¦ Module thumbnail_ai imported", file=sys.stderr)
except ImportError as e:
    HAS_THUMBNAIL_AI = False
    tai = None
    print(f"[Warmup] Ã¢Å¡ÂÃ¯Â¸Â thumbnail_ai tidak tersedia: {e}", file=sys.stderr)

# V8.8.0: Auto-Clip Generator
try:
    import auto_clip as ac

    HAS_AUTO_CLIP = True
    print("[Warmup] Ã¢Å“â€¦ Module auto_clip imported", file=sys.stderr)
except ImportError as e:
    HAS_AUTO_CLIP = False
    ac = None
    print(f"[Warmup] Ã¢Å¡ÂÃ¯Â¸Â auto_clip tidak tersedia: {e}", file=sys.stderr)


# V9.185.3: Smarter Auto-Clip (scene + hook + motion)
try:
    from auto_clip_smarter import smarter_split
    HAS_SMARTER = True
    print("[Warmup] Module auto_clip_smarter imported", file=sys.stderr)
except ImportError as e:
    HAS_SMARTER = False
    smarter_split = None
    print(f"[Warmup] auto_clip_smarter tidak tersedia: {e}", file=sys.stderr)
warmup_ok = {"whisper": False, "semantic": False, "vad": False}

try:
    warmup_model = os.getenv("WHISPER_WARMUP_MODEL", "tiny")
    print(f"[Warmup] Loading Whisper '{warmup_model}' model...", file=sys.stderr)
    pv.get_whisper_model(warmup_model)
    warmup_ok["whisper"] = True
    print(f"[Warmup] Ã¢Å“â€¦ Whisper '{warmup_model}' loaded", file=sys.stderr)
except Exception as e:
    print(f"[Warmup] Ã¢Å¡ÂÃ¯Â¸Â Whisper failed: {e}", file=sys.stderr)

try:
    if getattr(pv, "ENABLE_SEMANTIC", False):
        print("[Warmup] Loading Semantic model (Indo-BERT)...", file=sys.stderr)
        pv.get_similarity_model()
        warmup_ok["semantic"] = True
        print("[Warmup] Ã¢Å“â€¦ Semantic loaded", file=sys.stderr)
    else:
        print("[Warmup] Ã¢ÂÂÃ¯Â¸Â Semantic SKIP (disabled by config)", file=sys.stderr)
except Exception as e:
    print(f"[Warmup] Ã¢Å¡ÂÃ¯Â¸Â Semantic failed: {e}", file=sys.stderr)

try:
    print("[Warmup] Loading VAD model (Silero)...", file=sys.stderr)
    pv.get_vad_model()
    warmup_ok["vad"] = True
    print("[Warmup] Ã¢Å“â€¦ VAD loaded", file=sys.stderr)
except Exception as e:
    print(f"[Warmup] Ã¢Å¡ÂÃ¯Â¸Â VAD failed: {e}", file=sys.stderr)

print("=" * 60, file=sys.stderr)
print(f"Ã°Å¸Å½Â¯ Warmup status: {warmup_ok}", file=sys.stderr)
print("=" * 60, file=sys.stderr)

# V8.9.20: Cleanup file lama saat startup
try:
    results_dir = os.getenv("CLIPORA_RESULTS_DIR", str(Path(__file__).parent.parent / "results"))
    max_age = int(os.getenv("RESULTS_MAX_AGE_DAYS", "7"))
    print(f"[Warmup] Cleanup results > {max_age} hari...", file=sys.stderr)
    pv.cleanup_old_files(results_dir, max_age_days=max_age)
except Exception as e:
    print(f"[Warmup] Ã¢Å¡ÂÃ¯Â¸Â Cleanup failed: {e}", file=sys.stderr)


# ============================================================
# PER-REQUEST CONFIG (karena pakai global state di pv module)
# ============================================================
def apply_config(data):
    features = data.get("features", {})

    pv.ENABLE_SEMANTIC = bool(features.get("semantic", False))
    pv.ENABLE_KEYWORD = bool(features.get("keyword", False))
    pv.ENABLE_EMOTION = bool(features.get("emotion", False))
    pv.ENABLE_DIARIZATION = bool(features.get("diarization", False))
    pv.ENABLE_VAD = bool(features.get("vad", True))
    pv.ENABLE_NOISE_DETECTION = bool(features.get("noise_detection", True))

    style_memory = data.get("styleMemory", {})
    if style_memory and style_memory.get("total_videos", 0) >= 5:
        pv.STYLE_MEMORY = style_memory
        print(
            f"[Config] StyleMemory: {style_memory.get('total_videos')} videos, "
            f"{len(style_memory.get('categories', {}))} categories",
            file=sys.stderr,
        )
    else:
        pv.STYLE_MEMORY = {}

    pv.PROCESS_MODE = data.get("mode", "full")
    pv.ANALYSIS_JSON_PATH = data.get("analysisJsonPath") or None


# ============================================================
# ROUTES
# ============================================================
@app.route("/health", methods=["GET"])
def health():
    return jsonify(
        {
            "status": "ok",
            "version": "8.9.20",
            "warmup": warmup_ok,
            "auto_clip": HAS_AUTO_CLIP,
            "models_cached": {
                "whisper": list(pv._WHISPER_CACHE.keys()),
                "semantic": pv._SIM_MODEL is not None,
                "vad": pv._VAD_MODEL is not None,
            },
        }
    )


@app.route("/analyze", methods=["POST"])
def analyze():
    """V8.9.20: Dihilangkan _job_lock Ã¢â‚¬â€ analyze bisa jalan paralel."""
    try:
        data = request.get_json()
        print(f"\n{'='*60}", file=sys.stderr)
        print(f"Ã°Å¸â€Â [Analyze] Request received (V8.9.20)", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)

        input_path = data.get("inputPath")
        analyze_file = data.get("analyzeFile")

        if not input_path or not os.path.exists(input_path):
            return jsonify({"success": False, "error": f"Input not found: {input_path}"}), 400

        apply_config({**data, "mode": "analyze", "analysisJsonPath": analyze_file})

        dummy_output = data.get("dummyOutput") or str(Path(input_path).with_suffix(".dummy.mp4"))

        result = pv.process_video(
            input_path=input_path,
            output_path=dummy_output,
            aggressiveness=data.get("aggressiveness", "content"),
            add_watermark=data.get("addWatermark", True),
            whisper_model=data.get("whisperModel", "base"),
            enable_zoom=False,
            enable_scene=False,
            enable_noise_reduction=False,
            preset=data.get("preset", "1080p"),
            progress_path=None,
            enable_transition=False,
            enable_chapter=False,
            enable_summary=False,
            target_languages="id",
            batch_id=None,
            video_index=1,
            total_videos=1,
            enable_vertical_crop=False,
            enable_thumbnail=False,
            enable_music=False,
            music_path=None,
            enable_multi_format=False,
            thumbnail_title="Clipora",
            enable_burn_subtitle=data.get("enableBurnSubtitle", True),
        )

        try:
            if os.path.exists(dummy_output):
                os.unlink(dummy_output)
        except Exception:
            pass

        whisper_words = result.get("whisperWords", 0)
        print(
            f"Ã¢Å“â€¦ [Analyze] Done Ã¢â‚¬â€ {result.get('totalSegments', 0)} segments | "
            f"Whisper words: {whisper_words}",
            file=sys.stderr,
        )

        if whisper_words < 10:
            print(
                f"Ã¢Å¡ÂÃ¯Â¸Â  [Analyze] WARNING: Whisper hanya dapat {whisper_words} kata Ã¢â‚¬â€ "
                f"cek bahasa audio / kualitas suara!",
                file=sys.stderr,
            )

        
        # V9.1.0: Fallback HANYA kalau file benar-benar tidak ada / kosong
        file_ok = False
        if analyze_file and os.path.exists(analyze_file):
            if os.path.getsize(analyze_file) > 100:
                file_ok = True

        if analyze_file and not file_ok:
            print(f"[Analyze] Ã¢Å¡ÂÃ¯Â¸Â Fallback: tulis JSON minimal ke {analyze_file}", file=sys.stderr)
            fallback = {
                "version": "8.9.20",
                "inputPath": input_path,
                "duration": 0,
                "segments": [],
                "kept": [],
                "words": [],
                "originalWords": [],
                "srtPath": None,
                "stats": {
                    "totalRemoved": 0,
                    "phraseRepeat": 0,
                    "filler": 0,
                    "stutter": 0,
                    "falseStart": 0,
                    "silence": 0,
                    "duplicate": 0,
                    "whisperWords": 0,
                },
                "error": "Whisper tidak mendeteksi kata Ã¢â‚¬â€ audio mungkin terlalu pendek/tidak jelas",
            }
            with open(analyze_file, "w", encoding="utf-8") as f:
                json.dump(fallback, f, ensure_ascii=False, indent=2)

        result = _json_safe(result)
        return jsonify(result)

    except Exception as e:
        tb = traceback.format_exc()
        print(f"Ã¢ÂÅ’ [Analyze] ERROR: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e), "trace": tb}), 500




# ============================================================
# V9.185.3: AUTO-CLIP SMARTER - pakai scene + hook + motion
# ============================================================
@app.route("/auto-clip-smarter", methods=["POST"])
def auto_clip_smarter_endpoint():
    """Split video pintar pakai scene detection + audio hook + motion."""
    if not HAS_SMARTER:
        return jsonify({
            "success": False,
            "error": "auto_clip_smarter tidak tersedia. Cek auto_clip_smarter.py",
        }), 500

    try:
        data = request.get_json()
        words = data.get("words", [])
        source_path = data.get("sourcePath") or data.get("inputPath") or ""
        target_clips = int(data.get("target_clips", 5))

        if not words:
            return jsonify({"success": False, "error": "words kosong"}), 400
        if not source_path or not os.path.exists(source_path):
            return jsonify({"success": False, "error": f"Video tidak ada: {source_path}"}), 400
        if target_clips < 1 or target_clips > 20:
            target_clips = 5

        print(f"\n{'='*60}", file=sys.stderr)
        print(f"[AutoClipSmarter] Request: {len(words)} words, target {target_clips} klip", file=sys.stderr)
        print(f"   Video: {source_path}", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)

        clips_list = smarter_split(source_path, words, target_clips=target_clips)

        if not clips_list:
            return jsonify({"success": False, "error": "Tidak ada klip dihasilkan"}), 500

        result = {
            "success": True,
            "total_clips": len(clips_list),
            "clips": clips_list,
            "method": "smarter_v9.185",
            "total_duration": max((c["end"] for c in clips_list), default=0),
        }

        print(f"[AutoClipSmarter] Done - {result['total_clips']} klip", file=sys.stderr)
        return jsonify(result)

    except Exception as e:
        tb = traceback.format_exc()
        print(f"[AutoClipSmarter] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e), "trace": tb}), 500
# ============================================================
# V8.8.0: RENDER SINGLE CLIP
# ============================================================
@app.route("/render-clip", methods=["POST"])
def render_clip():
    """Render 1 klip dengan optional caption style + title.
    V8.9.22: Removed _job_lock Ã¢â‚¬â€ allow parallel rendering."""
    with _nullcontext():  
        try:
            data = request.get_json()
            
            # V9.180.90: DEBUG_TITIK_4
            print(f"[DEBUG-4] Python received keys: {list(data.keys())}", file=sys.stderr)
            print(f"[DEBUG-4] cultureRegion: {data.get('cultureRegion')}", file=sys.stderr)
            
            print(f"\n{'='*60}", file=sys.stderr)
            print(f"Ã°Å¸Å½Â¬ [RenderClip] Request received", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)

            source_path = data.get("sourcePath")
            output_path = data.get("outputPath")
            start = float(data.get("start", 0))
            end = float(data.get("end", 0))

            if not source_path or not os.path.exists(source_path):
                return (
                    jsonify(
                        {"success": False, "error": f"Source not found: {source_path}"}
                    ),
                    400,
                )
            if not output_path:
                return jsonify({"success": False, "error": "outputPath wajib"}), 400
            if end <= start:
                return jsonify({"success": False, "error": "Range tidak valid"}), 400

            caption_style = data.get("captionStyle") or None
            custom_subtitle = data.get("customSubtitle") or None  # V9.146.0
            title = data.get("title", "") or ""
            words = data.get("words") or None

            # V9.180.80: PYTHON_CULTURE
            culture_region = data.get("cultureRegion") or None
            if culture_region:
                print(f"[Culture] Region: {culture_region}", file=sys.stderr)

            custom_watermark_path = data.get("customWatermarkPath") or None

            # V9.60.3: UMKM config dari server.js
            umkm_config = data.get("umkmConfig") or data.get("umkm_config") or None
            if umkm_config:
                print(f"   Ã°Å¸ÂÂª UMKM: {umkm_config.get('product_name') or '-'} | {umkm_config.get('product_price') or '-'}", file=sys.stderr)
                _bc = umkm_config.get('brand_color') or '#f59e0b'
                _bcw = umkm_config.get('brand_color_wa') or '#25D366'
                print(f"   Ã°Å¸Å½Â¨ BRAND: {_bc} | WA: {_bcw}", file=sys.stderr)  # V9.118.0: BRAND LOG
                _lp = umkm_config.get('logo_path') or '-'
                print(f"   Ã°Å¸â€“Â¼Ã¯Â¸Â LOGO: {_lp} @ {umkm_config.get('logo_position', 'top-left')}", file=sys.stderr)  # V9.119.0: LOGO LOG

            # V9.108.0: MUSIC CONFIG Ã¢â‚¬â€ dari server.js
            # V9.148.0: AUDIO PRO CONFIG - dari server.js
            audio_config = data.get("audioConfig") or data.get("audio_config") or {}
            if audio_config:
                print(f"   AudioPro: vol={audio_config.get('volume', 100)}%, nr={audio_config.get('noiseReduction', True)}, norm={audio_config.get('normalize', True)}, fade_in={audio_config.get('fadeIn', 0)}, fade_out={audio_config.get('fadeOut', 0)}", file=sys.stderr)

            # V9.108.0: MUSIC CONFIG - dari server.js
            music_config = data.get("musicConfig") or data.get("music_config") or None
            if music_config:
                _duck = music_config.get('duck_original_audio', True)
                print(f"   Music: enabled={music_config.get('music_enabled')}, vol={music_config.get('music_volume')}, fade_in={music_config.get('music_fade_in')}, fade_out={music_config.get('music_fade_out')}, ducking={_duck}", file=sys.stderr)
            else:
                _duck = False
                print("   Music: DISABLED (tidak ada config)", file=sys.stderr)
            # V9.167.0: FIX_MUSIC_CONFIG_NULL

            if caption_style:
                _custom_keys = list(custom_subtitle.keys()) if custom_subtitle else []
                print(
                    f"   Caption: {caption_style}, Title: '{title[:40]}', Custom: {_custom_keys}",
                    file=sys.stderr,
                )

            if custom_watermark_path:
                print(
                    f"   Ã°Å¸Å½Â¨ Custom watermark: {custom_watermark_path}", file=sys.stderr
                )

            # V9.180.80: PYTHON_CULTURE_APPLY
            # Kalau ada culture_region, adapt subtitle dulu
            if culture_region:
                try:
                    from culture_adapter import adapt_subtitle_ass
                    # Cari file SRT/ASS yang akan di-burn
                    # Biasanya di-generate oleh render_single_clip
                    # Kita inject cultureRegion ke render_single_clip via env atau param
                    print(f"[Culture] Will adapt subtitle to {culture_region}", file=sys.stderr)
                    os.environ["_CULTURE_REGION"] = culture_region
                except Exception as e:
                    print(f"[Culture] Setup error: {e}", file=sys.stderr)

            result = pv.render_single_clip(
                source_path=source_path,
                output_path=output_path,
                start=start,
                end=end,
                preset=data.get("preset", "1080p"),
                add_watermark=data.get("addWatermark", True),
                burn_subtitle=data.get("burnSubtitle", True),
                vertical_crop=data.get("verticalCrop", False),
                aspect_ratio=data.get("aspectRatio", "auto"),
                use_karaoke=data.get("useKaraoke", False),  # V9.58.3
                karaoke_style=data.get("karaokeStyle", "tiktok"),  # V9.58.3  # V9.23.2: aspect_ratio
                progress_path=data.get("progressPath"),
                caption_style=caption_style,
                custom_subtitle=custom_subtitle,  # V9.146.0
                title=title,
                words=words,
                umkm_config=umkm_config,  # V9.60.3
                culture_region=culture_region,  # V9.180.121: PASS_CULTURE_TO_RENDER
                brand_color=(umkm_config.get('brand_color') if umkm_config else None),  # V9.118.0: BRAND COLOR
                brand_color_wa=(umkm_config.get('brand_color_wa') if umkm_config else None),  # V9.118.0
                logo_path=(umkm_config.get('logo_path') if umkm_config else None),  # V9.119.0: LOGO
                logo_position=(umkm_config.get('logo_position') if umkm_config else 'top-left'),  # V9.119.0
                logo_show_text=(umkm_config.get('logo_show_text', True) if umkm_config else True),  # V9.119.0
                # V9.109.0: MUSIC PARAMS
                enable_music=bool(music_config and music_config.get('music_enabled')),
                music_path=(music_config.get('music_file_path') if music_config else None),
                music_volume=(float(music_config.get('music_volume', 30)) / 100.0 if music_config else 0.15),
                music_fade_in=(float(music_config.get('music_fade_in', 1.0)) if music_config else 1.0),
                music_fade_out=(float(music_config.get('music_fade_out', 1.5)) if music_config else 1.5),
                # V9.130.0: AUTO-DUCKING BGM
                enable_ducking=bool(music_config and music_config.get('duck_original_audio', True)) if music_config else False,
                ducking_attack=int(music_config.get('ducking_attack', 100)) if music_config else 100,
                # V9.148.0: AUDIO PRO - user audio config
                user_audio_volume=(float(audio_config.get('volume', 100)) / 100.0 if audio_config else 1.0),
                user_enable_noise_reduction=bool(audio_config.get('noiseReduction', True)) if audio_config else True,
                user_enable_normalize=bool(audio_config.get('normalize', True)) if audio_config else True,
                user_audio_fade_in=float(audio_config.get('fadeIn', 0)) if audio_config else 0.0,
                user_audio_fade_out=float(audio_config.get('fadeOut', 0)) if audio_config else 0.0,
                ducking_release=int(music_config.get('ducking_release', 500)) if music_config else 500,
                custom_watermark_path=custom_watermark_path,
                job_id=data.get("jobId"),
            )

            if not result.get("success"):
                if result.get("cancelled"):
                    print(f"Ã¢ÂÂ¸Ã¯Â¸Â [RenderClip] Cancelled by user", file=sys.stderr)
                    return jsonify(result), 200
                return jsonify(result), 500

            print(
                f"Ã¢Å“â€¦ [RenderClip] Done Ã¢â‚¬â€ {result.get('newDuration', 0):.1f}s",
                file=sys.stderr,
            )
            return jsonify(result)

        except Exception as e:
            tb = traceback.format_exc()
            print(f"Ã¢ÂÅ’ [RenderClip] Error: {e}", file=sys.stderr)
            print(tb, file=sys.stderr)
            return jsonify({"success": False, "error": str(e), "trace": tb}), 500


# ============================================================
# V8.9.0: CANCEL RENDER Ã¢â‚¬â€ kill FFmpeg yang sedang jalan
# ============================================================
@app.route("/cancel-render", methods=["POST", "DELETE"])
def cancel_render():
    """V8.9.20: Cancel per-job (opsional)."""
    try:
        data = request.get_json(silent=True) or {}
        job_id = data.get("jobId")

        print(f"\n{'='*60}", file=sys.stderr)
        print(f"Ã°Å¸â€ºâ€˜ [CancelRender] Request Ã¢â‚¬â€ jobId={job_id or 'ALL'}", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)

        success = pv.cancel_active_render(job_id=job_id)

        return jsonify({
            "success": success,
            "message": "FFmpeg dibatalkan" if success else "Tidak ada FFmpeg aktif",
            "jobId": job_id,
        })
    except Exception as e:
        tb = traceback.format_exc()
        print(f"Ã¢ÂÅ’ [CancelRender] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================
# V8.8.3: PREVIEW SUBTITLE
# ============================================================
@app.route("/preview-subtitle", methods=["POST"])
def preview_subtitle():
    """Generate 1 frame preview dengan subtitle di-burn."""
    try:
        data = request.get_json()
        print(f"\n{'='*60}", file=sys.stderr)
        print(f"Ã°Å¸Å½Â¨ [Preview] Request received", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)

        source_path = data.get("sourcePath")
        output_path = data.get("outputPath")
        start = float(data.get("start", 0))
        end = float(data.get("end", 0))
        caption_style = data.get("captionStyle") or None
        title = data.get("title", "") or ""
        words = data.get("words") or None
        vertical_crop = data.get("verticalCrop", False)
        frame_offset = float(data.get("frameOffset", 1.5))
        preset = data.get("preset", "720p")

        if not source_path or not os.path.exists(source_path):
            return jsonify({"success": False, "error": "Source not found"}), 400

        if not output_path:
            return jsonify({"success": False, "error": "outputPath wajib"}), 400

        if end <= start:
            return jsonify({"success": False, "error": "Range tidak valid"}), 400

        result = pv.generate_subtitle_preview(
            source_path=source_path,
            output_path=output_path,
            start=start,
            end=end,
            caption_style=caption_style,
            title=title,
            words=words,
            vertical_crop=vertical_crop,
            frame_offset=frame_offset,
            preset=preset,
        )

        if not result.get("success"):
            print(f"Ã¢ÂÅ’ [Preview] Gagal: {result.get('error')}", file=sys.stderr)
            return jsonify(result), 500

        print(f"Ã¢Å“â€¦ [Preview] Done", file=sys.stderr)
        return jsonify(result)

    except Exception as e:
        tb = traceback.format_exc()
        print(f"Ã¢ÂÅ’ [Preview] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e), "trace": tb}), 500


# ============================================================
# V8.8.0: LIST CAPTION STYLES
# ============================================================
@app.route("/caption-styles", methods=["GET"])
def list_caption_styles():
    """List preset caption style."""
    try:
        if not getattr(pv, "HAS_CAPTION_STYLE", False):
            return (
                jsonify(
                    {"success": False, "error": "Caption style module tidak tersedia"}
                ),
                500,
            )
        styles = pv.cs.get_available_styles()
        return jsonify({"success": True, "styles": styles})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/render", methods=["POST"])
def render():
    with _job_lock:
        try:
            data = request.get_json()
            print(f"\n{'='*60}", file=sys.stderr)
            print(f"Ã°Å¸Å½Â¬ [Render] Request received (V8.9.20)", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)

            analysis_path = data.get("analysisJsonPath")
            output_path = data.get("outputPath")

            if not analysis_path or not os.path.exists(analysis_path):
                return (
                    jsonify(
                        {
                            "success": False,
                            "error": f"Analysis not found: {analysis_path}",
                        }
                    ),
                    400,
                )

            apply_config({**data, "mode": "render"})

            result = pv.render_from_analysis(
                analysis_path=analysis_path,
                output_path=output_path,
                progress_path=data.get("progressPath"),
                preset_override=data.get("preset", "1080p"),
                add_watermark_override=data.get("addWatermark", True),
                burn_subtitle_override=data.get("enableBurnSubtitle", True),
            )

            print(f"Ã¢Å“â€¦ [Render] Done", file=sys.stderr)
            return jsonify(result)

        except Exception as e:
            tb = traceback.format_exc()
            print(f"Ã¢ÂÅ’ [Render] ERROR: {e}", file=sys.stderr)
            print(tb, file=sys.stderr)
            return jsonify({"success": False, "error": str(e), "trace": tb}), 500


# ============================================================
# V8.7.0: AI VOICE OVER (edge-tts Ã¢â‚¬â€ gratis, no API key)
# ============================================================
# ============================================================
# V8.7.0 Ã¢â€â€™ V9.0.0 LEVEL 2: AI VOICE OVER (edge-tts)
# Upgrade: pitch, volume, SSML, more voices
# ============================================================
@app.route("/generate-voiceover", methods=["POST"])
def generate_voiceover():
    """Generate voice over dari text pakai edge-tts (LEVEL 2)."""
    if not HAS_EDGE_TTS:
        return (
            jsonify({
                "success": False,
                "error": "edge-tts tidak terinstall. Jalankan: pip install edge-tts",
            }),
            500,
        )

    try:
        data = request.get_json()
        text = (data.get("text") or "").strip()
        voice = data.get("voice", "id-ID-ArdiNeural")
        rate = data.get("rate", "+0%")
        pitch = data.get("pitch", "+0Hz")       # LEVEL 2
        volume = data.get("volume", "+0%")      # LEVEL 2
        emotion = data.get("emotion", "netral") # LEVEL 3 PHASE 2
        output_path = data.get("outputPath")

        if not text:
            return jsonify({"success": False, "error": "Teks kosong"}), 400
        if len(text) > 5000:
            return jsonify({"success": False, "error": "Teks maksimal 5000 karakter"}), 400
        if not output_path:
            return jsonify({"success": False, "error": "outputPath wajib diisi"}), 400

        ALLOWED_VOICES = [
            "id-ID-ArdiNeural",
            "id-ID-GadisNeural",
            "en-US-GuyNeural",
            "en-US-JennyNeural",
            "en-US-AriaNeural",
            "en-US-DavisNeural",
            "ja-JP-KeitaNeural",
            "ja-JP-NanamiNeural",
            "zh-CN-YunxiNeural",
            "zh-CN-XiaoxiaoNeural",
            "ko-KR-InJoonNeural",
            "ar-SA-HamedNeural",
        ]
        if voice not in ALLOWED_VOICES:
            voice = "id-ID-ArdiNeural"

        # Validasi format rate, pitch, volume
        import re as _re
        if not _re.match(r"^[+-]\d{1,3}%$", rate):
            rate = "+0%"
        if not _re.match(r"^[+-]\d{1,3}Hz$", pitch):
            pitch = "+0Hz"
        if not _re.match(r"^[+-]\d{1,3}%$", volume):
            volume = "+0%"
             
        # ============================================
        # V9.0.4 LEVEL 3 PHASE 2: EMOTION CONTROL
        # Override rate/pitch berdasarkan emosi
        # ============================================
        emotion = emotion.lower()
        EMOTION_MAP = {
            "netral":      {"rate": "+0%",   "pitch": "+0Hz",  "desc": "Netral"},
            "senang":      {"rate": "+10%",  "pitch": "+8Hz",  "desc": "Ceria"},
            "sedih":       {"rate": "-15%",  "pitch": "-12Hz", "desc": "Murung"},
            "serius":      {"rate": "-8%",   "pitch": "-15Hz", "desc": "Tegas"},
            "takut":       {"rate": "+20%",  "pitch": "+15Hz", "desc": "Panik"},
            "romantis":    {"rate": "-8%",   "pitch": "+5Hz",  "desc": "Lembut"},
            "berpikir":    {"rate": "-10%",  "pitch": "+0Hz",  "desc": "Kontemplatif"},
            "bersemangat": {"rate": "+25%",  "pitch": "+18Hz", "desc": "Antusias"},
        }

        if emotion != "netral" and emotion in EMOTION_MAP:
            emo = EMOTION_MAP[emotion]
            rate = emo["rate"]
            pitch = emo["pitch"]

        print(f"\n{'='*60}", file=sys.stderr)
        print(f"   [VoiceOver L3] Request", file=sys.stderr)
        print(f"\n{'='*60}", file=sys.stderr)
        print(f"Ã°Å¸Å½â„¢Ã¯Â¸Â  [VoiceOver L2] Request", file=sys.stderr)
        print(f"   Voice: {voice} | Rate: {rate} | Pitch: {pitch} | Vol: {volume}", file=sys.stderr)
        print(f"   Chars: {len(text)} | Output: {output_path}", file=sys.stderr)

        # V9.0.3 FIX: Pakai parameter LANGSUNG (bukan SSML)
        # edge-tts tidak support SSML di arg pertama â€” pakai parameter keyword
        async def _generate():
            communicate = edge_tts.Communicate(
                text,
                voice,
                rate=rate,
                pitch=pitch,
                volume=volume,
            )
            await communicate.save(output_path)

        asyncio.run(_generate())

        if os.path.exists(output_path) and os.path.getsize(output_path) > 1000:
            size_kb = os.path.getsize(output_path) / 1024
            print(f"   Ã¢Å“â€¦ Done: {size_kb:.1f} KB", file=sys.stderr)
            return jsonify({
                "success": True,
                "file": output_path,
                "size_kb": round(size_kb, 2),
                "voice": voice,
                "rate": rate,
                "pitch": pitch,
                "volume": volume,
            })
        else:
            return jsonify({"success": False, "error": "File gagal dibuat"}), 500

    except Exception as e:
        tb = traceback.format_exc()
        print(f"Ã¢ÂÅ’ [VoiceOver] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e), "trace": tb}), 500




# ============================================================
# V9.131.0 LEVEL 4B: BULK VOICE OVER MULTI-BAHASA
# 1 script -> N bahasa sekaligus (auto translate)
# ============================================================
@app.route("/generate-voiceover-bulk", methods=["POST"])
def generate_voiceover_bulk():
    """Generate voice over multi-bahasa dalam 1 request."""
    if not HAS_EDGE_TTS:
        return jsonify({
            "success": False,
            "error": "edge-tts tidak terinstall",
        }), 500

    if not HAS_TRANSLATOR:
        return jsonify({
            "success": False,
            "error": "deep-translator tidak terinstall. Jalankan: pip install deep-translator",
        }), 500

    try:
        data = request.get_json()
        text = (data.get("text") or "").strip()
        voice = data.get("voice", "id-ID-ArdiNeural")
        rate = data.get("rate", "+0%")
        pitch = data.get("pitch", "+0Hz")
        emotion = data.get("emotion", "netral")
        languages = data.get("languages", ["id", "en", "ja"])
        output_dir = data.get("outputDir")

        if not text:
            return jsonify({"success": False, "error": "Teks kosong"}), 400
        if len(text) > 3000:
            return jsonify({"success": False, "error": "Teks maksimal 3000 karakter untuk bulk"}), 400
        if not output_dir:
            return jsonify({"success": False, "error": "outputDir wajib"}), 400
        if not isinstance(languages, list) or len(languages) == 0:
            return jsonify({"success": False, "error": "languages harus array"}), 400
        if len(languages) > 5:
            return jsonify({"success": False, "error": "Maksimal 5 bahasa"}), 400

        # Voice mapping per bahasa
        VOICE_MAP = {
            "id": "id-ID-ArdiNeural",
            "en": "en-US-GuyNeural",
            "ja": "ja-JP-KeitaNeural",
            "zh": "zh-CN-YunxiNeural",
            "ko": "ko-KR-InJoonNeural",
            "ar": "ar-SA-HamedNeural",
        }

        # Emotion mapping
        emotion_lower = emotion.lower()
        EMOTION_MAP = {
            "netral": {"rate": "+0%", "pitch": "+0Hz"},
            "senang": {"rate": "+10%", "pitch": "+8Hz"},
            "sedih": {"rate": "-15%", "pitch": "-12Hz"},
            "serius": {"rate": "-8%", "pitch": "-15Hz"},
            "takut": {"rate": "+20%", "pitch": "+15Hz"},
            "romantis": {"rate": "-8%", "pitch": "+5Hz"},
            "berpikir": {"rate": "-10%", "pitch": "+0Hz"},
            "bersemangat": {"rate": "+25%", "pitch": "+18Hz"},
        }

        if emotion_lower != "netral" and emotion_lower in EMOTION_MAP:
            emo = EMOTION_MAP[emotion_lower]
            rate = emo["rate"]
            pitch = emo["pitch"]

        print(f"\n{'='*60}", file=sys.stderr)
        print(f"🌐 [BulkVO] Request: {len(languages)} bahasa - {languages}", file=sys.stderr)
        print(f"   Source (ID): {text[:60]}...", file=sys.stderr)
        print(f"   Emotion: {emotion} | Rate: {rate} | Pitch: {pitch}", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)

        results = []
        errors = []

        for lang in languages:
            lang = lang.lower().strip()
            try:
                # 1. Translate kalau bukan bahasa Indonesia
                if lang == "id":
                    translated = text
                else:
                    print(f"   🌍 Translating ID → {lang}...", file=sys.stderr)
                    translated = _translate_google(text, "id", lang)
                    if not translated:
                        translated = _translate_mymemory(text, "id", lang)
                    if not translated:
                        raise Exception(f"Translate gagal untuk {lang}")

                print(f"   📝 [{lang}] {translated[:60]}...", file=sys.stderr)

                # 2. Tentukan voice untuk bahasa ini
                lang_voice = VOICE_MAP.get(lang, voice)

                # 3. Generate voice over
                filename = f"bulk_{lang}_{int(__import__('time').time())}_{__import__('uuid').uuid4().hex[:6]}.mp3"
                output_path = os.path.join(output_dir, filename)

                async def _generate():
                    communicate = edge_tts.Communicate(
                        translated,
                        lang_voice,
                        rate=rate,
                        pitch=pitch,
                        volume="+0%",
                    )
                    await communicate.save(output_path)

                asyncio.run(_generate())

                if os.path.exists(output_path) and os.path.getsize(output_path) > 1000:
                    size_kb = round(os.path.getsize(output_path) / 1024, 2)
                    print(f"   ✅ [{lang}] Done: {size_kb} KB", file=sys.stderr)
                    results.append({
                        "lang": lang,
                        "voice": lang_voice,
                        "text": translated,
                        "filename": filename,
                        "url": f"/download/{filename}",
                        "size_kb": size_kb,
                    })
                else:
                    raise Exception(f"File gagal dibuat untuk {lang}")

            except Exception as e:
                err_msg = str(e)
                print(f"   ❌ [{lang}] Error: {err_msg}", file=sys.stderr)
                errors.append({
                    "lang": lang,
                    "error": err_msg,
                })

        print(f"\n✅ [BulkVO] Selesai: {len(results)}/{len(languages)} sukses", file=sys.stderr)

        return jsonify({
            "success": True,
            "total": len(languages),
            "success_count": len(results),
            "error_count": len(errors),
            "results": results,
            "errors": errors,
            "emotion": emotion,
            "rate": rate,
            "pitch": pitch,
        })

    except Exception as e:
        tb = traceback.format_exc()
        print(f"❌ [BulkVO] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e), "trace": tb}), 500




# ============================================================
# V9.132.0 LEVEL 4C: MULTI-VOICE DIALOG
# Generate dialog multi-karakter dalam 1 file MP3
# ============================================================
@app.route("/generate-voiceover-dialog", methods=["POST"])
def generate_voiceover_dialog():
    """Generate dialog multi-karakter dalam 1 file MP3."""
    if not HAS_EDGE_TTS:
        return jsonify({
            "success": False,
            "error": "edge-tts tidak terinstall",
        }), 500

    try:
        data = request.get_json()
        dialog = data.get("dialog", [])
        emotion = data.get("emotion", "netral")
        output_path = data.get("outputPath")
        pause_ms = int(data.get("pauseMs", 300))  # Jeda antar dialog

        # Validasi
        if not isinstance(dialog, list) or len(dialog) == 0:
            return jsonify({"success": False, "error": "Dialog kosong"}), 400
        if len(dialog) > 30:
            return jsonify({"success": False, "error": "Maksimal 30 baris dialog"}), 400
        if not output_path:
            return jsonify({"success": False, "error": "outputPath wajib"}), 400

        total_chars = sum(len(d.get("text", "")) for d in dialog)
        if total_chars > 5000:
            return jsonify({"success": False, "error": "Total teks maksimal 5000 karakter"}), 400

        # Emotion mapping
        emotion_lower = emotion.lower()
        EMOTION_MAP = {
            "netral":      {"rate": "+0%",   "pitch": "+0Hz"},
            "senang":      {"rate": "+10%",  "pitch": "+8Hz"},
            "sedih":       {"rate": "-15%",  "pitch": "-12Hz"},
            "serius":      {"rate": "-8%",   "pitch": "-15Hz"},
            "takut":       {"rate": "+20%",  "pitch": "+15Hz"},
            "romantis":    {"rate": "-8%",   "pitch": "+5Hz"},
            "berpikir":    {"rate": "-10%",  "pitch": "+0Hz"},
            "bersemangat": {"rate": "+25%",  "pitch": "+18Hz"},
        }
        emo = EMOTION_MAP.get(emotion_lower, EMOTION_MAP["netral"])
        rate = emo["rate"]
        pitch = emo["pitch"]

        print(f"\n{'='*60}", file=sys.stderr)
        print(f"🎭 [DialogVO] Request: {len(dialog)} baris, emotion={emotion}", file=sys.stderr)
        print(f"   Rate: {rate} | Pitch: {pitch} | Pause: {pause_ms}ms", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)

        # Folder temp untuk file per dialog
        temp_dir = os.path.join(os.path.dirname(output_path), "_dialog_temp")
        os.makedirs(temp_dir, exist_ok=True)

        # File temp per baris
        temp_files = []

        # Generate per baris
        for i, line in enumerate(dialog):
            speaker = line.get("speaker", f"Char{i}")
            text = (line.get("text") or "").strip()
            voice = line.get("voice", "id-ID-ArdiNeural")

            if not text:
                continue

            temp_file = os.path.join(temp_dir, f"line_{i:02d}.mp3")

            try:
                print(f"   [{i+1}/{len(dialog)}] {speaker}: {text[:40]}...", file=sys.stderr)

                async def _generate_one(t=text, v=voice, o=temp_file):
                    communicate = edge_tts.Communicate(t, v, rate=rate, pitch=pitch)
                    await communicate.save(o)

                asyncio.run(_generate_one())

                if os.path.exists(temp_file) and os.path.getsize(temp_file) > 500:
                    temp_files.append(temp_file)
                    print(f"      ✅ {os.path.getsize(temp_file) / 1024:.1f} KB", file=sys.stderr)
                else:
                    print(f"      ⚠️ File kosong, skip", file=sys.stderr)

            except Exception as e:
                print(f"      ❌ Error: {e}", file=sys.stderr)

        if not temp_files:
            return jsonify({"success": False, "error": "Tidak ada file yang berhasil di-generate"}), 500

        # Buat file jeda (silence)
        if pause_ms > 0:
            try:
                silence_file = os.path.join(temp_dir, "silence.mp3")
                silence_dur = pause_ms / 1000.0
                # Cari FFmpeg
                ffmpeg_bin = "ffmpeg"
                if os.name == "nt":
                    ffmpeg_bin = "C:\\ffmpeg\\bin\\ffmpeg.exe"
                import subprocess
                subprocess.run([
                    ffmpeg_bin, "-y", "-f", "lavfi", "-i",
                    f"anullsrc=r=24000:cl=mono",
                    "-t", str(silence_dur),
                    "-c:a", "libmp3lame",
                    silence_file
                ], capture_output=True, timeout=10)
                if os.path.exists(silence_file):
                    print(f"   ✅ Silence {pause_ms}ms dibuat", file=sys.stderr)
                else:
                    silence_file = None
            except Exception as e:
                print(f"   ⚠️ Silence gagal: {e}", file=sys.stderr)
                silence_file = None
        else:
            silence_file = None

        # Merge semua file
        print(f"\n   🔗 Merging {len(temp_files)} file...", file=sys.stderr)

        try:
            import subprocess
            ffmpeg_bin = "ffmpeg"
            if os.name == "nt":
                ffmpeg_bin = "C:\\ffmpeg\\bin\\ffmpeg.exe"

            # Buat list file untuk concat
            list_file = os.path.join(temp_dir, "concat_list.txt")
            with open(list_file, "w", encoding="utf-8") as f:
                for i, tf in enumerate(temp_files):
                    # Escape backslash untuk Windows
                    tf_escaped = tf.replace("\\", "/")
                    f.write(f"file '{tf_escaped}'\n")
                    # Tambah silence antar dialog (kecuali terakhir)
                    if silence_file and i < len(temp_files) - 1:
                        sf_escaped = silence_file.replace("\\", "/")
                        f.write(f"file '{sf_escaped}'\n")

            # Concat
            result = subprocess.run([
                ffmpeg_bin, "-y",
                "-f", "concat",
                "-safe", "0",
                "-i", list_file,
                "-c", "copy",
                output_path
            ], capture_output=True, timeout=60)

            if result.returncode != 0 or not os.path.exists(output_path):
                # Fallback: re-encode
                print(f"   ⚠️ Concat copy gagal, coba re-encode...", file=sys.stderr)
                result = subprocess.run([
                    ffmpeg_bin, "-y",
                    "-f", "concat",
                    "-safe", "0",
                    "-i", list_file,
                    "-c:a", "libmp3lame",
                    "-b:a", "128k",
                    output_path
                ], capture_output=True, timeout=120)

            if not os.path.exists(output_path):
                return jsonify({"success": False, "error": "Merge gagal"}), 500

        except Exception as e:
            print(f"   ❌ Merge error: {e}", file=sys.stderr)
            return jsonify({"success": False, "error": f"Merge error: {str(e)}"}), 500

        # Cleanup temp files
        try:
            for tf in temp_files:
                os.remove(tf)
            if silence_file and os.path.exists(silence_file):
                os.remove(silence_file)
            list_file_path = os.path.join(temp_dir, "concat_list.txt")
            if os.path.exists(list_file_path):
                os.remove(list_file_path)
            os.rmdir(temp_dir)
        except Exception:
            pass

        # Info hasil
        size_kb = round(os.path.getsize(output_path) / 1024, 2)
        filename = os.path.basename(output_path)

        print(f"\n   ✅ [DialogVO] Selesai: {filename} ({size_kb} KB)", file=sys.stderr)
        print(f"{'='*60}\n", file=sys.stderr)

        return jsonify({
            "success": True,
            "filename": filename,
            "url": f"/download/{filename}",
            "size_kb": size_kb,
            "dialog_count": len(temp_files),
            "characters": list(set(d.get("speaker", "") for d in dialog if d.get("speaker"))),
            "emotion": emotion,
        })

    except Exception as e:
        tb = traceback.format_exc()
        print(f"❌ [DialogVO] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e), "trace": tb}), 500


@app.route("/voices", methods=["GET"])
def list_voices():
    """List voice yang tersedia untuk voice over (LEVEL 2)."""
    voices = [
        # Indonesia
        {"code": "id-ID-ArdiNeural",   "name": "Ardi (Pria Indonesia)",   "lang": "id", "gender": "Male"},
        {"code": "id-ID-GadisNeural",  "name": "Gadis (Wanita Indonesia)", "lang": "id", "gender": "Female"},
        # English
        {"code": "en-US-GuyNeural",    "name": "Guy (English Male)",       "lang": "en", "gender": "Male"},
        {"code": "en-US-JennyNeural",  "name": "Jenny (English Female)",   "lang": "en", "gender": "Female"},
        {"code": "en-US-AriaNeural",   "name": "Aria (English Female Pro)", "lang": "en", "gender": "Female"},
        {"code": "en-US-DavisNeural",  "name": "Davis (English Male Pro)",  "lang": "en", "gender": "Male"},
        # Japanese
        {"code": "ja-JP-KeitaNeural",  "name": "Keita (Japanese Male)",    "lang": "ja", "gender": "Male"},
        {"code": "ja-JP-NanamiNeural", "name": "Nanami (Japanese Female)", "lang": "ja", "gender": "Female"},
        # Chinese
        {"code": "zh-CN-YunxiNeural",  "name": "Yunxi (Chinese Male)",     "lang": "zh", "gender": "Male"},
        {"code": "zh-CN-XiaoxiaoNeural","name": "Xiaoxiao (Chinese Female)","lang": "zh", "gender": "Female"},
        # Korean
        {"code": "ko-KR-InJoonNeural", "name": "InJoon (Korean Male)",     "lang": "ko", "gender": "Male"},
        # Arabic
        {"code": "ar-SA-HamedNeural",  "name": "Hamed (Arabic Male)",      "lang": "ar", "gender": "Male"},
    ]
    return jsonify({"success": True, "voices": voices})


# ============================================================
# V8.7.0: MULTI-BAHASA TRANSLATE
# ============================================================
MYMEMORY_LANG_MAP = {
    "en": "en-GB",
    "id": "id-ID",
    "ja": "ja-JP",
    "zh": "zh-CN",
    "ar": "ar-SA",
    "ko": "ko-KR",
    "es": "es-ES",
    "fr": "fr-FR",
    "de": "de-DE",
    "pt": "pt-PT",
    "ru": "ru-RU",
    "hi": "hi-IN",
    "th": "th-TH",
    "vi": "vi-VN",
    "ms": "ms-MY",
}


def _translate_google(text, from_code, to_code):
    """Coba Google Translate (kualitas terbaik)."""
    try:
        return GoogleTranslator(source=from_code, target=to_code).translate(text)
    except Exception:
        return None


def _translate_mymemory(text, from_code, to_code):
    """Fallback ke MyMemory."""
    src = MYMEMORY_LANG_MAP.get(from_code, from_code)
    tgt = MYMEMORY_LANG_MAP.get(to_code, to_code)
    try:
        return MyMemoryTranslator(source=src, target=tgt).translate(text)
    except Exception:
        return None


@app.route("/translate", methods=["POST"])
def translate():
    """Translate teks ke bahasa target. Google Ã¢â€â€™ MyMemory fallback."""
    if not HAS_TRANSLATOR:
        return (
            jsonify(
                {
                    "success": False,
                    "error": "deep-translator tidak terinstall. Jalankan: pip install deep-translator",
                }
            ),
            500,
        )

    try:
        data = request.get_json()
        text = (data.get("text") or "").strip()
        from_code = (data.get("from") or "id").lower()
        to_code = (data.get("to") or "en").lower()

        if not text:
            return jsonify({"success": False, "error": "Teks kosong"}), 400
        if len(text) > 5000:
            return (
                jsonify({"success": False, "error": "Teks maksimal 5000 karakter"}),
                400,
            )
        if from_code == to_code:
            return jsonify({"success": True, "translated": text, "provider": "same"})

        print(f"\n{'='*60}", file=sys.stderr)
        print(
            f"Ã°Å¸Å’Â [Translate] {from_code} Ã¢â€â€™ {to_code} ({len(text)} chars)",
            file=sys.stderr,
        )

        result = _translate_google(text, from_code, to_code)
        provider = "google"

        if not result:
            print(f"   Ã¢Å¡ÂÃ¯Â¸Â Google gagal Ã¢â‚¬â€ fallback ke MyMemory", file=sys.stderr)
            result = _translate_mymemory(text, from_code, to_code)
            provider = "mymemory"

        if not result:
            return (
                jsonify({"success": False, "error": "Semua provider translate gagal"}),
                500,
            )

        print(f"   Ã¢Å“â€¦ Done via {provider}: '{result[:80]}...'", file=sys.stderr)

        return jsonify(
            {
                "success": True,
                "translated": result,
                "from": from_code,
                "to": to_code,
                "provider": provider,
            }
        )

    except Exception as e:
        tb = traceback.format_exc()
        print(f"Ã¢ÂÅ’ [Translate] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/translate-languages", methods=["GET"])
def translate_languages():
    """List bahasa yang tersedia."""
    langs = [
        {"code": "en", "name": "English", "flag": "Ã°Å¸â€¡Â¬Ã°Å¸â€¡Â§"},
        {"code": "id", "name": "Indonesia", "flag": "Ã°Å¸â€¡Â®Ã°Å¸â€¡Â©"},
        {"code": "ja", "name": "Ã¦â€”Â¥Ã¦Å“Â¬Ã¨ÂªÅ¾", "flag": "Ã°Å¸â€¡Â¯Ã°Å¸â€¡Âµ"},
        {"code": "zh", "name": "Ã¤Â¸ÂÃ¦â€“â€¡", "flag": "Ã°Å¸â€¡Â¨Ã°Å¸â€¡Â³"},
        {"code": "ar", "name": "Ã˜Â§Ã™â€žÃ˜Â¹Ã˜Â±Ã˜Â¨Ã™ÅÃ˜Â©", "flag": "Ã°Å¸â€¡Â¸Ã°Å¸â€¡Â¦"},
        {"code": "ko", "name": "Ãâ€¢Å“ÃªÂµÂÃ¬â€“Â´", "flag": "Ã°Å¸â€¡Â°Ã°Å¸â€¡Â·"},
        {"code": "es", "name": "EspaÃƒÂ±ol", "flag": "Ã°Å¸â€¡ÂªÃ°Å¸â€¡Â¸"},
        {"code": "fr", "name": "FranÃƒÂ§ais", "flag": "Ã°Å¸â€¡Â«Ã°Å¸â€¡Â·"},
        {"code": "de", "name": "Deutsch", "flag": "Ã°Å¸â€¡Â©Ã°Å¸â€¡Âª"},
        {"code": "pt", "name": "PortuguÃƒÂªs", "flag": "Ã°Å¸â€¡ÂµÃ°Å¸â€¡Â¹"},
        {"code": "ru", "name": "ÃÂÃ‘Æ’Ã‘ÂÃ‘ÂÃÂºÃÂ¸ÃÂ¹", "flag": "Ã°Å¸â€¡Â·Ã°Å¸â€¡Âº"},
        {"code": "hi", "name": "ÃÂ¤Â¹ÃÂ¤Â¿ÃÂ¤Â¨ÃÂ¥ÂÃÂ¤Â¦ÃÂ¥â‚¬", "flag": "Ã°Å¸â€¡Â®Ã°Å¸â€¡Â³"},
        {"code": "th", "name": "ÃÂ¹â€žÃÂ¸â€”ÃÂ¸Â¢", "flag": "Ã°Å¸â€¡Â¹Ã°Å¸â€¡Â"},
        {"code": "vi", "name": "TiÃ¡ÂºÂ¿ng ViÃ¡Â»â€¡t", "flag": "Ã°Å¸â€¡Â»Ã°Å¸â€¡Â³"},
        {"code": "ms", "name": "Bahasa Melayu", "flag": "Ã°Å¸â€¡Â²Ã°Å¸â€¡Â¾"},
    ]
    return jsonify({"success": True, "languages": langs})


# ============================================================
# V8.7.0: REFERENCE STYLE LEARNING
# ============================================================
@app.route("/analyze-reference", methods=["POST"])
def analyze_reference():
    """Analisis video referensi Ã¢â€â€™ extract cut pattern."""
    try:
        data = request.get_json()
        video_path = data.get("videoPath")
        threshold = float(data.get("threshold", 0.3))

        if not video_path or not os.path.exists(video_path):
            return jsonify({"success": False, "error": "Video tidak ditemukan"}), 400

        print(f"\n{'='*60}", file=sys.stderr)
        print(f"Ã°Å¸Å½Â¨ [RefStyle] Analyzing reference...", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)

        profile = pv.analyze_reference_style(video_path, threshold=threshold)

        if not profile.get("success"):
            return jsonify(profile), 500

        return jsonify(profile)

    except Exception as e:
        tb = traceback.format_exc()
        print(f"Ã¢ÂÅ’ [RefStyle] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================
# V8.8.0: AUTO-CLIP Ã¢â‚¬â€ split video panjang jadi N klip pendek
# ============================================================
@app.route("/auto-clip", methods=["POST"])
def auto_clip_endpoint():
    """Split video jadi N klip pendek siap posting."""
    if not HAS_AUTO_CLIP:
        return (
            jsonify(
                {
                    "success": False,
                    "error": "auto_clip module tidak tersedia. Cek auto_clip.py",
                }
            ),
            500,
        )

    try:
        data = request.get_json()
        words = data.get("words", [])
        target_clips = int(data.get("target_clips", 5))

        if not words:
            return jsonify({"success": False, "error": "words kosong"}), 400
        if target_clips < 1 or target_clips > 20:
            target_clips = 5

        print(f"\n{'='*60}", file=sys.stderr)
        print(
            f"Ã¢Å“â€šÃ¯Â¸Â  [AutoClip] Request: {len(words)} words, target {target_clips} klip",
            file=sys.stderr,
        )
        print(f"{'='*60}", file=sys.stderr)

        result = ac.split_by_topic(words, target_clips=target_clips)

        if not result.get("success"):
            return jsonify(result), 500

        print(
            f"Ã¢Å“â€¦ [AutoClip] Done Ã¢â‚¬â€ {result['total_clips']} klip "
            f"(method={result['method']})",
            file=sys.stderr,
        )

        return jsonify(result)

    except Exception as e:
        tb = traceback.format_exc()
        print(f"Ã¢ÂÅ’ [AutoClip] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e), "trace": tb}), 500


# ============================================================
# V8.8.0: GENERATE CLIP THUMBNAIL
# ============================================================
@app.route("/generate-thumbnail", methods=["POST"])
def generate_thumbnail_endpoint():
    """Generate 1 thumbnail dari frame di timestamp tertentu."""
    try:
        data = request.get_json()
        source_path = data.get("sourcePath")
        output_path = data.get("outputPath")
        timestamp = float(data.get("timestamp", 0))
        vertical = data.get("vertical", False)
        title = data.get("title", "")

        if not source_path or not os.path.exists(source_path):
            return jsonify({"success": False, "error": "Source not found"}), 400
        if not output_path:
            return jsonify({"success": False, "error": "outputPath wajib"}), 400

        result = pv.generate_clip_thumbnail(
            source_path=source_path,
            output_path=output_path,
            timestamp=timestamp,
            vertical=vertical,
            title=title,
        )

        if not result.get("success"):
            return jsonify(result), 500
        return jsonify(result)

    except Exception as e:
        tb = traceback.format_exc()
        print(f"Ã¢ÂÅ’ [Thumbnail] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================
# V8.9.0: AI THUMBNAIL GENERATOR (Level 1)
# ============================================================
# ============================================================
# V9.175.0: RETENTION_ENDPOINT - analisis retention score
# ============================================================
# ============================================================
# V9.177.0: AUTO_OPTIMIZE_ENDPOINT — auto-optimize berdasarkan retention
# ============================================================
@app.route("/auto-optimize", methods=["POST"])
def auto_optimize_endpoint():
    """
    Auto-optimize clip berdasarkan retention suggestions.
    
    Request JSON:
    {
        "sourcePath": "/path/to/video.mp4",
        "outputPath": "/path/to/output.mp4",
        "start": 0,
        "end": 60,
        "suggestions": [
            {"type": "cut", "start": 3.5, "end": 6.2, "reason": "silence"},
            {"type": "speedup", "start": 12.0, "end": 15.5, "factor": 1.5},
            {"type": "zoom", "start": 20.0, "end": 22.0, "factor": 1.2}
        ],
        "preset": "1080p",
        "verticalCrop": false,
        "burnSubtitle": true,
        "aspectRatio": "auto",
        "words": [...],  // untuk subtitle
        ...
    }
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "error": "No JSON body"}), 400
        
        source_path = data.get("sourcePath")
        output_path = data.get("outputPath")
        start = float(data.get("start", 0))
        end = float(data.get("end", 0))
        suggestions = data.get("suggestions", [])
        
        if not source_path or not os.path.exists(source_path):
            return jsonify({"success": False, "error": f"Source not found: {source_path}"}), 400
        if not output_path:
            return jsonify({"success": False, "error": "outputPath wajib"}), 400
        if end <= start:
            return jsonify({"success": False, "error": "Range tidak valid"}), 400
        
        print(f"\n{'='*60}", file=sys.stderr)
        print(f"🎬 [AutoOptimize] Request — {start:.1f}-{end:.1f}s", file=sys.stderr)
        print(f"   Suggestions: {len(suggestions)}", file=sys.stderr)
        for s in suggestions:
            print(f"     - {s.get('type')}: {s.get('start')}-{s.get('end')} ({s.get('reason', '')})", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)
        
        # Apply retention suggestions ke clip via process_video
        # Kita set environment variable untuk di-read oleh process_video
        import json as _json
        os.environ["_RETENTION_SUGGESTIONS"] = _json.dumps(suggestions)
        
        # Call process_video dengan retention suggestions
        result = pv.process_video(
            input_path=source_path,
            output_path=output_path,
            aggressiveness=data.get("aggressiveness", "content"),
            add_watermark=data.get("addWatermark", True),
            preset=data.get("preset", "1080p"),
            enable_vertical_crop=bool(data.get("verticalCrop", False)),
            enable_noise_reduction=bool(data.get("enableNoiseReduction", True)),
            progress_path=data.get("progressPath"),
            enable_zoom=True,  # Aktifkan zoom
        )
        
        print(f"✅ [AutoOptimize] Done: {result}", file=sys.stderr)
        
        return jsonify({
            "success": True,
            "result": result,
            "suggestionsApplied": len(suggestions)
        })
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        print(f"❌ [AutoOptimize] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/retention", methods=["POST"])
def retention_analysis():
    """
    Analisis retention score dari words (Whisper transcript).
    
    Request JSON:
    {
        "words": [{"word": "...", "start": 0.0, "end": 0.5}, ...],
        "videoDuration": 308.38,
        "silenceData": [{"start": 10.5, "end": 12.0}, ...]  // optional
        "sceneData": [15.2, 30.5, ...]  // optional
    }
    
    Response:
    {
        "success": true,
        "retention": {
            "overall_score": 5.8,
            "virality": "medium",
            "wpm": 42.0,
            "timeline": [...],
            "drops": [...],
            "suggestions": [...]
        }
    }
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "error": "No JSON body"}), 400
        
        words = data.get("words", [])
        video_duration = float(data.get("videoDuration", 0))
        silence_data = data.get("silenceData") or None
        scene_data = data.get("sceneData") or None
        
        print(f"\n{'='*60}", file=sys.stderr)
        print(f"📊 [Retention] Request — words={len(words)}, duration={video_duration}s", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)
        
        if not words or video_duration <= 0:
            return jsonify({
                "success": False,
                "error": "Missing words or videoDuration"
            }), 400
        
        # Panggil fungsi analyze_retention dari process_video_v8
        result = pv.analyze_retention(
            words=words,
            video_duration=video_duration,
            silence_data=silence_data,
            scene_data=scene_data
        )
        
        print(f"✅ [Retention] Score: {result['overall_score']}/10 ({result['virality']})", file=sys.stderr)
        
        return jsonify({
            "success": True,
            "retention": result
        })
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        print(f"❌ [Retention] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/generate-thumbnail-ai", methods=["POST"])
def generate_thumbnail_ai_endpoint():
    """Generate opsi thumbnail AI (frame pick + hook text)."""
    if not HAS_THUMBNAIL_AI:
        return jsonify({
            "success": False,
            "error": "thumbnail_ai module tidak tersedia"
        }), 500

    try:
        data = request.get_json()
        print(f"\n{'='*60}", file=sys.stderr)
        print(f"Ã°Å¸Å½Â¨ [ThumbnailAI] Request received", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)

        source_path = data.get("sourcePath")
        output_dir = data.get("outputDir")
        start = float(data.get("start", 0))
        end = float(data.get("end", 0))
        transcript_text = data.get("transcriptText", "")
        count = int(data.get("count", 3))
        aspect = data.get("aspect", "16:9")

        if not source_path or not os.path.exists(source_path):
            return jsonify({"success": False, "error": "Source not found"}), 400

        if not output_dir:
            return jsonify({"success": False, "error": "outputDir wajib"}), 400

        font_path = getattr(pv, "FONT_PATH", None)

        result = tai.generate_thumbnail_options(
            source_path=source_path,
            start=start,
            end=end,
            output_dir=output_dir,
            transcript_text=transcript_text,
            count=count,
            aspect=aspect,
            font_path=font_path,
        )

        if not result.get("success"):
            print(f"Ã¢ÂÅ’ [ThumbnailAI] Gagal: {result.get('error')}", file=sys.stderr)
            return jsonify(result), 500

        print(f"Ã¢Å“â€¦ [ThumbnailAI] Done Ã¢â‚¬â€ {len(result.get('options', []))} opsi", file=sys.stderr)
        return jsonify(result)

    except Exception as e:
        tb = traceback.format_exc()
        print(f"Ã¢ÂÅ’ [ThumbnailAI] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e), "trace": tb}), 500




# ============================================================
# MAIN Ã¢â‚¬â€ V8.9.21: Production WSGI (waitress)
# ============================================================


# ============================================================
# V9.180.21: CULTURE_ENDPOINTS
# AI Local Culture & Slang Adaptation
# ============================================================
try:
    from culture_adapter import (
        list_regions,
        get_region_info,
        get_culture_visual,
        get_culture_full,
        adapt_text_for_region,
        adapt_subtitle_ass,
    )
    _CULTURE_AVAILABLE = True
    print("[Culture] Adapter loaded", file=sys.stderr)
except Exception as e:
    _CULTURE_AVAILABLE = False
    print(f"[Culture] Adapter load failed: {e}", file=sys.stderr)


@app.route("/culture/regions", methods=["GET"])
def culture_regions():
    """List semua region yang tersedia."""
    if not _CULTURE_AVAILABLE:
        return jsonify({"success": False, "error": "Culture adapter not available"}), 500
    try:
        regions = list_regions()
        return jsonify({"success": True, "regions": regions, "count": len(regions)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/culture/region/<region_key>", methods=["GET"])
def culture_region_detail(region_key):
    """Detail satu region."""
    if not _CULTURE_AVAILABLE:
        return jsonify({"success": False, "error": "Culture adapter not available"}), 500
    try:
        info = get_culture_full(region_key)
        if not info:
            return jsonify({"success": False, "error": "Region tidak ditemukan"}), 404
        return jsonify({"success": True, "region": info})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/culture/adapt-text", methods=["POST"])
def culture_adapt_text():
    """Adapt text untuk region tertentu."""
    if not _CULTURE_AVAILABLE:
        return jsonify({"success": False, "error": "Culture adapter not available"}), 500
    try:
        data = request.get_json()
        text = data.get("text", "")
        region_key = data.get("region", "")

        if not text or not region_key:
            return jsonify({"success": False, "error": "text & region wajib"}), 400

        adapted = adapt_text_for_region(text, region_key)

        return jsonify({
            "success": True,
            "original": text,
            "adapted": adapted,
            "region": region_key,
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/culture/adapt-subtitle", methods=["POST"])
def culture_adapt_subtitle():
    """Adapt subtitle ASS untuk region."""
    if not _CULTURE_AVAILABLE:
        return jsonify({"success": False, "error": "Culture adapter not available"}), 500
    try:
        data = request.get_json()
        ass_path = data.get("assPath")
        region_key = data.get("region")
        output_path = data.get("outputPath")

        if not ass_path or not region_key:
            return jsonify({"success": False, "error": "assPath & region wajib"}), 400

        if not os.path.exists(ass_path):
            return jsonify({"success": False, "error": f"File tidak ada: {ass_path}"}), 404

        result_path = adapt_subtitle_ass(ass_path, region_key, output_path)

        if result_path:
            return jsonify({
                "success": True,
                "outputPath": result_path,
                "region": region_key,
            })
        else:
            return jsonify({"success": False, "error": "Gagal adapt subtitle"}), 500
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500






# ============================================================
# V9.183.0: AI_DUBBING_GENERATOR
# Generate voice over bahasa daerah dari transcript
# ============================================================
@app.route("/generate-dubbing", methods=["POST"])
def generate_dubbing_endpoint():
    """Generate dubbing bahasa daerah dari transcript."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "error": "Body kosong"}), 400

        text = (data.get("text") or "").strip()
        lang_code = (data.get("langCode") or "jawa").strip()
        gender = (data.get("gender") or "female").strip()
        rate = (data.get("rate") or "+0%").strip()

        if not text:
            return jsonify({"success": False, "error": "Text kosong"}), 400

        if len(text) > 5000:
            text = text[:5000]  # limit

        print(f"\n{'='*60}", file=sys.stderr)
        print(f"[Dubbing] Request - {len(text)} char, lang={lang_code}, gender={gender}", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)

        from dubbing_generator import text_to_speech, list_available_languages

        # Output path
        import uuid
        output_dir = os.path.join(os.path.dirname(__file__), "temp")
        os.makedirs(output_dir, exist_ok=True)
        output_filename = f"dubbing_{uuid.uuid4().hex[:8]}.mp3"
        output_path = os.path.join(output_dir, output_filename)

        result_path = text_to_speech(
            text=text,
            lang_code=lang_code,
            gender=gender,
            output_path=output_path,
            rate=rate,
        )

        if not result_path or not os.path.exists(result_path):
            return jsonify({"success": False, "error": "Gagal generate dubbing"}), 500

        size_kb = os.path.getsize(result_path) / 1024

        return jsonify({
            "success": True,
            "audioFile": output_filename,
            "audioUrl": f"/temp/{output_filename}",
            "langCode": lang_code,
            "gender": gender,
            "sizeKB": round(size_kb, 1),
        })

    except Exception as e:
        tb = traceback.format_exc()
        print(f"[Dubbing] Error: {e}", file=sys.stderr)
        print(tb, file=sys.stderr)
        return jsonify({"success": False, "error": str(e), "trace": tb}), 500


# ============================================================
# V9.183.0: LIST DUBBING LANGUAGES
# ============================================================
@app.route("/dubbing-languages", methods=["GET"])
def dubbing_languages_endpoint():
    """List bahasa yang tersedia untuk dubbing."""
    try:
        from dubbing_generator import list_available_languages
        return jsonify({
            "success": True,
            "languages": list_available_languages(),
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================
# V9.182.0: AI_HOOK_GENERATOR
# ============================================================
@app.route("/generate-hooks", methods=["POST"])
def generate_hooks_endpoint():
    """Generate judul + hook + caption dari transcript video."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "error": "Body kosong"}), 400

        transcript = (data.get("transcript") or "").strip()
        title_hint = (data.get("title_hint") or "").strip()
        max_judul = int(data.get("max_judul") or 10)

        # Fallback: kalau ada words (Whisper format)
        if not transcript and data.get("words"):
            transcript = " ".join([w.get("word", "") for w in data["words"] if w.get("word")])

        if len(transcript) < 20:
            return jsonify({
                "success": False,
                "error": "Transcript terlalu pendek (min 20 karakter)"
            }), 400

        print(f"\n{'='*60}", file=sys.stderr)
        print(f"[HookGen] Request - {len(transcript)} char", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)

        from hook_generator import generate_hooks
        result = generate_hooks(transcript, title_hint, max_judul)

        if not result:
            return jsonify({
                "success": False,
                "error": "Gagal generate hooks (cek log server)"
            }), 500

        return jsonify({
            "success": True,
            **result,
        })

    except Exception as e:
        print(f"[HookGen] Error: {e}", file=sys.stderr)
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)}), 500


if __name__ == "__main__":
    PORT = int(os.getenv("PYTHON_SERVER_PORT", "5001"))
    HOST = os.getenv("PYTHON_SERVER_HOST", "127.0.0.1")
    THREADS = int(os.getenv("PYTHON_SERVER_THREADS", "8"))

    print(
        f"\nÃ°Å¸Å¡â‚¬ Python AI Server V8.9.21 (waitress) listening on http://{HOST}:{PORT}",
        file=sys.stderr,
    )
    print(f"   Endpoints: /health, /analyze, /render, /auto-clip, /cancel-render", file=sys.stderr)
    print(f"   Threads: {THREADS}", file=sys.stderr)
    print(f"   Ready to accept requests!\n", file=sys.stderr)

    try:
        from waitress import serve
        serve(
            app,
            host=HOST,
            port=PORT,
            threads=THREADS,
            channel_timeout=3600,        # 1 jam untuk analyze video panjang
            connection_limit=100,
            max_request_body_size=1024 * 1024 * 1024,  # 1GB
            clear_untrusted_proxy_headers=False,
        )
    except ImportError:
        print(
            "[ERROR] waitress tidak terinstall. Jalankan: pip install waitress",
            file=sys.stderr
        )
        print("[FALLBACK] Pakai Flask dev server (TIDAK untuk production)...", file=sys.stderr)
        app.run(host=HOST, port=PORT, threaded=True, debug=False, use_reloader=False)
