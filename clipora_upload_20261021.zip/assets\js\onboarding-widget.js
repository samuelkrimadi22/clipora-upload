// ============================================================
// PANDUAN AWAL WIDGET (Dashboard) - V9.1.0 + V9.31.0: Ganti text
// ============================================================
(function() {
    'use strict';

    const API = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.apiUrl) || '/api';
    const TOKEN = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || '';
    const IS_LOGGED_IN = window.CLIPORA_AUTH && window.CLIPORA_AUTH.isLoggedIn;
    const IS_ADMIN = window.CLIPORA_AUTH && window.CLIPORA_AUTH.isAdmin;

    if (!IS_LOGGED_IN || !TOKEN || IS_ADMIN) return;
    if (window.__ONBOARDING_WIDGET__) return;
    window.__ONBOARDING_WIDGET__ = true;

    const DISMISS_KEY = 'clipora_onboarding_widget_dismissed';
    const DISMISS_DURATION = 24 * 60 * 60 * 1000; // 24 jam

    // Cek apakah user dismiss dalam 24 jam terakhir
    function isDismissed() {
        try {
            const raw = localStorage.getItem(DISMISS_KEY);
            if (!raw) return false;
            const ts = parseInt(raw);
            if (Date.now() - ts > DISMISS_DURATION) {
                localStorage.removeItem(DISMISS_KEY);
                return false;
            }
            return true;
        } catch (e) {
            return false;
        }
    }

    function markDismissed() {
        try {
            localStorage.setItem(DISMISS_KEY, Date.now().toString());
        } catch (e) {}
    }

    // Cari container yang tepat untuk widget
    function findContainer() {
        // Prioritas: main .container > main > body
        const candidates = [
            'main .container',
            'main > .container',
            '.dashboard-container',
            'main',
        ];
        for (const sel of candidates) {
            const el = document.querySelector(sel);
            if (el) return el;
        }
        return null;
    }

    // Render widget
    function renderWidget(data) {
        const container = findContainer();
        if (!container) {
            console.warn('[OnboardingWidget] Container tidak ditemukan');
            return;
        }

        // Hapus widget lama kalau ada
        const existing = document.getElementById('onboardingWidget');
        if (existing) existing.remove();

        const { onboarding, progress } = data;
        const isCompleted = progress.completed;

        // Bangun HTML steps
        const stepsHtml = progress.steps.map((step, idx) => {
            const done = step.done;
            return `
                <div class="ob-step ${done ? 'done' : ''}">
                    <div class="ob-step-icon">${done ? '' : (idx + 1)}</div>
                    <span class="ob-step-label">${step.label}</span>
                </div>
            `;
        }).join('');

        // CTA button
        const ctaHtml = isCompleted
            ? `<button class="ob-widget-cta" onclick="document.getElementById('onboardingWidget').remove(); localStorage.setItem('${DISMISS_KEY}', Date.now().toString());">
                   🎉 Mulai Bikin Video
               </button>
               <div class="ob-widget-hint">Anda sudah menguasai dasar Clipora!</div>`
            : `<a href="index.php" class="ob-widget-cta">
                   <i class="fas fa-arrow-right"></i> Lanjutkan Panduan Awal
               </a>
               <div class="ob-widget-hint">${progress.done_count} dari ${progress.total} selesai</div>`;

        const widget = document.createElement('div');
        widget.id = 'onboardingWidget';
        widget.className = 'onboarding-widget' + (isCompleted ? ' completed' : '');

        widget.innerHTML = `
            <div class="ob-widget-header">
                <div class="ob-widget-title">
                    <span class="ob-emoji">${isCompleted ? '🎉' : '🎯'}</span>
                    <span>${isCompleted ? 'Selamat! Panduan Awal Selesai' : 'Progres Panduan Awal'}</span>
                    <span class="ob-progress-pill">${progress.done_count}/${progress.total}</span>
                </div>
                <button class="ob-widget-close" title="Sembunyikan 24 jam">×</button>
            </div>

            <div class="ob-progress-bar">
                <div class="ob-progress-fill" style="width:${progress.percent}%"></div>
            </div>

            <div class="ob-steps">
                ${stepsHtml}
            </div>

            <div class="ob-widget-actions">
                ${ctaHtml}
            </div>
        `;

        // Insert di atas container (paling atas dashboard)
        container.insertBefore(widget, container.firstChild);

        // Bind close button
        widget.querySelector('.ob-widget-close').addEventListener('click', () => {
            widget.style.opacity = '0';
            widget.style.transform = 'translateY(-12px)';
            setTimeout(() => widget.remove(), 300);
            markDismissed();
        });

        console.log(`🎯 [OnboardingWidget] Rendered ${progress.done_count}/${progress.total} (${progress.percent}%)`);
    }

    // Fetch progress
    async function fetchProgress() {
        try {
            const r = await fetch(API + '/user/onboarding', {
                headers: { 'Authorization': 'Bearer ' + TOKEN },
                cache: 'no-store'
            });
            const d = await r.json();
            return d.success ? d : null;
        } catch (e) {
            console.warn('[OnboardingWidget] Fetch error:', e.message);
            return null;
        }
    }

    // Init
    async function init() {
        // Kalau di-dismiss dalam 24 jam terakhir, skip
        if (isDismissed()) {
            console.log('🎯 [OnboardingWidget] Skipped (dismissed)');
            return;
        }

        // Delay kecil biar dashboard kelar render dulu
        setTimeout(async () => {
            const data = await fetchProgress();
            if (!data) return;
            renderWidget(data);
        }, 500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();