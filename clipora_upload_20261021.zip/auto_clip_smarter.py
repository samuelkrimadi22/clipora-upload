# ============================================================
# Auto-Clip Smarter — V9.185.0
# ============================================================
import os
import sys
import json
import subprocess
import tempfile
from pathlib import Path
from typing import List, Dict, Optional, Tuple

import cv2
import numpy as np

try:
    import scenedetect
    from scenedetect import open_video, SceneManager, ContentDetector
    HAS_SCENEDETECT = True
except ImportError:
    HAS_SCENEDETECT = False

try:
    import librosa
    HAS_LIBROSA = True
except ImportError:
    HAS_LIBROSA = False


def detect_scenes(video_path, threshold=27.0, min_scene_len=2.0):
    """Detect scene changes pakai PySceneDetect."""
    if not HAS_SCENEDETECT or not os.path.exists(video_path):
        return []
    try:
        video = open_video(video_path)
        sm = SceneManager()
        sm.add_detector(ContentDetector(threshold=threshold, min_scene_len=int(min_scene_len * 30)))
        sm.detect_scenes(video, show_progress=False)
        scene_list = sm.get_scene_list()
        scenes = []
        for i, (start, end) in enumerate(scene_list):
            s = start.get_seconds()
            e = end.get_seconds()
            scenes.append({"index": i, "start": s, "end": e, "duration": e - s})
        print(f"[Smarter] Found {len(scenes)} scenes", file=sys.stderr)
        return scenes
    except Exception as e:
        print(f"[Smarter] Scene error: {e}", file=sys.stderr)
        return []


def detect_audio_energy(audio_path, hop_length=512):
    """Detect audio energy per frame."""
    if not HAS_LIBROSA or not os.path.exists(audio_path):
        return None
    try:
        y, sr = librosa.load(audio_path, sr=None, mono=True)
        rms = librosa.feature.rms(y=y, hop_length=hop_length)[0]
        if rms.max() > 0:
            rms = rms / rms.max()
        kernel = np.ones(10) / 10
        return np.convolve(rms, kernel, mode="same")
    except Exception as e:
        print(f"[Smarter] Audio energy error: {e}", file=sys.stderr)
        return None


def extract_audio(video_path, output_path):
    """Extract audio via FFmpeg."""
    try:
        cmd = ["ffmpeg", "-y", "-i", video_path, "-vn", "-acodec", "pcm_s16le",
               "-ar", "16000", "-ac", "1", output_path]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        return r.returncode == 0 and os.path.exists(output_path)
    except Exception:
        return False


def detect_motion(video_path, sample_fps=2.0):
    """Detect motion per detik (proxy emosi)."""
    if not os.path.exists(video_path):
        return None
    try:
        cap = cv2.VideoCapture(video_path)
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        if fps <= 0 or total_frames <= 0:
            cap.release()
            return None
        sample_interval = max(1, int(fps / sample_fps))
        motion_scores = []
        prev_gray = None
        frame_idx = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            if frame_idx % sample_interval == 0:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                gray = cv2.resize(gray, (320, 180))
                if prev_gray is not None:
                    diff = cv2.absdiff(prev_gray, gray)
                    score = float(np.mean(diff)) / 255.0
                    motion_scores.append((frame_idx / fps, score))
                prev_gray = gray
            frame_idx += 1
        cap.release()
        if motion_scores:
            mx = max(s[1] for s in motion_scores)
            if mx > 0:
                motion_scores = [(t, s / mx) for t, s in motion_scores]
        print(f"[Smarter] Motion: {len(motion_scores)} samples", file=sys.stderr)
        return motion_scores
    except Exception as e:
        print(f"[Smarter] Motion error: {e}", file=sys.stderr)
        return None


def _make_preview_text(words, start, end, max_chars=100):
    if not words:
        return ""
    sel = [w.get("word", "") for w in words if start <= w.get("start", 0) <= end]
    text = " ".join(sel)
    if len(text) > max_chars:
        text = text[:max_chars] + "..."
    return text.strip()


def smarter_split(video_path, words, target_clips=5,
                  use_scene=True, use_hook=True, use_motion=True):
    """Split video pintar pakai scene + hook + motion."""
    print(f"\n[Smarter] === Auto-Clip Smarter ===", file=sys.stderr)
    print(f"[Smarter] Target: {target_clips} clips", file=sys.stderr)

    scenes = detect_scenes(video_path) if use_scene else []

    audio_energy = None
    if use_hook:
        with tempfile.TemporaryDirectory() as tmpdir:
            ap = os.path.join(tmpdir, "audio.wav")
            if extract_audio(video_path, ap):
                audio_energy = detect_audio_energy(ap)

    motion_scores = detect_motion(video_path) if use_motion else None
    motion_scores = motion_scores or []

    total_duration = 0
    if words:
        total_duration = max(w.get("end", 0) for w in words)
    elif scenes:
        total_duration = max(s["end"] for s in scenes)

    if total_duration <= 0:
        return []

    clips = []

    if scenes:
        for scene in scenes:
            if scene["duration"] < 3.0:
                continue
            start = scene["start"]
            end = scene["end"]

            hook_score = 0.0
            if audio_energy is not None:
                try:
                    sf = int(start * 16000 / 512)
                    ef = int(end * 16000 / 512)
                    if sf < len(audio_energy) and ef <= len(audio_energy):
                        seg = audio_energy[sf:ef]
                        hook_score = float(np.mean(seg)) if len(seg) > 0 else 0.0
                except Exception:
                    pass

            motion_score = 0.0
            if motion_scores:
                rel = [(t, s) for t, s in motion_scores if start <= t <= end]
                if rel:
                    motion_score = float(np.mean([s for _, s in rel]))

            combined = 0.5 * hook_score + 0.5 * motion_score

            clips.append({
                "start": start, "end": end, "duration": end - start,
                "score": combined, "hook_score": hook_score,
                "motion_score": motion_score, "is_scene": True,
            })
    else:
        # V9.185.2: Sliding window manual (tanpa auto_clip.py)
        # Pasti menghasilkan target_clips klip, dengan hook + motion score
        try:
            total_dur = 0.0
            if words:
                total_dur = max(w.get("end", 0) for w in words)
            if total_dur <= 0:
                print("[Smarter] Total durasi 0, skip", file=sys.stderr)
                return []

            # Window size: pakai 60s default, atau total/target kalau lebih kecil
            window_size = min(60.0, total_dur / target_clips)
            if window_size < 10.0:
                window_size = total_dur / target_clips

            # Hitung step agar dapat tepat target_clips
            step = (total_dur - window_size) / max(1, target_clips - 1) if target_clips > 1 else 0

            print(f"[Smarter] Sliding window manual: {target_clips} klip, window={window_size:.1f}s, step={step:.1f}s", file=sys.stderr)

            for i in range(target_clips):
                start = i * step
                end = start + window_size
                if end > total_dur:
                    end = total_dur
                    start = max(0.0, end - window_size)

                # Hook score dari audio energy
                hook_score = 0.0
                if audio_energy is not None:
                    try:
                        sf = int(start * 16000 / 512)
                        ef = int(end * 16000 / 512)
                        if sf < len(audio_energy) and ef <= len(audio_energy):
                            seg = audio_energy[sf:ef]
                            hook_score = float(np.mean(seg)) if len(seg) > 0 else 0.0
                    except Exception:
                        pass

                # Motion score
                motion_score = 0.0
                if motion_scores:
                    rel = [(t, s) for t, s in motion_scores if start <= t <= end]
                    if rel:
                        motion_score = float(np.mean([s for _, s in rel]))

                # Combined score
                combined = 0.5 * hook_score + 0.5 * motion_score

                clips.append({
                    "start": start,
                    "end": end,
                    "duration": end - start,
                    "score": combined,
                    "hook_score": hook_score,
                    "motion_score": motion_score,
                    "is_scene": False,
                    "preview_text": _make_preview_text(words, start, end),
                })

            print(f"[Smarter] Sliding window manual: {len(clips)} klip dibuat", file=sys.stderr)

        except Exception as e:
            print(f"[Smarter] Sliding window error: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()

    clips.sort(key=lambda c: c["score"], reverse=True)
    top = clips[:target_clips]

    for i, clip in enumerate(top):
        clip["id"] = i + 1
        clip["preview_text"] = _make_preview_text(words, clip["start"], clip["end"])

    print(f"[Smarter] Hasil: {len(top)} klip", file=sys.stderr)
    for c in top:
        print(f"[Smarter]   #{c['id']}: {c['start']:.1f}-{c['end']:.1f}s (score={c['score']:.3f})",
              file=sys.stderr)

    return top


if __name__ == "__main__":
    print("=== Auto-Clip Smarter Test ===\n")
    test_video = "uploads/1791496175060_61aa9998.mp4"
    if not os.path.exists(test_video):
        print(f"[SKIP] Video tidak ada: {test_video}")
        sys.exit(0)
    print("1. Test scene detection...")
    scenes = detect_scenes(test_video)
    print(f"   OK: {len(scenes)} scenes\n")
    print("2. Test motion detection...")
    motion = detect_motion(test_video)
    print(f"   OK: {len(motion) if motion else 0} samples\n")
    print("=== SELESAI ===")
