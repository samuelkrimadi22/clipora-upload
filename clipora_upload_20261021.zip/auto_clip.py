#!/usr/bin/env python3
# auto_clip.py — Clipora V8.8.0 Auto-Clip Generator
# ============================================================
# Fitur: Split 1 video panjang → N klip pendek siap posting
#
# Cara kerja:
#   1. Ambil transcript dari Whisper (input dari process_video_v8)
#   2. Embed tiap kalimat pakai sentence-transformer
#   3. Deteksi topic shift (percentile-based)
#   4. Split jadi N segmen topik
#   5. Per segmen → cari sub-window paling "menarik" (hook score)
#   6. Return list klip dengan start/end + metadata
# ============================================================

import os
import re
import sys
import json
import math
from collections import Counter

# Optional — kalau sentence-transformer tidak ada, pakai fallback keyword
try:
    import numpy as np
    from sklearn.metrics.pairwise import cosine_similarity
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None
    cosine_similarity = None


# ============================================================
# CONFIG
# ============================================================
MIN_TOPIC_DURATION      = float(os.getenv("AUTOCLIP_MIN_TOPIC_DUR", "8"))
MAX_TOPIC_DURATION      = float(os.getenv("AUTOCLIP_MAX_TOPIC_DUR", "180"))
MIN_CLIP_DURATION       = float(os.getenv("AUTOCLIP_MIN_CLIP_DUR", "15"))
MAX_CLIP_DURATION       = float(os.getenv("AUTOCLIP_MAX_CLIP_DUR", "60"))
TARGET_CLIP_COUNT       = int(os.getenv("AUTOCLIP_TARGET_COUNT", "5"))
TOPIC_SHIFT_THRESHOLD   = float(os.getenv("AUTOCLIP_TOPIC_THRESHOLD", "0.55"))
MAX_CLIPS_HARD_LIMIT    = int(os.getenv("AUTOCLIP_MAX_CLIPS", "10"))


# ============================================================
# HOOK SCORING
# ============================================================
HOOK_KEYWORDS = [
    'rahasia', 'ternyata', 'jangan', 'tahukah', 'penting', 'kunci',
    'cara', 'gimana', 'bagaimana', 'kenapa', 'mengapa', 'tips',
    'juta', 'miliar', 'ribu', 'persen', 'pertama', 'kedua', 'ketiga',
    'tahun', 'bulan', 'hari',
    'gagal', 'berhasil', 'sukses', 'bangkrut', 'kaya', 'miskin',
    'takut', 'berani', 'cinta', 'benci', 'sedih', 'senang',
    'cerita', 'pengalaman', 'waktu itu', 'dulu', 'akhirnya',
    'coba', 'lakukan', 'mulai', 'berhenti', 'ubah', 'tingkatkan'
]

BORING_MARKERS = [
    'oke', 'ya', 'jadi', 'nah', 'hmm', 'emm', 'eh',
    'sebentar', 'tunggu', 'maaf', 'sori'
]


def _score_window(words_in_window, duration):
    """Hitung skor "menarik" untuk satu window klip. Range: 0.0 - 1.0"""
    if not words_in_window or duration <= 0:
        return 0.0

    text = ' '.join(w.get('word', '') for w in words_in_window).lower()
    text_clean = re.sub(r'[^\w\s]', ' ', text)
    tokens = text_clean.split()

    if not tokens:
        return 0.0

    score = 0.0

    # 1. Word density
    density = len(tokens) / duration
    if 2.0 <= density <= 4.0:
        score += 0.25
    elif 1.5 <= density < 2.0 or 4.0 < density <= 5.5:
        score += 0.15
    elif density < 1.0:
        score -= 0.20

    # 2. Hook keywords
    hook_hits = sum(1 for kw in HOOK_KEYWORDS if kw in text)
    score += min(hook_hits * 0.08, 0.30)

    # 3. Boring markers
    boring_hits = sum(1 for kw in BORING_MARKERS if f' {kw} ' in f' {text} ')
    score -= min(boring_hits * 0.03, 0.15)

    # 4. Ada pertanyaan?
    if '?' in text:
        score += 0.10

    # 5. Ada angka?
    if re.search(r'\d', text):
        score += 0.08

    # 6. Intensifier
    intensifiers = ['sangat', 'banget', 'sekali', 'paling', 'terlalu', 'super']
    if any(i in text for i in intensifiers):
        score += 0.07

    # 7. Kalimat tuntas
    if tokens[-1] and words_in_window[-1].get('word', '').strip().endswith(('.', '!', '?')):
        score += 0.05

    # 8. Catchphrase
    word_freq = Counter(tokens)
    most_common = word_freq.most_common(1)
    if most_common and most_common[0][1] >= 2 and len(most_common[0][0]) > 4:
        score += 0.05

    return max(0.0, min(1.0, score))


def find_best_clip_window(words, topic_start, topic_end):
    """Dalam satu topik, cari sub-window dengan hook score tertinggi."""
    topic_words = [w for w in words if topic_start <= w.get('start', 0) <= topic_end]
    if not topic_words:
        return None

    topic_dur = topic_end - topic_start

    if topic_dur <= MAX_CLIP_DURATION:
        score = _score_window(topic_words, topic_dur)
        return {
            'start': round(topic_start, 2),
            'end': round(topic_end, 2),
            'score': round(score, 3),
            'duration': round(topic_dur, 2),
        }

    best = None
    for win_dur in [MAX_CLIP_DURATION, 45, 35, 25, MIN_CLIP_DURATION]:
        if win_dur > topic_dur:
            continue

        t = topic_start
        while t + win_dur <= topic_end:
            win_words = [w for w in topic_words if t <= w.get('start', 0) <= t + win_dur]
            if len(win_words) < 3:
                t += 5
                continue

            score = _score_window(win_words, win_dur)
            length_bonus = 0.05 if 30 <= win_dur <= 60 else 0
            final_score = score + length_bonus

            if best is None or final_score > best['score']:
                best = {
                    'start': round(t, 2),
                    'end': round(t + win_dur, 2),
                    'score': round(final_score, 3),
                    'duration': round(win_dur, 2),
                }
            t += 5

    return best


# ============================================================
# TOPIC SPLITTING
# ============================================================
def _build_sentences_from_words(words, max_gap=0.8, max_words=15, max_dur=5.0):
    """Gabungkan words jadi kalimat-kalimat."""
    if not words:
        return []

    sentences = []
    current = [words[0]]

    for w in words[1:]:
        gap = w.get('start', 0) - current[-1].get('end', 0)
        total_dur = w.get('end', 0) - current[0].get('start', 0)

        if gap > max_gap or len(current) >= max_words or total_dur > max_dur:
            sentences.append({
                'start': current[0]['start'],
                'end': current[-1]['end'],
                'text': ' '.join(x.get('word', '') for x in current).strip(),
                'words': current,
            })
            current = [w]
        else:
            current.append(w)

    if current:
        sentences.append({
            'start': current[0]['start'],
            'end': current[-1]['end'],
            'text': ' '.join(x.get('word', '') for x in current).strip(),
            'words': current,
        })

    return sentences


def _detect_topic_boundaries_semantic(sentences, threshold=None):
    """
    V8.8.0 FIX: Pakai percentile-based (top 25% distance jadi boundary)
    karena threshold absolut tidak robust untuk bahasa Indonesia.
    """
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2', device='cpu')
    except Exception as e:
        print(f"[AutoClip] Sentence-transformer gagal: {e}", file=sys.stderr)
        return None

    texts = [s['text'] for s in sentences if s['text'].strip()]
    if len(texts) < 3:
        return None

    try:
        embeddings = model.encode(texts, show_progress_bar=False, convert_to_numpy=True)
    except Exception as e:
        print(f"[AutoClip] Encode gagal: {e}", file=sys.stderr)
        return None

    distances = []
    for i in range(1, len(embeddings)):
        sim = cosine_similarity([embeddings[i-1]], [embeddings[i]])[0][0]
        distances.append(float(1.0 - sim))

    if not distances:
        return [0]

    sorted_dist = sorted(distances, reverse=True)
    n_boundaries = max(1, int(len(distances) * 0.25))
    cutoff_idx = min(n_boundaries - 1, len(sorted_dist) - 1)
    cutoff = sorted_dist[cutoff_idx]
    cutoff = max(0.30, min(0.75, cutoff))

    boundaries = [0]
    for i, dist in enumerate(distances):
        if dist >= cutoff:
            boundaries.append(i + 1)

    print(f"[AutoClip] Semantic boundaries: {len(boundaries)} dari {len(sentences)} kalimat "
          f"(cutoff={cutoff:.2f}, target_top={n_boundaries})", file=sys.stderr)
    return boundaries


def _detect_topic_boundaries_gap(sentences, min_gap=1.5):
    """Fallback: deteksi boundary dari gap antar kalimat."""
    boundaries = [0]
    for i in range(1, len(sentences)):
        gap = sentences[i]['start'] - sentences[i-1]['end']
        if gap > min_gap:
            boundaries.append(i)
    print(f"[AutoClip] Gap boundaries: {len(boundaries)}", file=sys.stderr)
    return boundaries


def _merge_short_topics(sentences, boundaries, min_duration=MIN_TOPIC_DURATION):
    """Gabung topik yang terlalu pendek ke topik berikutnya."""
    if not boundaries:
        return []

    boundaries = sorted(set(boundaries))
    if boundaries[-1] != len(sentences):
        boundaries.append(len(sentences))

    topics = []
    for i in range(len(boundaries) - 1):
        start_idx = boundaries[i]
        end_idx = boundaries[i + 1] - 1

        if start_idx >= len(sentences) or end_idx < start_idx:
            continue

        topic_start = sentences[start_idx]['start']
        topic_end = sentences[end_idx]['end']
        topic_dur = topic_end - topic_start

        if topic_dur < min_duration and topics:
            topics[-1]['end'] = topic_end
            topics[-1]['end_idx'] = end_idx
        else:
            topics.append({
                'start': topic_start,
                'end': topic_end,
                'start_idx': start_idx,
                'end_idx': end_idx,
                'duration': topic_dur,
            })

    return topics


# ============================================================
# MAIN FUNCTION
# ============================================================
def split_by_topic(words, target_clips=TARGET_CLIP_COUNT):
    """
    Main function: split transcript jadi N klip pendek siap posting.
    """
    if not words:
        return {"success": False, "error": "No words provided", "clips": []}

    total_duration = max((w.get('end', 0) for w in words), default=0)
    if total_duration < MIN_CLIP_DURATION:
        return {
            "success": True,
            "total_clips": 1,
            "clips": [{
                "id": 1,
                "start": 0,
                "end": round(total_duration, 2),
                "duration": round(total_duration, 2),
                "score": 0.5,
                "preview_text": ' '.join(w.get('word', '') for w in words[:15]),
            }],
            "method": "whole",
            "total_duration": round(total_duration, 2),
            "note": "Video terlalu pendek, pakai keseluruhan",
        }

    print(f"[AutoClip] Total duration: {total_duration:.1f}s, {len(words)} words", file=sys.stderr)

    # 1. Group jadi kalimat
    sentences = _build_sentences_from_words(words)
    print(f"[AutoClip] Sentences: {len(sentences)}", file=sys.stderr)

    if len(sentences) < 3:
        return _fallback_whole_video(words, total_duration)

    # 2. Deteksi boundary
    # V9.123.5: BYPASS SEMANTIC - pakai gap saja, hemat ~500 MB RAM
    _use_semantic = os.getenv("USE_SEMANTIC_BOUNDARY", "false").lower() == "true"
    if _use_semantic:
        boundaries = _detect_topic_boundaries_semantic(sentences, TOPIC_SHIFT_THRESHOLD)
        method = "semantic"
        if not boundaries:
            boundaries = _detect_topic_boundaries_gap(sentences)
            method = "gap"
    else:
        boundaries = _detect_topic_boundaries_gap(sentences)
        method = "gap"
        print("[AutoClip] V9.123.5: Using gap method (semantic disabled)", file=sys.stderr)

    # 3. Merge topik pendek
    topics = _merge_short_topics(sentences, boundaries)
    print(f"[AutoClip] Topics: {len(topics)}", file=sys.stderr)

    if not topics:
        return _fallback_whole_video(words, total_duration)

    # 4. Cari best window per topik
    clips = []
    for idx, topic in enumerate(topics):
        window = find_best_clip_window(words, topic['start'], topic['end'])
        if window:
            window['topic_id'] = idx + 1
            window['preview_text'] = _make_preview_text(words, window['start'], window['end'])
            clips.append(window)

    # 5. Kalau topik banyak, ambil N terbaik
    if len(clips) > MAX_CLIPS_HARD_LIMIT:
        clips.sort(key=lambda c: c['score'], reverse=True)
        clips = clips[:MAX_CLIPS_HARD_LIMIT]

    # V9.9.2: Merge clips kalau jumlah > target (cover range penuh)
    if len(clips) > target_clips and len(clips) > 1:
        print(f"[AutoClip] Merge {len(clips)} clips -> {target_clips} (target user)",
              file=sys.stderr)
        # Sort by start time dulu
        clips.sort(key=lambda c: c['start'])
        # Merge berulang: gabung pasangan dengan gap terkecil
        while len(clips) > target_clips:
            min_gap = float('inf')
            merge_idx = -1
            for i in range(len(clips) - 1):
                gap = clips[i+1]['start'] - clips[i]['end']
                if gap < min_gap:
                    min_gap = gap
                    merge_idx = i
            if merge_idx < 0:
                clips.sort(key=lambda c: c['score'], reverse=True)
                clips = clips[:target_clips]
                break
            a = clips[merge_idx]
            b = clips[merge_idx + 1]
            merged = {
                'start': a['start'],
                'end': b['end'],
                'duration': round(b['end'] - a['start'], 2),
                'score': max(a.get('score', 0.5), b.get('score', 0.5)),
                'preview_text': (str(a.get('preview_text', '')) + ' ' + str(b.get('preview_text', ''))).strip()[:200],
                'topic_id': a.get('topic_id', 0),
            }
            clips = clips[:merge_idx] + [merged] + clips[merge_idx + 2:]

    # 6. Fallback kalau topik < 2
    if len(clips) < 2:
        print(f"[AutoClip] Topik terlalu sedikit ({len(clips)}) — fallback ke sliding window",
              file=sys.stderr)
        clips = _sliding_window_clips(words, total_duration, target_clips)
    elif len(clips) < target_clips:
        clips = _expand_clips(clips, words, target_clips)

    # 7. Sort by start time
    clips.sort(key=lambda c: c['start'])

    # 8. Assign ID final
    for i, c in enumerate(clips, 1):
        c['id'] = i

    return {
        "success": True,
        "total_clips": len(clips),
        "clips": clips,
        "method": method,
        "total_duration": round(total_duration, 2),
    }


def _fallback_whole_video(words, total_duration):
    """Kalau tidak bisa split, return 1 klip dari seluruh video."""
    text = ' '.join(w.get('word', '') for w in words[:20])
    return {
        "success": True,
        "total_clips": 1,
        "clips": [{
            "id": 1,
            "start": 0,
            "end": round(total_duration, 2),
            "duration": round(total_duration, 2),
            "score": 0.5,
            "preview_text": text,
        }],
        "method": "fallback",
        "total_duration": round(total_duration, 2),
    }


def _make_preview_text(words, start, end, max_chars=100):
    """Ambil 10-15 kata pertama dari klip sebagai preview."""
    clip_words = [w.get('word', '') for w in words if start <= w.get('start', 0) <= end]
    text = ' '.join(clip_words)
    if len(text) > max_chars:
        text = text[:max_chars].rsplit(' ', 1)[0] + '...'
    return text.strip()


def _expand_clips(clips, words, target_count):
    """Kalau topik sedikit, pecah topik terpanjang jadi 2 klip."""
    result = list(clips)
    attempts = 0
    while len(result) < target_count and attempts < 5:
        attempts += 1
        longest = max(result, key=lambda c: c['duration'])
        if longest['duration'] < MIN_CLIP_DURATION * 2:
            break

        mid = (longest['start'] + longest['end']) / 2
        closest_word = min(words, key=lambda w: abs(w.get('start', 0) - mid))
        split_point = closest_word.get('start', mid)

        clip1 = {
            'start': longest['start'],
            'end': split_point,
            'duration': round(split_point - longest['start'], 2),
            'score': 0.5,
            'preview_text': _make_preview_text(words, longest['start'], split_point),
            'topic_id': longest.get('topic_id'),
        }
        clip2 = {
            'start': split_point,
            'end': longest['end'],
            'duration': round(longest['end'] - split_point, 2),
            'score': 0.5,
            'preview_text': _make_preview_text(words, split_point, longest['end']),
            'topic_id': longest.get('topic_id'),
        }

        clip1_words = [w for w in words if clip1['start'] <= w.get('start', 0) <= clip1['end']]
        clip2_words = [w for w in words if clip2['start'] <= w.get('start', 0) <= clip2['end']]
        clip1['score'] = round(_score_window(clip1_words, clip1['duration']), 3)
        clip2['score'] = round(_score_window(clip2_words, clip2['duration']), 3)

        result.remove(longest)
        result.extend([clip1, clip2])

    return result


# ============================================================
# SLIDING WINDOW FALLBACK
# ============================================================
def _sliding_window_clips(words, total_duration, target_count):
    """Fallback: bagi video jadi N klip dengan sliding window."""
    print(f"[AutoClip] Sliding window: target {target_count} klip", file=sys.stderr)

    win_dur = min(MAX_CLIP_DURATION, max(MIN_CLIP_DURATION, total_duration / target_count))

    candidates = []
    step = max(2.0, win_dur / 4)
    t = 0.0

    while t + win_dur <= total_duration + 0.1:
        win_words = [w for w in words if t <= w.get('start', 0) <= t + win_dur]
        if len(win_words) >= 5:
            score = _score_window(win_words, win_dur)
            candidates.append({
                'start': round(t, 2),
                'end': round(t + win_dur, 2),
                'duration': round(win_dur, 2),
                'score': round(score, 3),
                'preview_text': _make_preview_text(words, t, t + win_dur),
            })
        t += step

    if not candidates:
        return _fallback_whole_video(words, total_duration)['clips']

    candidates.sort(key=lambda c: c['score'], reverse=True)
    picked = []
    for c in candidates:
        overlap = False
        for p in picked:
            if not (c['end'] <= p['start'] or c['start'] >= p['end']):
                overlap = True
                break
        if not overlap:
            picked.append(c)
        if len(picked) >= target_count:
            break

    picked.sort(key=lambda c: c['start'])
    for i, c in enumerate(picked, 1):
        c['id'] = i

    print(f"[AutoClip] Sliding window: {len(picked)} klip terpilih dari {len(candidates)} kandidat",
          file=sys.stderr)
    return picked

# ============================================================
# V8.8.0: RENDER SINGLE CLIP — extract sub-clip dari video
# ============================================================
def build_clip_render_payload(clip, source_path, output_path,
                              preset='1080p', add_watermark=True,
                              burn_subtitle=True, vertical_crop=False):
    """
    Bangun payload untuk merender 1 klip.
    Return dict dengan info klip untuk process_video_v8.
    """
    return {
        'sourcePath': source_path,
        'outputPath': output_path,
        'start': float(clip.get('start', 0)),
        'end': float(clip.get('end', 0)),
        'preset': preset,
        'addWatermark': add_watermark,
        'burnSubtitle': burn_subtitle,
        'verticalCrop': vertical_crop,
    }

# ============================================================
# STANDALONE TEST
# ============================================================
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python auto_clip.py <words.json>")
        sys.exit(1)

    with open(sys.argv[1], 'r', encoding='utf-8') as f:
        data = json.load(f)

    words = data.get('words', [])
    print(f"Loaded {len(words)} words", file=sys.stderr)

    result = split_by_topic(words)
    print(json.dumps(result, ensure_ascii=False, indent=2))