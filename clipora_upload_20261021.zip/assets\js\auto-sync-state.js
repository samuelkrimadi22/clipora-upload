/* auto-sync-state.js - V1.0.0
   Auto-sync state internal editor-timeline.js dengan currentAnalysisData
   Jalan di flow apapun (analyze normal atau load project) */
(function autoSync() {
    'use strict';

    var lastSyncKey = null;

    function trySync() {
        // Cek apakah kedua sisi siap
        if (!window.CliporaEditor || typeof window.CliporaEditor.start !== 'function') return;
        if (typeof window.currentAnalysisData === 'undefined' || !window.currentAnalysisData) return;
        if (!window.window.currentAnalysisData.segments || !window.window.currentAnalysisData.segments.length) return;

        // Cek apakah state perlu sync
        var st = window.CliporaEditor.getState();
        var stateCount = st.segments ? st.segments.length : 0;
        var dataCount = window.window.currentAnalysisData.segments.length;

        // Kalau state kosong atau beda jauh → sync
        if (stateCount === 0 || dataCount > stateCount) {  // V9.2.0: jangan overwrite kalau user nambah segmen
            // Cegah spam — pakai key berdasarkan jumlah + timestamp analysis
            var key = dataCount + '_' + (window.currentAnalysisData.analysisId || window.currentAnalysisData.duration || '');
            if (key === lastSyncKey) return;
            lastSyncKey = key;

            console.log('[AutoSync] State mismatch — state:' + stateCount + ' data:' + dataCount + ' → sync');
            try {
                if (typeof window.CliporaEditor.setSegments === 'function') {
                    window.CliporaEditor.setSegments(currentAnalysisData);
                } else {
                    window.CliporaEditor.start(currentAnalysisData);
                }
                setTimeout(function() {
                    var st2 = window.CliporaEditor.getState();
                    console.log('[AutoSync] Verify:', {
                        segments: st2.segments ? st2.segments.length : 0,
                        duration: st2.duration,
                    });
                }, 200);
            } catch (e) {
                console.error('[AutoSync] Error:', e);
                lastSyncKey = null; // biar bisa retry
            }
        }
    }

    // Check tiap 1 detik, tapi hanya sampai state sync
    var checkCount = 0;
    var maxChecks = 60; // 60 detik
    var interval = setInterval(function() {
        checkCount++;
        trySync();
        // Stop kalau sudah sync dan stabil
        if (lastSyncKey && checkCount > 10) {
            var st = window.CliporaEditor.getState();
            if (st.segments && st.segments.length > 0) {
                clearInterval(interval);
                console.log('[AutoSync] Done, stop interval');
            }
        }
        if (checkCount >= maxChecks) {
            clearInterval(interval);
        }
    }, 1000);

    // Juga hook ke event kalau ada perubahan
    document.addEventListener('click', function() {
        // Trigger check pas user interaksi
        if (!lastSyncKey) trySync();
    }, true);

    console.log('[AutoSync] Watcher aktif');
})();
