﻿<!-- V9.51.0: Theme consistency -->

<?php

require_once __DIR__ . '/config/config.php';

require_once __DIR__ . '/includes/header.php';



$userPlan = $_SESSION['user_plan'] ?? 'free';

$isPremium = in_array($userPlan, ['pro', 'business', 'weekly', 'monthly']);



// V9.6.0 SECURITY FIX: Hapus cek cookie - bisa dipalsukan via DevTools

// Admin hanya dari session + DB (via $isAdmin di config.php)

$isAdminUser = !empty($isAdmin) || !empty($_SESSION['is_admin']);



// V9.27.0: Free tier allowed dengan kuota

$isFreeUser = ($userPlan === 'free' || empty($userPlan));

$canUseAutoClip = $isPremium || $isAdminUser || $isFreeUser;



// Cache-busting yang benar (hanya berubah saat file di-update)

$autoclipCssVer = file_exists(__DIR__ . '/assets/css/autoclip-timeline.css')

    ? filemtime(__DIR__ . '/assets/css/autoclip-timeline.css')

    : time();

$autoclipJsVer = file_exists(__DIR__ . '/assets/js/autoclip.js')

    ? filemtime(__DIR__ . '/assets/js/autoclip.js')

    : time();

?>



<style>

    /* ============================================================ */

    /* AUTOCLIP PAGE - V8.8.2 CLEAN                                  */

    /* ============================================================ */



    /* ===== HERO ===== */

    .autoclip-hero {

        text-align: center;

        padding: 40px 20px 30px;

        max-width: 800px;

        margin: 0 auto;

    }



    .autoclip-hero h1 {

        font-size: 2.2rem;

        font-weight: 800;

        margin-bottom: 12px;

        background: linear-gradient(135deg, #f59e0b, #8b5cf6);

        -webkit-background-clip: text;

        -webkit-text-fill-color: transparent;

        background-clip: text;

    }



    .autoclip-hero p {

        color: var(--text-muted);

        font-size: 1rem;

        line-height: 1.6;

    }



    .autoclip-badge {

        display: inline-flex;

        align-items: center;

        gap: 6px;

        padding: 6px 14px;

        background: linear-gradient(135deg, rgba(139, 92, 246, 0.15), rgba(245, 158, 11, 0.15));

        border: 1px solid rgba(139, 92, 246, 0.3);

        color: #a78bfa;

        border-radius: 20px;

        font-size: 0.75rem;

        font-weight: 700;

        letter-spacing: 0.5px;

        margin-bottom: 16px;

    }



    /* ===== UPLOAD ZONE ===== */

    .ac-upload-zone {

        max-width: 720px;

        margin: 0 auto 30px;

        padding: 50px 30px;

        border: 2px dashed rgba(139, 92, 246, 0.35);

        border-radius: 20px;

        background: linear-gradient(135deg, rgba(139, 92, 246, 0.05), rgba(6, 182, 212, 0.03));

        text-align: center;

        cursor: pointer;

        transition: 0.3s;

        position: relative;

    }



    .ac-upload-zone:hover,

    .ac-upload-zone.dragover {

        border-color: #8b5cf6;

        background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(6, 182, 212, 0.06));

        transform: translateY(-2px);

        box-shadow: 0 12px 40px rgba(139, 92, 246, 0.2);

    }



    .ac-upload-zone.disabled {

        opacity: 0.5;

        cursor: not-allowed;

        border-color: rgba(255, 255, 255, 0.1);

    }



    .ac-upload-icon {

        font-size: 3rem;

        margin-bottom: 16px;

        background: linear-gradient(135deg, #8b5cf6, #06b6d4);

        -webkit-background-clip: text;

        -webkit-text-fill-color: transparent;

        background-clip: text;

    }



    .ac-upload-title {

        font-size: 1.2rem;

        font-weight: 700;

        color: var(--text);

        margin-bottom: 8px;

    }



    .ac-upload-subtitle {

        font-size: 0.85rem;

        color: var(--text-muted);

        margin-bottom: 20px;

    }



    .ac-upload-btn {

        display: inline-flex;

        align-items: center;

        gap: 8px;

        padding: 14px 32px;

        background: linear-gradient(135deg, #8b5cf6, #06b6d4);

        color: white;

        border: none;

        border-radius: 50px;

        font-size: 0.95rem;

        font-weight: 700;

        cursor: pointer;

        font-family: inherit;

        transition: 0.25s;

        box-shadow: 0 4px 20px rgba(139, 92, 246, 0.4);

    }



    .ac-upload-btn:hover {

        transform: translateY(-2px);

        box-shadow: 0 8px 28px rgba(139, 92, 246, 0.6);

    }



    .ac-upload-meta {

        font-size: 0.72rem;

        color: var(--text-muted);

        margin-top: 14px;

    }



    /* ===== LOCK CARD (Free User) ===== */

    .ac-lock {

        max-width: 720px;

        margin: 30px auto;

        padding: 30px;

        background: linear-gradient(135deg, rgba(139, 92, 246, 0.08), rgba(6, 182, 212, 0.04));

        border: 1px solid rgba(139, 92, 246, 0.25);

        border-radius: 20px;

        text-align: center;

    }



    .ac-lock-icon {

        font-size: 3rem;

        margin-bottom: 12px;

    }



    .ac-lock h3 {

        font-size: 1.3rem;

        margin-bottom: 10px;

        color: var(--text);

    }



    .ac-lock p {

        color: var(--text-muted);

        font-size: 0.9rem;

        margin-bottom: 20px;

        line-height: 1.6;

    }



    .ac-lock-btn {

        display: inline-flex;

        align-items: center;

        gap: 8px;

        padding: 14px 30px;

        background: linear-gradient(135deg, #f59e0b, #d97706);

        color: white;

        border-radius: 50px;

        font-weight: 700;

        text-decoration: none;

        font-size: 0.9rem;

        transition: 0.2s;

        box-shadow: 0 4px 16px rgba(245, 158, 11, 0.4);

    }



    .ac-lock-btn:hover {

        transform: translateY(-2px);

        box-shadow: 0 8px 24px rgba(245, 158, 11, 0.6);

    }



    /* ===== PROGRESS BOX ===== */

    .ac-progress {

        display: none;

        max-width: 720px;

        margin: 24px auto;

        padding: 24px;

        background: var(--card);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 16px;

        animation: acFadeIn 0.4s ease;

    }



    @keyframes acFadeIn {

        from {

            opacity: 0;

            transform: translateY(8px);

        }



        to {

            opacity: 1;

            transform: translateY(0);

        }

    }



    .ac-progress-bar {

        width: 100%;

        height: 8px;

        background: rgba(255, 255, 255, 0.05);

        border-radius: 10px;

        overflow: hidden;

        margin-bottom: 14px;

    }



    .ac-progress-fill {

        height: 100%;

        background: linear-gradient(90deg, #8b5cf6, #06b6d4);

        border-radius: 10px;

        width: 0%;

        transition: width 0.4s ease;

        box-shadow: 0 0 12px rgba(139, 92, 246, 0.6);

    }



    .ac-progress-status {

        display: flex;

        align-items: center;

        gap: 12px;

        font-size: 0.9rem;

        color: var(--text);

    }



    .ac-spinner {

        width: 18px;

        height: 18px;

        border: 2px solid rgba(139, 92, 246, 0.3);

        border-top-color: #8b5cf6;

        border-radius: 50%;

        animation: acSpin 0.8s linear infinite;

        flex-shrink: 0;

    }



    @keyframes acSpin {

        to {

            transform: rotate(360deg);

        }

    }



    .ac-progress-detail {

        font-size: 0.78rem;

        color: var(--text-muted);

        margin-top: 8px;

        padding-left: 30px;

    }



    /* ===== SETTINGS GRID ===== */

    .ac-settings {

        max-width: 1100px;

        margin: 20px auto 0;

        display: grid;

        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));

        gap: 12px;

    }



    .ac-setting-item {

        background: rgba(0, 0, 0, 0.2);

        border: 1px solid rgba(255, 255, 255, 0.08);

        border-radius: 12px;

        padding: 14px 16px;

    }



    .ac-setting-item label {

        display: block;

        font-size: 0.72rem;

        color: var(--text-muted);

        text-transform: uppercase;

        letter-spacing: 0.5px;

        font-weight: 700;

        margin-bottom: 8px;

    }



    .ac-setting-item select {

        width: 100%;

        padding: 8px 12px;

        background: rgba(0, 0, 0, 0.4);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 8px;

        color: var(--text);

        font-family: inherit;

        font-size: 0.85rem;

        outline: none;

        cursor: pointer;

    }



    .ac-setting-item input[type="text"] {

        width: 100%;

        padding: 8px 12px;

        background: rgba(0, 0, 0, 0.4);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 8px;

        color: var(--text);

        font-family: inherit;

        font-size: 0.85rem;

        outline: none;

        box-sizing: border-box;

        transition: 0.2s;

    }



    .ac-setting-item input[type="text"]:focus {

        border-color: #8b5cf6;

        box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15);

    }



    /* ===== V9.170.0: UMKM_TEMPLATE_CSS ===== */

    .ac-umkm-template-grid {

        display: grid;

        grid-template-columns: repeat(3, 1fr);

        gap: 8px;

        margin-bottom: 14px;

    }

    @media (max-width: 640px) {

        .ac-umkm-template-grid { grid-template-columns: repeat(2, 1fr); }

    }

    .ac-umkm-template-btn {

        display: flex;

        flex-direction: column;

        align-items: center;

        justify-content: center;

        padding: 12px 8px;

        background: rgba(255,255,255,0.03);

        border: 1px solid rgba(255,255,255,0.1);

        border-radius: 10px;

        color: #cbd5e1;

        cursor: pointer;

        font-family: inherit;

        transition: all 0.2s ease;

        text-align: center;

        gap: 4px;

    }

    .ac-umkm-template-btn:hover {

        background: rgba(139, 92, 246, 0.15);

        border-color: rgba(139, 92, 246, 0.5);

        transform: translateY(-2px);

        box-shadow: 0 4px 12px rgba(139, 92, 246, 0.3);

    }

    .ac-umkm-template-btn.active {

        background: linear-gradient(135deg, rgba(139, 92, 246, 0.3), rgba(109, 40, 217, 0.3));

        border-color: #8b5cf6;

        color: #fff;

        box-shadow: 0 0 20px rgba(139, 92, 246, 0.5);

    }

    .ac-umkm-template-icon { font-size: 22px; }

    .ac-umkm-template-name { font-size: 10px; font-weight: 700; }

    .ac-umkm-template-desc { font-size: 8px; color: #94a3b8; }

    

    /* Template warna specific */

    .ac-umkm-template-btn[data-template="kuliner"]:hover { border-color: #ef4444; background: rgba(239, 68, 68, 0.15); }

    .ac-umkm-template-btn[data-template="kuliner"].active { background: linear-gradient(135deg, #ef4444, #b91c1c); border-color: #ef4444; }

    

    .ac-umkm-template-btn[data-template="fashion"]:hover { border-color: #ec4899; background: rgba(236, 72, 153, 0.15); }

    .ac-umkm-template-btn[data-template="fashion"].active { background: linear-gradient(135deg, #ec4899, #be185d); border-color: #ec4899; }

    

    .ac-umkm-template-btn[data-template="elektronik"]:hover { border-color: #3b82f6; background: rgba(59, 130, 246, 0.15); }

    .ac-umkm-template-btn[data-template="elektronik"].active { background: linear-gradient(135deg, #3b82f6, #1d4ed8); border-color: #3b82f6; }

    

    .ac-umkm-template-btn[data-template="skincare"]:hover { border-color: #f472b6; background: rgba(244, 114, 182, 0.15); }

    .ac-umkm-template-btn[data-template="skincare"].active { background: linear-gradient(135deg, #f472b6, #db2777); border-color: #f472b6; }

    

    .ac-umkm-template-btn[data-template="herbal"]:hover { border-color: #22c55e; background: rgba(34, 197, 94, 0.15); }

    .ac-umkm-template-btn[data-template="herbal"].active { background: linear-gradient(135deg, #22c55e, #15803d); border-color: #22c55e; }

    

    .ac-umkm-template-btn[data-template="jasa"]:hover { border-color: #8b5cf6; background: rgba(139, 92, 246, 0.15); }

    .ac-umkm-template-btn[data-template="jasa"].active { background: linear-gradient(135deg, #8b5cf6, #6d28d9); border-color: #8b5cf6; }

    

    /* === KONTEN DINAMIS === */

    .ac-umkm-section {

        margin-top: 16px;

        padding: 12px 14px;

        background: rgba(255,255,255,0.02);

        border: 1px solid rgba(255,255,255,0.08);

        border-radius: 10px;

    }

    .ac-umkm-section-title {

        font-size: 11px;

        font-weight: 700;

        color: #a78bfa;

        margin-bottom: 10px;

        display: flex;

        align-items: center;

        gap: 6px;

    }

    .ac-umkm-section-title .optional {

        font-size: 9px;

        color: #64748b;

        font-weight: 500;

    }



    /* V9.174.0: HIDE_UMKM_MODE */

/* V9.174.1: HIDE_UMKM_MODE_V2 - selector sebenarnya */

.ac-umkm-panel,

#acUmkmPanel,

#acUmkmHeader,

#acCardUmkm,

.ac-card#acCardUmkm,

.ac-card[id="acCardUmkm"] {

    display: none !important;

}



/* V9.174.0: HIDE_UMKM_MODE */

.ac-umkm-panel,

#acUmkmPanel,

#acUmkmHeader {

    display: none !important;

}



/* ===== V9.60.4: UMKM MODE ===== */

    .ac-umkm-panel {

        max-width: 1100px;

        margin: 20px auto 0;

        background: linear-gradient(135deg, rgba(245, 158, 11, 0.08), rgba(34, 197, 94, 0.08));

        border: 1px solid rgba(245, 158, 11, 0.3);

        border-radius: 16px;

        overflow: hidden;

        transition: 0.3s;

    }

    .ac-umkm-panel.active {

        border-color: rgba(245, 158, 11, 0.6);

        box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.1);

    }

    .ac-umkm-header {

        display: flex;

        align-items: center;

        justify-content: space-between;

        padding: 16px 20px;

        cursor: pointer;

        user-select: none;

    }

    .ac-umkm-header-title {

        display: flex;

        align-items: center;

        gap: 10px;

        font-weight: 700;

        font-size: 0.95rem;

        color: #fbbf24;

    }

    .ac-umkm-header-title i {

        font-size: 1.2rem;

    }

    .ac-umkm-subtitle {

        font-size: 0.7rem;

        color: var(--text-muted);

        font-weight: 500;

        margin-left: 6px;

    }

    .ac-umkm-toggle {

        display: flex;

        align-items: center;

        gap: 8px;

        font-size: 0.8rem;

        color: var(--text-muted);

    }

    .ac-umkm-toggle input[type="checkbox"] {

        width: 42px;

        height: 22px;

        appearance: none;

        background: rgba(0,0,0,0.4);

        border: 1px solid rgba(255,255,255,0.15);

        border-radius: 12px;

        position: relative;

        cursor: pointer;

        transition: 0.3s;

    }

    .ac-umkm-toggle input[type="checkbox"]::before {

        content: "";

        position: absolute;

        width: 16px;

        height: 16px;

        background: #fff;

        border-radius: 50%;

        top: 2px;

        left: 2px;

        transition: 0.3s;

    }

    .ac-umkm-toggle input[type="checkbox"]:checked {

        background: linear-gradient(135deg, #f59e0b, #22c55e);

        border-color: transparent;

    }

    .ac-umkm-toggle input[type="checkbox"]:checked::before {

        left: 22px;

    }

    .ac-umkm-body {

        padding: 0 20px 20px;

        display: none;

    }

    .ac-umkm-body.open {

        display: block;

    }

    .ac-umkm-grid {

        display: grid;

        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));

        gap: 12px;

        margin-bottom: 14px;

    }

    .ac-umkm-actions {

        display: flex;

        gap: 10px;

        flex-wrap: wrap;

        align-items: center;

    }

    .ac-umkm-btn {

        padding: 9px 18px;

        border-radius: 10px;

        border: none;

        font-family: inherit;

        font-weight: 700;

        font-size: 0.82rem;

        cursor: pointer;

        display: inline-flex;

        align-items: center;

        gap: 7px;

        transition: 0.2s;

    }

    .ac-umkm-btn-primary {

        background: linear-gradient(135deg, #f59e0b, #22c55e);

        color: #fff;

    }

    .ac-umkm-btn-primary:hover:not(:disabled) {

        transform: translateY(-1px);

        box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);

    }

    .ac-umkm-btn-secondary {

        background: rgba(255,255,255,0.05);

        color: var(--text-muted);

        border: 1px solid rgba(255,255,255,0.1);

    }

    .ac-umkm-btn:disabled {

        opacity: 0.5;

        cursor: not-allowed;

    }

    .ac-umkm-status {

        font-size: 0.78rem;

        margin-left: auto;

        padding: 5px 12px;

        border-radius: 8px;

    }

    .ac-umkm-status.ok { background: rgba(34, 197, 94, 0.15); color: #4ade80; }

    .ac-umkm-status.err { background: rgba(239, 68, 68, 0.15); color: #f87171; }

    .ac-umkm-status.info { background: rgba(139, 92, 246, 0.15); color: #a78bfa; }



    .ac-setting-item input[type="text"]::placeholder {

        color: rgba(255, 255, 255, 0.3);

    }



    /* Vertical Crop checkbox */

    .ac-vertical-check {

        display: flex;

        align-items: center;

        gap: 10px;

        font-size: 0.85rem;

        text-transform: none;

        font-weight: 500;

        cursor: pointer;

        padding-top: 6px;

        letter-spacing: normal;

        color: var(--text);

        margin-bottom: 0;

    }



    .ac-vertical-check input[type="checkbox"] {

        width: 18px;

        height: 18px;

        accent-color: #8b5cf6;

        cursor: pointer;

        flex-shrink: 0;

    }



    /* ===== STEP INDICATOR ===== */

    .ac-steps {

        display: flex;

        align-items: center;

        justify-content: center;

        gap: 12px;

        padding: 16px;

        margin-bottom: 20px;

        background: rgba(139, 92, 246, 0.06);

        border-radius: 12px;

        flex-wrap: wrap;

    }



    .ac-step {

        display: inline-flex;

        align-items: center;

        gap: 6px;

        font-size: 0.85rem;

        font-weight: 700;

    }



    .ac-step.done {

        color: #22c55e;

    }



    .ac-step.active {

        color: #a78bfa;

    }



    .ac-step.pending {

        color: var(--text-muted);

    }



    .ac-step-num {

        width: 22px;

        height: 22px;

        border-radius: 50%;

        font-size: 0.7rem;

        display: inline-flex;

        align-items: center;

        justify-content: center;

        flex-shrink: 0;

    }



    .ac-step.done .ac-step-num {

        background: #22c55e;

        color: white;

    }



    .ac-step.active .ac-step-num {

        background: linear-gradient(135deg, #8b5cf6, #06b6d4);

        color: white;

    }



    .ac-step.pending .ac-step-num {

        background: rgba(255, 255, 255, 0.1);

        color: var(--text-muted);

    }



    .ac-step-sep {

        color: rgba(255, 255, 255, 0.2);

        font-size: 0.7rem;

    }



    /* ===== RESPONSIVE ===== */

    @media (max-width: 640px) {

        .autoclip-hero h1 {

            font-size: 1.6rem;

        }



        .ac-settings {

            grid-template-columns: 1fr;

        }

    }



    /* ===== FULLSCREEN VIDEO ===== */

    video:fullscreen {

        width: 100vw !important;

        height: 100vh !important;

        object-fit: contain !important;

        background: black;

    }



    video:-webkit-full-screen {

        width: 100vw !important;

        height: 100vh !important;

        object-fit: contain !important;

        background: black;

    }



    video:-moz-full-screen {

        width: 100vw !important;

        height: 100vh !important;

        object-fit: contain !important;

        background: black;

    }



    /* ===== SUBTITLE EDITING PANEL ===== */

    .tl-subtitle-panel {

        margin-top: 20px;

        padding: 20px;

        background: linear-gradient(135deg, rgba(139, 92, 246, 0.06), rgba(6, 182, 212, 0.03));

        border: 1px solid rgba(139, 92, 246, 0.25);

        border-radius: 14px;

        animation: acFadeIn 0.4s ease;

    }



    .tl-subtitle-head {

        display: flex;

        justify-content: space-between;

        align-items: center;

        gap: 12px;

        margin-bottom: 12px;

        flex-wrap: wrap;

    }



    .tl-subtitle-head h3 {

        margin: 0;

        font-size: 1rem;

        display: flex;

        align-items: center;

        gap: 8px;

        color: var(--text, #fff);

    }



    .tl-subtitle-head h3 i {

        color: #8b5cf6;

    }



    .tl-subtitle-count {

        color: #a78bfa;

        font-size: 0.85rem;

        font-weight: 600;

    }



    .tl-subtitle-actions {

        display: flex;

        gap: 8px;

    }



    .tl-subtitle-btn {

        padding: 6px 12px;

        background: rgba(255, 255, 255, 0.05);

        border: 1px solid rgba(255, 255, 255, 0.12);

        color: var(--text-muted, #94a3b8);

        border-radius: 8px;

        font-size: 0.75rem;

        font-weight: 600;

        cursor: pointer;

        font-family: inherit;

        display: inline-flex;

        align-items: center;

        gap: 6px;

        transition: 0.2s;

    }



    .tl-subtitle-btn:hover {

        background: rgba(255, 255, 255, 0.1);

        color: var(--text, #fff);

    }



    .tl-subtitle-btn-close {

        padding: 6px 10px;

    }



    .tl-subtitle-hint {

        font-size: 0.75rem;

        color: var(--text-muted, #94a3b8);

        padding: 8px 12px;

        background: rgba(0, 0, 0, 0.15);

        border-radius: 8px;

        margin-bottom: 12px;

        display: flex;

        align-items: center;

        gap: 6px;

    }



    .tl-subtitle-hint i {

        color: #22d3ee;

    }



    .tl-subtitle-list {

        max-height: 400px;

        overflow-y: auto;

        display: flex;

        flex-direction: column;

        gap: 6px;

        padding-right: 6px;

        scrollbar-width: thin;

        scrollbar-color: rgba(139, 92, 246, 0.5) rgba(0, 0, 0, 0.2);

    }



    .tl-subtitle-list::-webkit-scrollbar {

        width: 8px;

    }



    .tl-subtitle-list::-webkit-scrollbar-track {

        background: rgba(0, 0, 0, 0.2);

        border-radius: 4px;

    }



    .tl-subtitle-list::-webkit-scrollbar-thumb {

        background: rgba(139, 92, 246, 0.5);

        border-radius: 4px;

    }



    .tl-subtitle-item {

        display: flex;

        align-items: flex-start;

        gap: 12px;

        padding: 10px 12px;

        background: rgba(0, 0, 0, 0.2);

        border: 1px solid rgba(255, 255, 255, 0.06);

        border-radius: 10px;

        transition: 0.15s;

        cursor: text;

    }



    .tl-subtitle-item:hover {

        background: rgba(139, 92, 246, 0.08);

        border-color: rgba(139, 92, 246, 0.3);

    }



    .tl-subtitle-item.editing {

        background: rgba(139, 92, 246, 0.12);

        border-color: rgba(139, 92, 246, 0.5);

        box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.15);

    }



    .tl-subtitle-item.modified {

        border-left: 3px solid #f59e0b;

    }



    .tl-subtitle-time {

        font-family: 'Courier New', monospace;

        font-size: 0.7rem;

        color: #a78bfa;

        flex-shrink: 0;

        padding-top: 3px;

        min-width: 90px;

    }



    .tl-subtitle-text {

        flex: 1;

        font-size: 0.85rem;

        color: var(--text, #fff);

        line-height: 1.5;

        outline: none;

        padding: 2px 4px;

        border-radius: 4px;

        min-height: 20px;

        word-break: break-word;

    }



    .tl-subtitle-item.editing .tl-subtitle-text {

        background: rgba(0, 0, 0, 0.4);

        border: 1px solid #8b5cf6;

        padding: 6px 8px;

    }



    .tl-subtitle-empty {

        text-align: center;

        padding: 40px 20px;

        color: var(--text-muted, #94a3b8);

        opacity: 0.7;

    }



    .tl-subtitle-empty i {

        font-size: 2rem;

        margin-bottom: 8px;

        display: block;

    }



    .tl-subtitle-empty p {

        margin: 0 0 4px;

        font-size: 0.9rem;

    }



    .tl-subtitle-empty small {

        font-size: 0.75rem;

    }



    /* ===== DRAFT RESTORE BANNER ===== */

    .ac-draft-banner {

        display: flex;

        align-items: center;

        gap: 16px;

        max-width: 1100px;

        margin: 0 auto 20px;

        padding: 16px 20px;

        background: linear-gradient(135deg, rgba(245, 158, 11, 0.12), rgba(139, 92, 246, 0.08));

        border: 1px solid rgba(245, 158, 11, 0.35);

        border-radius: 14px;

        animation: acFadeIn 0.4s ease;

        flex-wrap: wrap;

    }



    .ac-draft-icon {

        width: 44px;

        height: 44px;

        border-radius: 12px;

        background: rgba(245, 158, 11, 0.15);

        border: 1px solid rgba(245, 158, 11, 0.4);

        display: flex;

        align-items: center;

        justify-content: center;

        color: #f59e0b;

        font-size: 1.2rem;

        flex-shrink: 0;

    }



    .ac-draft-body {

        flex: 1;

        min-width: 180px;

    }



    .ac-draft-title {

        font-size: 0.95rem;

        font-weight: 800;

        color: var(--text, #fff);

        margin-bottom: 2px;

    }



    .ac-draft-info {

        font-size: 0.78rem;

        color: var(--text-muted, #94a3b8);

    }



    .ac-draft-actions {

        display: flex;

        gap: 8px;

        flex-shrink: 0;

    }



    .ac-draft-btn {

        padding: 9px 16px;

        border-radius: 10px;

        border: none;

        font-weight: 700;

        font-size: 0.78rem;

        cursor: pointer;

        font-family: inherit;

        display: inline-flex;

        align-items: center;

        gap: 6px;

        transition: 0.2s;

    }



    .ac-draft-btn-restore {

        background: linear-gradient(135deg, #f59e0b, #d97706);

        color: white;

        box-shadow: 0 3px 10px rgba(245, 158, 11, 0.35);

    }



    .ac-draft-btn-restore:hover {

        transform: translateY(-1px);

        box-shadow: 0 6px 16px rgba(245, 158, 11, 0.5);

    }



    .ac-draft-btn-delete {

        background: transparent;

        border: 1px solid rgba(255, 255, 255, 0.15);

        color: var(--text-muted, #94a3b8);

    }



    .ac-draft-btn-delete:hover {

        background: rgba(239, 68, 68, 0.1);

        border-color: rgba(239, 68, 68, 0.4);

        color: #ef4444;

    }



    @media (max-width: 640px) {

        .ac-draft-banner {

            flex-direction: column;

            text-align: center;

        }



        .ac-draft-actions {

            width: 100%;

            justify-content: center;

        }

    }



    /* ===== CUSTOM WATERMARK SECTION ===== */

    .ac-watermark-section {

        max-width: 1100px;

        margin: 20px auto 0;

        padding: 20px;

        background: linear-gradient(135deg, rgba(59, 130, 246, 0.06), rgba(139, 92, 246, 0.03));

        border: 1px solid rgba(59, 130, 246, 0.25);

        border-radius: 14px;

        animation: acFadeIn 0.4s ease;

    }



    .ac-wm-head {

        display: flex;

        justify-content: space-between;

        align-items: center;

        gap: 12px;

        margin-bottom: 12px;

        flex-wrap: wrap;

    }



    .ac-wm-head h3 {

        margin: 0;

        font-size: 1rem;

        display: flex;

        align-items: center;

        gap: 8px;

        color: var(--text, #fff);

    }



    .ac-wm-head h3 i {

        color: #3b82f6;

    }



    .ac-wm-beta {

        font-size: 0.6rem;

        padding: 2px 8px;

        border-radius: 10px;

        background: linear-gradient(135deg, #f59e0b, #d97706);

        color: white;

        font-weight: 800;

        letter-spacing: 0.5px;

    }



    .ac-wm-toggle {

        display: flex;

        align-items: center;

        gap: 8px;

        cursor: pointer;

        user-select: none;

    }



    .ac-wm-toggle input {

        display: none;

    }



    .ac-wm-switch {

        width: 40px;

        height: 22px;

        border-radius: 50px;

        background: rgba(255, 255, 255, 0.1);

        position: relative;

        transition: 0.25s;

        flex-shrink: 0;

    }



    .ac-wm-switch::after {

        content: '';

        position: absolute;

        top: 3px;

        left: 3px;

        width: 16px;

        height: 16px;

        border-radius: 50%;

        background: white;

        transition: 0.25s;

    }



    .ac-wm-toggle input:checked+.ac-wm-switch {

        background: linear-gradient(135deg, #3b82f6, #8b5cf6);

    }



    .ac-wm-toggle input:checked+.ac-wm-switch::after {

        transform: translateX(18px);

    }



    .ac-wm-toggle-label {

        font-size: 0.8rem;

        font-weight: 700;

        color: var(--text-muted, #94a3b8);

    }



    .ac-wm-toggle input:checked~.ac-wm-toggle-label {

        color: #22d3ee;

    }



    .ac-wm-hint {

        font-size: 0.75rem;

        color: var(--text-muted, #94a3b8);

        padding: 8px 12px;

        background: rgba(0, 0, 0, 0.15);

        border-radius: 8px;

        margin-bottom: 14px;

        display: flex;

        align-items: center;

        gap: 6px;

    }



    .ac-wm-hint i {

        color: #22d3ee;

    }



    .ac-wm-body {

        display: flex;

        gap: 20px;

        align-items: center;

        flex-wrap: wrap;

    }



    .ac-wm-preview {

        width: 160px;

        height: 100px;

        border-radius: 10px;

        background: rgba(0, 0, 0, 0.3);

        border: 1px dashed rgba(255, 255, 255, 0.15);

        display: flex;

        align-items: center;

        justify-content: center;

        overflow: hidden;

        flex-shrink: 0;

    }



    .ac-wm-preview img {

        max-width: 100%;

        max-height: 100%;

        object-fit: contain;

    }



    .ac-wm-empty {

        text-align: center;

        color: var(--text-muted, #94a3b8);

        opacity: 0.6;

        font-size: 0.7rem;

    }



    .ac-wm-empty i {

        font-size: 1.5rem;

        margin-bottom: 4px;

        display: block;

    }



    .ac-wm-empty p {

        margin: 0;

        font-size: 0.72rem;

    }



    .ac-wm-empty small {

        font-size: 0.65rem;

    }



    .ac-wm-controls {

        display: flex;

        gap: 10px;

        flex-wrap: wrap;

    }



    .ac-wm-btn {

        padding: 10px 18px;

        border-radius: 10px;

        border: none;

        font-weight: 700;

        font-size: 0.8rem;

        cursor: pointer;

        font-family: inherit;

        display: inline-flex;

        align-items: center;

        gap: 6px;

        transition: 0.2s;

    }



    .ac-wm-btn-upload {

        background: linear-gradient(135deg, #3b82f6, #2563eb);

        color: white;

        box-shadow: 0 3px 12px rgba(59, 130, 246, 0.35);

    }



    .ac-wm-btn-upload:hover {

        transform: translateY(-1px);

        box-shadow: 0 6px 18px rgba(59, 130, 246, 0.5);

    }



    .ac-wm-btn-delete {

        background: transparent;

        border: 1px solid rgba(239, 68, 68, 0.4);

        color: #ef4444;

    }



    .ac-wm-btn-delete:hover {

        background: rgba(239, 68, 68, 0.1);

    }



    .ac-wm-btn:disabled {

        opacity: 0.5;

        cursor: wait;

        transform: none !important;

    }



    @media (max-width: 640px) {

        .ac-wm-body {

            flex-direction: column;

            align-items: stretch;

        }



        .ac-wm-preview {

            width: 100%;

        }



        .ac-wm-controls {

            justify-content: center;

        }

    }



    /* ===== PREVIEW SUBTITLE MODAL ===== */

    .ac-preview-modal {

        position: fixed;

        inset: 0;

        z-index: 9999;

        display: flex;

        align-items: center;

        justify-content: center;

        padding: 20px;

    }



    .ac-preview-backdrop {

        position: absolute;

        inset: 0;

        background: rgba(0, 0, 0, 0.75);

        backdrop-filter: blur(4px);

    }



    .ac-preview-content {

        position: relative;

        width: 100%;

        max-width: 900px;

        max-height: 90vh;

        background: linear-gradient(135deg, #1a1a2e, #16162a);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 18px;

        display: flex;

        flex-direction: column;

        overflow: hidden;

        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.7);

        animation: acFadeIn 0.3s ease;

    }



    .ac-preview-head {

        display: flex;

        justify-content: space-between;

        align-items: center;

        padding: 18px 24px;

        border-bottom: 1px solid rgba(255, 255, 255, 0.08);

    }



    .ac-preview-head h3 {

        margin: 0;

        font-size: 1.1rem;

        display: flex;

        align-items: center;

        gap: 10px;

        color: #fff;

    }



    .ac-preview-head h3 i {

        color: #8b5cf6;

    }



    .ac-preview-close {

        width: 36px;

        height: 36px;

        border-radius: 10px;

        background: rgba(255, 255, 255, 0.05);

        border: 1px solid rgba(255, 255, 255, 0.1);

        color: #94a3b8;

        cursor: pointer;

        transition: 0.2s;

        display: flex;

        align-items: center;

        justify-content: center;

    }



    .ac-preview-close:hover {

        background: rgba(239, 68, 68, 0.15);

        border-color: rgba(239, 68, 68, 0.4);

        color: #ef4444;

    }



    .ac-preview-body {

        flex: 1;

        overflow-y: auto;

        padding: 20px 24px;

        display: flex;

        flex-direction: column;

        gap: 16px;

    }



    .ac-preview-settings {

        display: flex;

        gap: 12px;

        align-items: flex-end;

        flex-wrap: wrap;

    }



    .ac-preview-setting {

        flex: 1;

        min-width: 150px;

    }



    .ac-preview-setting label {

        display: block;

        font-size: 0.72rem;

        color: #94a3b8;

        text-transform: uppercase;

        letter-spacing: 0.5px;

        font-weight: 700;

        margin-bottom: 6px;

    }



    .ac-preview-setting select,

    .ac-preview-setting input[type="number"] {

        width: 100%;

        padding: 10px 12px;

        background: rgba(0, 0, 0, 0.4);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 8px;

        color: #fff;

        font-family: inherit;

        font-size: 0.85rem;

        outline: none;

    }



    .ac-preview-generate {

        padding: 12px 24px;

        border-radius: 10px;

        border: none;

        background: linear-gradient(135deg, #8b5cf6, #06b6d4);

        color: #fff;

        font-weight: 700;

        font-size: 0.85rem;

        cursor: pointer;

        font-family: inherit;

        display: inline-flex;

        align-items: center;

        gap: 8px;

        transition: 0.2s;

        box-shadow: 0 4px 16px rgba(139, 92, 246, 0.4);

        white-space: nowrap;

    }



    .ac-preview-generate:hover:not(:disabled) {

        transform: translateY(-2px);

        box-shadow: 0 8px 24px rgba(139, 92, 246, 0.6);

    }



    .ac-preview-generate:disabled {

        opacity: 0.6;

        cursor: wait;

    }



    .ac-preview-result {

        flex: 1;

        min-height: 300px;

        background: #000;

        border-radius: 12px;

        border: 1px solid rgba(255, 255, 255, 0.08);

        display: flex;

        align-items: center;

        justify-content: center;

        overflow: hidden;

        position: relative;

    }



    .ac-preview-result img {

        max-width: 100%;

        max-height: 60vh;

        object-fit: contain;

        display: block;

    }



    .ac-preview-empty,

    .ac-preview-loading {

        text-align: center;

        color: #94a3b8;

        padding: 40px 20px;

    }



    .ac-preview-empty i {

        font-size: 3rem;

        opacity: 0.3;

        display: block;

        margin-bottom: 12px;

    }



    .ac-preview-empty p {

        margin: 0;

        font-size: 0.9rem;

    }



    .ac-preview-loading i {

        font-size: 2rem;

        color: #8b5cf6;

        display: block;

        margin-bottom: 12px;

    }



    .ac-preview-hint {

        padding: 12px 24px;

        background: rgba(139, 92, 246, 0.06);

        border-top: 1px solid rgba(255, 255, 255, 0.06);

        font-size: 0.78rem;

        color: #94a3b8;

        display: flex;

        align-items: center;

        gap: 8px;

    }



    .ac-preview-hint i {

        color: #22d3ee;

    }



    @media (max-width: 640px) {

        .ac-preview-settings {

            flex-direction: column;

            align-items: stretch;

        }



        .ac-preview-generate {

            width: 100%;

            justify-content: center;

        }

    }



    /* ============================================================ */

    /* V8.9.0: AI THUMBNAIL MODAL                                    */

    /* ============================================================ */

    .ac-thumbnail-modal {

        position: fixed;

        inset: 0;

        z-index: 9999;

        display: flex;

        align-items: center;

        justify-content: center;

        padding: 20px;

    }



    .ac-thumbnail-backdrop {

        position: absolute;

        inset: 0;

        background: rgba(0, 0, 0, 0.8);

        backdrop-filter: blur(6px);

    }



    .ac-thumbnail-content {

        position: relative;

        width: 100%;

        max-width: 1100px;

        max-height: 90vh;

        background: linear-gradient(135deg, #1a1a2e, #16162a);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 18px;

        display: flex;

        flex-direction: column;

        overflow: hidden;

        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.7);

    }



    .ac-thumbnail-head {

        display: flex;

        justify-content: space-between;

        align-items: center;

        padding: 18px 24px;

        border-bottom: 1px solid rgba(255, 255, 255, 0.08);

    }



    .ac-thumbnail-head h3 {

        margin: 0;

        font-size: 1.1rem;

        color: #fff;

        display: flex;

        align-items: center;

        gap: 10px;

    }



    .ac-thumbnail-head h3 i {

        color: #f59e0b;

    }



    .ac-thumbnail-body {

        flex: 1;

        overflow-y: auto;

        padding: 24px;

    }



    .ac-thumbnail-actions-top {

        display: flex;

        gap: 12px;

        align-items: flex-end;

        margin-bottom: 20px;

        flex-wrap: wrap;

    }



    .ac-thumbnail-setting {

        flex: 1;

        min-width: 140px;

    }



    .ac-thumbnail-setting label {

        display: block;

        font-size: 0.7rem;

        color: #94a3b8;

        text-transform: uppercase;

        font-weight: 700;

        margin-bottom: 6px;

        letter-spacing: 0.5px;

    }



    .ac-thumbnail-setting select {

        width: 100%;

        padding: 10px 12px;

        background: rgba(0, 0, 0, 0.4);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 8px;

        color: #fff;

        font-family: inherit;

        font-size: 0.85rem;

        outline: none;

    }



    .ac-thumbnail-generate {

        padding: 12px 24px;

        border-radius: 10px;

        border: none;

        background: linear-gradient(135deg, #f59e0b, #d97706);

        color: #fff;

        font-weight: 700;

        font-size: 0.85rem;

        cursor: pointer;

        font-family: inherit;

        display: inline-flex;

        align-items: center;

        gap: 8px;

        box-shadow: 0 4px 16px rgba(245, 158, 11, 0.4);

        white-space: nowrap;

    }



    .ac-thumbnail-generate:hover:not(:disabled) {

        transform: translateY(-2px);

        box-shadow: 0 8px 24px rgba(245, 158, 11, 0.6);

    }



    .ac-thumbnail-generate:disabled {

        opacity: 0.6;

        cursor: wait;

    }



    .ac-thumbnail-grid {

        display: grid;

        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));

        gap: 16px;

    }



    .ac-thumbnail-card {

        background: rgba(0, 0, 0, 0.3);

        border: 2px solid rgba(255, 255, 255, 0.08);

        border-radius: 12px;

        overflow: hidden;

        cursor: pointer;

        transition: 0.2s;

        position: relative;

    }



    .ac-thumbnail-card:hover {

        border-color: rgba(245, 158, 11, 0.5);

        transform: translateY(-2px);

        box-shadow: 0 8px 24px rgba(245, 158, 11, 0.2);

    }



    .ac-thumbnail-card img {

        width: 100%;

        height: auto;

        display: block;

    }



    .ac-thumbnail-card-info {

        padding: 12px 14px;

        background: rgba(0, 0, 0, 0.4);

        border-top: 1px solid rgba(255, 255, 255, 0.06);

    }



    .ac-thumbnail-card-hook {

        font-size: 0.85rem;

        font-weight: 700;

        color: #f59e0b;

        margin-bottom: 4px;

        text-transform: uppercase;

        letter-spacing: 0.5px;

    }



    .ac-thumbnail-card-meta {

        font-size: 0.7rem;

        color: #94a3b8;

        display: flex;

        justify-content: space-between;

    }



    .ac-thumbnail-card-download {

        position: absolute;

        top: 12px;

        right: 12px;

        width: 38px;

        height: 38px;

        border-radius: 10px;

        background: rgba(0, 0, 0, 0.75);

        border: 1px solid rgba(255, 255, 255, 0.2);

        color: #fff;

        cursor: pointer;

        display: flex;

        align-items: center;

        justify-content: center;

        font-size: 0.95rem;

        transition: 0.2s;

        z-index: 5;

    }



    .ac-thumbnail-card-download:hover {

        background: #f59e0b;

        border-color: #f59e0b;

    }



    .ac-thumbnail-empty {

        text-align: center;

        padding: 60px 20px;

        color: #94a3b8;

    }



    .ac-thumbnail-empty i {

        font-size: 3.5rem;

        opacity: 0.3;

        display: block;

        margin-bottom: 16px;

    }



    .ac-thumbnail-empty p {

        margin: 0 0 6px;

        font-size: 0.95rem;

    }



    .ac-thumbnail-empty small {

        font-size: 0.8rem;

        opacity: 0.7;

    }



    .ac-thumbnail-loading {

        text-align: center;

        padding: 60px 20px;

        color: #f59e0b;

    }



    .ac-thumbnail-loading i {

        font-size: 2.5rem;

        display: block;

        margin-bottom: 16px;

    }



    .ac-thumbnail-loading span {

        font-size: 0.9rem;

    }



    @media (max-width: 640px) {

        .ac-thumbnail-actions-top {

            flex-direction: column;

            align-items: stretch;

        }



        .ac-thumbnail-grid {

            grid-template-columns: 1fr;

        }

    }





    





    .autoclip-history-link {

        display: inline-flex;

        align-items: center;

        gap: 8px;

        margin-top: 14px;

        padding: 10px 20px;

        background: rgba(139, 92, 246, 0.1);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 12px;

        color: #a78bfa;

        text-decoration: none;

        font-size: 0.85rem;

        font-weight: 700;

        transition: 0.2s;

    }

    .autoclip-history-link:hover {

        background: rgba(139, 92, 246, 0.18);

        border-color: rgba(139, 92, 246, 0.5);

        transform: translateY(-1px);

    }

    .autoclip-history-link i { font-size: 0.9rem; }





    /* V9.12.0: Tombol Simpan Proyek - compact icon */

    .ac-save-icon {

        width: 38px;

        height: 38px;

        border-radius: 10px;

        border: 1px solid rgba(139, 92, 246, 0.25);

        background: rgba(139, 92, 246, 0.08);

        color: #a78bfa;

        cursor: pointer;

        font-size: 0.95rem;

        display: inline-flex;

        align-items: center;

        justify-content: center;

        transition: 0.2s;

        padding: 0;

        font-family: inherit;

        position: relative;

    }

    .ac-save-icon:hover:not(:disabled) {

        background: rgba(139, 92, 246, 0.18);

        border-color: rgba(139, 92, 246, 0.5);

        color: #c4b5fd;

        transform: translateY(-1px);

    }

    .ac-save-icon:disabled {

        opacity: 0.35;

        cursor: not-allowed;

    }

    .ac-save-icon.saved::after {

        content: '';

        position: absolute;

        top: 6px;

        right: 6px;

        width: 6px;

        height: 6px;

        background: #22c55e;

        border-radius: 50%;

        animation: save-pulse 1.5s ease-out;

    }

    @keyframes save-pulse {

        0% { transform: scale(2); opacity: 1; }

        100% { transform: scale(1); opacity: 0; }

    }







    /* V9.14.1: Project mode - hide setting & upload zone */

    body.ac-load-project .ac-settings,

    body.ac-load-project .ac-upload-zone,

    body.ac-load-project #acUploadZone,

    body.ac-load-project .autoclip-hero,

    body.ac-load-project .ac-watermark-section,

    body.ac-load-project .watermark-custom,

    body.ac-load-project .ac-step-indicator,

    body.ac-load-project .ac-save-icon,

    body.ac-load-project .ac-upload-box,

    body.ac-load-project .ac-drop-zone,

    body.ac-load-project .ac-upload-area,

    body.ac-load-project .ac-progress {

        display: none !important;

    }

    /* Tetap tampilkan timeline */

    body.ac-load-project #timelineEditor,

    body.ac-load-project .ac-timeline-editor {

        display: block !important;

    }





    /* V9.16.0: Tombol Proyek Saya di bawah */

    .autoclip-history-bottom {

        max-width: 720px;

        margin: 40px auto 20px;

        padding: 18px 22px;

        background: linear-gradient(135deg, rgba(139, 92, 246, 0.08), rgba(6, 182, 212, 0.04));

        border: 1px solid rgba(139, 92, 246, 0.2);

        border-radius: 16px;

        display: flex;

        justify-content: space-between;

        align-items: center;

        gap: 16px;

        flex-wrap: wrap;

    }

    .ac-history-bottom-inner {

        display: flex;

        justify-content: space-between;

        align-items: center;

        gap: 16px;

        width: 100%;

        flex-wrap: wrap;

    }

    .ac-history-bottom-text {

        display: flex;

        align-items: center;

        gap: 14px;

        color: #e8e8ef;

        flex: 1;

        min-width: 200px;

    }

    .ac-history-bottom-text i {

        font-size: 1.6rem;

        color: #a78bfa;

        flex-shrink: 0;

    }

    .ac-history-bottom-text strong {

        display: block;

        font-size: 0.92rem;

        margin-bottom: 2px;

    }

    .ac-history-bottom-text small {

        font-size: 0.75rem;

        color: #94a3b8;

    }

    .ac-history-bottom-btn {

        display: inline-flex;

        align-items: center;

        gap: 8px;

        padding: 11px 20px;

        background: linear-gradient(135deg, #8b5cf6, #06b6d4);

        color: #fff;

        text-decoration: none;

        border-radius: 10px;

        font-weight: 700;

        font-size: 0.85rem;

        white-space: nowrap;

        transition: 0.2s;

        box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);

    }

    .ac-history-bottom-btn:hover {

        transform: translateY(-2px);

        box-shadow: 0 8px 24px rgba(139, 92, 246, 0.5);

    }

    /* Sembunyikan di project mode */

    body.ac-load-project .autoclip-history-bottom {

        display: none !important;

    }

    @media (max-width: 500px) {

        .autoclip-history-bottom-btn {

            width: 100%;

            justify-content: center;

        }

    }







    /* V9.18.0: Clip Preview Modal */

    .ac-clip-preview-modal {

        position: fixed;

        inset: 0;

        z-index: 9999;

        display: none;

        align-items: center;

        justify-content: center;

        padding: 20px;

    }

    .ac-cpm-backdrop {

        position: absolute;

        inset: 0;

        background: rgba(0, 0, 0, 0.85);

        backdrop-filter: blur(8px);

    }

    .ac-cpm-content {

        position: relative;

        width: 100%;

        max-width: 720px;

        background: linear-gradient(165deg, #15152b, #0f0f1e);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 20px;

        overflow: hidden;

        box-shadow: 0 30px 80px rgba(0, 0, 0, 0.7);

        animation: cpm-in 0.25s ease;

    }

    @keyframes cpm-in {

        from { transform: scale(0.9); opacity: 0; }

        to { transform: scale(1); opacity: 1; }

    }

    .ac-cpm-head {

        display: flex;

        justify-content: space-between;

        align-items: center;

        padding: 16px 20px;

        border-bottom: 1px solid rgba(255, 255, 255, 0.06);

    }

    .ac-cpm-title {

        display: flex;

        align-items: center;

        gap: 10px;

        color: #e8e8ef;

        font-weight: 700;

        font-size: 0.95rem;

    }

    .ac-cpm-title i { color: #a78bfa; }

    .ac-cpm-close {

        background: rgba(255, 255, 255, 0.05);

        border: none;

        color: #94a3b8;

        width: 32px;

        height: 32px;

        border-radius: 8px;

        cursor: pointer;

        display: flex;

        align-items: center;

        justify-content: center;

        transition: 0.15s;

    }

    .ac-cpm-close:hover { background: rgba(239, 68, 68, 0.15); color: #ef4444; }



    .ac-cpm-player {

        position: relative;

        background: #000;

        aspect-ratio: 16 / 9;

    }

    .ac-cpm-player video {

        width: 100%;

        height: 100%;

        display: block;

        background: #000;

        object-fit: contain;

    }

    .ac-cpm-play-overlay {

        position: absolute;

        inset: 0;

        background: rgba(0, 0, 0, 0.3);

        border: none;

        display: flex;

        align-items: center;

        justify-content: center;

        cursor: pointer;

        transition: 0.2s;

    }

    .ac-cpm-play-overlay i {

        font-size: 4rem;

        color: rgba(255, 255, 255, 0.9);

        text-shadow: 0 4px 20px rgba(0, 0, 0, 0.8);

        transition: transform 0.2s;

    }

    .ac-cpm-play-overlay:hover i { transform: scale(1.1); }



    .ac-cpm-timeline-bar {

        position: absolute;

        bottom: 0;

        left: 0;

        right: 0;

        height: 4px;

        background: rgba(255, 255, 255, 0.15);

    }

    .ac-cpm-range {

        position: absolute;

        inset: 0;

        background: linear-gradient(90deg, #8b5cf6, #06b6d4);

        opacity: 0.4;

    }

    .ac-cpm-playhead {

        position: absolute;

        top: -3px;

        bottom: -3px;

        width: 3px;

        background: #fff;

        border-radius: 3px;

        box-shadow: 0 0 8px rgba(255, 255, 255, 0.8);

        transition: left 0.1s linear;

    }



    .ac-cpm-time-badge {

        position: absolute;

        bottom: 12px;

        right: 12px;

        padding: 5px 12px;

        background: rgba(0, 0, 0, 0.75);

        border-radius: 8px;

        color: #e8e8ef;

        font-size: 0.78rem;

        font-weight: 700;

        font-family: 'Courier New', monospace;

        display: flex;

        gap: 6px;

        align-items: center;

    }

    .ac-cpm-time-sep { color: #64748b; }



    .ac-cpm-info {

        padding: 16px 20px;

        border-bottom: 1px solid rgba(255, 255, 255, 0.06);

    }

    .ac-cpm-info-row {

        display: flex;

        justify-content: space-between;

        font-size: 0.8rem;

        color: #94a3b8;

        margin-bottom: 8px;

    }

    .ac-cpm-info-row > span:first-child { color: #a78bfa; font-weight: 700; }

    .ac-cpm-info-row > span:last-child { color: #22c55e; font-weight: 700; }

    .ac-cpm-preview-text {

        font-size: 0.82rem;

        color: #94a3b8;

        line-height: 1.5;

        max-height: 60px;

        overflow-y: auto;

        font-style: italic;

    }



    .ac-cpm-actions {

        display: flex;

        gap: 10px;

        padding: 14px 20px;

        background: rgba(0, 0, 0, 0.3);

        flex-wrap: wrap;

    }

    .ac-cpm-btn {

        padding: 11px 18px;

        border-radius: 10px;

        border: none;

        font-family: inherit;

        font-weight: 700;

        font-size: 0.82rem;

        cursor: pointer;

        display: inline-flex;

        align-items: center;

        gap: 7px;

        transition: 0.2s;

    }

    .ac-cpm-btn-loop {

        background: rgba(139, 92, 246, 0.1);

        border: 1px solid rgba(139, 92, 246, 0.25);

        color: #94a3b8;

    }

    .ac-cpm-btn-loop.active {

        background: rgba(139, 92, 246, 0.2);

        border-color: rgba(139, 92, 246, 0.5);

        color: #a78bfa;

    }

    .ac-cpm-btn-secondary {

        background: rgba(255, 255, 255, 0.05);

        border: 1px solid rgba(255, 255, 255, 0.1);

        color: #e8e8ef;

        margin-left: auto;

    }

    .ac-cpm-btn-secondary:hover { background: rgba(255, 255, 255, 0.1); }

    .ac-cpm-btn-render {

        background: linear-gradient(135deg, #8b5cf6, #06b6d4);

        color: #fff;

        box-shadow: 0 4px 16px rgba(139, 92, 246, 0.35);

    }

    .ac-cpm-btn-render:hover:not(:disabled) {

        transform: translateY(-1px);

        box-shadow: 0 8px 24px rgba(139, 92, 246, 0.5);

    }

    .ac-cpm-btn-render:disabled {

        opacity: 0.6;

        cursor: wait;

    }



    @media (max-width: 600px) {

        .ac-cpm-content { max-width: 100%; border-radius: 14px; }

        .ac-cpm-actions { flex-direction: column; }

        .ac-cpm-btn { width: 100%; justify-content: center; }

        .ac-cpm-btn-secondary { margin-left: 0; }

    }







    /* V9.19.0: Aggressive hide CSS (backup layer) */

    body.ac-load-project .autoclip-hero,

    body.ac-load-project .autoclip-badge,

    body.ac-load-project .ac-upload-zone,

    body.ac-load-project #acUploadZone,

    body.ac-load-project .ac-upload-box,

    body.ac-load-project .ac-settings,

    body.ac-load-project .ac-watermark-section,

    body.ac-load-project .ac-draft-banner,

    body.ac-load-project .ac-step-indicator,

    body.ac-load-project .ac-progress,

    body.ac-load-project .autoclip-history-link,

    body.ac-load-project .autoclip-history-bottom,

    body.ac-load-project [id*="draftBanner"],

    body.ac-load-project [id*="DraftBanner"] {

        display: none !important;

    }







    /* V9.20.0: Caption Generator */

    .tl-clip-caption-btn {

        position: absolute;

        bottom: 8px;

        left: 8px;

        z-index: 5;

        padding: 5px 10px;

        background: linear-gradient(135deg, #8b5cf6, #06b6d4);

        border: none;

        border-radius: 8px;

        color: #fff;

        font-size: 0.68rem;

        font-weight: 700;

        font-family: inherit;

        cursor: pointer;

        display: inline-flex;

        align-items: center;

        gap: 4px;

        box-shadow: 0 2px 10px rgba(139, 92, 246, 0.5);

        transition: 0.15s;

        opacity: 0;

    }

    .tl-clip:hover .tl-clip-caption-btn {

        opacity: 1;

    }

    .tl-clip-caption-btn:hover {

        transform: translateY(-1px);

        box-shadow: 0 4px 16px rgba(139, 92, 246, 0.7);

    }

    .tl-clip-caption-btn i { font-size: 0.65rem; }



    .ac-caption-modal {

        position: fixed;

        inset: 0;

        z-index: 10000;

        display: none;

        align-items: center;

        justify-content: center;

        padding: 20px;

    }

    .ac-cap-backdrop {

        position: absolute;

        inset: 0;

        background: rgba(0, 0, 0, 0.85);

        backdrop-filter: blur(8px);

    }

    .ac-cap-content {

        position: relative;

        width: 100%;

        max-width: 540px;

        background: linear-gradient(165deg, #15152b, #0f0f1e);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 20px;

        overflow: hidden;

        box-shadow: 0 30px 80px rgba(0, 0, 0, 0.7);

        animation: cap-in 0.25s ease;

    }

    @keyframes cap-in {

        from { transform: scale(0.92); opacity: 0; }

        to { transform: scale(1); opacity: 1; }

    }

    .ac-cap-head {

        display: flex;

        justify-content: space-between;

        align-items: center;

        padding: 16px 20px;

        border-bottom: 1px solid rgba(255, 255, 255, 0.06);

    }

    .ac-cap-title {

        display: flex;

        align-items: center;

        gap: 10px;

        color: #e8e8ef;

        font-weight: 700;

        font-size: 0.95rem;

    }

    .ac-cap-title i { color: #a78bfa; }

    .ac-cap-close {

        background: rgba(255, 255, 255, 0.05);

        border: none;

        color: #94a3b8;

        width: 30px;

        height: 30px;

        border-radius: 8px;

        cursor: pointer;

        display: flex;

        align-items: center;

        justify-content: center;

    }

    .ac-cap-close:hover { background: rgba(239, 68, 68, 0.15); color: #ef4444; }

    .ac-cap-body {

        padding: 20px;

        max-height: 60vh;

        overflow-y: auto;

    }

    .ac-cap-label {

        display: block;

        font-size: 0.72rem;

        font-weight: 700;

        color: #a78bfa;

        text-transform: uppercase;

        letter-spacing: 0.6px;

        margin-bottom: 8px;

    }

    .ac-cap-text {

        padding: 14px 16px;

        background: rgba(139, 92, 246, 0.08);

        border: 1px solid rgba(139, 92, 246, 0.2);

        border-radius: 12px;

        color: #e8e8ef;

        font-size: 0.88rem;

        line-height: 1.6;

    }

    .ac-cap-tags {

        display: flex;

        flex-wrap: wrap;

        gap: 6px;

        padding: 12px;

        background: rgba(6, 182, 212, 0.06);

        border: 1px solid rgba(6, 182, 212, 0.2);

        border-radius: 12px;

    }

    .ac-cap-tag {

        padding: 4px 10px;

        background: rgba(6, 182, 212, 0.15);

        border-radius: 8px;

        color: #22d3ee;

        font-size: 0.75rem;

        font-weight: 600;

    }

    .ac-cap-full {

        padding: 14px 16px;

        background: rgba(0, 0, 0, 0.4);

        border: 1px dashed rgba(139, 92, 246, 0.3);

        border-radius: 12px;

        color: #94a3b8;

        font-size: 0.78rem;

        line-height: 1.7;

        font-family: 'Courier New', monospace;

        user-select: all;

    }

    .ac-cap-actions {

        display: flex;

        gap: 10px;

        padding: 14px 20px;

        background: rgba(0, 0, 0, 0.3);

    }

    .ac-cap-btn {

        padding: 12px 18px;

        border-radius: 10px;

        border: none;

        font-family: inherit;

        font-weight: 700;

        font-size: 0.85rem;

        cursor: pointer;

        display: inline-flex;

        align-items: center;

        gap: 7px;

        transition: 0.2s;

    }

    .ac-cap-btn-copy {

        flex: 1;

        background: linear-gradient(135deg, #8b5cf6, #06b6d4);

        color: #fff;

        justify-content: center;

        box-shadow: 0 4px 16px rgba(139, 92, 246, 0.35);

    }

    .ac-cap-btn-copy:hover {

        transform: translateY(-1px);

        box-shadow: 0 8px 24px rgba(139, 92, 246, 0.5);

    }

    .ac-cap-btn-close {

        background: rgba(255, 255, 255, 0.05);

        border: 1px solid rgba(255, 255, 255, 0.1);

        color: #e8e8ef;

    }

    .ac-cap-btn-close:hover { background: rgba(255, 255, 255, 0.1); }







    /* V9.21.0: Caption button always visible + lebih mencolok */

    .tl-clip-caption-btn {

        opacity: 1 !important;

        background: linear-gradient(135deg, #f59e0b, #ef4444) !important;

        padding: 8px 14px !important;

        font-size: 0.75rem !important;

        box-shadow: 0 4px 14px rgba(239, 68, 68, 0.6) !important;

        border: 2px solid rgba(255,255,255,0.3) !important;

        animation: captionPulse 2s ease-in-out infinite;

    }

    .tl-clip-caption-btn:hover {

        transform: translateY(-2px) scale(1.05) !important;

        box-shadow: 0 8px 20px rgba(239, 68, 68, 0.8) !important;

    }

    @keyframes captionPulse {

        0%, 100% { box-shadow: 0 4px 14px rgba(239, 68, 68, 0.6); }

        50% { box-shadow: 0 4px 22px rgba(239, 68, 68, 0.9); }

    }







    /* V9.23.0: Aspect Ratio UI */

    .tl-aspect-row {

        display: flex;

        align-items: center;

        gap: 14px;

        padding: 12px 16px;

        margin: 12px 0;

        background: rgba(139, 92, 246, 0.06);

        border: 1px solid rgba(139, 92, 246, 0.2);

        border-radius: 12px;

        flex-wrap: wrap;

    }

    .tl-aspect-label {

        display: flex;

        align-items: center;

        gap: 8px;

        font-size: 0.82rem;

        font-weight: 700;

        color: #a78bfa;

        white-space: nowrap;

    }

    .tl-aspect-label i { font-size: 0.9rem; }

    .tl-aspect-btns {

        display: flex;

        gap: 6px;

        flex-wrap: wrap;

    }

    .tl-aspect-btn {

        padding: 7px 12px;

        background: rgba(255, 255, 255, 0.05);

        border: 1px solid rgba(255, 255, 255, 0.1);

        border-radius: 8px;

        color: #94a3b8;

        font-family: inherit;

        font-size: 0.72rem;

        font-weight: 700;

        cursor: pointer;

        transition: 0.15s;

        display: inline-flex;

        align-items: center;

        gap: 5px;

    }

    .tl-aspect-btn:hover {

        background: rgba(139, 92, 246, 0.15);

        border-color: rgba(139, 92, 246, 0.4);

        color: #e8e8ef;

    }

    .tl-aspect-btn.active {

        background: linear-gradient(135deg, #8b5cf6, #06b6d4);

        border-color: transparent;

        color: #fff;

        box-shadow: 0 4px 14px rgba(139, 92, 246, 0.4);

    }

    .tl-aspect-btn i { font-size: 0.7rem; }

    .tl-aspect-hint {

        font-size: 0.7rem;

        color: #64748b;

        display: flex;

        align-items: center;

        gap: 5px;

        margin-left: auto;

    }

    .tl-aspect-hint i { color: #a78bfa; }

    @media (max-width: 700px) {

        .tl-aspect-hint { margin-left: 0; width: 100%; }

    }







    /* V9.28.0: Free tier banner */

    .ac-free-tier-banner {

        display: flex;

        align-items: center;

        gap: 14px;

        padding: 14px 18px;

        margin: 12px 0 20px;

        background: linear-gradient(135deg, rgba(245, 158, 11, 0.08), rgba(239, 68, 68, 0.04));

        border: 1px solid rgba(245, 158, 11, 0.3);

        border-radius: 14px;

        flex-wrap: wrap;

    }

    .ac-ftb-icon {

        width: 40px;

        height: 40px;

        border-radius: 10px;

        background: rgba(245, 158, 11, 0.15);

        color: #f59e0b;

        display: flex;

        align-items: center;

        justify-content: center;

        font-size: 1.1rem;

        flex-shrink: 0;

    }

    .ac-ftb-content {

        flex: 1;

        min-width: 200px;

    }

    .ac-ftb-content strong {

        display: block;

        font-size: 0.88rem;

        color: #f59e0b;

        margin-bottom: 4px;

    }

    .ac-ftb-info {

        display: flex;

        align-items: center;

        gap: 8px;

        font-size: 0.75rem;

        color: #94a3b8;

        flex-wrap: wrap;

    }

    .ac-ftb-info i { font-size: 0.7rem; opacity: 0.7; }

    .ac-ftb-sep { color: #475569; }

    .ac-ftb-upgrade {

        padding: 9px 16px;

        background: linear-gradient(135deg, #f59e0b, #ef4444);

        border: none;

        border-radius: 10px;

        color: #fff;

        font-weight: 700;

        font-size: 0.78rem;

        text-decoration: none;

        display: inline-flex;

        align-items: center;

        gap: 6px;

        transition: 0.2s;

        box-shadow: 0 4px 14px rgba(245, 158, 11, 0.4);

    }

    .ac-ftb-upgrade:hover {

        transform: translateY(-1px);

        box-shadow: 0 6px 20px rgba(245, 158, 11, 0.6);

    }

    .ac-ftb-quota-ok { color: #22c55e !important; font-weight: 700; }

    .ac-ftb-quota-warn { color: #ef4444 !important; font-weight: 700; }







    /* ============================================================

       V9.51.0: Theme consistency - Auto Clip pakai ORANGE

       ============================================================ */

    

    /* Hero title - hilangkan purple gradient */

    .autoclip-hero h1 span,

    .autoclip-hero h1 .gradient-text {

        background: linear-gradient(135deg, #fbbf24, #f59e0b, #d97706) !important;

        -webkit-background-clip: text !important;

        -webkit-text-fill-color: transparent !important;

        background-clip: text !important;

    }

    

    /* Upload zone - dashed border jadi orange */

    .ac-upload-zone,

    #acUploadZone,

    .ac-upload-area {

        border-color: rgba(245, 158, 11, 0.35) !important;

        background: linear-gradient(135deg, rgba(245, 158, 11, 0.03), rgba(245, 158, 11, 0.01)) !important;

    }

    .ac-upload-zone:hover,

    #acUploadZone:hover,

    .ac-upload-area:hover,

    .ac-upload-zone.dragover,

    #acUploadZone.dragover {

        border-color: #f59e0b !important;

        background: rgba(245, 158, 11, 0.06) !important;

    }

    

    /* Icon upload - dari biru/purple ke orange */

    .ac-upload-zone i,

    #acUploadZone i,

    .ac-upload-icon i,

    .ac-upload-icon {

        color: #f59e0b !important;

    }

    

    /* Icon wrapper upload - kalau ada background */

    .ac-upload-icon-wrap,

    .ac-upload-zone .upload-icon {

        background: linear-gradient(135deg, rgba(245, 158, 11, 0.15), rgba(245, 158, 11, 0.05)) !important;

        color: #f59e0b !important;

    }

    

    /* Tombol "Pilih Video" - dari purple ke orange */

    #acPickBtn,

    .ac-upload-btn,

    .ac-upload-zone button,

    .ac-upload-area button {

        background: linear-gradient(135deg, #f59e0b, #d97706) !important;

        color: #fff !important;

        border: none !important;

        box-shadow: 0 6px 20px rgba(245, 158, 11, 0.35) !important;

        transition: 0.25s !important;

    }

    #acPickBtn:hover,

    .ac-upload-btn:hover,

    .ac-upload-zone button:hover {

        transform: translateY(-2px) !important;

        box-shadow: 0 10px 28px rgba(245, 158, 11, 0.5) !important;

    }

    

    /* Upload icon font awesome - bikin orange */

    .ac-upload-icon i::before,

    #acUploadZone i.fa-cloud-upload-alt::before,

    .ac-upload-zone i.fa-cloud-upload-alt::before {

        color: #f59e0b !important;

    }

    

    /* ============================================================

       Additional consistency

       ============================================================ */

    

    /* Kalau ada tombol primary lain di autoclip */

    .ac-btn-primary,

    .ac-primary-btn,

    button.btn-primary {

        background: linear-gradient(135deg, #f59e0b, #d97706) !important;

        border: none !important;

    }

    

    /* Link / text highlight - dari purple ke orange */

    .ac-link,

    .ac-highlight {

        color: #f59e0b !important;

    }

    

    /* Settings labels - kalau ada icon purple */

    .ac-settings label i {

        color: #f59e0b !important;

    }

    

    /* Progress bar kalau ada */

    .ac-progress-bar-fill,

    .ac-progress-fill {

        background: linear-gradient(135deg, #f59e0b, #d97706) !important;

    }

    

    /* Timeline checkbox active */

    .tl-clip.checked .tl-clip-check-mark,

    .tl-clip-checkbox:checked + .tl-clip-check-mark {

        background: #f59e0b !important;

        border-color: #f59e0b !important;

    }

    

    /* Section head icon (Timeline, Klip Belum Terpakai) */

    .tl-section-head h3 i,

    .tl-section-head i {

        color: #f59e0b !important;

    }

    

    /* ============================================================

       Upload icon inline SVG / img - kalau pakai img

       ============================================================ */

    .ac-upload-zone img,

    #acUploadZone img {

        filter: hue-rotate(-30deg) saturate(1.3) !important;

    }





    /* V9.58.2: Karaoke UI (grid-friendly) */

    .ac-setting-item.ac-setting-item-full {

        grid-column: 1 / -1 !important;

        flex-basis: 100% !important;

        width: 100% !important;

    }

    #acKaraokeSetting {

        grid-column: 1 / -1 !important;

        flex-basis: 100% !important;

        width: 100% !important;

    }

    .ac-badge-new {

        display: inline-block;

        padding: 2px 8px;

        background: linear-gradient(135deg, #f59e0b, #d97706);

        color: #fff;

        font-size: 0.6rem;

        font-weight: 800;

        border-radius: 6px;

        margin-left: 6px;

        letter-spacing: 0.5px;

        vertical-align: middle;

    }

    .ac-karaoke-row { margin-top: 10px; }

    .ac-toggle-switch {

        display: flex !important;

        align-items: center;

        gap: 12px;

        cursor: pointer;

        user-select: none;

    }

    .ac-toggle-switch input[type="checkbox"] {

        display: none;

    }

    .ac-toggle-slider {

        position: relative;

        width: 44px;

        height: 24px;

        background: rgba(255, 255, 255, 0.1);

        border: 1px solid rgba(255, 255, 255, 0.15);

        border-radius: 12px;

        transition: 0.25s;

        flex-shrink: 0;

    }

    .ac-toggle-slider::after {

        content: '';

        position: absolute;

        top: 2px;

        left: 2px;

        width: 18px;

        height: 18px;

        background: #fff;

        border-radius: 50%;

        transition: 0.25s;

        box-shadow: 0 2px 6px rgba(0,0,0,0.3);

    }

    .ac-toggle-switch input:checked + .ac-toggle-slider {

        background: linear-gradient(135deg, #f59e0b, #d97706);

        border-color: #f59e0b;

    }

    .ac-toggle-switch input:checked + .ac-toggle-slider::after {

        transform: translateX(20px);

    }

    .ac-toggle-label {

        font-size: 0.84rem;

        color: #e8ecf1;

        font-weight: 500;

    }

    .ac-karaoke-style {

        margin-top: 14px;

        padding-left: 56px;

    }

    .ac-karaoke-style select {

        width: 100%;

        padding: 10px 14px;

        background: rgba(0, 0, 0, 0.35);

        border: 1px solid rgba(148, 163, 184, 0.15);

        border-radius: 10px;

        color: #fff;

        font-family: inherit;

        font-size: 0.85rem;

        cursor: pointer;

        transition: 0.2s;

    }

    .ac-karaoke-style select:focus {

        outline: none;

        border-color: #f59e0b;

        box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.1);

    }

    .ac-karaoke-hint {

        margin-top: 10px;

        padding-left: 56px;

        font-size: 0.72rem;

        color: #64748b;

        display: flex;

        align-items: flex-start;

        gap: 6px;

        line-height: 1.5;

    }

    .ac-karaoke-hint i { color: #f59e0b; margin-top: 2px; }



    /* ============================================================ */

    /* V9.60.5: CARD SYSTEM - Template untuk semua section          */

    /* ============================================================ */

    .ac-card {

        max-width: 1100px;

        margin: 18px auto 0;

        background: rgba(15, 23, 42, 0.5);

        border: 1px solid rgba(148, 163, 184, 0.12);

        border-radius: 16px;

        overflow: hidden;

        transition: all 0.25s ease;

    }

    .ac-card:hover { border-color: rgba(148, 163, 184, 0.2); }

    .ac-card--purple { border-color: rgba(139, 92, 246, 0.25); }

    .ac-card--purple:hover { border-color: rgba(139, 92, 246, 0.45); }

    .ac-card--purple .ac-card-header-icon { color: #a78bfa; }

    .ac-card--purple .ac-card-header { background: linear-gradient(90deg, rgba(139, 92, 246, 0.08), transparent); }

    .ac-card--blue { border-color: rgba(56, 189, 248, 0.25); }

    .ac-card--blue:hover { border-color: rgba(56, 189, 248, 0.45); }

    .ac-card--blue .ac-card-header-icon { color: #38bdf8; }

    .ac-card--blue .ac-card-header { background: linear-gradient(90deg, rgba(56, 189, 248, 0.08), transparent); }

    .ac-card--orange { border-color: rgba(245, 158, 11, 0.25); }

    .ac-card--orange:hover { border-color: rgba(245, 158, 11, 0.45); }

    .ac-card--orange .ac-card-header-icon { color: #fbbf24; }

    .ac-card--orange .ac-card-header { background: linear-gradient(90deg, rgba(245, 158, 11, 0.08), transparent); }

    .ac-card--pink { border-color: rgba(236, 72, 153, 0.25); }

    .ac-card--pink:hover { border-color: rgba(236, 72, 153, 0.45); }

    .ac-card--pink .ac-card-header-icon { color: #f472b6; }

    .ac-card--pink .ac-card-header { background: linear-gradient(90deg, rgba(236, 72, 153, 0.08), transparent); }

    .ac-card-header {

        display: flex;

        align-items: center;

        justify-content: space-between;

        padding: 16px 20px;

        cursor: pointer;

        user-select: none;

        transition: background 0.2s;

    }

    .ac-card-header:hover { background: rgba(255, 255, 255, 0.02); }

    .ac-card-header-left {

        display: flex;

        align-items: center;

        gap: 12px;

        flex: 1;

        min-width: 0;

    }

    .ac-card-header-icon {

        font-size: 1.2rem;

        width: 28px;

        text-align: center;

        flex-shrink: 0;

    }

    .ac-card-header-title {

        font-weight: 700;

        font-size: 0.95rem;

        color: #e8ecf1;

        letter-spacing: 0.3px;

    }

    .ac-card-header-sub {

        font-size: 0.72rem;

        color: #64748b;

        font-weight: 500;

        margin-left: 8px;

    }

    .ac-card-header-right {

        display: flex;

        align-items: center;

        gap: 10px;

        flex-shrink: 0;

    }

    .ac-card-chevron {

        color: #64748b;

        font-size: 0.85rem;

        transition: transform 0.25s;

        width: 20px;

        text-align: center;

    }

    .ac-card.collapsed .ac-card-chevron { transform: rotate(-90deg); }

    .ac-card.collapsed .ac-card-body {

        max-height: 0 !important;

        padding-top: 0 !important;

        padding-bottom: 0 !important;

        overflow: hidden;

        opacity: 0;

    }

    .ac-card-body {

        padding: 0 20px 20px;

        max-height: 3000px;

        transition: max-height 0.3s ease, opacity 0.2s ease, padding 0.2s ease;

        opacity: 1;

    }

    .ac-card-badge {

        font-size: 0.65rem;

        padding: 3px 8px;

        border-radius: 6px;

        font-weight: 700;

        letter-spacing: 0.5px;

        text-transform: uppercase;

    }

    .ac-card-badge--new {

        background: linear-gradient(135deg, #f59e0b, #d97706);

        color: #fff;

    }

    .ac-card-badge--active {

        background: rgba(34, 197, 94, 0.15);

        color: #4ade80;

        border: 1px solid rgba(34, 197, 94, 0.3);

    }

    .ac-card-badge--off {

        background: rgba(148, 163, 184, 0.1);

        color: #94a3b8;

        border: 1px solid rgba(148, 163, 184, 0.2);

    }

    .ac-card .ac-settings-grid {

        display: grid;

        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));

        gap: 14px;

    }

    .ac-card .ac-settings-grid--compact {

        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));

    }

    .ac-toggle-switch {

        display: inline-flex;

        align-items: center;

        gap: 10px;

        cursor: pointer;

        user-select: none;

    }

    .ac-toggle-switch input { display: none; }

    .ac-toggle-slider {

        position: relative;

        width: 44px;

        height: 24px;

        background: rgba(255, 255, 255, 0.1);

        border: 1px solid rgba(255, 255, 255, 0.15);

        border-radius: 12px;

        transition: 0.25s;

        flex-shrink: 0;

    }

    .ac-toggle-slider::after {

        content: "";

        position: absolute;

        top: 2px;

        left: 2px;

        width: 18px;

        height: 18px;

        background: #fff;

        border-radius: 50%;

        transition: 0.25s;

        box-shadow: 0 2px 6px rgba(0,0,0,0.3);

    }

    .ac-toggle-switch input:checked + .ac-toggle-slider {

        background: linear-gradient(135deg, #8b5cf6, #6366f1);

        border-color: transparent;

    }

    .ac-toggle-switch input:checked + .ac-toggle-slider::after {

        transform: translateX(20px);

    }

    .ac-card--orange .ac-toggle-switch input:checked + .ac-toggle-slider {

        background: linear-gradient(135deg, #f59e0b, #d97706);

    }

    .ac-card--blue .ac-toggle-switch input:checked + .ac-toggle-slider {

        background: linear-gradient(135deg, #38bdf8, #0284c7);

    }

    .ac-card--pink .ac-toggle-switch input:checked + .ac-toggle-slider {

        background: linear-gradient(135deg, #ec4899, #be185d);

    }

    .ac-toggle-label {

        font-size: 0.82rem;

        color: #cbd5e1;

        font-weight: 500;

    }

    /* V9.70.0: CAPCUT FADE - visual curve di bawah slider */

    .ac-fade-item {

        padding-bottom: 14px !important;

    }

    .ac-fade-label {

        color: #f472b6;

        font-weight: 700;

        float: right;

        transition: 0.15s;

    }

    .ac-fade-wrapper {

        position: relative;

        padding-bottom: 24px;

    }

    .ac-fade-slider {

        width: 100%;

        accent-color: #ec4899;

        position: relative;

        z-index: 2;

    }

    .ac-fade-curve {

        position: absolute;

        left: 0;

        right: 0;

        bottom: 0;

        width: 100%;

        height: 20px;

        pointer-events: none;

        opacity: 0.6;

    }

    .ac-fade-path {

        fill: rgba(236, 72, 153, 0.15);

        stroke: #ec4899;

        stroke-width: 0.8;

        stroke-linejoin: round;

        transition: d 0.2s ease;

    }

    







/* V9.87.0: TOMBOL PROSES VIDEO */

    .ac-proses-wrapper {

        max-width: 1100px;

        margin: 24px auto 0;

        text-align: center;

        display: none;

    }

    .ac-proses-wrapper.visible {

        display: block !important;

    }



    /* V9.124.5: Responsive tombol proses */

    @media (max-width: 640px) {

        .ac-proses-wrapper {

            padding: 0 16px;

            margin: 20px auto 0;

        }

        .ac-proses-btn {

            width: 100%;

            min-width: unset;

            max-width: unset;

            padding: 14px 24px;

            font-size: 14px;

        }

    }

    /* V9.124.5: RAPIKAN TOMBOL PROSES - compact, modern */

    .ac-proses-btn {

        display: inline-flex;

        flex-direction: row;

        align-items: center;

        justify-content: center;

        gap: 10px;

        padding: 14px 32px;

        min-width: 240px;

        max-width: 400px;

        background: linear-gradient(135deg, #f59e0b, #d97706);

        color: white;

        border: none;

        border-radius: 12px;

        font-family: inherit;

        font-size: 15px;

        font-weight: 600;

        cursor: pointer;

        box-shadow: 0 6px 20px rgba(245, 158, 11, 0.35);

        transition: transform 0.2s, box-shadow 0.2s;

    }

    .ac-proses-btn:hover {

        transform: translateY(-2px);

        box-shadow: 0 10px 28px rgba(245, 158, 11, 0.5);

    }

    .ac-proses-btn:active {

        transform: translateY(-1px);

    }

    .ac-proses-btn i {

        font-size: 18px;

    }

    .ac-proses-btn small {

        font-size: 0.72rem;

        opacity: 0.85;

        font-weight: 500;

        letter-spacing: 0;

        text-transform: none;

    }

    .ac-proses-btn:disabled {

        opacity: 0.5;

        cursor: not-allowed;

        transform: none;

    }



    

/* V9.89.0: VIDEO PREVIEW MODE - hide timeline di mode preview */

    body.ac-preview-mode .te-timeline-section,

    body.ac-preview-mode .te-quick-mode,

    body.ac-preview-mode .te-stats,

    body.ac-preview-mode .te-actions {

        display: none !important;

    }

    body.ac-preview-mode .te-header h3 {

        color: #f59e0b;

    }

    body.ac-preview-mode .te-subtitle {

        display: none;

    }

    

    

    /* V9.93.0: VIDEO PREVIEW ATAS */

    .ac-video-preview-wrap {

        max-width: 1100px;

        margin: 20px auto 0;

        background: rgba(15, 23, 42, 0.5);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 16px;

        padding: 16px;

        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3);

    }

    .ac-video-preview-head {

        display: flex;

        align-items: center;

        gap: 10px;

        margin-bottom: 12px;

        color: #a78bfa;

        font-weight: 700;

        font-size: 0.9rem;

    }

    .ac-video-preview-head i {

        font-size: 1.1rem;

    }

    .ac-video-preview-close {

        margin-left: auto;

        background: rgba(255, 255, 255, 0.05);

        border: none;

        color: #94a3b8;

        width: 30px;

        height: 30px;

        border-radius: 8px;

        cursor: pointer;

        display: flex;

        align-items: center;

        justify-content: center;

        transition: 0.2s;

    }

    .ac-video-preview-close:hover {

        background: rgba(239, 68, 68, 0.15);

        color: #ef4444;

    }

    

    /* V9.90.0: PREVIEW MODE PROTECT - pastikan card settings TIDAK di-hide */

    body.ac-preview-mode .ac-card,

    body.ac-preview-mode .ac-settings,

    body.ac-preview-mode .autoclip-hero,

    body.ac-preview-mode .autoclip-badge,

    body.ac-preview-mode .ac-free-tier-banner,

    body.ac-preview-mode .autoclip-history-bottom {

        display: block !important;

        visibility: visible !important;

        opacity: 1 !important;

    }

    body.ac-preview-mode .ac-card {

        display: block !important;

    }

    body.ac-preview-mode .ac-card-body {

        display: block !important;

    }

    /* Sembunyikan timeline editor detail (cuma video preview) */

    body.ac-preview-mode .te-timeline-section,

    body.ac-preview-mode .te-quick-mode,

    body.ac-preview-mode .te-actions,

    body.ac-preview-mode .te-stats,

    body.ac-preview-mode .te-timeline-hint,

    body.ac-preview-mode .te-legend-compact {

        display: none !important;

    }

    

    /* V9.94.0: HIDE EDITOR CONTAINER - cegah preview ganda */

    /* Sembunyikan editorContainer dari control_panel KECUALI saat timeline aktif */

    body:not(.ac-timeline-active) #editorContainer {

        display: none !important;

    }

    body.ac-timeline-active #editorContainer {

        display: block !important;

    }

    

    /* V9.97.0: HIDE PROGRESS DUPLICATE - sembunyikan progressContainer dari control_panel */

    #progressContainer,

    #controlPanel .progress-box,

    #controlPanel .progress-text {

        display: none !important;

    }

    

    /* V9.103.0: DUAL MODE LAYOUT - hide setup saat timeline aktif */

    /* Mode Setup: tampilkan card settings, upload zone, hero */

    /* Mode Timeline: tampilkan timeline editor, sembunyikan card */

    

    /* Hide setup elements saat timeline aktif */

    body.ac-timeline-active .autoclip-hero,

    body.ac-timeline-active .autoclip-badge,

    body.ac-timeline-active .ac-upload-zone,

    body.ac-timeline-active .ac-video-preview-wrap,

    body.ac-timeline-active .ac-card,

    body.ac-timeline-active .ac-progress,

    body.ac-timeline-active .ac-proses-wrapper,

    body.ac-timeline-active .ac-free-tier-banner,

    body.ac-timeline-active .autoclip-history-bottom {

        display: none !important;

    }

    

    /* Saat timeline aktif, tampilkan timeline editor dengan rapi */

    body.ac-timeline-active #acTimelineEditor {

        display: block !important;

    }

    

    /* Saat timeline TIDAK aktif, sembunyikan timeline editor */

    body:not(.ac-timeline-active) #acTimelineEditor {

        display: none !important;

    }

    

    /* Reset margin timeline editor supaya full-width */

    body.ac-timeline-active #acTimelineEditor {

        margin: 0 auto;

        max-width: 1100px;

        padding: 20px;

    }

    

    /* V9.104.0: RAPIKAN TIMELINE - layout timeline editor yang rapi */

    

    /* Container timeline - max-width, centered */

    #acTimelineEditor {

        max-width: 1000px !important;

        margin: 0 auto !important;

        padding: 24px 20px !important;

    }

    

    /* Video player - batasi ukuran, jangan overflow */

    body.ac-timeline-active #tlVideo {

        width: 100% !important;

        max-height: 480px !important;

        border-radius: 12px !important;

        background: #000 !important;

        display: block !important;

    }

    

    /* Preview container */

    body.ac-timeline-active .tl-preview {

        position: relative !important;

        max-width: 100% !important;

        overflow: hidden !important;

        border-radius: 12px !important;

        background: #000 !important;

    }

    

    /* Preview controls - rapi */

    body.ac-timeline-active .tl-preview-controls {

        display: flex !important;

        align-items: center !important;

        gap: 12px !important;

        padding: 12px 16px !important;

        background: rgba(0, 0, 0, 0.4) !important;

        border-radius: 8px !important;

        margin-top: 8px !important;

    }

    

    body.ac-timeline-active .tl-preview-info {

        padding: 8px 12px !important;

        background: rgba(139, 92, 246, 0.08) !important;

        border-radius: 6px !important;

        font-size: 0.8rem !important;

        color: #a78bfa !important;

        margin-top: 8px !important;

    }

    

    /* Timeline section - jarak yang lebih baik */

    body.ac-timeline-active .tl-section {

        margin-top: 28px !important;

        padding: 20px !important;

        background: rgba(15, 23, 42, 0.4) !important;

        border: 1px solid rgba(148, 163, 184, 0.1) !important;

        border-radius: 12px !important;

    }

    

    body.ac-timeline-active .tl-section-head {

        display: flex !important;

        justify-content: space-between !important;

        align-items: center !important;

        margin-bottom: 16px !important;

    }

    

    body.ac-timeline-active .tl-section-head h3 {

        margin: 0 !important;

        font-size: 0.95rem !important;

        color: #e8ecf1 !important;

        display: flex !important;

        align-items: center !important;

        gap: 8px !important;

    }

    

    body.ac-timeline-active .tl-section-head h3 i {

        color: #f59e0b !important;

    }

    

    body.ac-timeline-active .tl-section-hint {

        font-size: 0.72rem !important;

        color: #64748b !important;

        font-style: italic !important;

    }

    

    /* Timeline klip horizontal - scroll smooth */

    body.ac-timeline-active .tl-timeline {

        display: flex !important;

        gap: 12px !important;

        overflow-x: auto !important;

        padding: 8px 4px !important;

        min-height: 180px !important;

    }

    

    body.ac-timeline-active .tl-timeline::-webkit-scrollbar {

        height: 8px !important;

    }

    

    body.ac-timeline-active .tl-timeline::-webkit-scrollbar-thumb {

        background: rgba(139, 92, 246, 0.4) !important;

        border-radius: 4px !important;

    }

    

    /* Header timeline */

    body.ac-timeline-active .tl-header {

        display: flex !important;

        justify-content: space-between !important;

        align-items: center !important;

        margin-bottom: 24px !important;

        padding-bottom: 16px !important;

        border-bottom: 1px solid rgba(148, 163, 184, 0.1) !important;

    }

    

    body.ac-timeline-active .tl-header-left h2 {

        margin: 0 0 4px !important;

        font-size: 1.2rem !important;

        color: #e8ecf1 !important;

    }

    

    body.ac-timeline-active .tl-header-meta {

        font-size: 0.8rem !important;

        color: #94a3b8 !important;

    }

    

    /* Navbar tetap terlihat di timeline mode (karena bukan project mode murni) */

    /* Kalau mau hide navbar, uncomment baris bawah */

    /* body.ac-timeline-active nav,

    body.ac-timeline-active header {

        display: none !important;

    } */

    





    /* ============================================================

       V9.256.0: FIX DROPDOWN OVERFLOW

       Masalah: Native <select> tertutup cepat karena parent 

       punya 'overflow: hidden' + 'transition: all'.

       Fix: Override khusus untuk card body yang expanded.

       ============================================================ */

    

    /* Card expanded - overflow visible */

    .ac-card:not(.collapsed) {

        overflow: visible !important;

    }

    

    /* Card body expanded - overflow visible */

    .ac-card:not(.collapsed) .ac-card-body {

        overflow: visible !important;

    }

    

    /* Setting item - overflow visible */

    .ac-card:not(.collapsed) .ac-setting-item,

    .ac-card:not(.collapsed) .ac-settings-grid {

        overflow: visible !important;

    }

    

    /* Select - pastikan bisa buka dropdown native */

    .ac-card:not(.collapsed) .ac-setting-item select {

        position: relative !important;

        z-index: 100 !important;

        overflow: visible !important;

    }

    

    /* Matikan transition 'all' - ganti transition spesifik */

    .ac-card {

        transition: border-color 0.25s ease, background-color 0.25s ease !important;

    }

    

    /* Card body - transition max-height saja, tanpa overflow hidden */

    .ac-card:not(.collapsed) .ac-card-body {

        max-height: none !important;

    }





        /* V9.148.0: QUICK PRESET BUTTONS */

        .ac-quick-preset {

            display: flex;

            flex-direction: column;

            align-items: center;

            justify-content: center;

            padding: 10px 6px;

            background: rgba(255, 255, 255, 0.03);

            border: 1px solid rgba(255, 255, 255, 0.1);

            border-radius: 10px;

            color: #cbd5e1;

            cursor: pointer;

            font-family: inherit;

            transition: all 0.2s ease;

            text-align: center;

            gap: 3px;

        }

        

        .ac-quick-preset:hover {

            background: rgba(139, 92, 246, 0.15);

            border-color: rgba(139, 92, 246, 0.5);

            transform: translateY(-2px);

            box-shadow: 0 4px 12px rgba(139, 92, 246, 0.3);

        }

        

        .ac-quick-preset.active {

            background: linear-gradient(135deg, rgba(139, 92, 246, 0.3), rgba(109, 40, 217, 0.3));

            border-color: #8b5cf6;

            color: #fff;

            box-shadow: 0 0 20px rgba(139, 92, 246, 0.5);

        }

        

        .ac-quick-preset[data-preset="tiktok"]:hover { border-color: #ef4444; background: rgba(239, 68, 68, 0.15); }

        .ac-quick-preset[data-preset="tiktok"].active { background: linear-gradient(135deg, #ef4444, #b91c1c); border-color: #ef4444; }

        

        .ac-quick-preset[data-preset="reels"]:hover { border-color: #ec4899; background: rgba(236, 72, 153, 0.15); }

        .ac-quick-preset[data-preset="reels"].active { background: linear-gradient(135deg, #ec4899, #be185d); border-color: #ec4899; }

        

        .ac-quick-preset[data-preset="youtube"]:hover { border-color: #dc2626; background: rgba(220, 38, 38, 0.15); }

        .ac-quick-preset[data-preset="youtube"].active { background: linear-gradient(135deg, #dc2626, #991b1b); border-color: #dc2626; }

        

        .ac-quick-preset[data-preset="podcast"]:hover { border-color: #f59e0b; background: rgba(245, 158, 11, 0.15); }

        .ac-quick-preset[data-preset="podcast"].active { background: linear-gradient(135deg, #f59e0b, #d97706); border-color: #f59e0b; }

        

        @media (max-width: 640px) {

            .ac-quick-preset span:nth-child(3) { display: none; }

            .ac-quick-preset { padding: 8px 4px; }

        }



    

    /* ============================================================ */

    /* V9.175.0: RETENTION_HEATMAP_CSS                              */

    /* ============================================================ */

    .ac-retention-panel {

        margin: 14px auto 0;

        max-width: 100%;

        padding: 14px 16px;

        background: linear-gradient(135deg, rgba(139, 92, 246, 0.06), rgba(59, 130, 246, 0.06));

        border: 1px solid rgba(139, 92, 246, 0.25);

        border-radius: 12px;

        font-family: inherit;

    }

    .ac-retention-header {

        display: flex;

        justify-content: space-between;

        align-items: center;

        margin-bottom: 10px;

    }

    .ac-retention-title {

        font-size: 13px;

        font-weight: 700;

        color: #a78bfa;

        display: flex;

        align-items: center;

        gap: 6px;

    }

    .ac-retention-score {

        font-size: 14px;

        font-weight: 800;

        color: #22c55e;

    }

    .ac-retention-score.medium { color: #f59e0b; }

    .ac-retention-score.low { color: #ef4444; }

    .ac-retention-virality {

        font-size: 10px;

        padding: 3px 8px;

        border-radius: 6px;

        background: rgba(139, 92, 246, 0.15);

        color: #c4b5fd;

        font-weight: 700;

        text-transform: uppercase;

        letter-spacing: 0.5px;

    }

    .ac-retention-virality[data-virality="viral"] {

        background: linear-gradient(135deg, #22c55e, #16a34a);

        color: white;

    }

    .ac-retention-virality[data-virality="high"] {

        background: linear-gradient(135deg, #84cc16, #65a30d);

        color: white;

    }

    .ac-retention-virality[data-virality="medium"] {

        background: linear-gradient(135deg, #f59e0b, #d97706);

        color: white;

    }

    .ac-retention-virality[data-virality="low"] {

        background: linear-gradient(135deg, #ef4444, #dc2626);

        color: white;

    }

    .ac-retention-heatmap {

        display: flex;

        height: 40px;

        border-radius: 8px;

        overflow: hidden;

        margin-bottom: 12px;

        cursor: pointer;

        position: relative;

        box-shadow: inset 0 1px 3px rgba(0,0,0,0.3);

    }

    .ac-retention-segment {

        flex: 1;

        position: relative;

        transition: all 0.2s ease;

        cursor: pointer;

        min-width: 2px;

    }

    .ac-retention-segment:hover {

        transform: scaleY(1.15);

        z-index: 10;

        box-shadow: 0 0 12px currentColor;

    }

    .ac-retention-segment[data-type="peak"] { background: linear-gradient(180deg, #22c55e, #16a34a); }

    .ac-retention-segment[data-type="good"] { background: linear-gradient(180deg, #84cc16, #65a30d); }

    .ac-retention-segment[data-type="medium"] { background: linear-gradient(180deg, #f59e0b, #d97706); }

    .ac-retention-segment[data-type="drop"] { background: linear-gradient(180deg, #ef4444, #b91c1c); }

    .ac-retention-legend {

        display: flex;

        gap: 12px;

        font-size: 10px;

        color: #94a3b8;

        margin-bottom: 12px;

        flex-wrap: wrap;

    }

    .ac-retention-legend-item {

        display: flex;

        align-items: center;

        gap: 4px;

    }

    .ac-retention-legend-dot {

        width: 10px;

        height: 10px;

        border-radius: 3px;

    }

    .ac-retention-drops {

        margin-bottom: 10px;

        font-size: 11px;

    }

    .ac-retention-drops-title {

        font-size: 11px;

        font-weight: 700;

        color: #fbbf24;

        margin-bottom: 6px;

        display: flex;

        align-items: center;

        gap: 4px;

    }

    .ac-retention-drop-item {

        padding: 6px 10px;

        background: rgba(239, 68, 68, 0.1);

        border-left: 3px solid #ef4444;

        border-radius: 6px;

        margin-bottom: 4px;

        color: #fca5a5;

        font-size: 10px;

        display: flex;

        justify-content: space-between;

        align-items: center;

    }

    .ac-retention-suggestions {

        margin-top: 10px;

        padding-top: 10px;

        border-top: 1px solid rgba(255,255,255,0.06);

    }

    .ac-retention-suggestions-title {

        font-size: 11px;

        font-weight: 700;

        color: #22c55e;

        margin-bottom: 8px;

        display: flex;

        align-items: center;

        gap: 4px;

    }

    .ac-retention-suggestion-btn {

        display: inline-flex;

        align-items: center;

        gap: 6px;

        padding: 6px 12px;

        background: rgba(34, 197, 94, 0.15);

        border: 1px solid rgba(34, 197, 94, 0.4);

        color: #22c55e;

        font-size: 10px;

        font-weight: 600;

        border-radius: 8px;

        cursor: pointer;

        font-family: inherit;

        margin-right: 6px;

        margin-bottom: 6px;

        transition: all 0.2s;

    }

    .ac-retention-suggestion-btn:hover {

        background: rgba(34, 197, 94, 0.25);

        transform: translateY(-1px);

    }

    .ac-retention-loading {

        text-align: center;

        padding: 20px;

        color: #a78bfa;

        font-size: 12px;

    }

    .ac-retention-tooltip {

        position: absolute;

        bottom: 100%;

        left: 50%;

        transform: translateX(-50%) translateY(-8px);

        background: rgba(15, 23, 42, 0.98);

        border: 1px solid rgba(139, 92, 246, 0.5);

        color: white;

        padding: 8px 12px;

        border-radius: 8px;

        font-size: 11px;

        white-space: nowrap;

        pointer-events: none;

        opacity: 0;

        transition: opacity 0.15s;

        z-index: 100;

        box-shadow: 0 4px 20px rgba(0,0,0,0.5);

    }

    .ac-retention-segment:hover .ac-retention-tooltip {

        opacity: 1;

    }





    /* V9.178.0: AUTO_OPTIMIZE_UI */

    .ac-auto-optimize-btn {

        display: flex;

        align-items: center;

        justify-content: center;

        gap: 8px;

        width: 100%;

        padding: 12px 16px;

        background: linear-gradient(135deg, #22c55e, #16a34a);

        border: none;

        border-radius: 10px;

        color: #fff;

        font-family: inherit;

        font-size: 13px;

        font-weight: 700;

        cursor: pointer;

        margin-top: 10px;

        transition: all 0.2s ease;

        box-shadow: 0 4px 16px rgba(34, 197, 94, 0.35);

    }

    .ac-auto-optimize-btn:hover {

        transform: translateY(-2px);

        box-shadow: 0 6px 24px rgba(34, 197, 94, 0.5);

    }

    .ac-auto-optimize-btn:disabled {

        opacity: 0.5;

        cursor: not-allowed;

        transform: none;

    }

    .ac-auto-optimize-btn i { font-size: 16px; }



    /* Modal */

    .ac-auto-modal {

        position: fixed;

        inset: 0;

        background: rgba(0,0,0,0.8);

        backdrop-filter: blur(8px);

        display: none;

        align-items: center;

        justify-content: center;

        z-index: 99999;

        padding: 20px;

    }

    .ac-auto-modal.show { display: flex; }

    .ac-auto-modal-content {

        background: linear-gradient(135deg, #1a1a2e, #0f0f1a);

        border: 1px solid rgba(34, 197, 94, 0.3);

        border-radius: 16px;

        max-width: 520px;

        width: 100%;

        padding: 24px;

        box-shadow: 0 24px 64px rgba(0,0,0,0.7);

        max-height: 90vh;

        overflow-y: auto;

    }

    .ac-auto-modal-header {

        display: flex;

        align-items: center;

        gap: 12px;

        margin-bottom: 16px;

    }

    .ac-auto-modal-icon {

        width: 44px;

        height: 44px;

        border-radius: 12px;

        background: linear-gradient(135deg, #22c55e, #16a34a);

        display: flex;

        align-items: center;

        justify-content: center;

        color: #fff;

        font-size: 20px;

        flex-shrink: 0;

    }

    .ac-auto-modal-title {

        font-size: 16px;

        font-weight: 700;

        color: #fff;

    }

    .ac-auto-modal-subtitle {

        font-size: 11px;

        color: #94a3b8;

        margin-top: 2px;

    }

    .ac-auto-modal-body {

        font-size: 13px;

        color: #cbd5e1;

        line-height: 1.6;

        margin-bottom: 20px;

    }

    .ac-auto-summary-item {

        display: flex;

        align-items: center;

        gap: 10px;

        padding: 10px 12px;

        background: rgba(34, 197, 94, 0.08);

        border-left: 3px solid #22c55e;

        border-radius: 8px;

        margin-bottom: 8px;

        font-size: 12px;

    }

    .ac-auto-summary-item i {

        color: #22c55e;

        font-size: 14px;

    }

    .ac-auto-summary-item .count {

        margin-left: auto;

        font-weight: 700;

        color: #22c55e;

    }

    .ac-auto-impact {

        padding: 12px 14px;

        background: rgba(139, 92, 246, 0.1);

        border: 1px solid rgba(139, 92, 246, 0.3);

        border-radius: 10px;

        margin-bottom: 20px;

        font-size: 12px;

    }

    .ac-auto-impact-title {

        font-weight: 700;

        color: #a78bfa;

        margin-bottom: 8px;

    }

    .ac-auto-impact-row {

        display: flex;

        justify-content: space-between;

        margin-bottom: 4px;

        color: #cbd5e1;

    }

    .ac-auto-impact-value {

        color: #22c55e;

        font-weight: 700;

    }

    .ac-auto-modal-actions {

        display: flex;

        gap: 10px;

    }

    .ac-auto-btn {

        flex: 1;

        padding: 12px;

        border-radius: 10px;

        font-family: inherit;

        font-size: 13px;

        font-weight: 700;

        cursor: pointer;

        border: none;

        transition: all 0.2s;

    }

    .ac-auto-btn-secondary {

        background: rgba(255,255,255,0.05);

        border: 1px solid rgba(255,255,255,0.1);

        color: #cbd5e1;

    }

    .ac-auto-btn-secondary:hover {

        background: rgba(255,255,255,0.1);

    }

    .ac-auto-btn-primary {

        background: linear-gradient(135deg, #22c55e, #16a34a);

        color: #fff;

        box-shadow: 0 4px 16px rgba(34, 197, 94, 0.35);

    }

    .ac-auto-btn-primary:hover {

        transform: translateY(-2px);

        box-shadow: 0 6px 24px rgba(34, 197, 94, 0.5);

    }

    .ac-auto-btn-primary:disabled {

        opacity: 0.5;

        cursor: not-allowed;

        transform: none;

    }



    /* Progress */

    .ac-auto-progress {

        display: none;

    }

    .ac-auto-progress.show { display: block; }

    .ac-auto-progress-bar {

        height: 8px;

        background: rgba(34, 197, 94, 0.15);

        border-radius: 4px;

        overflow: hidden;

        margin: 16px 0 8px;

    }

    .ac-auto-progress-fill {

        height: 100%;

        width: 0%;

        background: linear-gradient(90deg, #22c55e, #16a34a);

        border-radius: 4px;

        transition: width 0.3s ease;

    }

    .ac-auto-progress-text {

        font-size: 12px;

        color: #94a3b8;

        text-align: center;

    }


/* ============================================================ */
/* V22.0.0: DESKTOP SCALING ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â PERBESAR AREA PENGATURAN           */
/* ============================================================ */

/* 1. Container utama: lebih lebar di desktop */
@media (min-width: 1024px) {
    /* Container untuk area upload & pengaturan */
    .ac-container,
    .autoclip-main,
    main.container {
        max-width: 1000px !important; /* Dari 600px ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ 1000px */
        width: 100% !important;
        margin: 0 auto !important;
        padding: 0 20px !important;
    }
    
    /* Accordion (Pengaturan Dasar, Subtitle, Music) */
    .ac-accordion,
    .ac-settings-group,
    .setting-group,
    details {
        max-width: 1000px !important;
        width: 100% !important;
        margin-left: auto !important;
        margin-right: auto !important;
    }
    
    /* Music Background container */
    .music-bg-container,
    .music-settings,
    .ac-music-box {
        max-width: 1000px !important;
        width: 100% !important;
        padding: 24px 32px !important;
    }
    
    /* Slider & kontrol di dalamnya */
    .music-slider-row,
    .slider-group,
    .volume-control {
        width: 100% !important;
    }
    
    /* Perbesar slider */
    input[type="range"] {
        height: 8px !important;
        width: 100% !important;
    }
    
    /* Perbesar teks label */
    .music-label,
    .volume-label,
    .fade-label {
        font-size: 0.95rem !important;
    }
    
    /* Tombol di dalam pengaturan */
    .music-actions .btn,
    .music-actions button {
        padding: 12px 24px !important;
        font-size: 0.9rem !important;
    }
}

/* 2. Upload area: tetap proporsional, tapi sedikit lebih lebar */
@media (min-width: 1024px) {
    .upload-area,
    #acUploadZone,
    .ac-upload-zone {
        max-width: 800px !important; /* Dari 680px ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ 800px */
        width: 100% !important;
        margin: 30px auto !important;
        padding: 60px 40px !important;
    }
    
    /* Perbesar judul */
    .upload-area h3,
    .ac-upload-zone h3 {
        font-size: 1.6rem !important;
    }
    
    /* Perbesar teks keterangan */
    .upload-area p,
    .ac-upload-zone p {
        font-size: 1rem !important;
    }
    
    /* Perbesar tombol Pilih Video */
    .upload-area .btn,
    .ac-upload-zone button {
        padding: 16px 32px !important;
        font-size: 1rem !important;
    }
}

/* 3. Tablet: ukuran menengah */
@media (min-width: 768px) and (max-width: 1023px) {
    .ac-container,
    .autoclip-main,
    main.container {
        max-width: 700px !important;
    }
    
    .upload-area,
    #acUploadZone {
        max-width: 650px !important;
    }
}

/* 4. Mobile: tetap full width (tidak berubah) */
@media (max-width: 767px) {
    .ac-container,
    .autoclip-main,
    main.container {
        max-width: 100% !important;
        padding: 0 12px !important;
    }
    
    .upload-area,
    #acUploadZone {
        max-width: 100% !important;
        padding: 32px 20px !important;
    }
}

/* ============================================================ */
/* V23.0.0: SAMAKAN LEBAR PENGATURAN DENGAN UPLOAD AREA         */
/* ============================================================ */

/* 1. Di Desktop: Paksa semua elemen pengaturan selebar upload area */
@media (min-width: 1024px) {
    
    /* Container utama di halaman autoclip */
    main.container,
    .autoclip-main,
    .ac-container {
        max-width: 1000px !important;
        width: 100% !important;
        margin: 0 auto !important;
        padding: 0 20px !important;
    }

    /* Paksa semua direct child dari main container jadi 100% lebar */
    main.container > *,
    .autoclip-main > *,
    .ac-container > * {
        width: 100% !important;
        max-width: 100% !important;
        box-sizing: border-box !important;
    }

    /* Accordion & Settings Group */
    .ac-accordion,
    .ac-settings-group,
    .setting-group,
    details,
    .music-bg-container,
    .music-settings,
    .ac-music-box,
    .ac-card,
    .ac-panel {
        width: 100% !important;
        max-width: 1000px !important;
        margin-left: auto !important;
        margin-right: auto !important;
        box-sizing: border-box !important;
    }

    /* Elemen di dalam Music Background */
    .music-bg-container > *,
    .music-settings > * {
        max-width: 100% !important;
    }

    /* Slider & kontrol di dalamnya */
    input[type="range"] {
        width: 100% !important;
        height: 8px !important;
    }

    /* Tombol di dalam pengaturan */
    .music-actions .btn,
    .music-actions button {
        padding: 12px 24px !important;
        font-size: 0.9rem !important;
    }
}

/* 2. Upload Area: Samakan lebar di desktop */
@media (min-width: 1024px) {
    .upload-area,
    #acUploadZone,
    .ac-upload-zone {
        max-width: 1000px !important; /* Dari 800px ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ 1000px agar sama */
        width: 100% !important;
        margin: 30px auto !important;
        padding: 60px 40px !important;
        box-sizing: border-box !important;
    }
}

/* 3. Tablet: ukuran menengah (700px) */
@media (min-width: 768px) and (max-width: 1023px) {
    main.container,
    .autoclip-main,
    .ac-container {
        max-width: 750px !important;
    }

    .upload-area,
    #acUploadZone,
    .ac-accordion,
    .music-bg-container {
        max-width: 750px !important;
        width: 100% !important;
    }
}

/* 4. Mobile: full width (tidak berubah) */
@media (max-width: 767px) {
    main.container,
    .autoclip-main,
    .ac-container {
        max-width: 100% !important;
        padding: 0 12px !important;
    }
    
    .upload-area,
    #acUploadZone,
    .ac-accordion,
    .music-bg-container {
        max-width: 100% !important;
        width: 100% !important;
        box-sizing: border-box !important;
    }
}

/* Pengecualian: Biarkan elemen dekorasi kuning tetap lebar/full screen */
@media (min-width: 1024px) {
    /* Ganti .bg-kuning dengan class asli dari Inspect */
    .bg-kuning {
        max-width: 100vw !important; /* Paksa selebar layar */
        width: 100vw !important;
        position: absolute !important; /* Posisikan lepas dari container */
        left: 0 !important;
        right: 0 !important;
        margin: 0 !important;
    }
    
    /* Untuk tombol panah (Back to Top) */
    /* Ganti .tombol-panah dengan class asli dari Inspect */
    .tombol-panah {
        max-width: 50px !important; /* Ukuran tetap */
        width: 50px !important;
        position: fixed !important; /* Biar nempel di pojok kanan bawah */
        bottom: 30px !important;
        right: 30px !important;
    }
}

/* ============================================================ */
/* FIX: Kecualikan Dekorasi Kuning & Tombol Back-to-Top         */
/* ============================================================ */

/* 1. Paksa container utama kembali ke tengah (normal) */
main.container {
    position: relative !important; /* Agar dekorasi absolute bisa lepas */
}

/* 2. Kecualikan elemen dekorasi kuning dari aturan max-width */
/* Trik: cari elemen yang posisinya absolute/fixed di dalam container */
@media (min-width: 1024px) {
    
    /* Cari elemen dekoratif di bawah. 
       Kita gunakan selector atribut atau class umum untuk elemen dekor */
    main.container > div[style*="absolute"],
    main.container > div[style*="fixed"],
    main.container > .decor,
    main.container > .wave,
    main.container > .glow,
    main.container > .bg-curve {
        max-width: 100vw !important;
        width: 100vw !important;
        position: absolute !important;
        left: 50% !important;
        transform: translateX(-50%) !important; /* Paksa ke tengah layar */
        margin: 0 !important;
    }

    /* 3. Perbaiki tombol panah (Back to top) agar tetap kecil & di pojok */
    /* Kita targetkan class umum tombol back-to-top */
    #backToTop, 
    .back-to-top, 
    .scroll-to-top,
    button[aria-label*="top"],
    a[href="#top"] {
        max-width: 50px !important;
        width: 50px !important;
        height: 50px !important;
        position: fixed !important;
        bottom: 30px !important;
        right: 30px !important;
        left: auto !important;
        transform: none !important;
        z-index: 9999 !important;
    }
}
</style>



<link rel="stylesheet" href="assets/css/autoclip-timeline.css?v=<?= $autoclipCssVer ?>">

<link rel="stylesheet" href="assets/css/autoclip-music.css?v=<?= $autoclipCssVer ?? "1.0" ?>">

    <!-- V9.180.50: CULTURE_UI_CSS -->

    <link rel="stylesheet" href="assets/css/culture-ui.css?v=<?= time() ?>">



<main class="container" style="min-height: 70vh;">



    <!-- ============================================================ -->

    <!-- HERO                                                          -->

    <!-- ============================================================ -->

    <div class="autoclip-hero">

        <div class="autoclip-badge">

            <i class="fas fa-magic"></i> AI AUTO-CLIP GENERATOR

        </div>

        <h1>1 Video - Banyak Klip Siap Posting</h1>

        <p>Upload 1 video panjang, AI akan otomatis memotongnya menjadi beberapa klip pendek yang siap di-upload ke TikTok, Reels, atau Shorts. Deteksi topik otomatis + pilih momen paling menarik.</p>

    </div>



    <?php if (!$canUseAutoClip): ?>



        <!-- ============================================================ -->

        <!-- LOCK CARD (Free User)                                         -->

        <!-- ============================================================ -->

        <div class="ac-lock">

            <div class="ac-lock-icon">-</div>

            <h3>Fitur Premium</h3>

            <p>Auto-Clip Generator hanya tersedia untuk pengguna Pro & Business. Upgrade sekarang untuk akses unlimited + klip tanpa watermark.</p>

            <a href="harga.php" class="ac-lock-btn">

                <i class="fas fa-crown"></i> Upgrade ke Premium

            </a>

        </div>



    <?php else: ?>



        <!-- ============================================================ -->

        <!-- UPLOAD ZONE                                                   -->

        <!-- ============================================================ -->

<!-- V9.28.1: Banner inserted -->

        <?php if (!empty($isFreeUser)): ?>

        <div class="ac-free-tier-banner" id="acFreeBanner">

            <div class="ac-ftb-icon"><i class="fas fa-gift"></i></div>

            <div class="ac-ftb-content">

                <strong>Anda menggunakan versi GRATIS</strong>

                <div class="ac-ftb-info">

                    <span id="acFtQuotaText"><i class="fas fa-spinner fa-spin"></i> Cek kuota...</span>

                    <span class="ac-ftb-sep">&middot;</span>

                    <span><i class="fas fa-film"></i> Maks 3 klip</span>

                    <span class="ac-ftb-sep">&middot;</span>

                    <span><i class="fas fa-tv"></i> Maks 720p</span>

                    <span class="ac-ftb-sep">&middot;</span>

                    <span><i class="fas fa-clock"></i> Maks 5 menit</span>

                </div>

            </div>

            <a href="harga.php" class="ac-ftb-upgrade">

                <i class="fas fa-crown"></i> Upgrade Pro

            </a>

        </div>

        <?php endif; ?>



        <div class="ac-upload-zone" id="acUploadZone">

            <div class="ac-upload-icon">&#127916;</div>

            <div class="ac-upload-title">Tarik Video ke Sini atau Klik untuk Pilih</div>

            <div class="ac-upload-subtitle">Video panjang akan otomatis dipecah jadi klip pendek</div>

            <button class="ac-upload-btn" type="button" id="acPickBtn">

                <i class="fas fa-cloud-upload-alt"></i> Pilih Video

            </button>

            <div class="ac-upload-meta">MP4, MOV, AVI, MKV, WEBM &middot; Maks 500 MB</div>

            <input type="file" id="acFileInput" accept="video/*" style="display:none;">

        </div>



                <!-- ============================================================ -->

        <!-- V9.60.5: SETTINGS - CARD SYSTEM                              -->

        <!-- ============================================================ -->



        <!-- CARD 1: PENGATURAN DASAR -->

        <!-- V9.93.0: VIDEO PREVIEW ATAS - preview video setelah upload -->

        <div class="ac-video-preview-wrap" id="acVideoPreviewWrap" style="display:none;">

            <div class="ac-video-preview-head">

                <i class="fas fa-eye"></i>

                <span>Preview Video Anda</span>

                <button type="button" class="ac-video-preview-close" id="acVideoPreviewClose" title="Tutup preview">

                    <i class="fas fa-times"></i>

                </button>

            </div>

            <video id="acVideoPreview" controls preload="metadata" style="width:100%;max-height:60vh;background:#000;border-radius:12px;display:block;"></video>

        </div>



        <div class="ac-card ac-card--purple" id="acCardBasic" data-storage-key="acCardBasic">

            <div class="ac-card-header" data-toggle="acCardBasic">

                <div class="ac-card-header-left">

                    <i class="fas fa-sliders-h ac-card-header-icon"></i>

                    <span class="ac-card-header-title">PENGATURAN DASAR</span>

                    <span class="ac-card-header-sub">Jumlah klip, kualitas, format</span>

                </div>

                <div class="ac-card-header-right">

                    <i class="fas fa-chevron-down ac-card-chevron"></i>

                </div>

            </div>

            <div class="ac-card-body">

                <!-- V9.148.0: PRESET CEPAT -->

                <div id="acPresetQuick" style="margin-bottom:16px; padding:12px 14px; background:rgba(139,92,246,0.06); border:1px solid rgba(139,92,246,0.25); border-radius:12px;">

                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">

                        <label style="font-size:12px; color:#c4b5fd; font-weight:700; margin:0;">

                            <i class="fas fa-bolt"></i> Preset Cepat (1 klik)

                        </label>

                        <span style="font-size:10px; color:#94a3b8;">Setting otomatis</span>

                    </div>

                    <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:8px;">

                        <button type="button" class="ac-quick-preset" data-preset="tiktok" title="Optimasi untuk TikTok">

                            <span style="font-size:20px;"><i class="fa-brands fa-tiktok" style="font-size:20px; color:#fff;"></i></span>

                            <span style="font-size:10px; font-weight:700;">TikTok</span>

                            <span style="font-size:8px; color:#94a3b8; margin-top:2px;">9:16 &middot; 30s &middot; 3 klip</span>

                        </button>

                        <button type="button" class="ac-quick-preset" data-preset="reels" title="Optimasi untuk Instagram Reels">

                            <span style="font-size:20px;"><i class="fa-brands fa-instagram" style="font-size:20px; color:#fff;"></i></span>

                            <span style="font-size:10px; font-weight:700;">Reels</span>

                            <span style="font-size:8px; color:#94a3b8; margin-top:2px;">9:16 &middot; 60s &middot; 5 klip</span>

                        </button>

                        <button type="button" class="ac-quick-preset" data-preset="youtube" title="Optimasi untuk YouTube">

                            <span style="font-size:20px;"><i class="fa-brands fa-youtube" style="font-size:20px; color:#fff;"></i></span>

                            <span style="font-size:10px; font-weight:700;">YouTube</span>

                            <span style="font-size:8px; color:#94a3b8; margin-top:2px;">16:9 &middot; 60s+ &middot; 10 klip</span>

                        </button>

                        <button type="button" class="ac-quick-preset" data-preset="podcast" title="Optimasi untuk Podcast">

                            <span style="font-size:20px;"><i class="fa-solid fa-microphone" style="font-size:20px; color:#fff;"></i></span>

                            <span style="font-size:10px; font-weight:700;">Podcast</span>

                            <span style="font-size:8px; color:#94a3b8; margin-top:2px;">1:1 &middot; Audio &middot; 5 klip</span>

                        </button>

                    </div>

                    <div style="font-size:10px; color:#94a3b8; margin-top:10px; text-align:center;">

                        - Klik preset untuk apply otomatis - atau atur manual di bawah

                    </div>

                </div>



                <div class="ac-settings-grid">

                    <div class="ac-setting-item">

                        <label><i class="fas fa-film"></i> Jumlah Klip</label>

                        <select id="acTargetClips">

                            <option value="3">3 klip (cepat)</option>

                            <option value="5" selected>5 klip (rekomendasi)</option>

                            <option value="8">8 klip</option>

                            <option value="10">10 klip (maks)</option>

                        </select>

                    </div>

                    <div class="ac-setting-item">

                        <label><i class="fas fa-expand"></i> Kualitas</label>

                        <select id="acPreset">

                            <option value="1080p" selected>1080p Full HD</option>

                            <option value="720p">720p HD</option>

                        </select>

                    </div>

                    <div class="ac-setting-item">

                        <label><i class="fas fa-crop"></i> Format Video</label>

                        <select id="acAspectRatio">

                            <option value="vertical" selected>Vertical (9:16) - TikTok/Reels</option>

                            <option value="horizontal">Horizontal (16:9) - YouTube</option>

                            <option value="square">Square (1:1) - Feed</option>

                            <option value="auto">Auto (ikut sumber)</option>

                        </select>

                    </div>

                </div>

                <div style="margin-top:14px; display:flex; flex-wrap:wrap; gap:20px;">

                    <label class="ac-toggle-switch">

                        <input type="checkbox" id="acRemoveNoise" checked>

                        <span class="ac-toggle-slider"></span>

                        <span class="ac-toggle-label"><i class="fas fa-volume-mute"></i> Hapus Batuk/Klik</span>

                    </label>

                    <label class="ac-toggle-switch">

                        <input type="checkbox" id="acVerticalCrop">

                        <span class="ac-toggle-slider"></span>

                        <span class="ac-toggle-label"><i class="fas fa-crop-alt"></i> Vertical Crop</span>

                    </label>

                </div>



                <!-- V9.148.0: AUDIO PRO PANEL -->

                <div id="acAudioPro" style="margin-top:18px; padding:14px; background:rgba(34,197,94,0.06); border:1px solid rgba(34,197,94,0.25); border-radius:12px;">

                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">

                        <label style="font-size:12px; color:#86efac; font-weight:700; margin:0;">

                            <i class="fas fa-headphones"></i> AUDIO PRO

                        </label>

                        <span style="font-size:10px; color:#94a3b8;">Kualitas suara</span>

                    </div>



                    <!-- Volume Slider -->

                    <div style="margin-bottom:12px;">

                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">

                            <label style="font-size:11px; color:#cbd5e1;">

                                <i class="fas fa-volume-up"></i> Volume Original

                            </label>

                            <span id="acAudioVolumeVal" style="font-size:11px; color:#86efac; font-weight:700;">100%</span>

                        </div>

                        <input type="range" id="acAudioVolume" min="0" max="200" value="100" step="5"

                               style="width:100%; accent-color:#22c55e;">

                    </div>



                    <!-- Fade In/Out -->

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:12px;">

                        <div>

                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">

                                <label style="font-size:10px; color:#cbd5e1;">Fade In</label>

                                <span id="acAudioFadeInVal" style="font-size:10px; color:#86efac; font-weight:700;">0.0s</span>

                            </div>

                            <input type="range" id="acAudioFadeIn" min="0" max="3" value="0" step="0.1"

                                   style="width:100%; accent-color:#22c55e;">

                        </div>

                        <div>

                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">

                                <label style="font-size:10px; color:#cbd5e1;">Fade Out</label>

                                <span id="acAudioFadeOutVal" style="font-size:10px; color:#86efac; font-weight:700;">0.0s</span>

                            </div>

                            <input type="range" id="acAudioFadeOut" min="0" max="3" value="0" step="0.1"

                                   style="width:100%; accent-color:#22c55e;">

                        </div>

                    </div>



                    <!-- Toggles -->

                    <div style="display:flex; flex-wrap:wrap; gap:16px;">

                        <label class="ac-toggle-switch">

                            <input type="checkbox" id="acAudioNoiseReduction" checked>

                            <span class="ac-toggle-slider"></span>

                            <span class="ac-toggle-label" style="font-size:11px;">

                                <i class="fas fa-filter"></i> Noise Reduction

                            </span>

                        </label>

                        <label class="ac-toggle-switch">

                            <input type="checkbox" id="acAudioNormalize" checked>

                            <span class="ac-toggle-slider"></span>

                            <span class="ac-toggle-label" style="font-size:11px;">

                                <i class="fas fa-balance-scale"></i> Normalize (-16 LUFS)

                            </span>

                        </label>

                    </div>



                    <div style="font-size:10px; color:#94a3b8; margin-top:10px; text-align:center;">

                        <i class="fas fa-info-circle"></i> Setting ini berlaku untuk semua klip

                    </div>

                </div>

            </div>

        </div>



        <!-- CARD 2: SUBTITLE & TEKS -->

        <div class="ac-card ac-card--blue" id="acCardSubtitle" data-storage-key="acCardSubtitle">

            <div class="ac-card-header" data-toggle="acCardSubtitle">

                <div class="ac-card-header-left">

                    <i class="fas fa-closed-captioning ac-card-header-icon"></i>

                    <span class="ac-card-header-title">SUBTITLE & TEKS</span>

                    <span class="ac-card-header-sub">Gaya caption, judul, karaoke</span>

                </div>

                <div class="ac-card-header-right">

                    <i class="fas fa-chevron-down ac-card-chevron"></i>

                </div>

            </div>

            <div class="ac-card-body">

                <div class="ac-settings-grid">

                    <div class="ac-setting-item">

                        <label><i class="fas fa-font"></i> Gaya Subtitle</label>

                        <select id="acCaptionStyle">

                            <option value="clean" selected>Clean Pro - Putih bersih</option>

                            <option value="bold">Bold Impact - Tebal</option>

                            <option value="neon">Neon Glow - Menyala</option>

                            <option value="karaoke">Karaoke - Word by Word</option>

                            <option value="emoji">- Fun with Emoji - Auto emoji</option>

                        </select>

                    </div>

                    <div class="ac-setting-item">

                        <label><i class="fas fa-heading"></i> Judul Klip (Opsional)</label>

                        <input type="text" id="acTitleInput" placeholder="Contoh: Rahasia Sukses...">

                    </div>

                </div>



                

                <!-- V9.182.0: AI_HOOK_GEN_BUTTON -->

                <div style="margin-top:14px; padding:14px; background:linear-gradient(135deg,rgba(139,92,246,0.08),rgba(236,72,153,0.08)); border:1px solid rgba(139,92,246,0.3); border-radius:12px;">

                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">

                        <label style="font-size:13px; color:#c4b5fd; font-weight:600; margin:0;">

                            <i class="fas fa-magic"></i> AI Hook Generator

                            <span style="font-size:9px; background:linear-gradient(135deg,#8b5cf6,#ec4899); color:#fff; padding:2px 6px; border-radius:8px; margin-left:6px;">BARU</span>

                        </label>

                    </div>

                    <?php if ($isPremium || $isAdminUser): ?>
                    <button type="button" id="acHookGenBtn" onclick="window.CliporaHookGen && window.CliporaHookGen.generate()" style="width:100%; padding:12px 16px; background:linear-gradient(135deg,#8b5cf6,#ec4899); color:#fff; border:none; border-radius:10px; font-size:13px; font-weight:700; cursor:pointer; transition:transform 0.15s; box-shadow:0 4px 12px rgba(139,92,246,0.3);">
                        <i class="fas fa-magic"></i> Generate Judul + Hook + Caption
                    </button>
                    <?php else: ?>
                    <a href="harga.php" style="display:flex; align-items:center; justify-content:center; gap:8px; width:100%; padding:12px 16px; background:rgba(107,114,128,0.2); color:#94a3b8; border:1px dashed rgba(148,163,184,0.4); border-radius:10px; font-size:13px; font-weight:700; text-decoration:none; cursor:pointer;">
                        <i class="fas fa-lock"></i> Pro Only ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â Upgrade untuk Akses
                    </a>
                    <?php endif; ?>

                    <div style="font-size:11px; color:#94a3b8; margin-top:8px; text-align:center; line-height:1.4;">

                        Dapat 10 judul, 5 hook, 3 caption dari AI Gemini

                    </div>

                </div>





                <!-- V9.183.0: AI_DUBBING_BUTTON -->

                <div style="margin-top:14px; padding:14px; background:linear-gradient(135deg,rgba(59,130,246,0.08),rgba(16,185,129,0.08)); border:1px solid rgba(59,130,246,0.3); border-radius:12px;">

                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">

                        <label style="font-size:13px; color:#93c5fd; font-weight:600; margin:0;">

                            <i class="fas fa-microphone"></i> AI Dubbing Bahasa Daerah

                            <span style="font-size:9px; background:linear-gradient(135deg,#3b82f6,#10b981); color:#fff; padding:2px 6px; border-radius:8px; margin-left:6px;">BARU</span>

                        </label>

                    </div>

                    <?php if ($isPremium || $isAdminUser): ?>
                    <button type="button" id="acDubbingBtn" onclick="window.CliporaDubbing && window.CliporaDubbing.openModal()" style="width:100%; padding:12px 16px; background:linear-gradient(135deg,#3b82f6,#10b981); color:#fff; border:none; border-radius:10px; font-size:13px; font-weight:700; cursor:pointer; transition:transform 0.15s; box-shadow:0 4px 12px rgba(59,130,246,0.3);">
                        <i class="fas fa-microphone"></i> Generate Dubbing Otomatis
                    </button>
                    <?php else: ?>
                    <a href="harga.php" style="display:flex; align-items:center; justify-content:center; gap:8px; width:100%; padding:12px 16px; background:rgba(107,114,128,0.2); color:#94a3b8; border:1px dashed rgba(148,163,184,0.4); border-radius:10px; font-size:13px; font-weight:700; text-decoration:none; cursor:pointer;">
                        <i class="fas fa-lock"></i> Pro Only ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â Upgrade untuk Akses
                    </a>
                    <?php endif; ?>

                    <div style="font-size:11px; color:#94a3b8; margin-top:8px; text-align:center; line-height:1.4;">

                        Ubah audio video ke bahasa daerah (Jawa, Sunda, Melayu, dll)

                    </div>

                </div>



<!-- V9.146.0: SUBTITLE STUDIO - CUSTOM OVERRIDE -->

                <div style="margin-top:14px; padding:12px 14px; background:rgba(59,130,246,0.06); border:1px solid rgba(59,130,246,0.25); border-radius:12px;">

                    <div id="acCustomSubToggle" style="display:flex; justify-content:space-between; align-items:center; cursor:pointer; user-select:none;">

                        <label style="font-size:13px; color:#93c5fd; font-weight:600; cursor:pointer; margin:0;">

                            <i class="fas fa-sliders-h"></i> Custom Subtitle (Advanced)

                        </label>

                        <i class="fas fa-chevron-down" id="acCustomSubChevron" style="color:#93c5fd; font-size:11px; transition:transform 0.2s;"></i>

                    </div>

                    

                    <div id="acCustomSubPanel" style="display:none; margin-top:14px;">

                        

                        <!-- Font + Size Row -->

                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:12px;">

                            <div>

                                <label style="font-size:11px; color:#94a3b8; font-weight:600; display:block; margin-bottom:5px;">- Font</label>

                                <select id="acCustomFont" style="width:100%; padding:8px 10px; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); border-radius:8px; color:#e8e8ef; font-size:12px; font-family:inherit; cursor:pointer; box-sizing:border-box;">

                                    <optgroup label=" Default">

                                        <option value="Rubik">Rubik (Default)</option>

                                    </optgroup>

                                    <optgroup label=" Trending 2026">

                                        <option value="Montserrat">Montserrat Bold (Modern)</option>

                                        <option value="MontserratBlack">Montserrat Black (Ultra Bold)</option>

                                        <option value="ArchivoBlack">Archivo Black (Ultra Bold)</option>

                                        <option value="Inter">Inter (Clean Modern)</option>

                                        <option value="Righteous">Righteous (Playful)</option>

                                    </optgroup>

                                    <optgroup label=" Bold Style">

                                        <option value="Anton">Anton (Bold Kuat)</option>

                                        <option value="BebasNeue">Bebas Neue</option>

                                        <option value="Poppins">Poppins Bold</option>

                                    </optgroup>

                                </select>

                            </div>

                            <div>

                                <label style="font-size:11px; color:#94a3b8; font-weight:600; display:flex; justify-content:space-between; margin-bottom:5px;">

                                    <span>- Ukuran</span>

                                    <span id="acCustomSizeVal" style="color:#93c5fd;">85px</span>

                                </label>

                                <input type="range" id="acCustomSize" min="50" max="120" value="85" step="5" style="width:100%; accent-color:#3b82f6; margin-top:8px;">

                            </div>

                        </div>

                        

                        <!-- Color Row -->

                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:12px;">

                            <div>

                                <label style="font-size:11px; color:#94a3b8; font-weight:600; display:block; margin-bottom:5px;">&#128640; Warna Teks</label>

                                <div style="display:flex; gap:6px; align-items:center;">

                                    <input type="color" id="acCustomColor" value="#FFFFFF" style="width:36px; height:32px; border:none; border-radius:6px; cursor:pointer; background:transparent;">

                                    <span id="acCustomColorHex" style="font-size:11px; color:#cbd5e1; font-family:monospace;">#FFFFFF</span>

                                </div>

                            </div>

                            <div>

                                <label style="font-size:11px; color:#94a3b8; font-weight:600; display:block; margin-bottom:5px;">- Warna Outline</label>

                                <div style="display:flex; gap:6px; align-items:center;">

                                    <input type="color" id="acCustomOutlineColor" value="#000000" style="width:36px; height:32px; border:none; border-radius:6px; cursor:pointer; background:transparent;">

                                    <span id="acCustomOutlineHex" style="font-size:11px; color:#cbd5e1; font-family:monospace;">#000000</span>

                                </div>

                            </div>

                        </div>

                        

                        <!-- Outline Width + Position -->

                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:12px;">

                            <div>

                                <label style="font-size:11px; color:#94a3b8; font-weight:600; display:flex; justify-content:space-between; margin-bottom:5px;">

                                    <span>- Ketebalan Outline</span>

                                    <span id="acCustomOutlineVal" style="color:#93c5fd;">3px</span>

                                </label>

                                <input type="range" id="acCustomOutlineWidth" min="0" max="10" value="3" step="1" style="width:100%; accent-color:#3b82f6; margin-top:8px;">

                            </div>

                            <div>

                                <label style="font-size:11px; color:#94a3b8; font-weight:600; display:block; margin-bottom:5px;">- Posisi</label>

                                <select id="acCustomPosition" style="width:100%; padding:8px 10px; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); border-radius:8px; color:#e8e8ef; font-size:12px; font-family:inherit; cursor:pointer; box-sizing:border-box;">

                                    <option value="bottom" selected>- Bawah (Default)</option>

                                    <option value="middle">- Tengah</option>

                                    <option value="top">- Atas</option>

                                </select>

                            </div>

                        </div>

                        

                        <!-- Background Box -->

                        <div style="padding-top:10px; border-top:1px solid rgba(255,255,255,0.08);">

                            <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:12px; color:#cbd5e1;">

                                <input type="checkbox" id="acCustomBgEnabled" style="width:16px; height:16px; accent-color:#3b82f6; cursor:pointer;">

                                <span>&#127919; Background Box (kotak di belakang teks)</span>

                            </label>

                            

                            <div id="acCustomBgOptions" style="display:none; margin-top:10px; padding:10px; background:rgba(0,0,0,0.2); border-radius:8px;">

                                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">

                                    <div>

                                        <label style="font-size:11px; color:#94a3b8; font-weight:600; display:block; margin-bottom:5px;">Warna BG</label>

                                        <div style="display:flex; gap:6px; align-items:center;">

                                            <input type="color" id="acCustomBgColor" value="#000000" style="width:36px; height:32px; border:none; border-radius:6px; cursor:pointer; background:transparent;">

                                            <span id="acCustomBgColorHex" style="font-size:11px; color:#cbd5e1; font-family:monospace;">#000000</span>

                                        </div>

                                    </div>

                                    <div>

                                        <label style="font-size:11px; color:#94a3b8; font-weight:600; display:flex; justify-content:space-between; margin-bottom:5px;">

                                            <span>Transparansi</span>

                                            <span id="acCustomBgOpacityVal" style="color:#93c5fd;">50%</span>

                                        </label>

                                        <input type="range" id="acCustomBgOpacity" min="0" max="100" value="50" step="5" style="width:100%; accent-color:#3b82f6; margin-top:8px;">

                                    </div>

                                </div>

                            </div>

                        </div>

                        

                        <!-- Reset Button -->

                        <button type="button" id="acCustomSubReset" style="width:100%; margin-top:12px; padding:8px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:8px; color:#94a3b8; font-size:12px; font-weight:600; cursor:pointer; font-family:inherit;">

                            <i class="fas fa-undo"></i> Reset Custom

                        </button>

                        

                    </div>

                </div>

                <div style="margin-top:14px;">

                    <label class="ac-toggle-switch">

                        <input type="checkbox" id="acKaraokeToggle">

                        <span class="ac-toggle-slider"></span>

                        <span class="ac-toggle-label">

                            <i class="fas fa-microphone-alt"></i> Aktifkan Word-by-Word (Karaoke)

                            <span class="ac-card-badge ac-card-badge--new">NEW</span>

                        </span>

                    </label>

                </div>

            </div>

        </div>



        <!-- ============================================================ -->

        <!-- V9.61.0: MUSIC CARD (pink)                                    -->

        <!-- ============================================================ -->

        <div class="ac-card ac-card--pink collapsed" id="acCardMusic" data-storage-key="acCardMusic">

            <div class="ac-card-header" data-toggle="acCardMusic">

                <div class="ac-card-header-left">

                    <i class="fas fa-music ac-card-header-icon"></i>

                    <span class="ac-card-header-title">MUSIC BACKGROUND</span>

                    <span class="ac-card-header-sub">Tambah backsound otomatis</span>

                </div>

                <div class="ac-card-header-right">

                    <label class="ac-toggle-switch" onclick="event.stopPropagation()">

                        <input type="checkbox" id="acMusicEnabled">

                        <span class="ac-toggle-slider"></span>

                    </label>

                    <span class="ac-card-badge ac-card-badge--off" id="acMusicBadge">OFF</span>

                    <i class="fas fa-chevron-down ac-card-chevron"></i>

                </div>

            </div>

            <div class="ac-card-body">

                <!-- V9.136.0: MUSIC SOURCE TABS -->

                <div class="ac-music-tabs" id="acMusicTabs">

                    <button type="button" class="ac-music-tab ac-music-tab--active" data-tab="library">

                        <i class="fas fa-layer-group"></i> Library

                    </button>

                    <button type="button" class="ac-music-tab" data-tab="upload">

                        <i class="fas fa-cloud-upload-alt"></i> Upload Sendiri

                    </button>

                </div>



                <!-- TAB 1: LIBRARY (existing content) -->

                <div class="ac-music-tab-content ac-music-tab-content--active" data-tab="library" id="acMusicLibraryTab">

                <div class="ac-settings-grid ac-settings-grid--compact">

                    <div class="ac-setting-item">

                        <label><i class="fas fa-filter"></i> Filter Mood</label>

                        <select id="acMusicMoodFilter">

                            <option value="">Semua Mood</option>

                            <option value="energetic">Energetic</option>

                            <option value="chill">Chill / Lofi</option>

                            <option value="funny">Funny</option>

                            <option value="dramatic">&#127916; Cinematic</option>

                            <option value="happy">Happy</option>

                        </select>

                    </div>

                    <div class="ac-setting-item" style="grid-column: span 2;">

                        <label><i class="fas fa-headphones"></i> Pilih Lagu</label>

                        <select id="acMusicTrackSelect">

                            <option value="">-- Loading library... --</option>

                        </select>

                        <!-- V9.125.0: MUSIC UI ENHANCE - Info lagu compact -->

                        <div id="acMusicInfoBox" style="display:none; margin-top:10px; padding:10px 14px; background:rgba(236,72,153,0.08); border:1px solid rgba(236,72,153,0.2); border-radius:8px; font-size:12px; color:#a1a1aa;">

                            <div style="display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap;">

                                <div>

                                    <strong id="acMusicInfoName" style="color:#f472b6; font-size:13px;">-</strong>

                                    <span id="acMusicInfoMeta" style="margin-left:8px; color:#71717a;">-</span>

                                </div>

                                <button type="button" id="acMusicSampleBtn" style="padding:4px 10px; background:rgba(236,72,153,0.15); color:#f472b6; border:1px solid rgba(236,72,153,0.3); border-radius:6px; font-size:11px; cursor:pointer;">

                                    <i class="fas fa-play"></i> Sample

                                </button>

                            </div>

                        </div>

                    </div>

                </div>

                </div>

                </div><!-- /acMusicLibraryTab -->



                <!-- TAB 2: UPLOAD SENDIRI -->

                <div class="ac-music-tab-content" data-tab="upload" id="acMusicUploadTab" style="display:none;">

                    <div style="padding:14px; background:rgba(139,92,246,0.06); border:1px dashed rgba(139,92,246,0.3); border-radius:10px; text-align:center; margin-bottom:14px;">

                        <div style="font-size:32px; color:#8b5cf6; margin-bottom:8px;">

                            <i class="fas fa-cloud-upload-alt"></i>

                        </div>

                        <div style="font-size:14px; font-weight:600; color:#e8e8ef; margin-bottom:4px;">

                            Upload Musik Anda Sendiri

                        </div>

                        <div style="font-size:11px; color:#94a3b8; margin-bottom:12px;">

                            Format: MP3, WAV, M4A, OGG (max 10 MB)

                        </div>

                        <input type="file" id="acMusicUploadInput" accept=".mp3,.wav,.m4a,.ogg" style="display:none;">

                        <button type="button" id="acMusicUploadBtn" style="padding:10px 24px; background:linear-gradient(135deg, #8b5cf6, #6d28d9); color:#fff; border:none; border-radius:8px; font-size:13px; font-weight:600; cursor:pointer; font-family:inherit;">

                            <i class="fas fa-plus"></i> Pilih File Musik

                        </button>

                    </div>



                    <!-- V9.145.0: STORAGE INDICATOR -->

                    <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 12px; background:rgba(139,92,246,0.06); border-radius:8px; margin-bottom:10px;">

                        <div style="display:flex; align-items:center; gap:8px; font-size:11px; color:#94a3b8;">

                            <i class="fas fa-database" style="color:#8b5cf6;"></i>

                            <span>Storage:</span>

                            <span id="acMusicStorageUsed" style="color:#c4b5fd; font-weight:700;">0 MB</span>

                            <span>/</span>

                            <span id="acMusicStorageLimit" style="color:#94a3b8;">50 MB</span>

                        </div>

                        <div style="height:4px; width:100px; background:rgba(255,255,255,0.08); border-radius:2px; overflow:hidden;">

                            <div id="acMusicStorageBar" style="height:100%; background:linear-gradient(90deg, #8b5cf6, #6d28d9); width:0%; transition:width 0.3s;"></div>

                        </div>

                    </div>



                    <!-- V9.145.0: SEARCH + SORT -->

                    <div style="display:flex; gap:8px; margin-bottom:10px;">

                        <div style="flex:1; position:relative;">

                            <input type="text" id="acMusicSearchInput" 

                                placeholder="Cari musik..."

                                style="width:100%; padding:8px 12px 8px 32px; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); border-radius:8px; color:#e8e8ef; font-size:11px; box-sizing:border-box; font-family:inherit;">

                            <i class="fas fa-search" style="position:absolute; left:10px; top:50%; transform:translateY(-50%); color:#64748b; font-size:10px; pointer-events:none;"></i>

                        </div>

                        <select id="acMusicSortSelect" style="padding:8px 10px; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); border-radius:8px; color:#e8e8ef; font-size:11px; font-family:inherit; cursor:pointer;">

                            <option value="date_desc">Terbaru</option>

                            <option value="date_asc">Terlama</option>

                            <option value="name_asc">Nama A-Z</option>

                            <option value="name_desc">Nama Z-A</option>

                            <option value="duration_desc">Terpanjang</option>

                            <option value="duration_asc">Terpendek</option>

                        </select>

                    </div>



                    <!-- User music list -->

                    <div style="margin-bottom:8px; display:flex; justify-content:space-between; align-items:center;">

                        <label style="font-size:12px; color:#94a3b8; font-weight:600;">

                            <i class="fas fa-music"></i> Musik Anda (<span id="acMusicUploadCount">0</span>)

                        </label>

                        <button type="button" id="acMusicRefreshBtn" style="background:transparent; border:none; color:#8b5cf6; font-size:11px; cursor:pointer;">

                            <i class="fas fa-sync-alt"></i> Refresh

                        </button>

                    </div>

                    <div id="acMusicUploadList" style="display:flex; flex-direction:column; gap:8px; max-height:200px; overflow-y:auto;">

                        <div style="padding:20px; text-align:center; color:#64748b; font-size:12px; background:rgba(255,255,255,0.02); border-radius:8px;">

                            <i class="fas fa-spinner fa-spin"></i> Memuat...

                        </div>

                    </div>



                    <!-- V9.137.0: MODAL UPLOAD MUSIK -->

                    <div id="acMusicUploadModal" style="display:none; position:fixed; inset:0; z-index:999999; background:rgba(0,0,0,0.8); backdrop-filter:blur(6px); align-items:center; justify-content:center; padding:20px;">

                        <div style="background:linear-gradient(135deg,#1a1a2e,#0f0f1a); border:1px solid rgba(236,72,153,0.3); border-radius:16px; padding:24px; max-width:440px; width:100%; box-shadow:0 24px 64px rgba(0,0,0,0.7);">

                            

                            <!-- Header -->

                            <div style="display:flex; align-items:center; gap:12px; margin-bottom:20px;">

                                <div style="width:44px; height:44px; border-radius:12px; background:linear-gradient(135deg,#8b5cf6,#6d28d9); display:flex; align-items:center; justify-content:center; color:#fff; font-size:18px; flex-shrink:0;">

                                    <i class="fas fa-cloud-upload-alt"></i>

                                </div>

                                <div style="flex:1; min-width:0;">

                                    <div style="font-size:15px; font-weight:700; color:#e8e8ef;">Upload Musik</div>

                                    <div style="font-size:11px; color:#94a3b8; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" id="acMusicUploadModalFile">-</div>

                                </div>

                            </div>

                            

                            <!-- Field: Nama -->

                            <label style="display:block; font-size:12px; color:#94a3b8; font-weight:600; margin-bottom:6px;">

                                - Nama Musik

                            </label>

                            <input type="text" id="acMusicUploadModalName" 

                                style="width:100%; padding:11px 14px; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#e8e8ef; font-size:13px; box-sizing:border-box; font-family:inherit;"

                                placeholder="Contoh: Lofi Chill Beats"

                                maxlength="100">

                            

                            <!-- Field: Mood -->

                            <label style="display:block; font-size:12px; color:#94a3b8; font-weight:600; margin:14px 0 6px 0;">

                                - Mood

                            </label>

                            <select id="acMusicUploadModalMood" 

                                style="width:100%; padding:11px 14px; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#e8e8ef; font-size:13px; box-sizing:border-box; font-family:inherit; cursor:pointer;">

                                <option value="general">General</option>

                                <option value="energetic">Energetic</option>

                                <option value="chill">Chill / Lofi</option>

                                <option value="funny">Funny</option>

                                <option value="dramatic">&#127916; Cinematic</option>

                                <option value="happy">Happy</option>

                            </select>

                            

                            <!-- Info -->

                            <div style="margin-top:14px; padding:10px 12px; background:rgba(139,92,246,0.08); border:1px solid rgba(139,92,246,0.2); border-radius:8px; font-size:11px; color:#94a3b8;">

                                - <strong style="color:#c4b5fd;">Info:</strong> Musik akan tersimpan di library Anda dan bisa dipakai untuk semua project.

                            </div>

                            

                            <!-- Buttons -->

                            <div style="display:flex; gap:10px; margin-top:20px;">

                                <button type="button" id="acMusicUploadModalCancel" 

                                    style="flex:1; padding:12px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#cbd5e1; font-size:13px; font-weight:600; cursor:pointer; font-family:inherit; transition:all 0.2s;">

                                    Batal

                                </button>

                                <button type="button" id="acMusicUploadModalConfirm" 

                                    style="flex:1; padding:12px; background:linear-gradient(135deg,#8b5cf6,#6d28d9); border:none; border-radius:10px; color:#fff; font-size:13px; font-weight:700; cursor:pointer; font-family:inherit; transition:all 0.2s; box-shadow:0 4px 16px rgba(139,92,246,0.3);">

                                    <i class="fas fa-cloud-upload-alt"></i> Upload

                                </button>

                            </div>

                        </div>

                    </div>



                    <div id="acMusicUploadStatus" style="font-size:11px; color:#94a3b8; margin-top:10px; text-align:center; min-height:16px;"></div>

                </div>



                <div class="ac-settings-grid ac-settings-grid--compact" style="margin-top:14px;">

                    <div class="ac-setting-item">

                        <label><i class="fas fa-volume-up"></i> Volume BGM: <span id="acMusicVolumeLabel">30%</span></label>

                        <input type="range" id="acMusicVolume" min="0" max="100" value="30"

                               style="width:100%; accent-color:#ec4899;">

                        <!-- V9.125.0: Preset volume cepat -->
                
                        <!-- V9.125.2: FIX PRESET WRAP -->

                        <div style="display:flex; gap:4px; margin-top:8px; flex-wrap:nowrap;">

                            <button type="button" class="ac-vol-preset" data-vol="10" style="flex:1; padding:3px 4px; background:rgba(236,72,153,0.1); color:#f472b6; border:1px solid rgba(236,72,153,0.2); border-radius:5px; font-size:9px; cursor:pointer; text-align:center;">10%</button>

                            <button type="button" class="ac-vol-preset" data-vol="25" style="flex:1; padding:3px 4px; background:rgba(236,72,153,0.1); color:#f472b6; border:1px solid rgba(236,72,153,0.2); border-radius:5px; font-size:9px; cursor:pointer; text-align:center;">25%</button>

                            <button type="button" class="ac-vol-preset" data-vol="50" style="flex:1; padding:3px 4px; background:rgba(236,72,153,0.1); color:#f472b6; border:1px solid rgba(236,72,153,0.2); border-radius:5px; font-size:9px; cursor:pointer; text-align:center;">50%</button>

                            <button type="button" class="ac-vol-preset" data-vol="75" style="flex:1; padding:3px 4px; background:rgba(236,72,153,0.1); color:#f472b6; border:1px solid rgba(236,72,153,0.2); border-radius:5px; font-size:9px; cursor:pointer; text-align:center;">75%</button>

                            <button type="button" class="ac-vol-preset" data-vol="100" style="flex:1; padding:3px 4px; background:rgba(236,72,153,0.1); color:#f472b6; border:1px solid rgba(236,72,153,0.2); border-radius:5px; font-size:9px; cursor:pointer; text-align:center;">100%</button>

                        </div>

                    </div>

                    <!-- V9.70.0: CAPCUT FADE - slider 0-10s + visual curve -->

                    <div class="ac-setting-item ac-fade-item">

                        <label>

                            <i class="fas fa-music"></i> Fade In

                            <span id="acMusicFadeInLabel" class="ac-fade-label">1.0s</span>

                        </label>

                        <div class="ac-fade-wrapper">

                            <input type="range" id="acMusicFadeIn" min="0" max="10" step="0.1" value="1.0"

                                   class="ac-fade-slider">

                            <svg class="ac-fade-curve" viewBox="0 0 100 20" preserveAspectRatio="none">

                                <path id="acMusicFadeInCurve" class="ac-fade-path" d="M 0 20 Q 10 0 20 0 L 100 0" />

                            </svg>

                        </div>

                    </div>

                    <div class="ac-setting-item ac-fade-item">

                        <label>

                            <i class="fas fa-music"></i> Fade Out

                            <span id="acMusicFadeOutLabel" class="ac-fade-label">1.5s</span>

                        </label>

                        <div class="ac-fade-wrapper">

                            <input type="range" id="acMusicFadeOut" min="0" max="10" step="0.1" value="1.5"

                                   class="ac-fade-slider">

                            <svg class="ac-fade-curve" viewBox="0 0 100 20" preserveAspectRatio="none">

                                <path id="acMusicFadeOutCurve" class="ac-fade-path" d="M 0 0 L 80 0 Q 90 0 100 20" />

                            </svg>

                        </div>

                    </div>

                </div>

                <div style="margin-top:14px; display:flex; flex-wrap:wrap; gap:18px; align-items:center;">

                    <label class="ac-toggle-switch">

                        <input type="checkbox" id="acMusicDuck" checked>

                        <span class="ac-toggle-slider"></span>

                        <span class="ac-toggle-label" title="Turunkan volume BGM otomatis saat ada voice over">

                            <i class="fas fa-volume-down"></i> Ducking Audio

                        </span>

                    </label>

                </div>

                <div style="margin-top:16px; display:flex; gap:10px; flex-wrap:wrap; align-items:center;">

                    <button type="button" class="ac-umkm-btn" id="acMusicPreviewBtn" style="background:rgba(236,72,153,0.15); color:#f472b6; border:1px solid rgba(236,72,153,0.3);">

                        <i class="fas fa-play"></i> Preview

                    </button>

                    <button type="button" class="ac-umkm-btn ac-umkm-btn-primary" id="acMusicSaveBtn" style="background:linear-gradient(135deg, #ec4899, #be185d);">

                        <i class="fas fa-save"></i> Simpan Config

                    </button>

                    <button type="button" class="ac-umkm-btn ac-umkm-btn-secondary" id="acMusicResetBtn">

                        <i class="fas fa-undo"></i> Reset

                    </button>

                    <span class="ac-umkm-status" id="acMusicStatus"></span>

                </div>

            </div>

        </div>



        <!-- V9.102.0: TIMELINE AUTOCLIP - timeline klip setelah analyze selesai -->

        <div id="acTimelineEditor" style="display:none;">

            <div class="tl-container active">

                <!-- Header -->

                <div class="tl-header">

                    <div class="tl-header-left">

                        <h2><i class="fas fa-film"></i> Edit Klip Anda</h2>

                        <div class="tl-header-meta" id="tlHeaderMeta">Memuat...</div>

                    </div>

                    <div class="tl-header-actions">

                        <button type="button" class="tl-btn tl-btn-secondary" id="tlResetBtn2">

                            <i class="fas fa-undo"></i> <span>Reset ke AI</span>

                        </button>

                        <button type="button" class="tl-btn tl-btn-secondary" id="tlNewVideoBtn">

                            <i class="fas fa-plus"></i> <span>Video Baru</span>

                        </button>

                    </div>

                </div>



                <!-- Video Player -->

                <div class="tl-preview">

                    <video id="tlVideo" controls preload="metadata" playsinline></video>

                    <div class="tl-preview-controls">

                        <button type="button" class="tl-preview-btn" id="tlPreviewPlay" title="Play/Pause">

                            <i class="fas fa-play"></i>

                        </button>

                        <button type="button" class="tl-preview-btn" id="tlPreviewMute" title="Mute">

                            <i class="fas fa-volume-up"></i>

                        </button>

                        <span class="tl-preview-time" id="tlPreviewTime">00:00 / 00:00</span>

                        <button type="button" class="tl-preview-btn" id="tlFullscreenBtn" title="Fullscreen">

                            <i class="fas fa-expand"></i>

                        </button>

                    </div>



        <!-- V9.175.0: RETENTION_HEATMAP_UI -->

        <div id="acRetentionPanel" class="ac-retention-panel" style="display:none;">

            <div class="ac-retention-header">

                <div class="ac-retention-title"><i class="fas fa-chart-line"></i> Retention Heatmap</div>

                <div style="display:flex;align-items:center;gap:8px;">

                    <span id="acRetentionScore" class="ac-retention-score">-</span>

                    <span id="acRetentionVirality" class="ac-retention-virality">-</span>

                </div>

            </div>

            <div id="acRetentionLoading" class="ac-retention-loading"><i class="fas fa-spinner fa-spin"></i> Menganalisis retention...</div>

            <div id="acRetentionContent" style="display:none;">

                <div class="ac-retention-heatmap" id="acRetentionHeatmap"></div>

                <div class="ac-retention-legend">

                    <div class="ac-retention-legend-item"><div class="ac-retention-legend-dot" style="background:#22c55e;"></div><span>Peak (9-10)</span></div>

                    <div class="ac-retention-legend-item"><div class="ac-retention-legend-dot" style="background:#84cc16;"></div><span>Bagus (7-8)</span></div>

                    <div class="ac-retention-legend-item"><div class="ac-retention-legend-dot" style="background:#f59e0b;"></div><span>Sedang (5-6)</span></div>

                    <div class="ac-retention-legend-item"><div class="ac-retention-legend-dot" style="background:#ef4444;"></div><span>Drop (0-4)</span></div>

                </div>

                <div id="acRetentionDrops" class="ac-retention-drops" style="display:none;">

                    <div class="ac-retention-drops-title"><i class="fas fa-exclamation-triangle"></i> Drop Points</div>

                    <div id="acRetentionDropsList"></div>

                </div>

                <div id="acRetentionSuggestions" class="ac-retention-suggestions" style="display:none;">

                    <div class="ac-retention-suggestions-title"><i class="fas fa-magic"></i> Saran Optimasi</div>

                    <div id="acRetentionSuggestionsList"></div>

                </div>



                <!-- V9.178.0: AUTO_OPTIMIZE_BTN -->

                <button type="button" class="ac-auto-optimize-btn" id="acAutoOptimizeBtn" style="display:none;">

                    <i class="fas fa-wand-magic-sparkles"></i>

                    <span>&#127916; Auto-Optimize Klip Ini</span>

                </button>



                <div class="ac-auto-progress" id="acAutoProgress">

                    <div class="ac-auto-progress-bar">

                        <div class="ac-auto-progress-fill" id="acAutoProgressFill"></div>

                    </div>

                    <div class="ac-auto-progress-text" id="acAutoProgressText">Memproses...</div>

                </div>

            </div>

        </div>



        <!-- V9.180.50: CULTURE_UI_AUTOCLIP -->

        <div id="acCultureContainer" class="ac-culture-wrapper"></div>



                    <div class="tl-preview-info" id="tlPreviewInfo">Klik klip untuk preview</div>

                </div>



                <!-- Timeline Klip -->

                <div class="tl-section">

                    <div class="tl-section-head">

                        <h3><i class="fas fa-stream"></i> Timeline Klip</h3>

                        <span class="tl-section-hint">Drag untuk reorder, klik untuk preview</span>

                    </div>

                    <div class="tl-timeline" id="tlTimeline">

                        <div class="tl-empty" id="tlTimelineEmpty">

                            <i class="fas fa-inbox"></i>

                            <p>Belum ada klip di timeline</p>

                        </div>

                    </div>

                </div>



                <!-- Pool Klip -->

                <div class="tl-section">

                    <div class="tl-section-head">

                        <h3><i class="fas fa-archive"></i> Klip Belum Terpakai</h3>

                        <span class="tl-pool-count" id="tlPoolCount">Pool (0)</span>

                    </div>

                    <div class="tl-pool" id="tlPool">

                        <div class="tl-empty" id="tlPoolEmpty">

                            <i class="fas fa-check-circle"></i>

                            <p>Semua klip sudah di timeline</p>

                        </div>

                    </div>

                </div>



                <!-- Action Buttons -->

                <div class="tl-actions">

                    <button type="button" class="tl-btn tl-btn-primary" id="tlRenderAllBtn">

                        <i class="fas fa-magic"></i> <span>Render Semua Klip</span>

                    </button>

                    <button type="button" class="tl-btn tl-btn-secondary" id="tlRenderSelectedBtn" disabled>

                        <i class="fas fa-check-square"></i> <span>Render Terpilih</span>

                    </button>

                    <button type="button" class="tl-btn tl-btn-secondary" id="tlDownloadZipBtn" disabled>

                        <i class="fas fa-download"></i> <span>Download ZIP</span>

                    </button>

                </div>



                <!-- Render Progress -->

                <div class="tl-render-progress" id="tlRenderProgress" style="display:none;">

                    <div class="tl-rp-head">

                        <span class="tl-rp-counter" id="tlRpCounter">0/0</span>

                        <span class="tl-rp-percent" id="tlRpPercent">0%</span>

                    </div>

                    <div class="tl-rp-bar">

                        <div class="tl-rp-fill" id="tlRpFill"></div>

                    </div>

                    <div class="tl-rp-log" id="tlRpLog"></div>

                </div>



                <!-- Subtitle Panel (toggle) -->

                <div class="tl-subtitle-panel" id="tlSubtitlePanel" style="display:none;">

                    <div class="tl-subtitle-head">

                        <h3><i class="fas fa-closed-captioning"></i> Edit Subtitle <span class="tl-subtitle-count" id="tlSubtitleCount">(0)</span></h3>

                        <div class="tl-subtitle-actions">

                            <button type="button" class="tl-subtitle-btn" id="tlSubtitleResetBtn">

                                <i class="fas fa-undo"></i> Reset

                            </button>

                            <button type="button" class="tl-subtitle-btn tl-subtitle-btn-close" id="tlSubtitleCloseBtn">

                                <i class="fas fa-times"></i>

                            </button>

                        </div>

                    </div>

                    <div class="tl-subtitle-hint">

                        <i class="fas fa-info-circle"></i>

                        <span>Klik subtitle untuk edit. Enter untuk simpan.</span>

                    </div>

                    <div class="tl-subtitle-list" id="tlSubtitleList"></div>

                </div>

            </div>

        </div>





        <!-- V9.101.0: FIX PROGRESS POSITION - progress bar di atas tombol proses -->

        <div class="ac-progress" id="acProgress" style="display:none;">

            <div class="ac-progress-bar">

                <div class="ac-progress-fill" id="acProgressFill"></div>

            </div>

            <div class="ac-progress-status">

                <div class="ac-spinner"></div>

                <span id="acProgressText">Memproses...</span>

            </div>

            <div class="ac-progress-detail" id="acProgressDetail"></div>

        </div>









<!-- V9.87.0: TOMBOL PROSES VIDEO - user set dulu, baru proses -->

        <div class="ac-proses-wrapper" id="acProsesWrapper" style="display:none;">

            <button type="button" class="ac-proses-btn" id="acProsesBtn">

                <i class="fas fa-play-circle"></i>

                <span>Proses Video Sekarang</span>

            </button>

        </div>



        
<script src="assets/js/fix-render.js?v=20261021_065513"></script>
<script src="assets/js/autoclip.js?v=<?= time() ?>"></script>

    <!-- V9.180.50: CULTURE_UI_JS -->

    <script src="assets/js/culture-ui.js?v=<?= time() ?>"></script>

    <!-- V9.182.0: AI_HOOK_GEN_UI -->

    <script src="assets/js/hookgen-v2.js?v=<?= time() ?>"></script>

    <!-- V9.183.0: AI_DUBBING_UI -->

    <script src="assets/js/dubbing-ui-v2.js?v=<?= time() ?>"></script>

    <script>

        document.addEventListener("DOMContentLoaded", function() {

            // Inisialisasi Culture UI setelah DOM siap

            setTimeout(function() {

                if (window.CliporaCulture && typeof window.CliporaCulture.render === "function") {

                    console.log("[CultureUI] Initializing...");

                    window.CliporaCulture.render("acCultureContainer");

                } else {

                    console.warn("[CultureUI] Not loaded yet, retry in 1s...");

                    setTimeout(function() {

                        if (window.CliporaCulture) {

                            window.CliporaCulture.render("acCultureContainer");

                        }

                    }, 1000);

                }

            }, 500);

        });

    </script>

<script>

    // V9.28.0: Free tier quota fetch

    // V9.134.0: REMOVE DUPLICATE FREE TIER - fungsi initFreeTierUI dihapus

    // (duplikat dengan runFreeTierUI, selector salah)



</script>

<?php endif; ?>





<!-- V9.16.0: Tombol Proyek Saya di bawah (secondary action) -->

<div class="autoclip-history-bottom" id="acHistoryBottom">

    <div class="ac-history-bottom-inner">

        <div class="ac-history-bottom-text">

            <i class="fas fa-folder-open"></i>

            <div>

                <strong>Punya Proyek Tersimpan?</strong>

                <small>Lihat & lanjutkan proyek Auto-Clip kamu</small>

            </div>

        </div>

        <a href="autoclip-history.php" class="ac-history-bottom-btn">

            <i class="fas fa-arrow-right"></i> Proyek Saya

        </a>

    </div>

</div>







<!-- V9.28.4: Free tier script -->

<script>

(function() {

    'use strict';

    

    function runFreeTierUI() {

        var isFree = <?php echo (!empty($isFreeUser)) ? 'true' : 'false'; ?>;

        if (!isFree) return;

        

        var el = document.getElementById('acFtQuotaText');

        if (!el) {

            console.warn('[FreeTier] Element acFtQuotaText tidak ada, retry...');

            setTimeout(runFreeTierUI, 500);

            return;

        }

        

        var auth = window.CLIPORA_AUTH || {};

        var token = auth.token || '';

        

        console.log('[FreeTier] Starting fetch, token:', token ? 'ADA' : 'KOSONG');

        

        fetch('/api/autoclip/quota', {

            headers: { 'Authorization': 'Bearer ' + token }

        })

        .then(function(r) {

            if (!r.ok) throw new Error('HTTP ' + r.status);

            return r.json();

        })

        .then(function(d) {

            console.log('[FreeTier] Quota loaded:', d);

            

            if (d.unlimited) {

                el.innerHTML = '<i class="fas fa-check"></i> Unlimited';

                el.className = 'ac-ftb-quota-ok';

                return;

            }

            

            var sisa = d.remaining;

            var limit = d.limit;

            

            if (sisa <= 0) {

                el.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Kuota habis (0/' + limit + ')';

                el.className = 'ac-ftb-quota-warn';

                

                document.querySelectorAll('.ac-upload-zone, #acFileInput, #acPickBtn').forEach(function(x) {

                    x.style.pointerEvents = 'none';

                    x.style.opacity = '0.4';

                });

                

                var banner = document.getElementById('acFreeBanner');

                if (banner) {

                    var block = document.createElement('div');

                    block.style.cssText = 'width:100%;margin-top:12px;padding:12px 16px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:10px;color:#ef4444;font-weight:700;font-size:0.85rem;text-align:center;';

                    block.innerHTML = '<i class="fas fa-lock"></i> Kuota harian habis. Reset besok atau <a href="harga.php" style="color:#f59e0b;text-decoration:underline;">upgrade ke Pro</a>.';

                    banner.appendChild(block);

                }

            } else {

                el.innerHTML = '<i class="fas fa-check-circle"></i> Kuota: ' + sisa + '/' + limit + ' tersisa hari ini';

                el.className = 'ac-ftb-quota-ok';

            }

            

            // Force 720p

            var presetSel = document.querySelector('select[name="preset"], #acPreset, #presetSelect');

            if (presetSel) {

                presetSel.value = '720p';

                presetSel.disabled = true;

                presetSel.title = 'Free user dibatasi 720p';

            }

            

            // Force max 3 klip

            document.querySelectorAll('select').forEach(function(sel) {

                var label = (sel.parentElement && sel.parentElement.textContent || '').toLowerCase();

                if (label.indexOf('jumlah klip') !== -1 || label.indexOf('clip') !== -1) {

                    Array.from(sel.options).forEach(function(opt) {

                        if (parseInt(opt.value) > 3) opt.disabled = true;

                    });

                    if (parseInt(sel.value) > 3) sel.value = '3';

                }

            });

        })

        .catch(function(e) {

            console.warn('[FreeTier] Fetch error:', e.message);

            el.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Gagal cek kuota';

            el.className = 'ac-ftb-quota-warn';

        });

    }

    

    if (document.readyState === 'loading') {

        document.addEventListener('DOMContentLoaded', function() { setTimeout(runFreeTierUI, 1000); });

    } else {

        setTimeout(runFreeTierUI, 1000);

    }

})();



/* ============================================================

   V9.148.0: QUICK PRESET HANDLER

   Apply otomatis setting untuk TikTok / Reels / YouTube / Podcast

   ============================================================ */

(function() {

    // V9.149.0: Preset + Audio Integration

    const AC_QUICK_PRESETS_V2 = {

        tiktok:  {

            clips: '3',  quality: '1080p', aspect: 'vertical',   removeNoise: true,  verticalCrop: true,

            audio: { volume: 110, fadeIn: 0.3, fadeOut: 0.5, noiseReduction: true, normalize: true }

        },

        reels:   {

            clips: '5',  quality: '1080p', aspect: 'vertical',   removeNoise: true,  verticalCrop: true,

            audio: { volume: 105, fadeIn: 0.5, fadeOut: 0.8, noiseReduction: true, normalize: true }

        },

        youtube: {

            clips: '10', quality: '1080p', aspect: 'horizontal', removeNoise: true,  verticalCrop: false,

            audio: { volume: 100, fadeIn: 1.0, fadeOut: 1.5, noiseReduction: true, normalize: true }

        },

        podcast: {

            clips: '5',  quality: '1080p', aspect: 'square',     removeNoise: true,  verticalCrop: false,

            audio: { volume: 150, fadeIn: 1.5, fadeOut: 2.0, noiseReduction: true, normalize: true }

        }

    };

    const AC_QUICK_PRESETS = AC_QUICK_PRESETS_V2; // backward compat



    function applyPreset(presetKey) {

        const preset = AC_QUICK_PRESETS[presetKey];

        if (!preset) { console.warn('[Preset] Unknown:', presetKey); return; }



        const setVal = (id, val) => {

            const el = document.getElementById(id);

            if (el) {

                el.value = val;

                el.dispatchEvent(new Event('change', { bubbles: true }));

            } else {

                console.warn('[Preset] Element not found:', id);

            }

        };

        const setChk = (id, val) => {

            const el = document.getElementById(id);

            if (el) {

                el.checked = val;

                el.dispatchEvent(new Event('change', { bubbles: true }));

            } else {

                console.warn('[Preset] Element not found:', id);

            }

        };



        setVal('acTargetClips', preset.clips);

        setVal('acPreset',      preset.quality);

        setVal('acAspectRatio', preset.aspect);

        setChk('acRemoveNoise', preset.removeNoise);

        setChk('acVerticalCrop', preset.verticalCrop);



        // V9.149.0: Apply audio config ke panel AUDIO PRO

        if (preset.audio) {

            const a = preset.audio;

            const volSlider = document.getElementById('acAudioVolume');

            const volLabel  = document.getElementById('acAudioVolumeVal');

            const fInSlider = document.getElementById('acAudioFadeIn');

            const fInLabel  = document.getElementById('acAudioFadeInVal');

            const fOutSlider= document.getElementById('acAudioFadeOut');

            const fOutLabel = document.getElementById('acAudioFadeOutVal');

            const nrToggle  = document.getElementById('acAudioNoiseReduction');

            const normToggle= document.getElementById('acAudioNormalize');



            if (volSlider)  { volSlider.value = a.volume; if (volLabel) volLabel.textContent = a.volume + '%'; }

            if (fInSlider)  { fInSlider.value = a.fadeIn; if (fInLabel) fInLabel.textContent = parseFloat(a.fadeIn).toFixed(1) + 's'; }

            if (fOutSlider) { fOutSlider.value = a.fadeOut; if (fOutLabel) fOutLabel.textContent = parseFloat(a.fadeOut).toFixed(1) + 's'; }

            if (nrToggle)   nrToggle.checked = a.noiseReduction;

            if (normToggle) normToggle.checked = a.normalize;



            // Trigger input events biar konsisten dengan user interaction

            if (volSlider)  volSlider.dispatchEvent(new Event('input', {bubbles: true}));

            if (fInSlider)  fInSlider.dispatchEvent(new Event('input', {bubbles: true}));

            if (fOutSlider) fOutSlider.dispatchEvent(new Event('input', {bubbles: true}));



            console.log('[AudioPro] Applied preset audio:', a);

        }



        console.log('[Preset Applied]', presetKey, preset);

    }



    function initQuickPresets() {

        const buttons = document.querySelectorAll('.ac-quick-preset');

        if (!buttons.length) {

            console.warn('[Preset] Tombol .ac-quick-preset tidak ditemukan');

            return;

        }



        buttons.forEach(btn => {

            btn.addEventListener('click', function(e) {

                e.preventDefault();

                const presetKey = this.dataset.preset;

                applyPreset(presetKey);



                document.querySelectorAll('.ac-quick-preset').forEach(b => b.classList.remove('active'));

                this.classList.add('active');



                const label = this.querySelector('span:nth-child(2)');

                const name = label ? label.textContent : presetKey.toUpperCase();



                if (typeof showToast === 'function') {

                    showToast('Preset ' + name + ' diterapkan!', 'success');

                } else {

                    const t = document.createElement('div');

                    t.textContent = 'Preset ' + name + ' diterapkan!';

                    t.style.cssText = 'position:fixed;top:20px;right:20px;padding:12px 20px;background:linear-gradient(135deg,#8b5cf6,#6d28d9);color:#fff;border-radius:10px;font-size:13px;font-weight:600;z-index:99999;box-shadow:0 8px 24px rgba(139,92,246,0.4);opacity:0;transition:opacity 0.3s;';

                    document.body.appendChild(t);

                    requestAnimationFrame(() => t.style.opacity = '1');

                    setTimeout(() => {

                        t.style.opacity = '0';

                        setTimeout(() => t.remove(), 300);

                    }, 2000);

                }

            });

        });



        console.log('[Preset] ' + buttons.length + ' tombol preset siap');

    }



    if (document.readyState === 'loading') {

        document.addEventListener('DOMContentLoaded', initQuickPresets);

    } else {

        initQuickPresets();

    }

})();





/* V9.148.0: AUDIO PRO - UI handler + getAudioConfig() */

(function() {

    function initAudioPro() {

        const volume    = document.getElementById('acAudioVolume');

        const volumeVal = document.getElementById('acAudioVolumeVal');

        const fadeIn    = document.getElementById('acAudioFadeIn');

        const fadeInVal = document.getElementById('acAudioFadeInVal');

        const fadeOut   = document.getElementById('acAudioFadeOut');

        const fadeOutVal= document.getElementById('acAudioFadeOutVal');

        const nrToggle  = document.getElementById('acAudioNoiseReduction');

        const normToggle= document.getElementById('acAudioNormalize');



        if (!volume || !fadeIn || !fadeOut) {

            console.warn('[AudioPro] UI elements tidak ditemukan');

            return;

        }



        volume.addEventListener('input', () => {

            volumeVal.textContent = volume.value + '%';

        });

        fadeIn.addEventListener('input', () => {

            fadeInVal.textContent = parseFloat(fadeIn.value).toFixed(1) + 's';

        });

        fadeOut.addEventListener('input', () => {

            fadeOutVal.textContent = parseFloat(fadeOut.value).toFixed(1) + 's';

        });



        // Expose getAudioConfig()

        window.getAudioConfig = function() {

            return {

                volume:         parseInt(volume.value, 10),

                noiseReduction: nrToggle ? nrToggle.checked : true,

                normalize:      normToggle ? normToggle.checked : true,

                fadeIn:         parseFloat(fadeIn.value),

                fadeOut:        parseFloat(fadeOut.value),

            };

        };



        console.log('[AudioPro] Handler ready');

    }



    if (document.readyState === 'loading') {

        document.addEventListener('DOMContentLoaded', initAudioPro);

    } else {

        initAudioPro();

    }

})();



</script>





<!-- V9.128.0: REVIEW MODAL -->

<div id="acReviewModal" style="display:none; position:fixed; inset:0; z-index:99999; background:rgba(0,0,0,0.75); backdrop-filter:blur(6px);">

  <div style="position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); background:linear-gradient(135deg,#1e1b4b,#2d1b4e); border:1px solid rgba(236,72,153,0.3); border-radius:16px; padding:32px; max-width:520px; width:90%; box-shadow:0 20px 60px rgba(0,0,0,0.5);">

    <div style="text-align:center; margin-bottom:20px;">

      <div style="font-size:52px; margin-bottom:8px; line-height:1;">-</div>

      <h2 style="color:white; margin:0 0 8px; font-size:22px; font-weight:800;">Video Berhasil Dibuat!</h2>

      <p style="color:#a1a1aa; margin:0; font-size:13px;">Gimana hasilnya? Kasih rating dong -</p>

    </div>



    <div id="acReviewStars" style="display:flex; justify-content:center; gap:8px; margin:20px 0 12px; cursor:pointer; user-select:none;">

      <span data-star="1" style="font-size:40px; color:#52525b; transition:0.15s; line-height:1;">-</span>

      <span data-star="2" style="font-size:40px; color:#52525b; transition:0.15s; line-height:1;">-</span>

      <span data-star="3" style="font-size:40px; color:#52525b; transition:0.15s; line-height:1;">-</span>

      <span data-star="4" style="font-size:40px; color:#52525b; transition:0.15s; line-height:1;">-</span>

      <span data-star="5" style="font-size:40px; color:#52525b; transition:0.15s; line-height:1;">-</span>

    </div>

    <div id="acReviewRatingText" style="text-align:center; color:#a1a1aa; font-size:13px; margin-bottom:16px; min-height:18px;">Klik bintang untuk menilai</div>



    <textarea id="acReviewComment" placeholder="Ceritakan pengalamanmu (opsional)..." maxlength="1000" style="width:100%; min-height:80px; padding:12px; background:rgba(15,23,42,0.7); border:1px solid rgba(236,72,153,0.2); border-radius:10px; color:white; font-size:13px; font-family:inherit; resize:vertical; box-sizing:border-box; margin-bottom:18px; outline:none;"></textarea>



    <div style="display:flex; gap:12px;">

      <button id="acReviewSkip" type="button" style="flex:1; padding:12px; background:transparent; color:#a1a1aa; border:1px solid #52525b; border-radius:10px; font-size:14px; font-weight:600; cursor:pointer;">Lewati</button>

      <button id="acReviewSubmit" type="button" disabled style="flex:2; padding:12px; background:linear-gradient(135deg,#ec4899,#be185d); color:white; border:none; border-radius:10px; font-size:14px; font-weight:700; cursor:pointer; opacity:0.5; transition:opacity 0.2s;">Kirim Review</button>

    </div>



    <div id="acReviewStatus" style="text-align:center; margin-top:12px; font-size:12px; color:#71717a; min-height:16px;"></div>

  </div>

</div>





<!-- V9.253.0: VIDEO PREVIEW MODAL - Standalone (tidak bentrok dengan acPreviewModal) -->

<div class="ac-preview-modal" id="acVideoPreviewModal" style="display:none;">

    <div class="ac-preview-backdrop" onclick="window.closeVideoPreview && window.closeVideoPreview()"></div>

    <div class="ac-preview-content">

        <div class="ac-preview-head">

            <h3><i class="fas fa-play-circle"></i> <span id="acVideoPreviewTitle">Preview Video</span></h3>

            <button class="ac-preview-close" type="button" onclick="window.closeVideoPreview && window.closeVideoPreview()">

                <i class="fas fa-times"></i>

            </button>

        </div>

        <div style="background:#000; padding:16px;">

            <video id="acVideoPreviewPlayer" controls preload="metadata" playsinline

                   style="width:100%; max-height:60vh; border-radius:12px; display:block; background:#000;">

                Browser Anda tidak mendukung video.

            </video>

        </div>

        <div style="padding:16px 24px; display:flex; gap:12px; justify-content:flex-end; border-top:1px solid rgba(255,255,255,0.08);">

            <button type="button" 

                    onclick="window.closeVideoPreview && window.closeVideoPreview()"

                    style="padding:10px 18px; border-radius:10px; background:rgba(255,255,255,0.05); color:#94a3b8; border:1px solid rgba(255,255,255,0.1); cursor:pointer; font-weight:600;">

                <i class="fas fa-times"></i> Tutup

            </button>

            <a id="acVideoPreviewDownload" 

               href="#" 

               download

               style="padding:10px 18px; border-radius:10px; background:linear-gradient(135deg,#f59e0b,#ea580c); color:#fff; border:none; text-decoration:none; cursor:pointer; font-weight:700; display:inline-flex; align-items:center; gap:6px;">

                <i class="fas fa-download"></i> Download Video

            </a>

        </div>

    </div>

</div>





<!-- V9.178.0: AUTO_OPTIMIZE_MODAL -->

<div class="ac-auto-modal" id="acAutoModal">

    <div class="ac-auto-modal-content">

        <div class="ac-auto-modal-header">

            <div class="ac-auto-modal-icon">

                <i class="fas fa-wand-magic-sparkles"></i>

            </div>

            <div>

                <div class="ac-auto-modal-title">Auto-Optimize Klip?</div>

                <div class="ac-auto-modal-subtitle">AI akan edit otomatis berdasarkan retention</div>

            </div>

        </div>

        <div class="ac-auto-modal-body" id="acAutoModalBody">

            Loading...

        </div>

        <div class="ac-auto-modal-actions" id="acAutoModalActions">

            <button type="button" class="ac-auto-btn ac-auto-btn-secondary" id="acAutoCancelBtn">

                <i class="fas fa-times"></i> Batal

            </button>

            <button type="button" class="ac-auto-btn ac-auto-btn-primary" id="acAutoConfirmBtn">

                <i class="fas fa-wand-magic-sparkles"></i> Mulai Optimize

            </button>

        </div>

    </div>

</div>



<?php require_once __DIR__ . '/includes/footer.php'; ?>


<script src="assets/js/fix-permanent.js?v=20261021_075344"></script>

<script src="assets/js/fix-upload-permanent.js?v=20261021_081111"></script>

