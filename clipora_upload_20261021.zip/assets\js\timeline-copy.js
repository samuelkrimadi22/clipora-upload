/* timeline-copy.js - V3.0.0 - Pakai start time, bukan ID */
(function () {
    'use strict';

    function showToast(msg) {
        var t = document.createElement('div');
        t.textContent = msg;
        t.style.cssText = 'position:fixed;bottom:40px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,#8b5cf6,#06b6d4);color:#fff;padding:10px 20px;border-radius:24px;font-size:0.9rem;font-weight:600;z-index:99999;box-shadow:0 8px 32px rgba(139,92,246,0.5);pointer-events:none;';
        document.body.appendChild(t);
        setTimeout(function(){ t.style.opacity = '0'; t.style.transition = 'opacity 0.3s'; }, 1500);
        setTimeout(function(){ t.remove(); }, 1900);
    }

    function getDuration() {
        if (typeof currentAnalysisData !== 'undefined' && currentAnalysisData && currentAnalysisData.duration > 0) return currentAnalysisData.duration;
        var v = document.getElementById('editorVideo');
        if (v && v.duration > 0) return v.duration;
        return 0;
    }

    function getSegs() {
        if (typeof currentAnalysisData !== 'undefined' && currentAnalysisData && currentAnalysisData.segments) return currentAnalysisData.segments;
        if (window.CliporaEditor && window.CliporaEditor.getSegments) return window.CliporaEditor.getSegments();
        return null;
    }

    // Copy berdasarkan segmen yang diklik — pakai start time (bukan ID)
    function duplicate(segEl) {
        var segs = getSegs();
        if (!segs || !segs.length) { showToast('Data tidak ada'); return; }

        var dur = getDuration();
        if (!dur) { showToast('Duration tidak ada'); return; }

        // Hitung start-end dari posisi DOM (paling akurat, karena DOM = state yang di-render)
        var leftPct = parseFloat(segEl.style.left) || 0;
        var widthPct = parseFloat(segEl.style.width) || 0;
        var startTime = (leftPct / 100) * dur;
        var endTime = ((leftPct + widthPct) / 100) * dur;
        var segDuration = endTime - startTime;

        if (segDuration <= 0) {
            showToast('Segmen tidak valid');
            return;
        }

        // Cari segmen yang match (by start time)
        var seg = null;
        for (var i = 0; i < segs.length; i++) {
            if (Math.abs(segs[i].start - startTime) < 0.2) {
                seg = segs[i];
                break;
            }
        }

        // Kalau tidak ketemu, pakai data dari DOM saja
        if (!seg) {
            seg = { start: startTime, end: endTime, source: 'manual', reason: 'copy', priority: 5, enabled: true };
            console.log('[Copy] Fallback — pakai DOM time langsung');
        }

        // Bikin segmen baru
        var newStart = seg.end + 0.1;
        var newEnd = newStart + segDuration;
        if (newEnd > dur) {
            newStart = seg.start - segDuration - 0.1;
            newEnd = newStart + segDuration;
            if (newStart < 0) { newStart = 0; newEnd = Math.min(segDuration, dur); }
        }

        var newSeg = {
            id: 'copy_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
            start: parseFloat(newStart.toFixed(3)),
            end: parseFloat(newEnd.toFixed(3)),
            source: seg.source || 'manual',
            reason: (seg.reason || 'copy') + '_copy',
            priority: seg.priority || 5,
            enabled: seg.enabled !== false,
        };

        // Push ke currentAnalysisData
        segs.push(newSeg);
        segs.sort(function(a, b) { return a.start - b.start; });

        // Sync ke state internal via API
        if (window.CliporaEditor && window.CliporaEditor.setSegments) {
            try {
                window.CliporaEditor.setSegments({
                    segments: JSON.parse(JSON.stringify(segs)),
                    duration: dur,
                });
            } catch (e) {
                console.warn('[Copy] setSegments error:', e);
            }
        }

        // Re-render
        if (typeof renderTimeline === 'function') { try { renderTimeline(); } catch (e) {} }
        if (typeof renderStats === 'function') { try { renderStats(); } catch (e) {} }

        console.log('[Copy] OK → ' + newStart.toFixed(2) + 's - ' + newEnd.toFixed(2) + 's. Total: ' + segs.length);
        showToast('Segmen di-copy (total ' + segs.length + ')');
    }

    function attachButtons() {
        var track = document.getElementById('teTrack');
        if (!track) return false;

        if (!document.getElementById('_hcStyle')) {
            var st = document.createElement('style');
            st.id = '_hcStyle';
            st.textContent = '.te-segment{position:relative}.te-segment-copy-btn{position:absolute;top:2px;right:2px;width:22px;height:22px;border-radius:4px;border:none;background:rgba(139,92,246,0.95);color:#fff;cursor:pointer;display:none;align-items:center;justify-content:center;font-size:0.7rem;z-index:5;padding:0;font-family:inherit;font-weight:700;box-shadow:0 2px 8px rgba(0,0,0,0.5)}.te-segment:hover .te-segment-copy-btn{display:flex!important}.te-segment-copy-btn:hover{background:rgba(6,182,212,0.95);transform:scale(1.15)}';
            document.head.appendChild(st);
        }

        var allSegs = track.querySelectorAll('.te-segment');
        for (var i = 0; i < allSegs.length; i++) {
            var seg = allSegs[i];
            if (seg.querySelector('.te-segment-copy-btn')) continue;
            var btn = document.createElement('button');
            btn.className = 'te-segment-copy-btn';
            btn.type = 'button';
            btn.textContent = 'C';
            (function (segElRef) {
                btn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    duplicate(segElRef);
                });
            })(seg);
            btn.addEventListener('pointerdown', function (e) { e.stopPropagation(); });
            seg.appendChild(btn);
        }
        return true;
    }

    function run() {
        var track = document.getElementById('teTrack');
        if (!track) { setTimeout(run, 500); return; }
        console.log('[CopyV3] Init');
        attachButtons();
        var obs = new MutationObserver(function (muts) {
            var need = false;
            muts.forEach(function (m) {
                for (var i = 0; i < m.addedNodes.length; i++) {
                    var n = m.addedNodes[i];
                    if (n.nodeType === 1 && n.classList && n.classList.contains('te-segment')) need = true;
                }
            });
            if (need) setTimeout(attachButtons, 50);
        });
        obs.observe(track, { childList: true, subtree: true });
        console.log('[CopyV3] Ready');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { setTimeout(run, 1500); });
    } else {
        setTimeout(run, 1500);
    }
})();
