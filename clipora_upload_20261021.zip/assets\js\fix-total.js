﻿// ============================================================
// V9.200.0: PERBAIKAN TOTAL (Upload & Render)
// ============================================================
(function() {
    "use strict";

    // 1. PAKSA TOMBOL UPLOAD BEKERJA
    function forcePreview() {
        var input = document.getElementById("acFileInput");
        if (!input || !input.files || input.files.length === 0) return;

        var file = input.files[0];
        console.log("✅ File terdeteksi:", file.name);

        var previewWrap = document.getElementById("acVideoPreviewWrap");
        var previewVideo = document.getElementById("acVideoPreview");
        if (previewWrap && previewVideo) {
            previewWrap.style.display = "block";
            if (!previewVideo.src || previewVideo.src === "") {
                previewVideo.src = URL.createObjectURL(file);
                previewVideo.load();
            }
            console.log("✅ Preview video dipasang!");
        }

        var prosesWrapper = document.getElementById("acProsesWrapper");
        if (prosesWrapper) {
            prosesWrapper.style.display = "block";
            prosesWrapper.classList.add("visible");
        }

        var uploadZone = document.getElementById("acUploadZone");
        if (uploadZone) uploadZone.style.display = "none";
    }

    function forceUpload() {
        var btn = document.getElementById("acPickBtn");
        var zone = document.getElementById("acUploadZone");
        var input = document.getElementById("acFileInput");
        
        if (!input) return;
        
        if (btn && !btn.dataset.forced) {
            btn.dataset.forced = "true";
            btn.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                input.click();
                // Pasang listener untuk mendeteksi file yang dipilih
                setTimeout(function() {
                    input.onchange = function() {
                        forcePreview();
                    };
                }, 100);
                console.log("✅ Tombol Pilih Video dipaksa bekerja!");
            };
        }
        
        if (zone && !zone.dataset.forced) {
            zone.dataset.forced = "true";
            zone.onclick = function(e) {
                if (e.target.id !== "acFileInput") {
                    e.preventDefault();
                    e.stopPropagation();
                    input.click();
                // Pasang listener untuk mendeteksi file yang dipilih
                setTimeout(function() {
                    input.onchange = function() {
                        forcePreview();
                    };
                }, 100);
                }
            };
        }
    }

    // 2. BYPASS SHOWCONFIRM
    window.showConfirm = function(opts) {
        return Promise.resolve(confirm((opts.title || "Konfirmasi") + "\n\n" + (opts.message || "")));
    };

    // 3. FUNGSI RENDER DARURAT
    window.emergencyRender = async function() {
        var st = window.__TL_STATE;
        if (!st || !st.timeline || st.timeline.length === 0) {
            alert("Tidak ada klip. Silakan upload video baru.");
            return;
        }

        var clips = [...st.timeline, ...st.pool];
        if (!confirm("Render " + clips.length + " klip sekarang?")) return;

        var token = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || "";
        var analysisId = st.analysisId || st._projectId;
        var preset = document.getElementById("acPreset")?.value || "1080p";

        console.log("🚀 Memulai render darurat " + clips.length + " klip...");
        
        for (var i = 0; i < clips.length; i++) {
            var clip = clips[i];
            console.log("[" + (i+1) + "/" + clips.length + "] Merender Klip #" + clip.id + "...");
            
            try {
                var res = await fetch("http://localhost:3000/api/render-clip/" + analysisId + "/" + clip.id, {
                    method: "POST",
                    headers: {
                        "Authorization": "Bearer " + token,
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        preset: preset,
                        vertical_crop: false,
                        enable_burn_subtitle: true,
                        caption_style: "clean",
                        culture_region: "id" // Paksa ID agar tidak Error 500
                    })
                });
                var data = await res.json();
                if (data.success) {
                    console.log("✅ Klip #" + clip.id + " selesai: " + data.filename);
                } else {
                    console.error("❌ Klip #" + clip.id + " gagal: " + (data.error || "Unknown"));
                }
            } catch (e) {
                console.error("❌ Error: " + e.message);
            }
        }
        console.log("🏁 Render selesai!");
        alert("Render selesai! Silakan cek folder results/.");
    };

    // 4. PASANG TOMBOL RENDER
    function forceRenderBtn() {
        var btnAll = document.getElementById("tlRenderAllBtn");
        if (btnAll && !btnAll.dataset.forced) {
            btnAll.dataset.forced = "true";
            btnAll.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                window.emergencyRender();
            };
            console.log("✅ Tombol Render dipaksa pakai Fungsi Darurat!");
        }
    }

    // Jalankan semua perbaikan
    document.addEventListener("DOMContentLoaded", function() {
        // Panggil forcePreview setiap halaman dimuat (jika ada file yang sudah dipilih)
        setTimeout(forcePreview, 500);
        setTimeout(forcePreview, 1500);
        forceUpload();
        forceRenderBtn();
        
        // Coba lagi berkala (jika elemen baru muncul)
        setInterval(forceUpload, 2000);
        setInterval(forceRenderBtn, 2000);
    });

    console.log("[V9.200.0] Perbaikan Total aktif!");

    // 5. PERBAIKI TOMBOL COLLAPSE PANEL PENGATURAN
    function fixSettingsPanel() {
        // Cari semua header panel pengaturan
        var headers = document.querySelectorAll(".ac-settings-header, .ac-panel-header, .ac-card-header");
        
        headers.forEach(function(header) {
            if (header.dataset.fixed) return; // Jangan pasang 2x
            header.dataset.fixed = "true";
            
            header.style.cursor = "pointer";
            header.addEventListener("click", function(e) {
                // Jangan tutup jika yang diklik adalah tombol switch
                if (e.target.closest(".ac-toggle-switch")) return;
                if (e.target.closest("button")) return;
                
                // Cari konten panel di dalam elemen yang sama
                var parent = header.parentElement;
                var content = parent.querySelector(".ac-settings-body, .ac-panel-body, .ac-card-body");
                
                if (content) {
                    if (content.style.display === "none") {
                        content.style.display = "block";
                        console.log("✅ Panel dibuka");
                    } else {
                        content.style.display = "none";
                        console.log("✅ Panel ditutup");
                    }
                }
            });
            console.log("✅ Tombol panel dipasangi event click!");
        });
    }

    document.addEventListener("DOMContentLoaded", function() {
        // Panggil fixSettingsPanel
        setTimeout(fixSettingsPanel, 1000);
        setInterval(fixSettingsPanel, 2000);
    });


    // 6. PAKSA TOMBOL PROSES VIDEO BEKERJA
    function forceProsesBtn() {
        var btn = document.getElementById("acProsesBtn");
        if (btn && !btn.dataset.forced) {
            btn.dataset.forced = "true";
            btn.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                var input = document.getElementById("acFileInput");
                if (!input || !input.files || input.files.length === 0) {
                    alert("Silakan pilih video terlebih dahulu.");
                    return;
                }
                
                var file = input.files[0];
                console.log("✅ Tombol Proses diklik, memulai upload:", file.name);
                
                // Tampilkan progress
                var progress = document.getElementById("acProgress");
                if (progress) progress.style.display = "block";
                
                var progressText = document.getElementById("acProgressText");
                if (progressText) progressText.textContent = "Mengupload video...";
                
                // Sembunyikan tombol proses dan preview
                var prosesWrapper = document.getElementById("acProsesWrapper");
                if (prosesWrapper) prosesWrapper.style.display = "none";
                
                var previewWrap = document.getElementById("acVideoPreviewWrap");
                if (previewWrap) previewWrap.style.display = "none";
                
                // Panggil fungsi upload yang ada di autoclip.js (jika tersedia)
                if (typeof uploadAndAnalyze === "function") {
                    uploadAndAnalyze(file);
                } else {
                    // Fallback: upload manual via fetch
                    var fd = new FormData();
                    fd.append("video", file);
                    fd.append("target_clips", document.getElementById("acTargetClips")?.value || "5");
                    fd.append("preset", document.getElementById("acPreset")?.value || "1080p");
                    fd.append("enable_umkm", "false");
                    fd.append("enable_music", "false");
                    
                    var token = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || "";
                    
                    fetch("http://localhost:3000/api/auto-clip", {
                        method: "POST",
                        headers: { "Authorization": "Bearer " + token },
                        body: fd
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            console.log("✅ Analisis selesai:", data.totalClips, "klip");
                            if (progressText) progressText.textContent = "Selesai! Menampilkan timeline...";
                            
                            // PERBAIKAN: Simpan data ke window.__TL_STATE agar timeline muncul
                            var allClips = (data.clips || []).map(function(c, i) {
                                return {
                                    id: c.id,
                                    start: c.start,
                                    end: c.end,
                                    duration: c.duration,
                                    score: c.score,
                                    preview_text: c.preview_text || "",
                                    thumbnailUrl: c.thumbnailUrl || null
                                };
                            });
                            
                            window.__TL_STATE = {
                                timeline: allClips,
                                pool: [],
                                initial: [...allClips],
                                analysisId: data.analysisId,
                                _projectId: data.analysisId,
                                videoUrl: URL.createObjectURL(file)
                            };
                            
                            console.log("✅ State timeline disiapkan:", window.__TL_STATE.timeline.length, "klip");
                            
                            // Sembunyikan upload zone
                            var uploadZone = document.getElementById("acUploadZone");
                            if (uploadZone) uploadZone.style.display = "none";
                            var settingsPanel = document.querySelector(".ac-settings");
                            if (settingsPanel) settingsPanel.style.display = "none";
                            var progressBar = document.getElementById("acProgress");
                            if (progressBar) progressBar.style.display = "none";
                            
                            // Tampilkan Timeline
                            var editor = document.getElementById("acTimelineEditor");
                            if (editor) {
                                editor.classList.add("active");
                                editor.style.display = "block";
                            }
                            document.body.classList.add("ac-timeline-active");
                            
                            // Render timeline jika fungsi tersedia
                            if (typeof renderTimeline === "function") renderTimeline();
                            if (typeof renderPool === "function") renderPool();
                            
                            // Pasang video
                            var videos = document.querySelectorAll("video");
                            videos.forEach(function(v) { 
                                v.src = window.__TL_STATE.videoUrl; 
                                v.load(); 
                            });
                            
                            // Scroll ke timeline
                            setTimeout(function() {
                                if (editor) editor.scrollIntoView({ behavior: "smooth", block: "start" });
                            }, 500);
                        } else {
                            alert("Gagal: " + (data.error || "Unknown"));
                        }
                    })
                    .catch(err => {
                        alert("Error: " + err.message);
                    });
                }
            };
            console.log("✅ Tombol Proses Video dipaksa bekerja!");
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
        setTimeout(forceProsesBtn, 1000);
        setInterval(forceProsesBtn, 2000);
    });

})();