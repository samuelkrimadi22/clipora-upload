// V9.152.0: SUPPRESS WARNINGS - filter Fabric.js noise

(function() {

    // ============================================================
    // V9.203.0: TOAST NOTIFICATION
    // ============================================================
    function showTs2Toast(message, type) {
        type = type || 'info';

        var container = document.getElementById('ts2ToastContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'ts2ToastContainer';
            container.style.cssText = 'position:fixed;top:90px;right:20px;z-index:99999;display:flex;flex-direction:column;gap:8px;pointer-events:none;';
            document.body.appendChild(container);
        }

        var colors = {
            info:    { bg: 'rgba(139, 92, 246, 0.95)', border: '#8b5cf6', icon: 'fa-info-circle' },
            success: { bg: 'rgba(34, 197, 94, 0.95)',  border: '#22c55e', icon: 'fa-check-circle' },
            warning: { bg: 'rgba(245, 158, 11, 0.95)', border: '#f59e0b', icon: 'fa-exclamation-triangle' },
            error:   { bg: 'rgba(239, 68, 68, 0.95)',  border: '#ef4444', icon: 'fa-times-circle' },
        };
        var c = colors[type] || colors.info;

        var toast = document.createElement('div');
        toast.style.cssText = 'padding:12px 18px;background:' + c.bg + ';color:#fff;border-radius:10px;font-size:13px;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,0.4);display:flex;align-items:center;gap:10px;pointer-events:auto;opacity:0;transform:translateX(20px);transition:all 0.3s ease;max-width:320px;font-family:Rubik, sans-serif;';
        toast.innerHTML = '<i class="fas ' + c.icon + '" style="font-size:16px;"></i><span>' + message + '</span>';

        container.appendChild(toast);

        requestAnimationFrame(function() {
            toast.style.opacity = '1';
            toast.style.transform = 'translateX(0)';
        });

        setTimeout(function() {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(20px)';
            setTimeout(function() {
                if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, 300);
        }, 3000);
    }


    const origWarn = console.warn;

    console.warn = function() {

        var args = Array.prototype.slice.call(arguments);

        var msg = String(args[0] || '');

        if (msg.indexOf('alphabetical') !== -1) return;

        if (msg.indexOf('CanvasTextBaseline') !== -1) return;

        origWarn.apply(console, args);

    };

})();



/* ============================================================

   THUMBNAIL STUDIO v2.0 - JavaScript

   Dibuat berdasarkan riset thumbnail profesional

   ============================================================ */

(function () {

    'use strict';



    const state = {

        canvas: null,

        bgImage: null,

        titleText: null,

        subtitleText: null,

        borderRect: null,

        icons: [],

        currentW: 1280,

        currentH: 720,

        currentColor: '#ffffff',

        currentFont: 'Bebas Neue',

        currentPos: 'middle',

        sizeMultiplier: 1.0,

        strokeWidth: 4,

        bgEnabled: false,

        currentBorder: 'none',

        // V9.165.0: track active object manually

        _lastActive: null,

        // V9.167.1: KEYBOARD STATE

        history: [],

        historyIndex: -1,

        maxHistory: 30,

        clipboard: null,

        _restoring: false,

        currentTemplate: 'youtube',

    };



    // ============================================================

    // TEMPLATES - berdasarkan riset thumbnail viral

    // ============================================================

    const TEMPLATES = {

        youtube: {

            font: 'Bebas Neue', color: '#fbbf24', bgEnabled: false,

            position: 'middle', sizeMultiplier: 1.0, strokeWidth: 4,

        },

        tiktok: {

            font: 'Anton', color: '#ec4899', bgEnabled: true,

            position: 'top', sizeMultiplier: 1.1, strokeWidth: 3,

        },

        podcast: {

            font: 'Poppins', color: '#ffffff', bgEnabled: true,

            position: 'bottom', sizeMultiplier: 0.85, strokeWidth: 0,

        },

        gaming: {

            font: 'Archivo Black', color: '#fbbf24', bgEnabled: false,

            position: 'middle', sizeMultiplier: 1.15, strokeWidth: 6,

        },

        minimalist: {

            font: 'Poppins', color: '#ffffff', bgEnabled: false,

            position: 'bottom', sizeMultiplier: 0.7, strokeWidth: 0,

        },

        custom: {},

    };



    // ============================================================

    // INIT

    // ============================================================

    // ============================================================

    // V9.161.0: MODAL SCOPE FIX - fungsi di scope modul

    // ============================================================

    let _editingTarget = null;



    function openEditModal(target) {

        _editingTarget = target;

        const modal = document.getElementById('ts2EditModal');

        const input = document.getElementById('ts2ModalInput');

        if (!modal || !input) return;



        input.value = target.text || '';

        modal.classList.add('active');



        setTimeout(function() {

            input.focus();

            input.select();

        }, 100);

    }



    function closeEditModal() {

        const modal = document.getElementById('ts2EditModal');

        if (modal) modal.classList.remove('active');

        _editingTarget = null;

    }



    function saveEditModal() {

        const input = document.getElementById('ts2ModalInput');

        if (!input || !_editingTarget) {

            closeEditModal();

            return;

        }



        const newText = input.value;

        _editingTarget.set('text', newText);



        // Sync ke input panel

        if (_editingTarget === state.titleText) {

            const t = document.getElementById('ts2Title');

            if (t) t.value = newText;

        } else if (_editingTarget === state.subtitleText) {

            const s = document.getElementById('ts2Subtitle');

            if (s) s.value = newText;

        }



        if (state.canvas) state.canvas.renderAll();

        closeEditModal();

    }



    // ============================================================

    // V9.167.0: KEYBOARD FUNCTIONS

    // ============================================================



    function saveHistory() {

        if (!state.canvas) return;

        try {

            var snap = JSON.stringify(state.canvas.toJSON());

            if (state.historyIndex < state.history.length - 1) {

                state.history = state.history.slice(0, state.historyIndex + 1);

            }

            state.history.push(snap);

            if (state.history.length > state.maxHistory) {

                state.history.shift();

            }

            state.historyIndex = state.history.length - 1;

            console.log("[v2] History saved #" + state.historyIndex);

        } catch (e) {

            console.warn("[v2] saveHistory error:", e.message);

        }

    }



    function rebuildReferences() {

        if (!state.canvas) return;

        var objs = state.canvas.getObjects();

        state.bgImage = null;

        state.titleText = null;

        state.subtitleText = null;

        state.borderRect = null;

        state.icons = [];

        objs.forEach(function(o) {

            if (o.type === "image") state.bgImage = o;

            else if (o.type === "textbox" || o.type === "i-text" || o.type === "text") {

                if (!state.titleText) state.titleText = o;

                else if (!state.subtitleText) state.subtitleText = o;

            } else if (o.type === "rect") state.borderRect = o;

        });

    }



    function undo() {

        if (!state.canvas || state.historyIndex <= 0) {

            console.log("[v2] Undo: sudah di awal");

            return;

        }

        state.historyIndex--;

        var snap = state.history[state.historyIndex];

        try {

            state._restoring = true;

            state.canvas.loadFromJSON(snap, function() {

                state.canvas.renderAll();

                rebuildReferences();

                state._restoring = false;

                console.log("[v2] Undo #" + state.historyIndex);

            });

        } catch (e) {

            state._restoring = false;

            console.warn("[v2] Undo error:", e.message);

        }

    }



    function redo() {

        if (!state.canvas || state.historyIndex >= state.history.length - 1) {

            console.log("[v2] Redo: sudah di akhir");

            return;

        }

        state.historyIndex++;

        var snap = state.history[state.historyIndex];

        try {

            state._restoring = true;

            state.canvas.loadFromJSON(snap, function() {

                state.canvas.renderAll();

                rebuildReferences();

                state._restoring = false;

                console.log("[v2] Redo #" + state.historyIndex);

            });

        } catch (e) {

            state._restoring = false;

            console.warn("[v2] Redo error:", e.message);

        }

    }



    function copyElement() {

        if (!state.canvas) return;

        var active = state.canvas.getActiveObject() || state._lastActive;

        if (!active) {

            console.log("[v2] Copy: tidak ada elemen");

            return;

        }

        active.clone(function(c) {

            state.clipboard = c;

            console.log("[v2] Copied: " + active.type);

        });

    }



    function pasteElement() {

        if (!state.canvas || !state.clipboard) {

            console.log("[v2] Paste: clipboard kosong");

            return;

        }

        state.clipboard.clone(function(c) {

            c.set({

                left: (c.left || 0) + 20,

                top: (c.top || 0) + 20,

                evented: true

            });

            state.canvas.add(c);

            state.canvas.setActiveObject(c);

            state.canvas.renderAll();

            state._lastActive = c;

            saveHistory();

            console.log("[v2] Pasted");

        });

    }



    function duplicateElement() {

        if (!state.canvas) return;

        var active = state.canvas.getActiveObject() || state._lastActive;

        if (!active) return;

        active.clone(function(c) {

            c.set({

                left: (c.left || 0) + 30,

                top: (c.top || 0) + 30,

                evented: true

            });

            state.canvas.add(c);

            state.canvas.setActiveObject(c);

            state.canvas.renderAll();

            state._lastActive = c;

            saveHistory();

            console.log("[v2] Duplicated");

        });

    }



    function selectAllElements() {

        if (!state.canvas) return;

        var objs = state.canvas.getObjects().filter(function(o) {

            return o.type !== "image" && o.type !== "rect";

        });

        if (objs.length === 0) return;

        var sel = new fabric.ActiveSelection(objs, { canvas: state.canvas });

        state.canvas.setActiveObject(sel);

        state.canvas.renderAll();

        console.log("[v2] Select all: " + objs.length);

    }



    function handleKeydown(e) {

        var tag = (document.activeElement || {}).tagName;

        if (tag === "INPUT" || tag === "TEXTAREA") {

            if (e.ctrlKey && e.key.toLowerCase() === "z") return;

            return;

        }

        var ctrl = e.ctrlKey || e.metaKey;

        var key = e.key.toLowerCase();



        if (ctrl && key === "z" && !e.shiftKey) { e.preventDefault(); undo(); return; }

        if ((ctrl && key === "y") || (ctrl && e.shiftKey && key === "z")) { e.preventDefault(); redo(); return; }

        if (ctrl && key === "c") { e.preventDefault(); copyElement(); return; }

        if (ctrl && key === "v") { e.preventDefault(); pasteElement(); return; }

        if (ctrl && key === "d") { e.preventDefault(); duplicateElement(); return; }

        if (ctrl && key === "a") { e.preventDefault(); selectAllElements(); return; }



        if (e.key === "Delete" || e.key === "Backspace") {

            var active = state.canvas && state.canvas.getActiveObject();

            if (!active) return;

            if (active.type === "image" || active.type === "rect") return;

            e.preventDefault();

            state.canvas.remove(active);

            state.canvas.discardActiveObject();

            state.canvas.renderAll();

            state._lastActive = null;

            saveHistory();

            console.log("[v2] Element deleted (keyboard)");

        }

    }



    function init() {

        state.canvas = new fabric.Canvas('ts2Canvas', {

            width: state.currentW,

            height: state.currentH,

            backgroundColor: '#000',

        });



        // Add initial texts

        addTexts();



        // V9.165.0: Track active object manually (fallback getActiveObject)

        state.canvas.on('selection:created', function(e) {

            if (e.selected && e.selected.length > 0) {

                state._lastActive = e.selected[0];

                console.log('[v2] Selected:', state._lastActive.type);

            }

        });

        state.canvas.on('selection:updated', function(e) {

            if (e.selected && e.selected.length > 0) {

                state._lastActive = e.selected[0];

                console.log('[v2] Selected (updated):', state._lastActive.type);

            }

        });

        state.canvas.on('selection:cleared', function() {

            console.log('[v2] Selection cleared');

            // Jangan hapus _lastActive - biar bisa hapus terakhir yang dipilih

        });



        // V9.161.0: dblclick untuk edit text (fungsi di scope modul)

        state.canvas.on('mouse:dblclick', function (opt) {

            if (opt.target && (opt.target === state.titleText || opt.target === state.subtitleText)) {

                openEditModal(opt.target);

            }

        });



        // V9.161.0: modal dipindah ke scope modul



        // V9.151.0: DELETE FEATURE - hapus elemen dengan Delete/Backspace

        document.addEventListener('keydown', function(e) {

            // Cek input field active - jangan hapus text input

            const activeEl = document.activeElement;

            if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {

                return;

            }



            if (e.key === 'Delete' || e.key === 'Backspace') {

                const active = state.canvas.getActiveObject();

                if (!active) return;



                // Jangan hapus background image

                if (active === state.bgImage) return;



                // Jangan hapus border rect

                if (active === state.borderRect) return;



                e.preventDefault();



                // Kalau hapus title text

                if (active === state.titleText) {

                    state.titleText = null;

                    document.getElementById('ts2Title').value = '';

                }

                // Kalau hapus subtitle

                else if (active === state.subtitleText) {

                    state.subtitleText = null;

                    document.getElementById('ts2Subtitle').value = '';

                }

                // Hapus icon

                else if (state.icons.indexOf(active) !== -1) {

                    state.icons = state.icons.filter(i => i !== active);

                }



                state.canvas.remove(active);

                state.canvas.discardActiveObject();

                state.canvas.renderAll();

                console.log('[v2] Element deleted');

            }

        });



        // V9.151.0: Delete via double-click toolbar (mobile friendly)

        // V9.154.2: SIMPLE TAB - tab navigation

        document.querySelectorAll('.ts2-tab').forEach(function(tab) {

            tab.addEventListener('click', function() {

                // Update tab active

                document.querySelectorAll('.ts2-tab').forEach(t => t.classList.remove('active'));

                tab.classList.add('active');



                // Update content

                const target = tab.dataset.tab;

                document.querySelectorAll('.ts2-tab-content').forEach(c => c.classList.remove('active'));

                const targetContent = document.querySelector('[data-tab-content="' + target + '"]');

                if (targetContent) targetContent.classList.add('active');



                console.log('[v2] Tab: ' + target);

            });

        });



        // Panel close button (mobile)

        document.getElementById('ts2PanelToggle')?.addEventListener('click', function() {

            const panel = document.querySelector('.ts2-panel');

            if (!panel) return;

            if (panel.style.transform === 'translateX(100%)') {

                panel.style.transform = '';

                panel.style.opacity = '';

            } else {

                panel.style.transform = 'translateX(100%)';

                panel.style.opacity = '0';

                panel.style.transition = 'all 0.3s';

            }

        });



        // Window resize

        window.addEventListener('resize', fitCanvas);



        console.log('[ThumbnailStudio v2] Ready');



        // V9.150.1: Pastikan empty state visible kalau canvas belum aktif

        const canvasWrap = document.getElementById('ts2CanvasWrap');

        const emptyState = document.getElementById('ts2Empty');

        if (canvasWrap && emptyState) {

            if (canvasWrap.classList.contains('active')) {

                emptyState.style.display = 'none';

            } else {

                emptyState.style.display = 'flex';

            }

        }

    }



    // ============================================================

    // TEXT

    // ============================================================

    function addTexts() {

        if (!state.canvas) return;



        const titleVal = document.getElementById('ts2Title').value || '';

        const subVal = document.getElementById('ts2Subtitle').value || '';



        if (state.titleText) state.canvas.remove(state.titleText);

        if (state.subtitleText) state.canvas.remove(state.subtitleText);



        // Posisi Y berdasarkan pos

        let titleY, subY;

        if (state.currentPos === 'top') {

            titleY = state.currentH * 0.18;

            subY = state.currentH * 0.32;

        } else if (state.currentPos === 'bottom') {

            titleY = state.currentH * 0.72;

            subY = state.currentH * 0.84;

        } else {

            titleY = state.currentH * 0.45;

            subY = state.currentH * 0.60;

        }



        const bgProps = state.bgEnabled ? {

            backgroundColor: 'rgba(0,0,0,0.75)',

            padding: Math.round(state.currentW * 0.02),

        } : {};



        state.titleText = new fabric.Textbox(titleVal, Object.assign({

            left: state.currentW / 2,

            top: titleY,

            originX: 'center',

            originY: 'center',

            width: state.currentW * 0.85,

            fontFamily: state.currentFont + ', sans-serif',

            fontSize: Math.round(state.currentW * 0.09 * state.sizeMultiplier),

            fontWeight: 'bold',

            fill: state.currentColor,

            stroke: '#000',

            strokeWidth: state.strokeWidth,

            paintFirst: 'stroke',

            textAlign: 'center',

            shadow: 'rgba(0,0,0,0.8) 2px 2px 6px',

            selectable: true,

            evented: true,

            hasControls: true,

            hasBorders: true,

            transparentCorners: false,

            cornerColor: '#f59e0b',

            cornerSize: 12,

            cornerStyle: 'circle',

            borderColor: '#f59e0b',

        }, bgProps));



        if (subVal) {

            state.subtitleText = new fabric.Textbox(subVal, Object.assign({

                left: state.currentW / 2,

                top: subY,

                originX: 'center',

                originY: 'center',

                width: state.currentW * 0.85,

                fontFamily: 'Poppins, sans-serif',

                fontSize: Math.round(state.currentW * 0.035 * state.sizeMultiplier),

                fontWeight: 'bold',

                fill: '#ffffff',

                stroke: '#000',

                strokeWidth: Math.min(3, state.strokeWidth),

                paintFirst: 'stroke',

                textAlign: 'center',

                shadow: 'rgba(0,0,0,0.8) 2px 2px 4px',

                selectable: true,

                evented: true,

                hasControls: true,

                hasBorders: true,

                transparentCorners: false,

                cornerColor: '#f59e0b',

                cornerSize: 12,

                cornerStyle: 'circle',

                borderColor: '#f59e0b',

            }, bgProps));

        }



        state.canvas.add(state.titleText);

        if (state.subtitleText) state.canvas.add(state.subtitleText);



        // Re-add border on top

        redrawBorder();



        state.canvas.renderAll();

    }



    // ============================================================

    // UPLOAD

    // ============================================================

    function handleUpload(file) {

        const reader = new FileReader();

        reader.onload = function (e) {

            fabric.Image.fromURL(e.target.result, function (img) {

                if (!state.canvas) return;



                // Show canvas

                // V9.150.1: POLISH JS - hide empty state

                document.getElementById('ts2Empty').style.display = 'none';

                document.getElementById('ts2CanvasWrap').classList.add('active');

                document.getElementById('ts2Actions').classList.add('active');

                document.getElementById('ts2Download').disabled = false;



                // Fit image cover

                const cw = state.currentW;

                const ch = state.currentH;

                const iw = img.width;

                const ih = img.height;

                const scale = Math.max(cw / iw, ch / ih);



                img.set({

                    scaleX: scale,

                    scaleY: scale,

                    left: (cw - iw * scale) / 2,

                    top: (ch - ih * scale) / 2,

                    selectable: false,

                    evented: false,

                });



                state.canvas.clear();

                state.canvas.add(img);

                state.bgImage = img;



                // Add texts back

                addTexts();



                // Fit canvas to viewport

                fitCanvas();

            });

        };

        reader.readAsDataURL(file);

    }




    // ============================================================
    // V9.187.0: LAYER UPLOAD (foto/stiker tambahan, multi)
    // ============================================================
    function handleUploadLayer(file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            fabric.Image.fromURL(e.target.result, function (img) {
                if (!state.canvas) return;

                // Hitung layer tambahan (bukan background)
                const layers = state.canvas.getObjects().filter(o => o._isLayer);
                const idx = layers.length;

                // Set ukuran & posisi (offset biar tidak tumpuk)
                img.set({
                    left: 80 + (idx * 30),
                    top: 80 + (idx * 30),
                    scaleX: 0.35,
                    scaleY: 0.35,
                    selectable: true,
                    evented: true,
                    hasControls: true,
                    hasBorders: true,
                    cornerColor: '#8b5cf6',
                    cornerSize: 12,
                    transparentCorners: false,
                });
                img._isLayer = true;

                state.canvas.add(img);
                state.canvas.setActiveObject(img);
                state.canvas.renderAll();

                console.log(`[Layer] +Layer #${idx + 1} (${file.name || 'image'})`);
            });
        };
        reader.readAsDataURL(file);
    }

    // ============================================================

    // BORDER

    // ============================================================

    function applyBorder(name) {

        state.currentBorder = name;

        redrawBorder();

    }



    function redrawBorder() {

        if (!state.canvas) return;



        if (state.borderRect) {

            state.canvas.remove(state.borderRect);

            state.borderRect = null;

        }



        if (state.currentBorder === 'none') {

            state.canvas.renderAll();

            return;

        }



        const config = {

            white: { color: '#ffffff', width: 8, radius: 0 },

            black: { color: '#000000', width: 8, radius: 0 },

            neon: { color: '#f59e0b', width: 10, radius: 15, glow: true },

            pink: { color: '#ec4899', width: 8, radius: 20 },

            rounded: { color: '#ffffff', width: 8, radius: 40 },

        }[state.currentBorder];



        if (!config) return;



        const inset = config.width / 2 + 4;

        const rect = new fabric.Rect({

            left: inset,

            top: inset,

            width: state.currentW - inset * 2,

            height: state.currentH - inset * 2,

            fill: 'transparent',

            stroke: config.color,

            strokeWidth: config.width,

            rx: config.radius || 0,

            ry: config.radius || 0,

            selectable: false,

            evented: false,

            shadow: config.glow ? 'rgba(245,158,11,0.8) 0 0 20px' : null,

        });



        state.borderRect = rect;

        state.canvas.add(rect);

        // V9.192.0: BORDER ON TOP

        if (state.bgImage) state.canvas.sendToBack(state.bgImage);

        state.canvas.bringToFront(rect);

        if (state.titleText) state.canvas.bringToFront(state.titleText);

        if (state.subtitleText) state.canvas.bringToFront(state.subtitleText);



        state.canvas.renderAll();

    }



    // ============================================================

    // ICON

    // ============================================================

    const EMOJI = {

        star: '\u2B50',                    //
        heart: '\u2764\uFE0F',            //
        fire: '\uD83D\uDD25',             //
        bolt: '\u26A1',                    //
        check: '\u2705',                   //
        crown: '\uD83D\uDC51',            //
    };



    function addIcon(name) {

        if (!state.canvas) return;

        const emoji = EMOJI[name] || '-';

        const size = Math.round(state.currentW * 0.12);



        const icon = new fabric.Text(emoji, {

            left: state.currentW * 0.82,

            top: state.currentH * 0.18,

            originX: 'center',

            originY: 'center',

            fontFamily: 'Segoe UI Emoji, Apple Color Emoji, sans-serif',

            fontSize: size,

            selectable: true,

            evented: true,

            hasControls: true,

            hasBorders: true,

            transparentCorners: false,

            cornerColor: '#f59e0b',

            cornerSize: 12,

            cornerStyle: 'circle',

            borderColor: '#f59e0b',

        });



        state.canvas.add(icon);

        state.canvas.setActiveObject(icon);

        state.canvas.renderAll();

        state.icons.push(icon);

    }



    // ============================================================

    // CANVAS FIT

    // ============================================================

    function fitCanvas() {
        // V9.215.1: FIT CANVAS BY WIDTH - preview besar di mobile
        if (!state.canvas) return;
        const wrap = document.getElementById('ts2CanvasWrap');
        if (!wrap) return;
        const parent = wrap.parentElement;
        if (!parent) return;

        const isMobile = window.innerWidth <= 1024;

        if (isMobile) {
            // Mobile: fit ke LEBAR parent
            const maxW = parent.clientWidth - 16;
            const scale = maxW / state.currentW;

            state.canvas.setDimensions({
                width: state.currentW * scale,
                height: state.currentH * scale,
            });
            state.canvas.setZoom(scale);
            // Set style width 100%
            const canvasEl = state.canvas.getElement();
            if (canvasEl) {
                canvasEl.style.width = '100%';
                canvasEl.style.height = 'auto';
            }
        } else {
            // Desktop: fit ke width & height
            const maxW = parent.clientWidth - 40;
            const maxH = parent.clientHeight - 100;
            const scale = Math.min(1, maxW / state.currentW, maxH / state.currentH);

            state.canvas.setDimensions({
                width: state.currentW * scale,
                height: state.currentH * scale,
            });
            state.canvas.setZoom(scale);
        }

        state.canvas.renderAll();
    }



    // ============================================================

    // ASPECT

    // ============================================================

    function changeAspect(w, h) {

        state.currentW = w;

        state.currentH = h;



        if (state.bgImage && state.bgImage._element) {

            const src = state.bgImage._element.src;

            fabric.Image.fromURL(src, function (img) {

                const scale = Math.max(w / img.width, h / img.height);

                img.set({

                    scaleX: scale, scaleY: scale,

                    left: (w - img.width * scale) / 2,

                    top: (h - img.height * scale) / 2,

                    selectable: false, evented: false,

                });

                state.canvas.clear();

                state.canvas.add(img);

                state.bgImage = img;

                addTexts();

                state.canvas.setDimensions({ width: w, height: h });

                setTimeout(fitCanvas, 50);

            });

        } else {

            state.canvas.setDimensions({ width: w, height: h });

            setTimeout(fitCanvas, 50);

        }

    }



    // ============================================================

    // DOWNLOAD

    // ============================================================

    function download() {

        if (!state.canvas) return;

        const prevZoom = state.canvas.getZoom();

        state.canvas.setZoom(1);

        state.canvas.setDimensions({ width: state.currentW, height: state.currentH });

        state.canvas.renderAll();



        const dataURL = state.canvas.toDataURL({ format: 'png', quality: 1 });



        state.canvas.setZoom(prevZoom);

        setTimeout(fitCanvas, 50);



        const a = document.createElement('a');

        a.href = dataURL;

        a.download = 'thumbnail-' + Date.now() + '.png';

        a.click();

    }



    // ============================================================

    // TEMPLATE APPLY

    // ============================================================

    function applyTemplate(name) {

        // V9.151.0: Reset icons + border saat ganti template

        if (state.canvas) {

            // Hapus semua icons

            state.icons.forEach(function(icon) {

                state.canvas.remove(icon);

            });

            state.icons = [];



            // Reset border

            state.currentBorder = 'none';

            if (state.borderRect) {

                state.canvas.remove(state.borderRect);

                state.borderRect = null;

            }

            // Sync border button

            document.querySelectorAll('[data-border]').forEach(b => {

                b.classList.toggle('active', b.dataset.border === 'none');

            });

        }



        const tpl = TEMPLATES[name];

        if (!tpl) return;



        state.currentTemplate = name;

        if (tpl.font) state.currentFont = tpl.font;

        if (tpl.color) state.currentColor = tpl.color;

        if (tpl.position) state.currentPos = tpl.position;

        if (tpl.sizeMultiplier) state.sizeMultiplier = tpl.sizeMultiplier;

        if (tpl.strokeWidth !== undefined) state.strokeWidth = tpl.strokeWidth;

        if (tpl.bgEnabled !== undefined) state.bgEnabled = tpl.bgEnabled;



        // Sync UI

        const fontSel = document.getElementById('ts2Font');

        if (fontSel) fontSel.value = tpl.font;

        const sizeS = document.getElementById('ts2Size');

        if (sizeS) sizeS.value = Math.round(tpl.sizeMultiplier * 100);

        const sizeV = document.getElementById('ts2SizeVal');

        if (sizeV) sizeV.textContent = Math.round(tpl.sizeMultiplier * 100) + '%';

        const strokeS = document.getElementById('ts2Stroke');

        if (strokeS) strokeS.value = tpl.strokeWidth;

        const strokeV = document.getElementById('ts2StrokeVal');

        if (strokeV) strokeV.textContent = tpl.strokeWidth + 'px';

        document.querySelectorAll('[data-pos]').forEach(b => {

            b.classList.toggle('active', b.dataset.pos === tpl.position);

        });

        document.querySelectorAll('#ts2Colors .ts2-color').forEach(b => {

            b.classList.toggle('active', b.dataset.color === tpl.color);

        });

        const bgT = document.getElementById('ts2BgEnabled');

        if (bgT) bgT.checked = state.bgEnabled;



        addTexts();

    }



    // ============================================================

    // EVENT BINDINGS

    // ============================================================

    function bindEvents() {

        // Upload

        // V9.155.0: NULL GUARD

        const upBtn = document.getElementById('ts2UploadBtn');

        const fileInput = document.getElementById('ts2File');

        if (upBtn && fileInput) {

            upBtn.onclick = () => fileInput.click();

        }

        // V9.187.0: Bind tombol "Tambah Foto / Stiker"
        const layerBtn = document.getElementById('ts2UploadLayerBtn');
        const layerInput = document.getElementById('ts2LayerFile');

        if (layerBtn && layerInput) {
            layerBtn.onclick = () => layerInput.click();
            console.log('[V2] Layer upload button bound');

            layerInput.onchange = (e) => {
                const files = Array.from(e.target.files || []);
                if (files.length > 0) {
                    files.forEach((f, i) => {
                        setTimeout(() => handleUploadLayer(f), i * 150);
                    });
                }
                e.target.value = '';
            };
        } else {
            console.warn('[V2] Layer upload button NOT found');
        }

        document.getElementById('ts2File').onchange = (e) => {
            const files = Array.from(e.target.files || []);
            if (files.length > 0) {
                // V9.186.0: MULTI UPLOAD - loop semua file
                files.forEach((f, idx) => {
                    setTimeout(() => handleUpload(f), idx * 150);
                });
            }
            // Reset value biar bisa upload file yang sama lagi
            e.target.value = '';

        };



        // Drag & drop canvas

        const canvasArea = document.querySelector('.ts2-canvas');

        canvasArea.addEventListener('dragover', e => { e.preventDefault(); });

        canvasArea.addEventListener('drop', e => {

            e.preventDefault();

            const f = e.dataTransfer.files[0];

            if (f && f.type.startsWith('image/')) handleUpload(f);

        });



        // Text

        document.getElementById('ts2Title').oninput = addTexts;

        document.getElementById('ts2Subtitle').oninput = addTexts;



        // Color

        document.querySelectorAll('#ts2Colors .ts2-color').forEach(btn => {

            btn.onclick = () => {

                if (btn.dataset.color === 'custom') {

                    document.getElementById('ts2CustomColor').click();

                    return;

                }

                document.querySelectorAll('#ts2Colors .ts2-color').forEach(b => b.classList.remove('active'));

                btn.classList.add('active');

                state.currentColor = btn.dataset.color;

                addTexts();

            };

        });

        document.getElementById('ts2CustomColor').oninput = (e) => {

            state.currentColor = e.target.value;

            document.querySelectorAll('#ts2Colors .ts2-color').forEach(b => b.classList.remove('active'));

            document.querySelector('.ts2-color-custom').classList.add('active');

            addTexts();

        };



        // Font

        document.getElementById('ts2Font').onchange = (e) => {

            state.currentFont = e.target.value;

            addTexts();

        };



        // Size

        document.getElementById('ts2Size').oninput = (e) => {

            state.sizeMultiplier = e.target.value / 100;

            document.getElementById('ts2SizeVal').textContent = e.target.value + '%';

            addTexts();

        };



        // Stroke

        document.getElementById('ts2Stroke').oninput = (e) => {

            state.strokeWidth = parseInt(e.target.value);

            document.getElementById('ts2StrokeVal').textContent = e.target.value + 'px';

            addTexts();

        };



        // Position

        document.querySelectorAll('[data-pos]').forEach(btn => {

            btn.onclick = () => {

                document.querySelectorAll('[data-pos]').forEach(b => b.classList.remove('active'));

                btn.classList.add('active');

                state.currentPos = btn.dataset.pos;

                addTexts();

            };

        });



        // Background text

        document.getElementById('ts2BgEnabled').onchange = (e) => {

            state.bgEnabled = e.target.checked;

            addTexts();

        };



        // Border

        document.querySelectorAll('[data-border]').forEach(btn => {

            btn.onclick = () => {

                document.querySelectorAll('[data-border]').forEach(b => b.classList.remove('active'));

                btn.classList.add('active');

                applyBorder(btn.dataset.border);

            };

        });



        // Icon

        document.querySelectorAll('[data-icon]').forEach(btn => {

            btn.onclick = () => addIcon(btn.dataset.icon);

        });



        // Aspect

        document.querySelectorAll('[data-aspect]').forEach(btn => {

            btn.onclick = () => {

                document.querySelectorAll('[data-aspect]').forEach(b => b.classList.remove('active'));

                btn.classList.add('active');

                const [w, h] = btn.dataset.aspect.split('x').map(Number);

                changeAspect(w, h);

            };

        });



        // Template

        document.querySelectorAll('.ts2-tpl').forEach(btn => {

            btn.onclick = () => {

                document.querySelectorAll('.ts2-tpl').forEach(b => b.classList.remove('active'));

                btn.classList.add('active');

                applyTemplate(btn.dataset.tpl);

            };

        });



        // Download

        document.getElementById('ts2Download').onclick = download;

        document.getElementById('ts2QuickDownload').onclick = download;



        // Sidebar scroll

        document.querySelectorAll('[data-scroll]').forEach(btn => {

            btn.onclick = () => {

                document.querySelectorAll('.ts2-sidebar-btn').forEach(b => b.classList.remove('active'));

                btn.classList.add('active');

                const keyword = btn.dataset.scroll;

                const body = document.getElementById('ts2PanelBody');

                if (!body) return;

                const sections = body.querySelectorAll('.ts2-section');

                sections.forEach(sec => {

                    const label = sec.querySelector('.ts2-label');

                    if (label && label.textContent.toLowerCase().includes(keyword)) {

                        sec.scrollIntoView({ behavior: 'smooth', block: 'start' });

                    }

                });

            };

        });



        // V9.155.0: NULL GUARD - Guide toggle (opsional)

        const guideBtn = document.getElementById('ts2QuickGuide');

        const guideEl = document.getElementById('ts2Guide');

        if (guideBtn && guideEl) {

            guideBtn.onclick = () => {

                guideEl.classList.toggle('active');

            };

        }



        // V9.163.0: DELETE INLINE FIX - inline function

        (function() {

            var delBtn = document.getElementById('ts2QuickDelete');

            if (!delBtn) {

                console.warn('[v2] ts2QuickDelete tidak ketemu');

                return;

            }



            var newBtn = delBtn.cloneNode(true);

            delBtn.parentNode.replaceChild(newBtn, delBtn);



            newBtn.addEventListener('click', function(e) {

                e.preventDefault();

                console.log('[v2] Delete button clicked');



                if (!state || !state.canvas) {

                    console.warn('[v2] state.canvas tidak ada');

                    return;

                }



                // V9.165.0: pakai _lastActive, fallback ke getActiveObject

                var active = state._lastActive || state.canvas.getActiveObject();

                if (!active) {

                    console.warn('[v2] Tidak ada elemen terpilih');

                    return;

                }

                if (active === state.bgImage) {

                    console.warn('[v2] Background tidak bisa dihapus');

                    return;

                }

                if (active === state.borderRect) {

                    console.warn('[v2] Border tidak bisa dihapus');

                    return;

                }



                if (active === state.titleText) {

                    state.titleText = null;

                    var t = document.getElementById('ts2Title');

                    if (t) t.value = '';

                } else if (active === state.subtitleText) {

                    state.subtitleText = null;

                    var s = document.getElementById('ts2Subtitle');

                    if (s) s.value = '';

                } else if (state.icons && state.icons.indexOf(active) !== -1) {

                    state.icons = state.icons.filter(function(i) { return i !== active; });

                }



                state.canvas.remove(active);

                state.canvas.discardActiveObject();

                state.canvas.renderAll();

                console.log('[v2] Element deleted');

            });



            console.log('[v2] Delete button bound (inline)');

        })();



        // V9.155.0: NULL GUARD - Reset (id baru: ts2ResetBtn mungkin beda)

        const resetBtn = document.getElementById('ts2ResetBtn');

        if (resetBtn) {

            resetBtn.onclick = () => {

                const titleEl = document.getElementById('ts2Title');

                const subEl = document.getElementById('ts2Subtitle');

                if (titleEl) titleEl.value = 'JUDUL VIDEO';

                if (subEl) subEl.value = 'Subtitle di sini';

                document.querySelectorAll('.ts2-tpl').forEach(b => b.classList.remove('active'));

                const ytBtn = document.querySelector('.ts2-tpl[data-tpl="youtube"]');

                if (ytBtn) ytBtn.classList.add('active');

                applyTemplate('youtube');

            };

        }



        // Sidebar download

        // V9.160.2: MODAL JS - bind events

        const modalInput = document.getElementById('ts2ModalInput');

        const modalSave = document.getElementById('ts2ModalSave');



        if (modalInput) {

            modalInput.addEventListener('keydown', function(e) {

                if (e.key === 'Enter') {

                    e.preventDefault();

                    saveEditModal();

                } else if (e.key === 'Escape') {

                    e.preventDefault();

                    closeEditModal();

                }

            });

        }

        if (modalSave) {

            modalSave.onclick = saveEditModal;

        }



        // ESC global close

        document.addEventListener('keydown', function(e) {

            if (e.key === 'Escape') {

                const modal = document.getElementById('ts2EditModal');

                if (modal && modal.classList.contains('active')) {

                    closeEditModal();

                }

            }

        });



        // V9.155.0: NULL GUARD - Sidebar download (opsional)

        const sideDl = document.getElementById('ts2DownloadBtn');

        if (sideDl) sideDl.onclick = download;

    }



    // ============================================================

    // V9.167.2: KEYBOARD BIND

    function bindKeyboard() {

        document.addEventListener("keydown", handleKeydown);

        console.log("[v2] Keyboard shortcuts bound");

    }



    // V9.167.2: TRACK SELECTION

    function trackSelection() {

        if (!state.canvas) return;

        state.canvas.on("selection:created", function(e) {

            if (e.selected && e.selected.length > 0) state._lastActive = e.selected[0];

        });

        state.canvas.on("selection:updated", function(e) {

            if (e.selected && e.selected.length > 0) state._lastActive = e.selected[0];

        });

    }



    // V9.167.2: HISTORY EVENTS

    function setupHistory() {

        if (!state.canvas) return;

        setTimeout(function() { saveHistory(); }, 500);

        state.canvas.on("object:added", function() {

            if (state._restoring) return;

            clearTimeout(window._histDebounce);

            window._histDebounce = setTimeout(saveHistory, 300);

        });

        state.canvas.on("object:modified", function() {

            if (state._restoring) return;

            clearTimeout(window._histDebounce);

            window._histDebounce = setTimeout(saveHistory, 300);

        });

        state.canvas.on("object:removed", function() {

            if (state._restoring) return;

            clearTimeout(window._histDebounce);

            window._histDebounce = setTimeout(saveHistory, 300);

        });

    }



    // BOOT

    // ============================================================

    document.addEventListener('DOMContentLoaded', function () {

        init();

        bindKeyboard();

        trackSelection();

        setupHistory();

        bindEvents();

    });



    window.ThumbnailStudioV2 = {

        // V9.170.0: EXPORT BORDER + ICON + TEMPLATE

        applyBorder: typeof applyBorder !== 'undefined' ? applyBorder : function(){},

        addIcon: typeof addIcon !== 'undefined' ? addIcon : function(){},

        applyTemplate: typeof applyTemplate !== 'undefined' ? applyTemplate : function(){},

        undo: undo,

        redo: redo,

        copyElement: copyElement,

        pasteElement: pasteElement,

        duplicateElement: duplicateElement,

        selectAllElements: selectAllElements,

        openEditModal: openEditModal,

        closeEditModal: closeEditModal,

        saveEditModal: saveEditModal, state, download,

        deleteSelected: function() {

            const active = state.canvas?.getActiveObject();

            if (!active || active === state.bgImage || active === state.borderRect) return;



            if (active === state.titleText) {

                state.titleText = null;

                document.getElementById('ts2Title').value = '';

            } else if (active === state.subtitleText) {

                state.subtitleText = null;

                document.getElementById('ts2Subtitle').value = '';

            } else if (state.icons.indexOf(active) !== -1) {

                state.icons = state.icons.filter(i => i !== active);

            }



            state.canvas.remove(active);

            state.canvas.discardActiveObject();

            state.canvas.renderAll();

        }

    };



    // ============================================================
    // V9.188.0: LAYER CONTROL PANEL
    // ============================================================
    function initLayerControls() {
        const controls = document.getElementById('ts2LayerControls');
        const nameEl = document.getElementById('ts2LcLayerName');
        const opSlider = document.getElementById('ts2LcOpacity');
        const opVal = document.getElementById('ts2LcOpacityVal');
        const delBtn = document.getElementById('ts2LcDelete');
        const dupBtn = document.getElementById('ts2LcDuplicate');

        // V9.200.1: Z-ORDER BUTTONS
        var upBtn = document.getElementById('ts2LcUp');
        var downBtn = document.getElementById('ts2LcDown');
        var frontBtn = document.getElementById('ts2LcFront');
        var backBtn = document.getElementById('ts2LcBack');

        if (upBtn) {
            upBtn.onclick = function() {
                var active = state.canvas.getActiveObject() || currentObj;
                if (!active) return;
                active.bringForward();
                state.canvas.renderAll();
                if (typeof renderLayerList === 'function') renderLayerList();
            };
        }
        if (downBtn) {
            downBtn.onclick = function() {
                var active = state.canvas.getActiveObject() || currentObj;
                if (!active) return;
                active.sendBackwards();
                state.canvas.renderAll();
                if (typeof renderLayerList === 'function') renderLayerList();
            };
        }
        if (frontBtn) {
            frontBtn.onclick = function() {
                var active = state.canvas.getActiveObject() || currentObj;
                if (!active) return;
                state.canvas.bringToFront(active);
                state.canvas.renderAll();
                if (typeof renderLayerList === 'function') renderLayerList();
            };
        }
        if (backBtn) {
            backBtn.onclick = function() {
                var active = state.canvas.getActiveObject() || currentObj;
                if (!active) return;
                state.canvas.sendToBack(active);
                state.canvas.renderAll();
                if (typeof renderLayerList === 'function') renderLayerList();
            };
        }

        if (!controls || !opSlider) {
            console.warn('[V9.188.0] Layer controls not found in DOM');
            return;
        }

        if (!state || !state.canvas) {
            console.warn('[V9.188.0] state.canvas tidak ready');
            return;
        }

        let currentObj = null;

        function showControls(obj) {
            if (!obj || obj === state.bgImage || obj === state.borderRect) {
                controls.style.display = 'none';
                currentObj = null;
                return;
            }
            currentObj = obj;
            controls.style.display = 'block';

            let type = 'Layer';
            if (obj === state.titleText) type = 'Judul';
            else if (obj === state.subtitleText) type = 'Subtitle';
            else if (obj._isLayer) type = 'Foto/Stiker';
            else if (state.icons && state.icons.indexOf(obj) !== -1) type = 'Icon';
            nameEl.textContent = type;

            const op = Math.round((obj.opacity || 1) * 100);
            opSlider.value = op;
            opVal.textContent = op + '%';
        }

        function hideControls() {
            controls.style.display = 'none';
            currentObj = null;
        }

        opSlider.addEventListener('input', () => {
            if (!currentObj) return;
            const val = parseInt(opSlider.value);
            currentObj.set('opacity', val / 100);
            opVal.textContent = val + '%';
            state.canvas.renderAll();
        });

        delBtn.addEventListener('click', () => {
            if (!currentObj) return;
            state.canvas.remove(currentObj);
            state.canvas.discardActiveObject();
            state.canvas.renderAll();
            hideControls();
        });

        dupBtn.addEventListener('click', () => {
            if (!currentObj) return;
            currentObj.clone((cloned) => {
                cloned.set({
                    left: (currentObj.left || 0) + 30,
                    top: (currentObj.top || 0) + 30,
                    _isLayer: true,
                });
                state.canvas.add(cloned);
                state.canvas.setActiveObject(cloned);
                state.canvas.renderAll();
                showControls(cloned);
            });
        });

        state.canvas.on('selection:created', (e) => {
            if (e.selected && e.selected.length > 0) showControls(e.selected[0]);
        });
        state.canvas.on('selection:updated', (e) => {
            if (e.selected && e.selected.length > 0) showControls(e.selected[0]);
        });
        state.canvas.on('selection:cleared', hideControls);

        console.log('[V9.188.0] Layer controls ready');
    }

    // Auto-init
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(initLayerControls, 800);
        });
    } else {
        setTimeout(initLayerControls, 800);
    }

    // ============================================================
    // V9.189.0: LAYER LIST PANEL (sidebar)
    // ============================================================
    function renderLayerList() {
        const list = document.getElementById('ts2LayerList');
        if (!list) return;
        if (!state || !state.canvas) return;

        const objects = state.canvas.getObjects().slice().reverse();
        const active = state.canvas.getActiveObject();

        list.innerHTML = '';

        if (objects.length === 0) {
            list.innerHTML = '<div class="ts2-layer-empty"><i class="fas fa-inbox"></i><small>Belum ada layer</small></div>';
            return;
        }

        objects.forEach((obj, idx) => {
            const item = document.createElement('div');
            item.className = 'ts2-layer-item';
            if (obj === active) item.classList.add('active');
            if (obj.visible === false) item.classList.add('hidden-layer');

            // Icon & nama
            let icon = '🖼️';
            let name = 'Layer';

            if (obj === state.bgImage) { icon = '🎨'; name = 'Background'; }
            else if (obj === state.borderRect) { icon = '⬛'; name = 'Border'; }
            else if (obj === state.titleText) { icon = '📝'; name = 'Judul'; }
            else if (obj === state.subtitleText) { icon = '📝'; name = 'Subtitle'; }
            else if (obj._isLayer) { icon = '🖼️'; name = 'Foto/Stiker'; }
            else if (obj.type === 'textbox' || obj.type === 'text') {
                icon = '📝';
                name = (obj.text || 'Text').substring(0, 18);
            }
            else if (state.icons && state.icons.indexOf(obj) !== -1) { icon = '😀'; name = 'Emoji'; }

            item.innerHTML = `
                <span class="ts2-layer-icon">${icon}</span>
                <span class="ts2-layer-name">${name}</span>
                <button class="ts2-layer-btn" data-action="toggle" title="Show/Hide"><i class="fas fa-eye"></i></button>
                <button class="ts2-layer-btn danger" data-action="delete" title="Hapus"><i class="fas fa-times"></i></button>
            `;

            // Klik item → select
            item.onclick = (e) => {
                if (e.target.closest('.ts2-layer-btn')) return;
                state.canvas.setActiveObject(obj);
                state.canvas.renderAll();
                renderLayerList();
                // V9.204.0: Trigger panel kontrol update
                if (typeof showControls === 'function') {
                    showControls(obj);
                } else if (window._ts2ShowControls) {
                    window._ts2ShowControls(obj);
                }
            };

            // Toggle visibility
            const toggleBtn = item.querySelector('[data-action="toggle"]');
            toggleBtn.onclick = (e) => {
                e.stopPropagation();
                obj.visible = !obj.visible;
                state.canvas.renderAll();
                renderLayerList();
            };
            if (obj.visible === false) {
                toggleBtn.innerHTML = '<i class="fas fa-eye-slash"></i>';
            }

            // Delete
            const delBtn = item.querySelector('[data-action="delete"]');
            delBtn.onclick = (e) => {
                e.stopPropagation();
                if (obj === state.bgImage) {
                    showTs2Toast('Background tidak bisa dihapus. Ganti Background untuk ubah.', 'warning');
                    return;
                }
                state.canvas.remove(obj);
                state.canvas.discardActiveObject();
                state.canvas.renderAll();
                renderLayerList();
            };

            list.appendChild(item);
        });
    }

    // Auto-refresh layer list saat ada perubahan
    function hookLayerListAutoRefresh() {
        if (!state || !state.canvas) return;
        const events = [
            'object:added',
            'object:removed',
            'object:modified',
            'selection:created',
            'selection:updated',
            'selection:cleared',
        ];
        events.forEach(ev => {
            state.canvas.on(ev, () => {
                setTimeout(renderLayerList, 50);
            });
        });
        renderLayerList();
        console.log('[V9.189.0] Layer list auto-refresh hooked');
    }

    // Init setelah canvas ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(hookLayerListAutoRefresh, 1200);
        });
    } else {
        setTimeout(hookLayerListAutoRefresh, 1200);
    }

    // ============================================================
    // V9.201.0: CROP LAYER (re-add)
    // ============================================================
    var _cropState = {
        active: false,
        target: null,
        rect: null,
    };

    function startCrop() {
        var active = state.canvas.getActiveObject();
        if (!active || active.type !== 'image') {
            if (typeof showTs2Toast === 'function') {
                showTs2Toast('Pilih layer gambar dulu di canvas', 'warning');
            } else {
                showTs2Toast('Pilih layer gambar dulu', 'warning');
            }
            return;
        }

        _cropState.active = true;
        _cropState.target = active;

        var bounds = active.getBoundingRect(true, true);
        var rect = new fabric.Rect({
            left: bounds.left + 30,
            top: bounds.top + 30,
            width: Math.max(bounds.width - 60, 100),
            height: Math.max(bounds.height - 60, 100),
            fill: 'rgba(139, 92, 246, 0.15)',
            stroke: '#8b5cf6',
            strokeWidth: 2,
            strokeDashArray: [8, 4],
            strokeUniform: true,
            selectable: true,
            evented: true,
            hasControls: true,
            hasBorders: true,
            cornerColor: '#8b5cf6',
            cornerSize: 14,
            transparentCorners: false,
            lockRotation: true,
        });
        rect._isCropRect = true;

        state.canvas.add(rect);
        state.canvas.setActiveObject(rect);
        state.canvas.renderAll();

        _cropState.rect = rect;

        var startBtn = document.getElementById('ts2CropStartBtn');
        var actions = document.getElementById('ts2CropActions');
        if (startBtn) {
            startBtn.classList.add('active');
            startBtn.innerHTML = '<i class="fas fa-crop-alt"></i> Mode Crop Aktif';
        }
        if (actions) actions.style.display = 'flex';
        if (actions) actions.style.gap = '8px';

        console.log('[Crop] Started');
    }

    function applyCrop() {
        if (!_cropState.active || !_cropState.target || !_cropState.rect) {
            console.warn('[Crop] State not ready');
            return;
        }

        var target = _cropState.target;
        var rect = _cropState.rect;

        try {
            var rectBounds = rect.getBoundingRect(true, true);
            var targetBounds = target.getBoundingRect(true, true);

            // Hitung area crop dalam koordinat gambar asli
            var scaleX = target.scaleX || 1;
            var scaleY = target.scaleY || 1;
            var angle = target.angle || 0;

            var relX = (rectBounds.left - targetBounds.left) / scaleX;
            var relY = (rectBounds.top - targetBounds.top) / scaleY;
            var relW = rectBounds.width / scaleX;
            var relH = rectBounds.height / scaleY;

            console.log('[Crop] relX=' + relX + ' relY=' + relY + ' relW=' + relW + ' relH=' + relH);

            // V9.209.0: Pakai cropX/cropY/width/height — native Fabric.js
            var newCropX = (target.cropX || 0) + relX;
            var newCropY = (target.cropY || 0) + relY;
            var newWidth = relW;
            var newHeight = relH;

            // Batas — jangan melebihi gambar asli
            var imgOriginalW = target._element.naturalWidth || target._element.width;
            var imgOriginalH = target._element.naturalHeight || target._element.height;

            if (newCropX < 0) newCropX = 0;
            if (newCropY < 0) newCropY = 0;
            if (newCropX + newWidth > imgOriginalW) newWidth = imgOriginalW - newCropX;
            if (newCropY + newHeight > imgOriginalH) newHeight = imgOriginalH - newCropY;

            // Set crop properties
            target.set({
                cropX: newCropX,
                cropY: newCropY,
                width: newWidth,
                height: newHeight,
                left: rectBounds.left,
                top: rectBounds.top,
            });

            target.setCoords();

            // Hapus crop rect dari canvas
            state.canvas.remove(rect);
            state.canvas.discardActiveObject();
            state.canvas.renderAll();

            console.log('[Crop] Applied — cropX=' + newCropX + ' cropY=' + newCropY + ' w=' + newWidth + ' h=' + newHeight);

            // Refresh layer list
            if (typeof renderLayerList === 'function') {
                setTimeout(renderLayerList, 100);
            }

        } catch (err) {
            console.error('[Crop] Error:', err);
        }

        // Reset state
        _cropState.active = false;
        _cropState.target = null;
        _cropState.rect = null;

        var startBtn = document.getElementById('ts2CropStartBtn');
        var actions = document.getElementById('ts2CropActions');
        if (startBtn) {
            startBtn.classList.remove('active');
            startBtn.innerHTML = '<i class="fas fa-crop-alt"></i> Mulai Crop';
        }
        if (actions) actions.style.display = 'none';
    }

    function cancelCrop() {
        if (_cropState.rect) {
            state.canvas.remove(_cropState.rect);
            state.canvas.renderAll();
        }
        endCrop();
    }

    function endCrop() {
        _cropState.active = false;
        _cropState.target = null;
        _cropState.rect = null;

        var startBtn = document.getElementById('ts2CropStartBtn');
        var actions = document.getElementById('ts2CropActions');
        if (startBtn) {
            startBtn.classList.remove('active');
            startBtn.innerHTML = '<i class="fas fa-crop-alt"></i> Mulai Crop';
        }
        if (actions) actions.style.display = 'none';
    }

    function initCrop() {
        var startBtn = document.getElementById('ts2CropStartBtn');
        var applyBtn = document.getElementById('ts2CropApplyBtn');
        var cancelBtn = document.getElementById('ts2CropCancelBtn');

        if (!startBtn) {
            console.warn('[V9.201.0] Crop elements not found');
            return;
        }

        startBtn.onclick = startCrop;
        if (applyBtn) applyBtn.onclick = applyCrop;
        if (cancelBtn) cancelBtn.onclick = cancelCrop;

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && _cropState.active) {
                cancelCrop();
            }
        });

        console.log('[V9.201.0] Crop ready');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(initCrop, 1700);
        });
    } else {
        setTimeout(initCrop, 1700);
    }

    // ============================================================
    // V9.210.0: FILTER & EFEK (CSS-based)
    // ============================================================
    var FILTER_STATE = { brightness: 100, contrast: 100, saturation: 100, blur: 0 };

    function applyFilters() {
        var canvasEl = state.canvas && state.canvas.getElement && state.canvas.getElement();
        if (!canvasEl) return;
        var css = [];
        if (FILTER_STATE.brightness !== 100) css.push('brightness(' + (FILTER_STATE.brightness / 100) + ')');
        if (FILTER_STATE.contrast !== 100) css.push('contrast(' + (FILTER_STATE.contrast / 100) + ')');
        if (FILTER_STATE.saturation !== 100) css.push('saturate(' + (FILTER_STATE.saturation / 100) + ')');
        if (FILTER_STATE.blur > 0) css.push('blur(' + (FILTER_STATE.blur / 10) + 'px)');
        canvasEl.style.filter = css.length > 0 ? css.join(' ') : 'none';
    }

    function applyPreset(preset) {
        var canvasEl = state.canvas && state.canvas.getElement && state.canvas.getElement();
        if (!canvasEl) return;
        var css = 'none';
        if (preset === 'bw') css = 'grayscale(1) contrast(1.1)';
        else if (preset === 'sepia') css = 'sepia(1)';
        else if (preset === 'vintage') css = 'sepia(0.6) contrast(0.9) brightness(1.05) saturate(0.7)';
        canvasEl.style.filter = css;
        var br = document.getElementById('ts2Brightness');
        var co = document.getElementById('ts2Contrast');
        var sa = document.getElementById('ts2Saturation');
        var bl = document.getElementById('ts2Blur');
        if (br) { br.value = 100; document.getElementById('ts2BrightnessVal').textContent = '100%'; }
        if (co) { co.value = 100; document.getElementById('ts2ContrastVal').textContent = '100%'; }
        if (sa) { sa.value = 100; document.getElementById('ts2SaturationVal').textContent = '100%'; }
        if (bl) { bl.value = 0; document.getElementById('ts2BlurVal').textContent = '0'; }
        console.log('[Filter] Preset ' + preset + ':', css);
    }

    function initFilters() {
        var brightness = document.getElementById('ts2Brightness');
        var contrast = document.getElementById('ts2Contrast');
        var saturation = document.getElementById('ts2Saturation');
        var blur = document.getElementById('ts2Blur');
        if (!brightness) return;
        brightness.oninput = function() {
            FILTER_STATE.brightness = parseInt(brightness.value);
            document.getElementById('ts2BrightnessVal').textContent = FILTER_STATE.brightness + '%';
            applyFilters();
        };
        contrast.oninput = function() {
            FILTER_STATE.contrast = parseInt(contrast.value);
            document.getElementById('ts2ContrastVal').textContent = FILTER_STATE.contrast + '%';
            applyFilters();
        };
        saturation.oninput = function() {
            FILTER_STATE.saturation = parseInt(saturation.value);
            document.getElementById('ts2SaturationVal').textContent = FILTER_STATE.saturation + '%';
            applyFilters();
        };
        blur.oninput = function() {
            FILTER_STATE.blur = parseInt(blur.value);
            document.getElementById('ts2BlurVal').textContent = FILTER_STATE.blur;
            applyFilters();
        };
        document.querySelectorAll('.ts2-filter-preset').forEach(function(btn) {
            btn.onclick = function() {
                document.querySelectorAll('.ts2-filter-preset').forEach(function(b) { b.classList.remove('active'); });
                btn.classList.add('active');
                applyPreset(btn.dataset.preset);
            };
        });
        console.log('[V9.210.0] Filter ready');
    }

    setTimeout(initFilters, 1500);

    // ============================================================
    // V9.210.0: STICKER LIBRARY
    // ============================================================
    var STICKER_DATA = {
        emoji: ['😀','😂','❤️','🔥','⭐','👍','🎉','💯','✨','🎯','😍','🤔','😱','😎','🥳','💪','🙏','👏','🤝','✌️','😅','😭','🤯','💖','🌟','⚡','💎','🎁','🏆','🥇'],
        arrow: ['→','←','↑','↓','↗','↘','↙','↖','➡️','⬅️','⬆️','⬇️'],
        badge: ['NEW','HOT','SALE','FREE','PRO','BARU','GRATIS','PROMO','TOP','BEST'],
        shape: ['●','■','▲','★','♥','◆','⬟','⬢','⬤','▬','◐','✚'],
        icon: ['▶️','✅','❌','❓','❗','⚠️','🎬','📹','🔔','📌','🎵','🎨','📸','💡','🔍'],
    };

    function renderStickers(cat) {
        var grid = document.getElementById('ts2StickerGrid');
        if (!grid) return;
        var items = STICKER_DATA[cat] || [];
        grid.innerHTML = '';
        items.forEach(function(item) {
            var el = document.createElement('div');
            el.className = 'ts2-sticker-item';
            el.dataset.type = cat;
            if (cat === 'badge') el.dataset.label = item;
            el.textContent = item;
            el.title = item;
            el.onclick = function() { addStickerToCanvas(item, cat); };
            grid.appendChild(el);
        });
    }

    function addStickerToCanvas(content, type) {
        if (!state || !state.canvas) return;
        var fontSize = type === 'badge' ? 36 : (type === 'shape' ? 120 : 80);
        var textObj = new fabric.Text(content, {
            left: state.currentW / 2,
            top: state.currentH / 2,
            fontSize: fontSize,
            fontFamily: type === 'badge' ? 'Rubik, sans-serif' : 'Arial, sans-serif',
            fontWeight: type === 'badge' ? 'bold' : 'normal',
            fill: type === 'shape' ? '#fbbf24' : '#ffffff',
            originX: 'center',
            originY: 'center',
            selectable: true,
            evented: true,
            cornerColor: '#8b5cf6',
            cornerSize: 12,
            transparentCorners: false,
        });
        if (type === 'badge') {
            textObj.set({ backgroundColor: 'rgba(139, 92, 246, 0.9)', padding: 12 });
        }
        textObj._isLayer = true;
        textObj._isSticker = true;
        state.canvas.add(textObj);
        state.canvas.setActiveObject(textObj);
        state.canvas.renderAll();
        if (typeof renderLayerList === 'function') renderLayerList();
    }

    function initStickerLibrary() {
        var tabs = document.querySelectorAll('.ts2-sticker-tab');
        if (!tabs.length) return;
        tabs.forEach(function(tab) {
            tab.onclick = function() {
                document.querySelectorAll('.ts2-sticker-tab').forEach(function(t) { t.classList.remove('active'); });
                tab.classList.add('active');
                renderStickers(tab.dataset.cat);
            };
        });
        renderStickers('emoji');
        console.log('[V9.210.0] Sticker library ready');
    }

    setTimeout(initStickerLibrary, 1600);

    // ============================================================
    // V9.210.0: GRID OVERLAY
    // ============================================================
    function initGridOverlay() {
        var gridToggle = document.getElementById('ts2GridToggle');
        var gridOverlay = document.getElementById('ts2GridOverlay');
        var safeToggle = document.getElementById('ts2SafeToggle');
        var safeOverlay = document.getElementById('ts2SafeOverlay');
        var centerToggle = document.getElementById('ts2CenterToggle');
        var centerOverlay = document.getElementById('ts2CenterOverlay');

        if (gridToggle && gridOverlay) {
            gridToggle.onchange = function() {
                gridOverlay.style.display = gridToggle.checked ? 'block' : 'none';
            };
        }
        if (safeToggle && safeOverlay) {
            safeToggle.onchange = function() {
                safeOverlay.style.display = safeToggle.checked ? 'block' : 'none';
            };
        }
        if (centerToggle && centerOverlay) {
            centerToggle.onchange = function() {
                centerOverlay.style.display = centerToggle.checked ? 'block' : 'none';
            };
        }
        console.log('[V9.210.0] Grid overlay ready');
    }

    setTimeout(initGridOverlay, 1700);

})();