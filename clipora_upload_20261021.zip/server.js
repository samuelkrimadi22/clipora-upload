// V9.180.30: CULTURE_PROXY
// V9.179.03: FIX_VSYNC_OPT
// V9.59.5: Start Worker inside listen
// V9.59.4: Render status endpoint
// V9.59.3: Render via Queue
// V9.59.2: Queue System
// ============================================================
// V9.2.0: SENTRY ERROR MONITORING
// Harus paling atas, sebelum require lain
// ============================================================
const Sentry = require("@sentry/node");
require("dotenv").config();

const SENTRY_DSN = process.env.SENTRY_DSN;

if (SENTRY_DSN && SENTRY_DSN.length > 20) {
  Sentry.init({
    dsn: SENTRY_DSN,
    environment: process.env.SENTRY_ENVIRONMENT || "production",
    tracesSampleRate: parseFloat(process.env.SENTRY_TRACES_SAMPLE_RATE) || 0.1,
    integrations: [],
    beforeSend(event, hint) {
      const err = hint && hint.originalException;
      if (err && err.message) {
        // Skip error yang tidak penting
        if (err.message.includes("EADDRINUSE")) return null;
        if (err.message.includes("ECONNREFUSED")) return null;
        if (err.message.includes("aborted")) return null;
      }
      return event;
    },
  });

  console.log(
    `  [Sentry] Initialized (env: ${process.env.SENTRY_ENVIRONMENT || "production"})`,
  );
} else {
  console.log("  [Sentry] DSN tidak di-set  error monitoring OFF");
}

// V9.250.0: MOVE DB REQUIRE UP - load database di awal
require("dotenv").config();
const _db = require("./database/db");
console.log('[V9.250.0] Database module loaded at startup (early)');

// server.js - V8.7.0 Platform Core (Guest Quota Fix + Portability + Style Memory)
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const multer = require("multer");

// V9.119.1: FIX LOGOUPLOAD - define multer storage untuk UMKM logo
const UPLOAD_LOGO_DIR = require('path').join(__dirname, 'uploads', 'umkm_logos');
if (!require('fs').existsSync(UPLOAD_LOGO_DIR)) {
  require('fs').mkdirSync(UPLOAD_LOGO_DIR, { recursive: true });
  console.log('[UploadLogo]  Created ' + UPLOAD_LOGO_DIR);
}

const logoStorage = multer.diskStorage({
  destination: function (req, file, cb) { cb(null, UPLOAD_LOGO_DIR); },
  filename: function (req, file, cb) {
    var ext = (require('path').extname(file.originalname) || '.png').toLowerCase();
    if (!/^\.(png|jpg|jpeg)$/.test(ext)) ext = '.png';
    var userId = (req.user && req.user.id) ? String(req.user.id).slice(0, 8) : 'anon';
    // V9.126.0: RANDOM LOGO FILENAME
    var crypto = require('crypto');
    var randomHex = crypto.randomBytes(8).toString('hex');
    cb(null, 'logo_' + userId + '_' + Date.now() + '_' + randomHex + ext);
  }
});

const logoUpload = multer({
  storage: logoStorage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: function (req, file, cb) {
    var ok = /image\/(png|jpe?g)/i.test(file.mimetype);
    cb(ok ? null : new Error('Format harus PNG/JPG'), ok);
  }
});

console.log('[UploadLogo]  multer ready, dir=' + UPLOAD_LOGO_DIR);
const path = require("path");
const fs = require("fs");
const http = require("http");
const { Server: SocketIOServer } = require("socket.io");
const { v4: uuidv4 } = require("uuid");
const { exec } = require("child_process");
const { spawn } = require("child_process");
const util = require("util");
const execPromise = util.promisify(exec);
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");

// ============================================================
// V9.94.0: Pakai custom queue (services/queue.js)  no BullMQ
// ============================================================
require("dotenv").config();

// ============================================================
// DATABASE & MIDDLEWARE
// ============================================================
const {
  initSchema,
  dbRun,
  dbGet,
  dbAll,
  backupDatabase,
  getStats,
} = require("./database/db");
const {
  requireAuth,
  optionalAuth,
  requireApiKey,
} = require("./middleware/auth");
const { requireAdmin } = require("./middleware/adminAuth");
const {
  globalLimiter,
  requireQuota,
  incrementQuota,
  checkUserQuota,
  jobPollingLimiter,
  requirePremium,
  analyzeLimiter,
  autoClipLimiter,
} = require("./middleware/rateLimit");
const queue = require("./services/queue");
const logger = require("./utils/logger");
//  V9.6.0: Auto backup scheduler
let backupScheduler = null;
try {
  backupScheduler = require("./services/backupScheduler");
} catch (e) {
  console.warn(" Backup scheduler tidak tersedia:", e.message);
}

// ============================================================
// ROUTES
// ============================================================
const authRoutes = require("./routes/auth");
const userRoutes = require("./routes/user");
const analyticsRoutes = require("./routes/analytics");
const apiKeyRoutes = require("./routes/apikeys");
const adminRoutes = require("./routes/admin");
const subscriptionRoutes = require("./routes/subscriptions");
const paymentRoutes = require("./routes/payment");
const projectRoutes = require("./routes/projects");
const autoclipProjectRoutes = require("./routes/autoclip-projects");
const { checkAudioQuality } = require('./services/audioQuality');

// ============================================================
// V8.7.0: PYTHON PERSISTENT SERVER CONFIG
// ============================================================
let pythonServer = null;
const PYTHON_SERVER_PORT = parseInt(process.env.PYTHON_SERVER_PORT) || 5001;
const PYTHON_SERVER_URL = `http://127.0.0.1:${PYTHON_SERVER_PORT}`;

// ============================================================
// V8.7.0 WATCHDOG: Auto-restart Python kalau crash
// ============================================================
let pythonRestartCount = 0;
const MAX_PYTHON_RESTARTS = 10;
const PYTHON_RESTART_DELAY_MS = 5000;

function schedulePythonRestart() {
  if (pythonRestartCount >= MAX_PYTHON_RESTARTS) {
    console.error(
      ` [Watchdog] Sudah restart ${pythonRestartCount}x  menyerah.`,
    );
    console.error(
      `   Python server mati permanen. Restart Node.js manual untuk coba lagi.`,
    );
    logger.error("Python restart limit reached", {
      attempts: pythonRestartCount,
    });
    return;
  }

  pythonRestartCount++;
  const attempt = pythonRestartCount;
  console.log(
    ` [Watchdog] Restart Python dalam ${PYTHON_RESTART_DELAY_MS / 1000}s... (${attempt}/${MAX_PYTHON_RESTARTS})`,
  );

  setTimeout(async () => {
    try {
      await // V9.120.4: DISABLED  startPythonServer();

      console.log(` [Watchdog] Python restarted (attempt #${attempt})`);
      logger.info("Python restarted via watchdog", { attempt });
      // Reset counter setelah 60 detik stabil
      setTimeout(() => {
        if (pythonServer) pythonRestartCount = 0;
      }, 60000);
    } catch (e) {
      console.error(` [Watchdog] Restart #${attempt} gagal: ${e.message}`);
      schedulePythonRestart();
    }
  }, PYTHON_RESTART_DELAY_MS);
}

function httpPostJSON(url, body, timeoutMs = 600000) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const data = JSON.stringify(body);
    const req = http.request(
      {
        hostname: parsed.hostname,
        port: parsed.port,
        path: parsed.pathname,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(data),
        },
        timeout: timeoutMs,
      },
      (res) => {
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => {
          const text = Buffer.concat(chunks).toString("utf-8");
          try {
            const parsedResp = JSON.parse(text);
            resolve({ status: res.statusCode, data: parsedResp });
          } catch (e) {
            reject(
              new Error(
                `Invalid JSON from Python (status ${res.statusCode}): ${text.slice(0, 300)}`,
              ),
            );
          }
        });
      },
    );
    req.on("error", (e) =>
      reject(new Error(`HTTP to Python failed: ${e.message}`)),
    );
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Python timeout"));
    });
    req.write(data);
    req.end();
  });
}

function httpGetJSON(url, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const req = http.request(
      {
        hostname: parsed.hostname,
        port: parsed.port,
        path: parsed.pathname,
        method: "GET",
        timeout: timeoutMs,
      },
      (res) => {
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => {
          try {
            resolve({
              status: res.statusCode,
              data: JSON.parse(Buffer.concat(chunks).toString()),
            });
          } catch (e) {
            reject(e);
          }
        });
      },
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout"));
    });
    req.end();
  });
}

async function startPythonServer() {
  // V9.120.5: WATCHDOG SAFE WRAP  skip spawn, resolve langsung
  // Python di-handle oleh PM2 (clipora-python), bukan Node.js
  console.log(" [Watchdog] DISABLED  Python di-handle oleh PM2 (clipora-python)");
  console.log("   Skip spawn. Wait for PM2-managed Python server...");

  // Tunggu Python server ready via health check (max 30 detik)
  const maxWait = 30000;
  const startTime = Date.now();
  while (Date.now() - startTime < maxWait) {
    try {
      const r = await httpGetJSON(`${PYTHON_SERVER_URL}/health`, 3000);
      if (r.status === 200) {
        console.log(" [Watchdog] Python server ready (PM2-managed)");
        return;
      }
    } catch (e) {
      // Belum ready, tunggu
    }
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }

  console.warn(" [Watchdog] Python server tidak ready dalam 30s  lanjut tanpa Python");
  // Jangan throw  biarkan Node.js tetap jalan
  return;
}

// ============================================================
// CORS
// ============================================================
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "http://localhost")
  .split(",")
  .map((o) => o.trim())
  .filter(Boolean);

console.log(` CORS Allowed Origins: ${ALLOWED_ORIGINS.join(", ")}`);

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin) return callback(null, true);
    if (ALLOWED_ORIGINS.includes(origin)) return callback(null, true);
    console.warn(`  CORS blocked: ${origin}`);
    logger.warn("CORS blocked: " + origin);
    return callback(new Error("Not allowed by CORS"));
  },
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization", "X-API-Key"],
  credentials: true,
  maxAge: 86400,
};

const app = express();

// ============================================================
// V9.265.0: CORS GLOBAL (WAJIB DI PALING ATAS)
// ============================================================
app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    if (req.method === 'OPTIONS') {
        return res.status(204).end();
    }
    next();
});

// ============================================================
// V9.263.0: MIDDLEWARE ANTI-500 (Fallback Global)
// ============================================================
app.use(function(req, res, next) {
    // V9.264.0: Middleware Anti-500 + CORS Fix
    if (req.path && req.path.indexOf('/api/culture') === 0) {
        console.log("[Anti-500] Intercept Culture:", req.path);
        
        // TAMBAHKAN HEADER CORS
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
        
        // Tangani preflight OPTIONS request
        if (req.method === 'OPTIONS') {
            return res.status(204).end();
        }
        
        // Berikan response kosong
        return res.json({ success: true, regions: [], _fallback: true });
    }
    next();
});

const server = http.createServer(app);
app.set("trust proxy", 1);

const io = new SocketIOServer(server, {
  cors: {
    origin: ALLOWED_ORIGINS,
    methods: ["GET", "POST"],
    credentials: true,
  },
});

const PORT = process.env.PORT || 3000;

// ============================================================
// DIREKTORI
// ============================================================
const BASE_DIR = __dirname;
const UPLOAD_DIR = path.join(BASE_DIR, "uploads");
const RESULT_DIR = path.join(BASE_DIR, "results");
const TEMP_DIR = path.join(BASE_DIR, "temp");
const PROGRESS_DIR = path.join(BASE_DIR, "progress");
const ASSETS_DIR = path.join(BASE_DIR, "assets");
const LOGS_DIR = path.join(BASE_DIR, "logs");
const WATERMARK_DIR = path.join(UPLOAD_DIR, "watermarks");

[
  UPLOAD_DIR,
  RESULT_DIR,
  TEMP_DIR,
  PROGRESS_DIR,
  ASSETS_DIR,
  LOGS_DIR,
  WATERMARK_DIR,
].forEach((dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// ============================================================
// V8.7.0: FFmpeg path  env var dengan fallback (portability)
// ============================================================
const FFMPEG =
  process.env.FFMPEG_PATH ||
  (process.platform === "win32" ? "C:\\ffmpeg\\bin\\ffmpeg.exe" : "ffmpeg");
const FFPROBE =
  process.env.FFPROBE_PATH ||
  (process.platform === "win32" ? "C:\\ffmpeg\\bin\\ffprobe.exe" : "ffprobe");

console.log(" Mengecek FFmpeg...");
try {
  const result = require("child_process").execSync(`"${FFMPEG}" -version`, {
        windowsHide: true, // V9.6.0
        
    timeout: 15000,
    stdio: ["ignore", "pipe", "pipe"],
  });
  const firstLine = result.toString().split("\n")[0].trim();
  console.log(` FFmpeg ditemukan: ${FFMPEG}`);
  console.log(`   ${firstLine}`);
} catch (e) {
  console.error(` FFmpeg gagal: ${FFMPEG}`);
  console.error(`   Error: ${e.message}`);
  if (e.stderr)
    console.error(`   stderr: ${e.stderr.toString().slice(0, 300)}`);
  console.error("   Cek: 1) antivirus block 2) permission 3) corrupt");
  logger.error("FFmpeg gagal: " + e.message);
  process.exit(1);
}

// V8.8.0: Cek ffprobe juga
try {
  require("child_process").execSync(`"${FFPROBE}" -version`, {
        windowsHide: true, // V9.6.0
        
    timeout: 15000,
    stdio: ["ignore", "pipe", "pipe"],
  });
  console.log(` FFprobe ditemukan: ${FFPROBE}`);
} catch (e) {
  console.error(` FFprobe gagal: ${FFPROBE}`);
  console.error(`   Error: ${e.message}`);
  logger.error("FFprobe gagal");
  process.exit(1);
}

const BACKGROUND_MUSIC = path.join(ASSETS_DIR, "background_music.mp3");
console.log(
  ` Background music: ${fs.existsSync(BACKGROUND_MUSIC) ? " Ada" : " Tidak ada"}`,
);

// ============================================================
// GLOBAL MIDDLEWARE
// ============================================================
// V9.41.0: CSP for Midtrans + Google + inline scripts
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginResourcePolicy: { policy: "cross-origin" },
  crossOriginEmbedderPolicy: false,
}));
app.use(cors(corsOptions));
app.use(express.json({ limit: "10mb" }));
app.use(cookieParser());
app.use(morgan("tiny"));

app.use((req, res, next) => {
  const start = Date.now();
  res.on("finish", () => {
    const duration = Date.now() - start;
    const userId = req.user ? req.user.id : null;
    if (
      !req.path.startsWith("/results") &&
      !req.path.startsWith("/progress") &&
      !req.path.startsWith("/assets") &&
      !req.path.startsWith("/download") &&
      !req.path.startsWith("/preview")
    ) {
      logger.request(
        req.method,
        req.originalUrl,
        res.statusCode,
        duration,
        userId,
      );
    }
  });
  next();
});

// Global rate limiter  skip webhook Midtrans & static files
app.use((req, res, next) => {
  // Skip rate limit untuk webhook Midtrans (dari luar)
  if (req.path === "/api/payment/webhook") return next();

  // Skip untuk static files
  if (
    req.path.startsWith("/results") ||
    req.path.startsWith("/progress") ||
    req.path.startsWith("/assets") ||
    req.path.startsWith("/download") ||
    req.path.startsWith("/uploads") ||   // V9.152.0: UPLOADS_BYPASS_RATE_LIMIT
    req.path.startsWith("/preview")
  ) {
    return next();
  }

  // Apply global limiter untuk route lain
  return globalLimiter(req, res, next);
});
app.use("/results", express.static(RESULT_DIR));

// V9.138.0: SERVE FOLDER UPLOADS (untuk music user, logo, dll)
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
console.log(" Static /uploads: " + path.join(__dirname, "uploads"));
app.use("/progress", express.static(PROGRESS_DIR));

// V9.66.0: Serve folder audio
const AUDIO_DIR = path.join(BASE_DIR, "audio");
app.use("/audio", express.static(AUDIO_DIR));

// ============================================================
// MULTER
// ============================================================
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}_${uuidv4().slice(0, 8)}${ext}`);
  },
});

const ALLOWED_VIDEO_MIMES = [
  "video/mp4",
  "video/quicktime",
  "video/x-msvideo",
  "video/x-matroska",
  "video/webm",
  "video/mpeg",
  "video/x-m4v",
  "application/octet-stream",
];
const ALLOWED_VIDEO_EXTS = [
  ".mp4",
  ".mov",
  ".avi",
  ".mkv",
  ".webm",
  ".m4v",
  ".mpg",
  ".mpeg",
];

const upload = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const mime = file.mimetype;
    if (!ALLOWED_VIDEO_EXTS.includes(ext)) {
      return cb(
        new Error(
          `Format ${ext} tidak didukung. Gunakan: ${ALLOWED_VIDEO_EXTS.join(", ")}`,
        ),
      );
    }
    if (ALLOWED_VIDEO_MIMES.includes(mime) || mime.startsWith("video/"))
      return cb(null, true);
    return cb(new Error(`Tipe file ${mime} tidak didukung`));
  },
});

// ============================================================
// V9.135.0 LEVEL 5: USER MUSIC UPLOAD
// ============================================================
const USER_MUSIC_DIR = path.join(UPLOAD_DIR, "music");
if (!fs.existsSync(USER_MUSIC_DIR)) {
  fs.mkdirSync(USER_MUSIC_DIR, { recursive: true });
}

const musicStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const userDir = path.join(USER_MUSIC_DIR, `user_${req.user.id}`);
    if (!fs.existsSync(userDir)) {
      fs.mkdirSync(userDir, { recursive: true });
    }
    cb(null, userDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const allowed = [".mp3", ".wav", ".m4a", ".ogg"];
    if (!allowed.includes(ext)) {
      return cb(new Error("Format harus MP3, WAV, M4A, atau OGG"));
    }
    const name = `music_${Date.now()}_${uuidv4().slice(0, 6)}${ext}`;
    cb(null, name);
  },
});

const musicUpload = multer({
  storage: musicStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB max
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const allowed = [".mp3", ".wav", ".m4a", ".ogg"];
    if (!allowed.includes(ext)) {
      return cb(new Error("Hanya MP3, WAV, M4A, atau OGG yang didukung"));
    }
    cb(null, true);
  },
});

console.log("[Music]  Upload setup ready:", USER_MUSIC_DIR);


// ============================================================
// ROUTES
// ============================================================
app.use("/api/auth", authRoutes);
app.use("/api/user", userRoutes);
app.use("/api/user/onboarding", require("./routes/onboarding"));
// V9.128.0: REVIEWS ROUTE
app.use("/api/reviews", require("./routes/reviews"));
app.use("/api/analytics", analyticsRoutes);
app.use("/api/apikeys", apiKeyRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/admin/2fa", require("./routes/twoFA"));
app.use("/api/subscriptions", subscriptionRoutes);
app.use("/api/payment", paymentRoutes);
app.use("/api/projects", projectRoutes);
// ============================================================
// V9.175.0: RETENTION_PROXY - proxy ke Python /retention
// ============================================================
// ============================================================
// V9.177.2: AUTO_OPTIMIZE_PROXY - proxy ke Python /auto-optimize
// ============================================================
// ============================================================
// V9.178.61: LATEST_ENDPOINT - cek file autoopt terbaru untuk analysisId
app.get("/api/auto-optimize/latest/:analysisId", optionalAuth, (req, res) => {
  try {
    const _fs = require("fs");
    const _pathMod = require("path");
    const resultsDir = _pathMod.join(__dirname, "results");

    if (!_fs.existsSync(resultsDir)) {
      return res.json({ success: false, file: null });
    }

    // Cari file autoopt dalam 5 menit terakhir
    const now = Date.now();
    const files = _fs.readdirSync(resultsDir)
      .filter(f => f.startsWith("autoopt_") && f.endsWith(".mp4"))
      .map(f => {
        const stat = _fs.statSync(_pathMod.join(resultsDir, f));
        return { name: f, mtime: stat.mtime.getTime(), size: stat.size };
      })
      .filter(f => now - f.mtime < 5 * 60 * 1000)   // 5 menit
      .sort((a, b) => b.mtime - a.mtime);

    if (files.length === 0) {
      return res.json({ success: false, file: null, message: "Belum ada hasil" });
    }

    res.json({
      success: true,
      file: files[0].name,
      size: files[0].size,
      downloadUrl: `/download/${files[0].name}`
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// V9.178.31: DOWNLOAD_ENDPOINT - serve file dari results/ dan temp/
// ============================================================
app.get("/download/:filename", (req, res) => {
  try {
    const _pathMod = require("path");
    const _fs = require("fs");
    const filename = req.params.filename;

    // Sanitasi filename (cegah path traversal)
    if (filename.includes("..") || filename.includes("/") || filename.includes("\\")) {
      return res.status(400).send("Nama file tidak valid");
    }

    // Cari di berbagai folder
    const searchDirs = [
      _pathMod.join(__dirname, "results"),
      _pathMod.join(__dirname, "temp"),
      _pathMod.join(__dirname, "uploads"),
      _pathMod.join(__dirname, "processed")
    ];

    let filePath = null;
    for (const dir of searchDirs) {
      const candidate = _pathMod.join(dir, filename);
      if (_fs.existsSync(candidate)) {
        filePath = candidate;
        break;
      }
    }

    if (!filePath) {
      console.log(`[Download] File tidak ditemukan: ${filename}`);
      return res.status(404).send("File tidak ditemukan: " + filename);
    }

    console.log(`[Download] Serving: ${filePath}`);
    res.download(filePath, filename, (err) => {
      if (err) {
        console.error(`[Download] Error saat kirim:`, err.message);
        if (!res.headersSent) {
          res.status(500).send("Gagal download file");
        }
      }
    });
  } catch (e) {
    console.error("[Download] Error:", e.message);
    res.status(500).send("Error: " + e.message);
  }
});

// ============================================================
// V9.178.31: STREAM_ENDPOINT - preview video inline
// ============================================================
app.get("/preview/:filename", (req, res) => {
  try {
    const _pathMod = require("path");
    const _fs = require("fs");
    const filename = req.params.filename;

    if (filename.includes("..") || filename.includes("/") || filename.includes("\\")) {
      return res.status(400).send("Nama file tidak valid");
    }

    const searchDirs = [
      _pathMod.join(__dirname, "results"),
      _pathMod.join(__dirname, "temp")
    ];

    let filePath = null;
    for (const dir of searchDirs) {
      const candidate = _pathMod.join(dir, filename);
      if (_fs.existsSync(candidate)) {
        filePath = candidate;
        break;
      }
    }

    if (!filePath) {
      return res.status(404).send("File tidak ditemukan");
    }

    const stat = _fs.statSync(filePath);
    res.setHeader("Content-Type", "video/mp4");
    res.setHeader("Content-Length", stat.size);
    res.setHeader("Accept-Ranges", "bytes");
    _fs.createReadStream(filePath).pipe(res);
  } catch (e) {
    console.error("[Preview] Error:", e.message);
    res.status(500).send("Error: " + e.message);
  }
});

// V9.178.25: REQUEST_LOCK - cegah request paralel
const _autoOptLocks = new Map();  // key: analysisId, value: {started, promise}

app.post("/api/auto-optimize/:analysisId/:clipId", optionalAuth, async (req, res) => {
  try {
    const analysisId = req.params.analysisId;
    const clipId = req.params.clipId;

    // V9.178.25: REQUEST_LOCK
    if (_autoOptLocks.has(analysisId)) {
      const elapsed = Date.now() - _autoOptLocks.get(analysisId).started;
      console.log(`[AutoOptimize]  Request ditolak (duplikat, elapsed=${elapsed}ms)`);
      return res.status(429).json({
        success: false,
        error: "Auto-optimize sedang berjalan untuk project ini. Tunggu selesai.",
        elapsed
      });
    }
    _autoOptLocks.set(analysisId, { started: Date.now() });
    console.log(`[AutoOptimize] Lock acquired for ${analysisId.substring(0, 8)}`);
    const { suggestions, preset, verticalCrop, burnSubtitle, aspectRatio, words, sourcePath, outputPath } = req.body;
    let start = Number(req.body.start || 0);
    let end = Number(req.body.end || 0);

    if (!suggestions || !Array.isArray(suggestions)) {
      return res.status(400).json({
        success: false,
        error: "suggestions wajib (array)"
      });
    }

    // V9.178.9: SKIP_DB_LOOKUP (Supabase down, langsung file search)
    let resolvedSourcePath = sourcePath;
    if (!resolvedSourcePath) {
      console.log("[AutoOptimize] sourcePath kosong, skip DB lookup (Supabase down), langsung file search");
    }

    // V9.178.11: AUTO_OUTPUTPATH - generate kalau kosong
    let resolvedOutputPath = outputPath;
    if (!resolvedOutputPath) {
      const _fs = require("fs");
      const _path = require("path");
      const _resultsDir = _path.join(__dirname, "results");
      if (!_fs.existsSync(_resultsDir)) {
        _fs.mkdirSync(_resultsDir, { recursive: true });
      }
      const _timestamp = Date.now();
      const _random = Math.random().toString(36).substring(2, 8);
      resolvedOutputPath = _path.join(_resultsDir, `autoopt_${_timestamp}_${_random}.mp4`);
      console.log(`[AutoOptimize] outputPath auto-generated: ${resolvedOutputPath}`);
    }

    // V9.178.9: SMART_FILE_SEARCH - prioritas uploads/, skip file output
    if (!resolvedSourcePath) {
      try {
        const fs = require("fs");
        const pathMod = require("path");

        const searchDirs = [
          pathMod.join(__dirname, "uploads"),
          pathMod.join(__dirname, "temp"),
          pathMod.join(__dirname, "results")
        ];

        const videoExts = [".mp4", ".mov", ".mkv", ".webm", ".avi"];
        const skipPatterns = ["clipora_clip", "output_", "_output", "test_", "final_", "render_"];

        console.log("[AutoOptimize] Smart file search:");

        for (const dir of searchDirs) {
          if (!fs.existsSync(dir)) {
            console.log(`  [skip] ${pathMod.basename(dir)}/ tidak ada`);
            continue;
          }

          const allFiles = fs.readdirSync(dir);
          console.log(`  Scan ${pathMod.basename(dir)}/: ${allFiles.length} files`);

          const videoFiles = allFiles
            .filter(f => {
              const lower = f.toLowerCase();
              if (!videoExts.some(ext => lower.endsWith(ext))) return false;
              if (skipPatterns.some(pat => lower.includes(pat))) {
                console.log(`    [skip output] ${f}`);
                return false;
              }
              return true;
            })
            .map(f => {
              const fullPath = pathMod.join(dir, f);
              const stat = fs.statSync(fullPath);
              return { name: f, path: fullPath, mtime: stat.mtime, size: stat.size };
            })
            .sort((a, b) => b.mtime - a.mtime);

          if (videoFiles.length > 0) {
            resolvedSourcePath = videoFiles[0].path;
            const mb = (videoFiles[0].size / 1024 / 1024).toFixed(2);
            console.log(`[AutoOptimize]  Ditemukan: ${videoFiles[0].name} (${mb} MB) di ${pathMod.basename(dir)}/`);
            break;
          }
        }

        // Fallback terakhir kalau semua folder kosong
        if (!resolvedSourcePath) {
          console.log("[AutoOptimize]  Tidak ada file source, pakai file apapun");
          for (const dir of searchDirs) {
            if (!fs.existsSync(dir)) continue;
            const anyVideo = fs.readdirSync(dir)
              .filter(f => videoExts.some(ext => f.toLowerCase().endsWith(ext)))
              .map(f => ({ path: pathMod.join(dir, f), mtime: fs.statSync(pathMod.join(dir, f)).mtime }))
              .sort((a, b) => b.mtime - a.mtime);
            if (anyVideo.length > 0) {
              resolvedSourcePath = anyVideo[0].path;
              console.log(`[AutoOptimize]  Pakai file: ${resolvedSourcePath}`);
              break;
            }
          }
        }
      } catch (e) {
        console.warn("[AutoOptimize] File search error:", e.message);
      }
    }

    if (!resolvedSourcePath) {
      return res.status(400).json({
        success: false,
        error: "sourcePath tidak bisa di-resolve. Kirim sourcePath di body atau pastikan video tersimpan."
      });
    }

    // V9.178.20: PRECUT_VIDEO - potong video ke durasi pendek dulu
    const _preCutMaxSec = 30;
    if (end > _preCutMaxSec || start > 0) {
      console.log(`[AutoOptimize] Pre-cut: ${start}s-${end}s  0-${Math.min(end - start, _preCutMaxSec)}s`);
      const _pathMod = require("path");
      const _fs = require("fs");
      const { spawnSync } = require("child_process");

      const _tempDir = _pathMod.join(__dirname, "temp");
      if (!_fs.existsSync(_tempDir)) _fs.mkdirSync(_tempDir, { recursive: true });

      const _cutPath = _pathMod.join(_tempDir, `precut_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.mp4`);
      const _duration = Math.min(end - start, _preCutMaxSec);

      const _ffmpegCmd = process.env.FFMPEG_PATH || "ffmpeg";
      // V9.178.40: CFR_PRECUT - paksa CFR 30fps sejak awal
      const _args = [
        "-ss", String(start),
        "-i", resolvedSourcePath,
        "-t", String(_duration),
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-crf", "23",
        "-r", "30",                     //  paksa 30fps
        "-fps_mode", "cfr",                //  CFR mode
        "-c:a", "aac",
        "-b:a", "128k",
        "-ar", "48000",                 //  audio sample rate standard
        "-ac", "2",                     //  stereo
        "-avoid_negative_ts", "make_zero",
        "-y", _cutPath
      ];

      console.log(`[AutoOptimize] Running FFmpeg pre-cut...`);
      const _result = spawnSync(_ffmpegCmd, _args, { encoding: "utf-8", timeout: 60000 });

      if (_result.status === 0 && _fs.existsSync(_cutPath)) {
        const _size = Math.round(_fs.statSync(_cutPath).size / 1024 / 1024);
        console.log(`[AutoOptimize]  Pre-cut OK: ${_cutPath} (${_size} MB, ${_duration}s)`);
        resolvedSourcePath = _cutPath;
        end = _duration;
        start = 0;
      } else {
        console.warn(`[AutoOptimize]  Pre-cut gagal (status=${_result.status})`);
        if (_result.stderr) console.warn(`  stderr: ${_result.stderr.substring(0, 500)}`);
      }
    }

    console.log(`[AutoOptimize] Request: analysisId=${analysisId.slice(0, 8)}, clipId=${clipId}, suggestions=${suggestions.length}`);

    // Build Python request
    const pyBody = {
      sourcePath: resolvedSourcePath,  // V9.178.4
      outputPath: resolvedOutputPath,  // V9.178.11
      start: start || 0,
      end: end || 0,
      suggestions: suggestions,
      preset: preset || "1080p",
      verticalCrop: !!verticalCrop,
      burnSubtitle: burnSubtitle !== false,
      aspectRatio: aspectRatio || "auto",
      words: words || [],
      addWatermark: req.body.addWatermark !== false,
      enableNoiseReduction: req.body.enableNoiseReduction !== false,
      progressPath: req.body.progressPath
    };

    const resp = await httpPostJSON(`${PYTHON_SERVER_URL}/auto-optimize`, pyBody, 30 * 60 * 1000); // 30 min timeout

    if (resp.status !== 200 || !resp.data || !resp.data.success) {
      throw new Error((resp.data && resp.data.error) || `Python HTTP ${resp.status}`);
    }

    console.log(`[AutoOptimize]  Done: ${resp.data.suggestionsApplied} suggestions applied`);

    // V9.178.30: RETURN_FILENAME
    const _pathMod2 = require("path");
    const _filename = _pathMod2.basename(resolvedOutputPath);
    const _downloadUrl = `/download/${_filename}`;

    res.json({
      success: true,
      result: resp.data.result,
      suggestionsApplied: resp.data.suggestionsApplied,
      outputPath: resolvedOutputPath,
      filename: _filename,
      downloadUrl: _downloadUrl
    });
  } catch (e) {
    console.error("[AutoOptimize] Error:", e.message);
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: e.message
      });
    }
  } finally {
    // V9.178.25: Release lock
    _autoOptLocks.delete(req.params.analysisId);
    console.log(`[AutoOptimize] Lock released for ${req.params.analysisId.substring(0, 8)}`);

    // V9.178.80: AUTO_CLEANUP - hapus file precut lama
    try {
      const _fs = require("fs");
      const _pathMod = require("path");
      const tempDir = _pathMod.join(__dirname, "temp");
      if (_fs.existsSync(tempDir)) {
        const cutoff = Date.now() - 60 * 60 * 1000;  // 1 jam
        const files = _fs.readdirSync(tempDir).filter(f => f.startsWith("precut_"));
        let cleaned = 0;
        for (const f of files) {
          const fp = _pathMod.join(tempDir, f);
          const stat = _fs.statSync(fp);
          if (stat.mtimeMs < cutoff) {
            _fs.unlinkSync(fp);
            cleaned++;
          }
        }
        if (cleaned > 0) {
          console.log(`[AutoOptimize] Cleanup: ${cleaned} file precut lama dihapus`);
        }
      }
    } catch (e) {
      console.warn("[AutoOptimize] Cleanup error:", e.message);
    }
  }
});

app.post("/api/retention/:analysisId", optionalAuth, async (req, res) => {
  try {
    const analysisId = req.params.analysisId;
    
    // Ambil analysis dari pendingAnalyses atau DB
    let words = req.body.words;
    let videoDuration = req.body.videoDuration;
    
    // Kalau tidak ada di body, coba ambil dari file analysis
    if (!words || !videoDuration) {
      try {
        const _analysisFile = path.join(BASE_DIR, "analysis", `${analysisId}.json`);
        if (fs.existsSync(_analysisFile)) {
          const _aj = JSON.parse(fs.readFileSync(_analysisFile, "utf8"));
          words = words || _aj.words || [];
          videoDuration = videoDuration || _aj.videoDuration || 0;
        }
      } catch (e) {
        console.warn("[Retention] Load analysis error:", e.message);
      }
    }
    
    if (!words || words.length === 0) {
      return res.status(400).json({
        success: false,
        error: "Words tidak tersedia. Kirim di body atau pastikan analysis sudah ada."
      });
    }
    
    console.log(`[Retention] Request: analysisId=${analysisId.slice(0, 8)}, words=${words.length}, duration=${videoDuration}s`);
    
    const resp = await httpPostJSON(`${PYTHON_SERVER_URL}/retention`, {
      words: words,
      videoDuration: videoDuration,
      silenceData: req.body.silenceData || null,
      sceneData: req.body.sceneData || null
    }, 60000);  // 1 menit timeout
    
    if (resp.status !== 200 || !resp.data || !resp.data.success) {
      throw new Error((resp.data && resp.data.error) || `Python HTTP ${resp.status}`);
    }
    
    console.log(`[Retention]  Score: ${resp.data.retention.overall_score}/10 (${resp.data.retention.virality})`);
    
    res.json({
      success: true,
      retention: resp.data.retention
    });
  } catch (e) {
    console.error("[Retention] Error:", e.message);
    res.status(500).json({
      success: false,
      error: e.message
    });
  }
});

app.use("/api/autoclip-projects", autoclipProjectRoutes);

// ============================================================
// PENDING ANALYSES (V8.9.21: disk-backed, TTL 1 jam)
// ============================================================
const pendingAnalyses = require("./services/pendingStore");
const PENDING_TTL_MS = 60 * 60 * 1000;

setInterval(
  () => {
    const now = Date.now();
    for (const [id, meta] of pendingAnalyses.entries()) {
      if (now - meta.createdAt > PENDING_TTL_MS) {
        try {
          if (fs.existsSync(meta.analyzeFile)) fs.unlinkSync(meta.analyzeFile);
        } catch (e) {}
        try {
          if (fs.existsSync(meta.inputPath)) fs.unlinkSync(meta.inputPath);
        } catch (e) {}
        pendingAnalyses.delete(id);
        console.log(`  [Pending] Cleaned analysis ${id}`);
      }
    }
  },
  5 * 60 * 1000,
);

// ============================================================
// HELPER: Plan limits
// ============================================================
function getMaxDuration(plan) {
  const limits = {
    free: parseInt(process.env.FREE_MAX_DURATION) || 120,
    pro: parseInt(process.env.PRO_MAX_DURATION) || 600,
    business: parseInt(process.env.BUSINESS_MAX_DURATION) || 1800,
  };
  return limits[plan] || limits.free;
}

function getWhisperModel(plan) {
  const models = {
    free: process.env.FREE_WHISPER_MODEL || "tiny",
    pro: process.env.PRO_WHISPER_MODEL || "small",
    business: process.env.BUSINESS_WHISPER_MODEL || "small",
  };
  return models[plan] || models.free;
}

async function getVideoDuration(filepath) {
  try {
    const { stdout } = await execPromise(
      `"${FFPROBE}" -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${filepath}"`,
      { timeout: 10000 },
    );
    return parseFloat(stdout.trim()) || 0;
  } catch (e) {
    console.warn("Get duration error:", e.message);
    return 0;
  }
}

function formatDurationText(seconds) {
  if (seconds < 60) return Math.round(seconds) + " detik";
  const mins = Math.floor(seconds / 60);
  const secs = Math.round(seconds % 60);
  return mins + " menit" + (secs > 0 ? " " + secs + " detik" : "");
}

function getAllowedPresets(plan) {
  const presets = {
    free: ["720p"],
    pro: ["720p", "1080p"],
    business: ["720p", "1080p"],
  };
  return presets[plan] || presets.free;
}

function getDefaultPreset(plan) {
  const defaults = { free: "720p", pro: "1080p", business: "1080p" };
  return defaults[plan] || "720p";
}

function getFeaturesForPlan(plan) {
  const isPremium = ["pro", "business", "weekly", "monthly"].includes(
    (plan || "free").toLowerCase(),
  );
  return {
    vad: true,
    noise_detection: true, // V9.5.0  tersedia semua plan
    semantic: isPremium,
    keyword: isPremium,
    emotion: isPremium,
    diarization: isPremium,
  };
}

function isPremiumPlan(plan) {
  return ["pro", "business", "weekly", "monthly"].includes(
    (plan || "free").toLowerCase(),
  );
}
// V9.27.1: Free quota helper
const FREE_QUOTA = {
  videosPerDay: 1,
  maxClips: 3,
  maxDurationSec: 300,
  maxResolution: "720p",
};

async function getTodayUsage(userId) {
  try {
    const row = await dbGet(
      "SELECT COUNT(*) as count FROM autoclip_usage WHERE user_id = ? AND DATE(created_at) = CURRENT_DATE",
      [userId]
    );
    return row ? parseInt(row.count) : 0;
  } catch (e) {
    console.warn("[Quota] getTodayUsage error:", e.message);
    return 0;
  }
}



// ============================================================
// STYLE MEMORY HELPERS
// ============================================================
// ============================================================
// V8.9.22: Style Memory cache (60s TTL)
// ============================================================
const _styleMemoryCache = new Map();
const STYLE_MEMORY_CACHE_TTL = 60 * 1000;

function _invalidateStyleMemoryCache(userId) {
  _styleMemoryCache.delete(userId);
}

async function getUserStyleMemory(userId, forceRefresh = false) {
  if (!userId) return {};

  if (!forceRefresh) {
    const cached = _styleMemoryCache.get(userId);
    if (cached && Date.now() - cached.ts < STYLE_MEMORY_CACHE_TTL) {
      return cached.data;
    }
  }

  try {
    const rows = await dbAll(
      `SELECT memory_json, total_videos, last_updated FROM user_style_memory WHERE user_id = ?`,
      [userId],
    );
    if (!rows || rows.length === 0) {
      _styleMemoryCache.set(userId, { data: {}, ts: Date.now() });
      return {};
    }

    let mem = rows[0].memory_json;
    if (typeof mem === "string") {
      try {
        mem = JSON.parse(mem);
      } catch (e) {
        mem = {};
      }
    }
    mem = mem || {};

    if (!mem.last_updated && rows[0].last_updated) {
      mem.last_updated = rows[0].last_updated;
    }
    if (!mem.total_videos && rows[0].total_videos) {
      mem.total_videos = rows[0].total_videos;
    }

    _styleMemoryCache.set(userId, { data: mem, ts: Date.now() });
    return mem;
  } catch (e) {
    console.warn("getUserStyleMemory error:", e.message);
    return {};
  }
}

async function mergeStyleMemory(userId, delta) {
  if (!userId || !delta || !delta.categories) return null;

  const existing = await getUserStyleMemory(userId);
  const merged = {
    categories: existing.categories || {},
    total_videos: (existing.total_videos || 0) + 1,
    preferred_mode: existing.preferred_mode || "content",
    last_updated: new Date().toISOString(),
  };

  for (const [catName, catData] of Object.entries(delta.categories)) {
    if (!merged.categories[catName]) {
      merged.categories[catName] = {
        total_shown: 0,
        enabled_by_user: 0,
        disabled_by_user: 0,
        keep_rate: 1.0,
      };
    }
    const c = merged.categories[catName];
    c.total_shown += catData.total_shown || 0;
    c.enabled_by_user += catData.enabled_by_user || 0;
    c.disabled_by_user += catData.disabled_by_user || 0;

    const totalUserChoices = c.enabled_by_user + c.disabled_by_user;
    c.keep_rate =
      totalUserChoices > 0
        ? parseFloat((c.enabled_by_user / totalUserChoices).toFixed(3))
        : 1.0;
  }

  try {
    const existing_rows = await dbAll(
      `SELECT user_id FROM user_style_memory WHERE user_id = ?`,
      [userId],
    );

    if (existing_rows && existing_rows.length > 0) {
      await dbRun(
        `UPDATE user_style_memory
                 SET memory_json = ?, total_videos = ?, last_updated = NOW()
                 WHERE user_id = ?`,
        [JSON.stringify(merged), merged.total_videos, userId],
      );
    } else {
      await dbRun(
        `INSERT INTO user_style_memory (user_id, memory_json, total_videos)
                 VALUES (?, ?, ?)`,
        [userId, JSON.stringify(merged), merged.total_videos],
      );
    }

    console.log(
      ` [StyleMemory] Saved for user ${userId} (${merged.total_videos} videos, ${Object.keys(merged.categories).length} categories)`,
    );
    _invalidateStyleMemoryCache(userId);
    return merged;
  } catch (e) {
    console.error("mergeStyleMemory error:", e.message);
    return null;
  }
}

// ============================================================
// V8.9.22: GUEST quota  3 video lifetime per IP
// Format file: { "ip": jumlah_video_sudah_dipakai }
// ============================================================
const GUEST_TRIAL_FILE = path.join(LOGS_DIR, "guest_trial.json");
const GUEST_QUOTA = parseInt(process.env.GUEST_QUOTA) || 3;

let guestTrial = new Map(); // ip -> count (number)
try {
  if (fs.existsSync(GUEST_TRIAL_FILE)) {
    const raw = JSON.parse(fs.readFileSync(GUEST_TRIAL_FILE, "utf8"));

    if (Array.isArray(raw)) {
      // Auto-migrate dari format lama (Set  Map)
      raw.forEach((ip) => {
        if (typeof ip === "string") guestTrial.set(ip, 1);
      });
      console.log(
        ` [Guest] Auto-migrated ${guestTrial.size} IP dari format lama`,
      );
      setTimeout(() => saveGuestTrial(), 1000);
    } else if (raw && typeof raw === "object") {
      // Format baru: { ip: count }
      Object.entries(raw).forEach(([ip, count]) => {
        const c = Math.min(parseInt(count) || 0, GUEST_QUOTA);
        guestTrial.set(ip, c);
      });
      console.log(
        ` [Guest] Loaded ${guestTrial.size} IP (kuota ${GUEST_QUOTA}/IP)`,
      );
    }
  }
} catch (e) {
  console.warn(" Gagal load guest_trial.json:", e.message);
  guestTrial = new Map();
}

let guestSaveTimer = null;
function saveGuestTrial() {
  if (guestSaveTimer) clearTimeout(guestSaveTimer);
  guestSaveTimer = setTimeout(() => {
    try {
      const obj = {};
      guestTrial.forEach((count, ip) => {
        obj[ip] = count;
      });
      fs.writeFileSync(GUEST_TRIAL_FILE, JSON.stringify(obj, null, 2));
    } catch (e) {
      console.warn(" Gagal save guest_trial.json:", e.message);
    }
  }, 500);
}

function normalizeIp(ip) {
  return (ip || "unknown")
    .replace("::ffff:", "")
    .replace("::1", "localhost")
    .trim();
}

// ============================================================
// V8.9.22: checkGuestQuota  return used + remaining
// ============================================================
function checkGuestQuota(ip) {
  const cleanIp = normalizeIp(ip);
  const used = guestTrial.get(cleanIp) || 0;
  const remaining = Math.max(0, GUEST_QUOTA - used);

  return {
    allowed: remaining > 0,
    used,
    remaining,
    total: GUEST_QUOTA,
    reason: remaining > 0 ? null : "quota_exhausted",
  };
}

function commitGuestQuota(ip) {
  const cleanIp = normalizeIp(ip);
  const current = guestTrial.get(cleanIp) || 0;
  if (current < GUEST_QUOTA) {
    guestTrial.set(cleanIp, current + 1);
    saveGuestTrial();
    console.log(
      ` [Guest] Committed untuk ${cleanIp} (${current + 1}/${GUEST_QUOTA})`,
    );
  }
}

function getGuestLimits() {
  return {
    maxDuration: parseInt(process.env.GUEST_MAX_DURATION) || 60,
    whisperModel: process.env.GUEST_WHISPER_MODEL || "tiny",
    allowedPresets: ["720p"],
    defaultPreset: "720p",
  };
}

// ============================================================
// QUEUE EVENT HANDLER
// ============================================================
queue.on("job:ready", async (job, { done, fail, updateProgress }) => {
  const opts = job.data;

  try {
    console.log(
      ` [Job ${job.id}] Memulai proses (mode: ${opts.mode || "full"})`,
    );
    logger.info(`Job ${job.id} mulai diproses`, {
      userId: job.userId,
      mode: opts.mode || "full",
    });

    if (job.userId) {
      io.to(`user_${job.userId}`).emit("job:update", {
        jobId: job.id,
        status: "processing",
        progress: 0,
        message: "Memulai...",
      });
    }

    const plan = (opts.userPlan || "free").toLowerCase();
    const isAdminJob = opts.isAdmin === true;
    const envEmotion = process.env.ENABLE_EMOTION !== "false";
    const envDiarization = process.env.ENABLE_DIARIZATION !== "false";

    let features;
    if (isAdminJob) {
      features = {
        vad: true,
        semantic: false,
        keyword: false,
        emotion: false,
        diarization: false,
      };
      console.log(
        ` [Admin Job] Fitur: emotion=${envEmotion}, diarization=${envDiarization}`,
      );
    } else {
      features = getFeaturesForPlan(plan);
    }
    console.log(
      `  Features [${plan}${isAdminJob ? "/admin" : ""}]:`,
      JSON.stringify(features),
    );
    console.log(
      ` Burn subtitle: ${opts.enableBurnSubtitle !== false ? "AKTIF" : "NONAKTIF"}`,
    );
    console.log(` Aggressiveness: ${opts.aggressiveness || "content"}`);

    // Style memory
    let styleMemory = {};
    if (job.userId) {
      try {
        const sm = await getUserStyleMemory(job.userId);
        if (sm && sm.total_videos >= 5) {
          styleMemory = sm;
          console.log(
            ` [StyleMemory] Loaded for user ${job.userId} (${sm.total_videos} videos)`,
          );
        }
      } catch (e) {}
    }

    // Progress watcher
    const progressPath = opts.progressPath;
    let progressInterval = null;
    if (progressPath) {
      progressInterval = setInterval(() => {
        try {
          if (fs.existsSync(progressPath)) {
            const data = JSON.parse(fs.readFileSync(progressPath, "utf8"));
            updateProgress(data.progress || 0, data.message || "");
            if (job.userId) {
              io.to(`user_${job.userId}`).emit("job:update", {
                jobId: job.id,
                status: "processing",
                progress: data.progress,
                message: data.message,
              });
            }
          }
        } catch (e) {}
      }, 1000);
    }

    //  V9.94.0: Handle render-clip mode (dari /api/render-clip)
if (opts.mode === "render-clip") {
    console.log(` [Job ${job.id}] Render clip #${opts.clipId} via Python...`);
    const t0 = Date.now();

    try {
        let progressInterval = null;
        if (opts.progressPath) {
            progressInterval = setInterval(() => {
                try {
                    if (fs.existsSync(opts.progressPath)) {
                        const pd = JSON.parse(fs.readFileSync(opts.progressPath, "utf8"));
                        updateProgress(pd.progress || 0, pd.message || "");
                        if (job.userId) {
                            io.to(`user_${job.userId}`).emit("autoclip:render-progress", {
                                jobId: job.id,
                                clipId: opts.clipId,
                                progress: pd.progress || 0,
                                step: pd.step || "render",
                                message: pd.message || "",
                            });
                        }
                    }
                } catch (e) {}
            }, 1000);
        }

        // Panggil Python /render-clip
        const resp = await httpPostJSON(
            `${PYTHON_SERVER_URL}/render-clip`,
            {
                sourcePath: opts.inputPath,
                outputPath: opts.outputPath,
                start: opts.start,
                end: opts.end,
                preset: opts.preset,
                addWatermark: opts.addWatermark,
                burnSubtitle: opts.enableBurnSubtitle !== false,
                captionStyle: opts.captionStyle,
                customSubtitle: opts.customSubtitle || null,  // V9.146.0
                verticalCrop: opts.verticalCrop,
                aspectRatio: opts.aspectRatio,
                title: opts.title,
                words: opts.words,
                customWatermarkPath: opts.customWatermarkPath,
                useKaraoke: opts.useKaraoke,
                umkmConfig: opts.umkmConfig || null,  // V9.60.3: UMKM
                musicConfig: opts.musicConfig || null,  // V9.108.0: MUSIC CONFIG TO PYTHON
                audioConfig: opts.audioConfig || null,  // V9.148.0: AUDIO PRO TO PYTHON
                karaokeStyle: opts.karaokeStyle,
                progressPath: opts.progressPath,
                jobId: job.id,
            },
            30 * 60 * 1000
        );

        if (progressInterval) clearInterval(progressInterval);

        if (resp.status !== 200 || !resp.data || !resp.data.success) {
            throw new Error((resp.data && resp.data.error) || `Python HTTP ${resp.status}`);
        }

        if (!fs.existsSync(opts.outputPath)) {
            throw new Error(`File output tidak ada: ${opts.outputPath}`);
        }

        const stats = fs.statSync(opts.outputPath);
        const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
        const finalFilename = path.basename(opts.outputPath);

        let subtitleFile = null;
        try {
            const baseName = path.basename(finalFilename, path.extname(finalFilename));
            const srtPath = path.join(RESULT_DIR, `${baseName}.srt`);
            if (fs.existsSync(srtPath)) subtitleFile = `${baseName}.srt`;
        } catch (e) {}

        const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
        console.log(` [Job ${job.id}] Clip #${opts.clipId} selesai  ${finalFilename} (${sizeMB} MB) dalam ${elapsed}s`);

        done({
            filename: finalFilename,
            downloadUrl: `/download/${finalFilename}`,
            filesize: sizeMB,
            subtitleFile: subtitleFile,
            subtitleUrl: subtitleFile ? `/download/${subtitleFile}` : null,
            clipId: opts.clipId,
            analysisId: opts.analysisId,
        });

        if (job.userId) {
            io.to(`user_${job.userId}`).emit("autoclip:render-progress", {
                jobId: job.id,
                clipId: opts.clipId,
                progress: 100,
                step: "done",
                message: "Selesai",
            });
        }
        return;
    } catch (e) {
        console.error(` [Job ${job.id}] Clip #${opts.clipId} gagal:`, e.message);
        fail(e.message);
        if (job.userId) {
            io.to(`user_${job.userId}`).emit("autoclip:render-progress", {
                jobId: job.id,
                clipId: opts.clipId,
                progress: 0,
                step: "error",
                message: e.message,
            });
        }
        return;
    }
}

    // Call Python persistent server via HTTP
    let resp;
    try {
      if (opts.mode === "render") {
        console.log(` [Job ${job.id}] Sending to Python /render...`);
        resp = await httpPostJSON(
          `${PYTHON_SERVER_URL}/render`,
          {
            analysisJsonPath: opts.analysisJsonPath,
            outputPath: opts.outputPath,
            progressPath: opts.progressPath,
            preset: opts.preset || "1080p",
            addWatermark: opts.addWatermark !== false,
            burnSubtitle: opts.enableBurnSubtitle !== false,
            mode: "render",
          },
          60 * 60 * 1000,
        );
      } else {
        console.log(` [Job ${job.id}] Sending to Python /analyze...`);
        resp = await httpPostJSON(
          `${PYTHON_SERVER_URL}/analyze`,
          {
            inputPath: opts.inputPath,
            analyzeFile: opts.analysisJsonPath,
            dummyOutput: opts.outputPath,
            aggressiveness: opts.aggressiveness || "content",
            whisperModel: opts.whisperModel || "base",
            preset: opts.preset || "1080p",
            enableBurnSubtitle: opts.enableBurnSubtitle !== false,
            addWatermark: opts.addWatermark !== false,
            features,
            styleMemory,
            mode: "analyze",
          },
          60 * 60 * 1000,
        );
      }
    } finally {
      // V8.9.5: WAJIB di-clear, bahkan jika httpPostJSON throw
      if (progressInterval) clearInterval(progressInterval);
    }

    if (resp.status !== 200 || !resp.data.success) {
      throw new Error(
        resp.data.error || `Python error (status ${resp.status})`,
      );
    }

    const result = resp.data;

    // Cleanup inputPath (kecuali render mode)
    // V8.6.9 FIX: Jangan hapus input di analyze mode  dibutuhkan render mode
    // File akan dihapus oleh TTL cleanup (pendingAnalyses) setelah user selesai render
    if (opts.mode === "render") {
      console.log(
        ` [Job ${job.id}] Render mode  input dipertahankan untuk cleanup terjadwal`,
      );
    } else {
      console.log(
        ` [Job ${job.id}] Analyze mode  input dipertahankan (untuk render)`,
      );
    }

    const stats = fs.existsSync(opts.outputPath)
      ? fs.statSync(opts.outputPath)
      : { size: 0 };
    const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
    const saved = (result.originalDuration || 0) - (result.newDuration || 0);

    if (job.userId) {
      try {
        await dbRun(
          `
                    INSERT INTO videos (
                        user_id, filename, original_duration, new_duration, saved_duration, saved_percent,
                        silences, ai_segments, filler_segments, stutter_segments, false_start_segments,
                        llm_segments, scene_count, has_thumbnail, has_subtitle, has_gif, has_mp3,
                        preset, aggressiveness, filesize_mb, whisper_model, processing_time
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `,
          [
            job.userId,
            path.basename(opts.outputPath),
            result.originalDuration,
            result.newDuration,
            saved,
            result.originalDuration > 0
              ? (saved / result.originalDuration) * 100
              : 0,
            result.silences || 0,
            result.aiSegments || 0,
            result.fillerSegments || 0,
            result.stutterSegments || 0,
            result.falseStartSegments || 0,
            result.llmSegments || 0,
            result.sceneCount || 0,
            result.thumbnailFile ? 1 : 0,
            result.subtitleFile ? 1 : 0,
            result.gifFile ? 1 : 0,
            result.mp3File ? 1 : 0,
            opts.preset || "1080p",
            opts.aggressiveness || "content",
            sizeMB,
            opts.whisperModel || "base",
            result.processingTimeSeconds || 0,
          ],
        );
      } catch (dbErr) {
        console.error("DB insert error:", dbErr.message);
        logger.error("DB insert video error", {
          error: dbErr.message,
          userId: job.userId,
        });
      }

      if (!isAdminJob) {
        try {
          await incrementQuota(job.userId);
          console.log(` [Quota] Incremented for user ${job.userId}`);
        } catch (e) {
          console.error(` [Quota] incrementQuota failed:`, e.message);
        }
      } else {
        console.log(` [Admin Job] Skip quota increment`);
      }
    }

    const outputFilename = path.basename(opts.outputPath);
    const extraOutputs = {};
    if (result.thumbnailFile)
      extraOutputs.thumbnailUrl = `/download/${result.thumbnailFile}`;
    if (result.gifFile) extraOutputs.gifUrl = `/download/${result.gifFile}`;
    if (result.mp3File) extraOutputs.mp3Url = `/download/${result.mp3File}`;
    if (result.subtitleFile)
      extraOutputs.subtitleUrl = `/download/${result.subtitleFile}`;

    const finalResult = {
      ...result,
      downloadUrl: `/download/${outputFilename}`,
      filename: outputFilename,
      filesize: sizeMB,
      saved,
      savedPercent:
        result.originalDuration > 0
          ? Math.round((saved / result.originalDuration) * 100)
          : 0,
      extraOutputs,
    };

    done(finalResult);
    logger.success(`Job ${job.id} selesai`, {
      userId: job.userId,
      filesize: sizeMB,
      savedPercent: finalResult.savedPercent,
    });

    if (job.userId) {
      io.to(`user_${job.userId}`).emit("job:completed", {
        jobId: job.id,
        result: finalResult,
      });
    }
  } catch (error) {
    console.error(` [Job ${job.id}] error:`, error.message);
    logger.error(`Job ${job.id} gagal`, {
      error: error.message,
      userId: job.userId,
      stack: error.stack
        ? error.stack.split("\n").slice(0, 3).join(" | ")
        : null,
    });
    fail(error.message);
    if (job.userId) {
      io.to(`user_${job.userId}`).emit("job:failed", {
        jobId: job.id,
        error: error.message,
      });
    }
  }
});

// ============================================================
// STYLE MEMORY ENDPOINTS
// ============================================================
app.get("/api/user/style-memory", requireAuth, async (req, res) => {
  try {
    const memory = await getUserStyleMemory(req.user.id);
    res.json({ success: true, memory });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post("/api/user/style-memory", requireAuth, async (req, res) => {
  try {
    const { delta } = req.body;
    if (!delta || !delta.categories) {
      return res.status(400).json({ success: false, error: "Invalid delta" });
    }

    const merged = await mergeStyleMemory(req.user.id, delta);
    if (!merged) {
      return res
        .status(500)
        .json({ success: false, error: "Failed to merge memory" });
    }

    res.json({
      success: true,
      total_videos: merged.total_videos,
      categories: merged.categories,
      message: `Style memory updated (${merged.total_videos} videos learned)`,
    });
  } catch (e) {
    console.error("Style memory endpoint error:", e);
    res.status(500).json({ success: false, error: e.message });
  }
});

//  V9.6.0: Manual trigger backup (untuk test)
app.post("/api/admin/backup-now", requireAuth, requireAdmin, async (req, res) => {
  try {
    if (!backupScheduler) {
      return res.status(503).json({ success: false, error: "Scheduler not loaded" });
    }
    console.log(" [Admin] Manual backup triggered by user", req.user.id);
    backupScheduler.runBackup();
    res.json({ success: true, message: "Backup started in background" });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================
// ============================================================
// V9.180.30: CULTURE_PROXY
// Proxy endpoint dari frontend ke Python culture adapter
// ============================================================

// List semua region
app.get("/api/culture/regions", optionalAuth, async (req, res) => {
  try {
    const resp = await httpGetJSON(`${PYTHON_SERVER_URL}/culture/regions`);
    if (resp.status !== 200 || !resp.data) {
      return res.status(500).json({ success: false, error: "Python error" });
    }
    res.json(resp.data);
  } catch (e) {
    console.error("[Culture] Proxy error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

// Detail region
app.get("/api/culture/region/:regionKey", optionalAuth, async (req, res) => {
  try {
    const regionKey = req.params.regionKey;
    const resp = await httpGetJSON(`${PYTHON_SERVER_URL}/culture/region/${regionKey}`);
    if (resp.status !== 200 || !resp.data) {
      return res.status(500).json({ success: false, error: "Python error" });
    }
    res.json(resp.data);
  } catch (e) {
    console.error("[Culture] Region proxy error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

// Adapt text
app.post("/api/culture/adapt-text", optionalAuth, async (req, res) => {
  try {
    const { text, region } = req.body;
    if (!text || !region) {
      return res.status(400).json({ success: false, error: "text & region wajib" });
    }
    const resp = await httpPostJSON(`${PYTHON_SERVER_URL}/culture/adapt-text`, { text, region }, 30000);
    if (resp.status !== 200 || !resp.data) {
      return res.status(500).json({ success: false, error: "Python error" });
    }
    res.json(resp.data);
  } catch (e) {
    console.error("[Culture] Adapt text error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

// Adapt subtitle ASS
app.post("/api/culture/adapt-subtitle", optionalAuth, async (req, res) => {
  try {
    const { assPath, region, outputPath } = req.body;
    if (!assPath || !region) {
      return res.status(400).json({ success: false, error: "assPath & region wajib" });
    }
    const resp = await httpPostJSON(`${PYTHON_SERVER_URL}/culture/adapt-subtitle`, { assPath, region, outputPath }, 60000);
    if (resp.status !== 200 || !resp.data) {
      return res.status(500).json({ success: false, error: "Python error" });
    }
    res.json(resp.data);
  } catch (e) {
    console.error("[Culture] Adapt subtitle error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

// V8.9.22: RESET STYLE MEMORY
// ============================================================
app.delete("/api/user/style-memory", requireAuth, async (req, res) => {
  try {
    console.log(` [StyleMemory] Reset request  user ${req.user.id}`);

    const existing = await dbAll(
      `SELECT user_id FROM user_style_memory WHERE user_id = ?`,
      [req.user.id],
    );

    if (!existing || existing.length === 0) {
      return res.json({
        success: true,
        message: "Style memory sudah kosong",
        already_empty: true,
      });
    }

    await dbRun(`DELETE FROM user_style_memory WHERE user_id = ?`, [
      req.user.id,
    ]);

    _invalidateStyleMemoryCache(req.user.id);

    console.log(` [StyleMemory] Reset selesai untuk user ${req.user.id}`);

    res.json({
      success: true,
      message: "Style memory berhasil direset. AI akan belajar ulang dari nol.",
    });
  } catch (e) {
    console.error(" [StyleMemory] Reset error:", e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================
// V8.8.9: CUSTOM WATERMARK
// ============================================================

// Upload custom watermark
const watermarkUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, WATERMARK_DIR),
    filename: (req, file, cb) => cb(null, `user_${req.user.id}.png`),
  }),
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) {
      return cb(new Error("Hanya file gambar (PNG/WebP)"));
    }
    cb(null, true);
  },
});

app.post(
  "/api/user/watermark",
  requireAuth,
  watermarkUpload.single("logo"),
  (req, res) => {
    try {
      if (!req.file) {
        return res
          .status(400)
          .json({ success: false, error: "Tidak ada file" });
      }
      console.log(
        ` [Watermark] User ${req.user.id} upload: ${req.file.size} bytes`,
      );
      res.json({
        success: true,
        url: `/watermark/user_${req.user.id}.png`,
        size: req.file.size,
        filename: req.file.filename,
      });
    } catch (e) {
      console.error(" [Watermark] Upload error:", e);
      res.status(500).json({ success: false, error: e.message });
    }
  },
);

// Get watermark info
app.get("/api/user/watermark", requireAuth, (req, res) => {
  try {
    const userWmPath = path.join(WATERMARK_DIR, `user_${req.user.id}.png`);
    const exists = fs.existsSync(userWmPath);
    res.json({
      success: true,
      hasWatermark: exists,
      url: exists ? `/watermark/user_${req.user.id}.png` : null,
      size: exists ? fs.statSync(userWmPath).size : 0,
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// Delete watermark
app.delete("/api/user/watermark", requireAuth, (req, res) => {
  try {
    const userWmPath = path.join(WATERMARK_DIR, `user_${req.user.id}.png`);
    if (fs.existsSync(userWmPath)) {
      fs.unlinkSync(userWmPath);
      console.log(` [Watermark] User ${req.user.id} deleted`);
    }
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// Serve watermark file
app.get("/watermark/:filename", (req, res) => {
  const safePath = safeResolveFile(WATERMARK_DIR, req.params.filename, [
    ".png",
    ".webp",
    ".jpg",
    ".jpeg",
  ]);
  if (!safePath) return res.status(400).send("Nama file tidak valid");
  if (fs.existsSync(safePath)) res.sendFile(safePath);
  else res.status(404).send("File tidak ditemukan");
});

// ============================================================
// ANALYZE via HTTP ke Python persistent server
// ============================================================
app.post(
  "/api/analyze",
  optionalAuth,
  analyzeLimiter,
  upload.single("video"),
  async (req, res) => {
    // V8.7.0 FIX: track guest IP untuk commit setelah sukses
    let guestIpToCommit = null;

    try {
      if (!req.file)
        return res
          .status(400)
          .json({ success: false, error: "Tidak ada file" });

      const isAdmin =
        req.user &&
        (req.user.is_admin === true ||
          req.user.is_admin === 1 ||
          req.user.is_admin === "true");
      if (isAdmin)
        console.log(` [Admin Bypass] Analyze  user ${req.user.id}`);

      if (!isAdmin) {
        if (req.user) {
          let quota;
          try {
            quota = await checkUserQuota(req.user.id);
          } catch (e) {
            quota = { allowed: true, used: 0, total: 3 };
          }
          if (!quota.allowed) {
            if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
            return res.status(429).json({
              success: false,
              code: "QUOTA_EXCEEDED",
              error: `Kuota harian habis (${quota.used}/${quota.total}).`,
              quota,
            });
          }
        } else {
          const guestIp = req.ip || req.connection.remoteAddress || "unknown";
          const gq = checkGuestQuota(guestIp);
          if (!gq.allowed) {
            if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
            return res.status(429).json({
              success: false,
              code: "GUEST_QUOTA_EXCEEDED",
              error: `Kuota gratis habis (${gq.used}/${gq.total} sudah terpakai). Daftar GRATIS untuk dapat 3 video/hari!`,
              cta: "register",
              cta_url: "/register.php",
              quota: gq,
            });
          }
          // V8.7.0 FIX: simpan, commit setelah sukses
          guestIpToCommit = guestIp;
        }
      }

      const userPlan = req.user ? req.user.plan || "free" : "guest";
      const videoDuration = await getVideoDuration(req.file.path);

      if (!isAdmin) {
        const maxDur = req.user
          ? getMaxDuration(userPlan)
          : getGuestLimits().maxDuration;
        if (videoDuration > maxDur) {
          if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
          return res.status(400).json({
            success: false,
            code: "DURATION_EXCEEDED",
            error: `Video terlalu panjang (${formatDurationText(videoDuration)}). Maks ${formatDurationText(maxDur)}.`,
            duration: videoDuration,
            max_duration: maxDur,
            plan: userPlan,
          });
        }
      }

      const preset =
        req.body.preset ||
        (isAdmin ? "1080p" : req.user ? getDefaultPreset(userPlan) : "720p");
      const aggressiveness = req.body.aggressiveness || "content";
      const ADMIN_WHISPER_MODEL = process.env.ADMIN_WHISPER_MODEL || "base";
      const whisperModel = isAdmin
        ? req.body.whisper_model || ADMIN_WHISPER_MODEL
        : req.user
          ? req.body.whisper_model || getWhisperModel(userPlan)
          : "tiny";
      const enableBurnSubtitle = req.body.enable_burn_subtitle !== "false";
      // V9.25.1: Pakai helper isPremiumPlan yang existing
      const _isAdminUser = !!(req.user && (req.user.is_admin === 1 || req.user.is_admin === true || req.user.role === "admin" || req.user.role === "super_admin"));
      const _isPaidUser = _isAdminUser || !!(req.user && isPremiumPlan(req.user.plan));
      const addWatermark = !_isPaidUser;
      console.log("[RenderClip] Watermark - plan: " + (req.user ? req.user.plan : "guest") + ", isAdmin: " + _isAdminUser + ", watermark: " + addWatermark);

            //  V9.4.0: Cek kualitas audio
      let audioCheck = { quality: 'unknown' };
      try {
        audioCheck = await checkAudioQuality(req.file.path, FFMPEG, FFPROBE);
        console.log(` [AudioQuality] ${audioCheck.quality}`, audioCheck);
      } catch (e) {
        console.warn(' [AudioQuality] Gagal cek:', e.message);
      }

      const analysisId = uuidv4();
      const analyzeFile = path.join(
        TEMP_DIR,
        `analysis_${analysisId.slice(0, 8)}.json`,
      );
      const dummyOutput = path.join(
        TEMP_DIR,
        `dummy_${analysisId.slice(0, 8)}.mp4`,
      );

      console.log(
        ` [Analyze] Start untuk user ${req.user ? req.user.id : "guest"}...`,
      );

      const styleMemory = req.user ? await getUserStyleMemory(req.user.id) : {};
      const hasEnoughData = (styleMemory.total_videos || 0) >= 5;

      if (hasEnoughData) {
        console.log(
          ` [StyleMemory] User ${req.user.id}: ${styleMemory.total_videos} videos`,
        );
      }

      // V8.7.0 FIX: honor features per plan (bukan hardcode false)
      const analyzeFeatures = isAdmin
  ? {
      vad: true,
      noise_detection: true, // V9.5.0
      semantic: false,
      keyword: false,
      emotion: false,
      diarization: false,
    }
  : getFeaturesForPlan(userPlan);

      const startTime = Date.now();
      const resp = await httpPostJSON(
        `${PYTHON_SERVER_URL}/analyze`,
        {
          inputPath: req.file.path,
          analyzeFile,
          dummyOutput,
          aggressiveness,
          whisperModel,
          preset,
          enableBurnSubtitle,
          addWatermark,
          features: analyzeFeatures,
          styleMemory: hasEnoughData ? styleMemory : {},
          mode: "analyze",
        },
        15 * 60 * 1000,
      );
      const elapsed = Date.now() - startTime;

      if (resp.status !== 200 || !resp.data.success) {
        throw new Error(
          resp.data.error || `Python error (status ${resp.status})`,
        );
      }
      const result = resp.data;

      // ============================================================
      // V8.7.0 FIX: Commit guest quota HANYA setelah analyze sukses
      // ============================================================
      if (guestIpToCommit) {
        commitGuestQuota(guestIpToCommit);
        guestIpToCommit = null;
      }

      const analysis = JSON.parse(fs.readFileSync(analyzeFile, "utf8"));

// V9.32.1: Fix clipResult - track usage di route analyze
      try {
        const _tp27 = req.user ? (req.user.plan || "free") : "guest";
        const _tprem27 = isPremiumPlan(_tp27) || (req.user && req.user.is_admin === 1);
        if (!_tprem27 && req.user) {
          // Skip clip limit di sini (analyze belum punya clips)
          // Limit klip dilakukan di /autoclip-auto-clip
          await dbRun("INSERT INTO autoclip_usage (user_id, analysis_id, clip_count, duration_seconds) VALUES (?, ?, ?, ?)",
            [req.user.id, analysisId, 0, 0]);
          console.log("[Quota] Tracked usage user " + req.user.id + " (analyze)");
        }
      } catch (e) { console.warn("[Quota] Track error:", e.message); }

      pendingAnalyses.set(analysisId, {
        inputPath: req.file.path,
        analyzeFile,
        userId: req.user ? req.user.id : null,
        plan: userPlan,
        isAdmin,
        preset,
        aggressiveness,
        whisperModel,
        enableBurnSubtitle,
        addWatermark,
        createdAt: Date.now(),
      });

      console.log(
        ` [Analyze] Selesai  ${result.totalSegments} segmen (${analysisId.slice(0, 8)}) dalam ${(elapsed / 1000).toFixed(1)}s `,
      );
      if (result.styleMemoryApplied) {
        console.log(
          ` [Analyze] Style memory applied: ${result.styleMemoryZones} zones, prioritized: ${result.styleMemoryPrioritized || 0}`,
        );
      }
      if (result.whisperWords !== undefined) {
        console.log(` [Analyze] Whisper words: ${result.whisperWords}`);
      }

      // V8.9.22: Info kuota guest untuk user (biar tahu sisa)
      let guestQuotaInfo = null;
      if (!req.user) {
        const guestIp = req.ip || req.connection.remoteAddress || "unknown";
        guestQuotaInfo = checkGuestQuota(guestIp);
      }

      const noiseCount = (analysis.stats && analysis.stats.noise) || 0;
      
      res.json({
        success: true,
        analysisId,
        inputPath: req.file.path,  // V9.10.0: Kirim inputPath untuk auto-save
        duration: analysis.duration,
        segments: analysis.segments,
        stats: analysis.stats,
        preset,
        aggressiveness,
        styleMemoryApplied: result.styleMemoryApplied || false,
        is_admin: isAdmin,
        elapsed_ms: elapsed,
        whisperWords: result.whisperWords || 0,
        guestQuota: guestQuotaInfo, // null kalau login
        //  V9.8.0: Kirim words untuk fitur translate subtitle
        words: analysis.originalWords || analysis.words || [],
        detectedLanguage: analysis.detectedLanguage || 'id',
        // V1.0.0: Expose inputPath untuk fitur Save Project
        inputPath: analysis.inputPath || (typeof meta !== "undefined" && meta && meta.inputPath) || "",
        noiseSegments: noiseCount,
        audioWarning: audioCheck.quality === 'poor'
        
       ? 'Audio Anda terlalu noisy/pelan  subtitle mungkin kurang akurat. Rekam di ruangan sunyi untuk hasil terbaik.'
          : null,                                                              
      });
    } catch (error) {
      console.error(" [Analyze] Error:", error);
      if (req.file && fs.existsSync(req.file.path))
        fs.unlinkSync(req.file.path);
      res.status(500).json({ success: false, error: error.message });
    }
  },
);

// ============================================================
// RENDER  pakai segmen hasil edit user
// ============================================================
// ============================================================
// V1.0.0: Re-hydrate PROJECT  register ke pendingAnalyses
// ============================================================
app.post("/api/projects/:id/use", requireAuth, async (req, res) => {
    try {
        const project = await dbGet(
            "SELECT * FROM projects WHERE id = ? AND user_id = ?",
            [req.params.id, req.user.id],
        );
        if (!project) {
            return res.status(404).json({ success: false, error: "Proyek tidak ditemukan" });
        }

        const inputPath = project.input_video_path;
        if (!inputPath || !fs.existsSync(inputPath)) {
            return res.status(404).json({ success: false, error: "File video tidak ada di disk" });
        }

        // Parse analysis_json (bisa string atau object)
        let analysis;
        try {
            analysis = typeof project.analysis_json === "string"
                ? JSON.parse(project.analysis_json)
                : project.analysis_json;
        } catch (e) {
            return res.status(500).json({ success: false, error: "Analysis JSON rusak" });
        }

        if (!analysis || !Array.isArray(analysis.segments)) {
            return res.status(500).json({ success: false, error: "Analysis JSON tidak valid" });
        }

        // Tulis ke file temp baru
        const newId = uuidv4().slice(0, 8);
        const analyzeFile = path.join(TEMP_DIR, `analysis_${newId}.json`);
        analysis.inputPath = inputPath;
        fs.writeFileSync(analyzeFile, JSON.stringify(analysis, null, 2));

        // Register ke pendingAnalyses (TTL dari PENDING_TTL_MS)
        pendingAnalyses.set(newId, {
            userId: req.user.id,
            inputPath,
            analyzeFile,
            aggressiveness: analysis.aggressiveness || "content",
            preset: project.preset || "720p",
            enableBurnSubtitle: project.enable_burn_subtitle !== false,
            addWatermark: project.add_watermark !== false,
            whisperModel: analysis.whisperModel || "base",
            plan: req.user.plan,
            isAdmin: !!req.user.is_admin,
        });

        console.log(` [Project] Rehydrated ${req.params.id.slice(0, 8)}  analysis ${newId}`);

        res.json({
            success: true,
            analysisId: newId,
            analysis,
            projectId: project.id,
            translateTarget: project.translate_target || null,
            translatedWords: project.translated_words || null,
            translatedSegments: project.translated_segments || null,
        });
    } catch (e) {
        console.error(" [Project/use] Error:", e);
        res.status(500).json({ success: false, error: e.message });
    }
});

app.post("/api/render/:analysisId", optionalAuth, async (req, res) => {
  try {
    let meta = pendingAnalyses.get(req.params.analysisId);
    // V9.32.0: DB fallback /api/render (load project dari history)
    if (!meta) {
      try {
        const projectRow = await dbGet(
          "SELECT id, user_id, preset, input_video_path, clips_json, analysis_json, total_clips FROM autoclip_projects WHERE id = ?",
          [req.params.analysisId]
        );
        if (projectRow) {
          console.log("[Render] DB fallback: project " + req.params.analysisId.slice(0, 8));
          const analysisObj = projectRow.analysis_json || {};
          let clipsArr = [];
          if (projectRow.clips_json) {
            clipsArr = Array.isArray(projectRow.clips_json)
              ? projectRow.clips_json
              : (typeof projectRow.clips_json === "string" ? JSON.parse(projectRow.clips_json) : []);
          }
          if ((!clipsArr || !clipsArr.length) && analysisObj.clips) {
            clipsArr = analysisObj.clips;
          }
          meta = {
            isAutoClip: true,
            clips: clipsArr,
            preset: projectRow.preset || "1080p",
            addWatermark: true,
            inputPath: projectRow.input_video_path,
            analyzeFile: null,
            originalWords: analysisObj.words || analysisObj.originalWords || [],
            userId: projectRow.user_id,
            loadedFromDb: true,
          };
          pendingAnalyses.set(req.params.analysisId, meta);
          console.log("[Render] Cached " + clipsArr.length + " klip dari DB");
        }
      } catch (dbErr) {
        console.warn("[Render] DB fallback error:", dbErr.message);
      }

    // V9.32.2: Fallback pendingAnalyses by 8-char prefix
    if (!meta && req.params.analysisId) {
      const _prefix = req.params.analysisId.slice(0, 8);
      for (const [_key, _val] of pendingAnalyses.entries()) {
        if (_key.startsWith(_prefix) || _val.analysisId === _prefix) {
          meta = _val;
          console.log("[Render] Found pendingAnalyses by prefix:", _prefix, " key:", _key);
          break;
        }
      }
    }

    // V9.32.3: Fallback analysis_*.json file di temp/
    if (!meta && req.params.analysisId) {
      try {
        const _prefix = req.params.analysisId.slice(0, 8);
        const _tempDir = path.join(__dirname, "temp");
        const _analysisFile = path.join(_tempDir, "analysis_" + _prefix + ".json");
        if (fs.existsSync(_analysisFile)) {
          console.log("[Render] Found analysis file:", _analysisFile);
          const _analysis = JSON.parse(fs.readFileSync(_analysisFile, "utf8"));
          // Cari clips di analysis file
          let _clips = _analysis.clips || [];
          // Cari input video path
          let _inputPath = _analysis.inputPath || _analysis.videoPath;
          if (!_inputPath) {
            // Cari di autoclip_projects/temp/
            const _acTemp = path.join(__dirname, "autoclip_projects", "temp");
            if (fs.existsSync(_acTemp)) {
              const _files = fs.readdirSync(_acTemp).filter(f => f.startsWith("clip_norm_") && f.endsWith(".mp4"));
              if (_files.length > 0) {
                _files.sort((a,b) => fs.statSync(path.join(_acTemp,b)).mtimeMs - fs.statSync(path.join(_acTemp,a)).mtimeMs);
                _inputPath = path.join(_acTemp, _files[0]);
                console.log("[Render] Guessed input video:", _inputPath);
              }
            }
          }
          if (_inputPath) {
            meta = {
              isAutoClip: true,
              clips: _clips,
              preset: _analysis.preset || "1080p",
              addWatermark: true,
              inputPath: _inputPath,
              analyzeFile: _analysisFile,
              originalWords: _analysis.words || _analysis.originalWords || [],
              loadedFromDb: false,
              loadedFromAnalysisFile: true,
            };
            console.log("[Render] Loaded from analysis file: " + _clips.length + " clips");
          } else {
            console.warn("[Render] Analysis file ada tapi input video tidak ketemu");
          }
        }
      } catch (_ae) {
        console.warn("[Render] Analysis file fallback error:", _ae.message);
      }
    }
    }

    // V9.34.0: Match by inputPath (cari analysis file berdasarkan video source)
    if (!meta && req.params.analysisId) {
      try {
        const _tempD = path.join(__dirname, "temp");
        if (fs.existsSync(_tempD)) {
          const _files34 = fs.readdirSync(_tempD).filter(f => f.startsWith("analysis_") && f.endsWith(".json"));
          for (const _f34 of _files34) {
            try {
              const _p34 = path.join(_tempD, _f34);
              const _a34 = JSON.parse(fs.readFileSync(_p34, "utf8"));
              if (_a34.inputPath && _a34.inputPath.indexOf(req.params.analysisId) !== -1) {
                console.log("[Render] V9.34.0 match by inputPath:", _f34);
                meta = {
                  isAutoClip: true,
                  clips: _a34.clips || [],
                  preset: _a34.preset || "1080p",
                  addWatermark: true,
                  inputPath: _a34.inputPath,
                  analyzeFile: _p34,
                  originalWords: _a34.words || _a34.originalWords || [],
                  segments: _a34.segments || [],
                  loadedFromDb: false,
                  loadedFromAnalysisFile: true,
                };
                break;
              }
            } catch (_fe34) {}
          }
        }
      } catch (_e34) {
        console.warn("[Render] V9.34.0 inputPath fallback error:", _e34.message);
      }
    }

    if (!meta) {
      return res.status(404).json({
        success: false,
        error: "Analysis tidak ditemukan atau expired",
      });
    }

    const { segments, translatedWords, subtitleSegments, preset, enable_burn_subtitle, add_watermark } =
      req.body || {};
    if (!Array.isArray(segments)) {
      return res
        .status(400)
        .json({ success: false, error: "segments harus array" });
    }

    const analysis = JSON.parse(fs.readFileSync(meta.analyzeFile, "utf8"));
    analysis.segments = segments.map((s) => ({
      start: parseFloat(s.start),
      end: parseFloat(s.end),
      source: s.source || "manual",
      reason: s.reason || "user_edit",
      priority: s.priority || 5,
      enabled: s.enabled !== false,
    }));
    
    // V9.9.0: Replace analysis.words dari translatedWords (timing ASLI dari frontend)
    if (Array.isArray(translatedWords) && translatedWords.length > 0) {
      analysis.words = translatedWords.map((w) => ({
        word: String(w.word || "").trim(),
        start: parseFloat(w.start),
        end: parseFloat(w.end),
      }));
      analysis.originalWords = analysis.words.slice();

      // V9.9.1: SHIFT timestamps untuk cut (subtitle sync dengan audio akhir)
      const _cutsForShift = analysis.segments
        .filter((c) => c.enabled === false)
        .map((c) => ({ start: parseFloat(c.start), end: parseFloat(c.end) }))
        .sort((a, b) => a.start - b.start);
      
      function _cumulativeCutBefore(t) {
        let total = 0;
        for (const c of _cutsForShift) {
          if (c.end <= t) total += (c.end - c.start);
          else if (c.start < t) total += (t - c.start);   // partial
        }
        return total;
      }
      
      analysis.words = analysis.words.map((w) => ({
        word: w.word,
        start: Math.max(0, parseFloat(w.start) - _cumulativeCutBefore(parseFloat(w.start))),
        end: Math.max(0, parseFloat(w.end) - _cumulativeCutBefore(parseFloat(w.end))),
      }));
      analysis.originalWords = analysis.words.slice();
      console.log(
        ` [Render] Time-shifted: ${analysis.words.length} kata, ${_cutsForShift.length} cut`,
      );
      console.log(
        ` [Render] Subtitle replaced (sync audio): ${translatedWords.length} kata`,
      );
    }

    if (preset) analysis.preset = preset;
    if (typeof enable_burn_subtitle === "boolean")
      analysis.enableBurnSubtitle = enable_burn_subtitle;
    if (typeof add_watermark === "boolean")
      analysis.addWatermark = add_watermark;
    fs.writeFileSync(meta.analyzeFile, JSON.stringify(analysis, null, 2));

    const outputFilename = `Clipora_${Date.now()}_${uuidv4().slice(0, 4)}.mp4`;
    const outputPath = path.join(RESULT_DIR, outputFilename);
    const progressFilename = `progress_${Date.now()}_${uuidv4().slice(0, 4)}.json`;
    const progressPath = path.join(PROGRESS_DIR, progressFilename);

    const jobId = queue.add(
      {
        inputPath: meta.inputPath,
        outputPath,
        progressPath,
        mode: "render",
        analysisJsonPath: meta.analyzeFile,
        aggressiveness: meta.aggressiveness,
        addWatermark:
          typeof add_watermark === "boolean"
            ? add_watermark
            : meta.addWatermark,
        preset: preset || meta.preset,
        enableBurnSubtitle:
          typeof enable_burn_subtitle === "boolean"
            ? enable_burn_subtitle
            : meta.enableBurnSubtitle,
        whisperModel: meta.whisperModel,
        userPlan: meta.plan,
        isAdmin: meta.isAdmin,
      },
      { userId: meta.userId, priority: 1 },
    );

    setTimeout(() => {
      try {
        if (fs.existsSync(meta.analyzeFile)) fs.unlinkSync(meta.analyzeFile);
      } catch (e) {}
      try {
        if (fs.existsSync(meta.inputPath)) fs.unlinkSync(meta.inputPath);
      } catch (e) {}
      pendingAnalyses.delete(req.params.analysisId);
    }, PENDING_TTL_MS);

    console.log(
      ` [Render] Job ${jobId} untuk analysis ${req.params.analysisId.slice(0, 8)}  ${segments.filter((s) => s.enabled !== false).length} segmen aktif`,
    );

    res.json({
      success: true,
      jobId,
      outputFilename,
      progressFilename,
      queueStats: queue.getStats(),
    });
  } catch (error) {
    console.error(" [Render] Error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================
// V8.8.0: AUTO-CLIP  1 video  N klip pendek
// ============================================================
app.post(
  "/api/auto-clip",
  optionalAuth,
  autoClipLimiter,
  upload.single("video"),
  async (req, res) => {
    try {
      if (!req.file) {
        return res
          .status(400)
          .json({ success: false, error: "Tidak ada file" });
      }

      // === 1. Cek user & plan ===
      const isAdmin =
        req.user &&
        (req.user.is_admin === true ||
          req.user.is_admin === 1 ||
          req.user.is_admin === "true");

      if (!isAdmin) {
        if (!req.user) {
          if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
          return res.status(403).json({
            success: false,
            code: "LOGIN_REQUIRED",
            error: "Auto-Clip Generator butuh login & upgrade ke Premium.",
            cta: "register",
            cta_url: "/register.php",
          });
        }

        // V9.27.3: quota check (free tier allowed with limits)
        {
          const _p27 = req.user.plan || "free";
          const _prem27 = isPremiumPlan(_p27) || req.user.is_admin === 1;
          if (!_prem27) {
            const _used27 = await getTodayUsage(req.user.id);
            if (_used27 >= FREE_QUOTA.videosPerDay) {
              if (req.file && req.file.path && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
              return res.status(429).json({
                success: false,
                quota_exceeded: true,
                used: _used27,
                limit: FREE_QUOTA.videosPerDay,
                error: "Kuota harian habis (maks 1 video/hari). Upgrade ke Pro untuk unlimited."
              });
            }
            console.log("[Quota] Free user " + req.user.id + " - sisa kuota: " + (FREE_QUOTA.videosPerDay - _used27));
          }
        }

        let quota;
        try {
          quota = await checkUserQuota(req.user.id);
        } catch (e) {
          quota = { allowed: true, used: 0, total: 3 };
        }
        if (!quota.allowed) {
          if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
          return res.status(429).json({
            success: false,
            code: "QUOTA_EXCEEDED",
            error: `Kuota harian habis (${quota.used}/${quota.total}).`,
            quota,
          });
        }
      }

      // === 2. Validasi durasi ===
      const userPlan = req.user ? req.user.plan || "free" : "guest";
      const videoDuration = await getVideoDuration(req.file.path);

      if (!isAdmin) {
        // V8.8.2: Auto-Clip dibatasi 3 menit (proses Whisper lama)
        const AUTO_CLIP_MAX =
          parseInt(process.env.AUTO_CLIP_MAX_DURATION) || 180;
        const maxDur = Math.min(getMaxDuration(userPlan), AUTO_CLIP_MAX);
        if (videoDuration > maxDur) {
          if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
          return res.status(400).json({
            success: false,
            code: "DURATION_EXCEEDED",
            error: `Video terlalu panjang (${formatDurationText(videoDuration)}). Auto-Clip maks ${formatDurationText(maxDur)}.`,
            duration: videoDuration,
            max_duration: maxDur,
          });
        }
      }

      // === 3. Validasi target klip ===
      let targetClips = parseInt(req.body.target_clips) || 5;
      if (targetClips < 2) targetClips = 2;
      if (targetClips > 10) targetClips = 10;

      const preset =
        req.body.preset || (isAdmin ? "1080p" : getDefaultPreset(userPlan));
      const aggressiveness = req.body.aggressiveness || "content";
      // V8.8.2: Admin default ke 'base' untuk speed (~3x lebih cepat dari 'small')
      const ADMIN_WHISPER_MODEL = process.env.ADMIN_WHISPER_MODEL || "base";
      const whisperModel = isAdmin
        ? req.body.whisper_model || ADMIN_WHISPER_MODEL
        : req.body.whisper_model || getWhisperModel(userPlan);

      const analysisId = uuidv4();
      const analyzeFile = path.join(
        TEMP_DIR,
        `autoclip_${analysisId.slice(0, 8)}.json`,
      );
            //  V9.5.0: Baca toggle noise dari user
      const userNoiseDetection = req.body.enable_noise_detection !== 'false';
      console.log(` [AutoClip] Noise detection: ${userNoiseDetection ? 'ON' : 'OFF'}`);
      // V9.136.0: UMKM FLAG - terima toggle UMKM dari frontend
      const userUmkmEnabled = req.body.enable_umkm === 'true';
      console.log(` [AutoClip] UMKM mode: ${userUmkmEnabled ? 'ON' : 'OFF'}`);
      // V9.137.0: MUSIC FLAG - terima toggle Music dari frontend
      const userMusicEnabled = req.body.enable_music === 'true';
      console.log(` [AutoClip] Music mode: ${userMusicEnabled ? 'ON' : 'OFF'}`);
      const dummyOutput = path.join(
        TEMP_DIR,
        `dummy_ac_${analysisId.slice(0, 8)}.mp4`,
      );

      console.log(
        `  [AutoClip] Start  user ${req.user ? req.user.id : "guest"}, durasi ${videoDuration.toFixed(1)}s, target ${targetClips} klip`,
      );

      // === 4. Analyze dulu ===
            let analyzeFeatures;
      if (isAdmin) {
        analyzeFeatures = {
          vad: true,
          semantic: false,
          keyword: false,
          emotion: false,
          diarization: false,
          noise_detection: userNoiseDetection, //  V9.5.0
        };
      } else {
        analyzeFeatures = getFeaturesForPlan(userPlan);
        // Override dari toggle user
        analyzeFeatures.noise_detection = userNoiseDetection;
      }

      const startTime = Date.now();
      // V8.8.2: Progress real-time via WebSocket
      const progressFilename = `ac_progress_${analysisId.slice(0, 8)}.json`;
      const progressPath = path.join(PROGRESS_DIR, progressFilename);

      // Emit progress dari file ke user via WebSocket
      const progressWatcher = setInterval(() => {
        try {
          if (fs.existsSync(progressPath)) {
            const p = JSON.parse(fs.readFileSync(progressPath, "utf8"));
            if (req.user) {
              io.to(`user_${req.user.id}`).emit("autoclip:progress", {
                analysisId,
                progress: p.progress || 0,
                message: p.message || "",
              });
            }
          }
        } catch (e) {
          /* ignore */
        }
      }, 1000);

      const analyzeResp = await httpPostJSON(
        `${PYTHON_SERVER_URL}/analyze`,
        {
          inputPath: req.file.path,
          analyzeFile,
          dummyOutput,
          aggressiveness,
          whisperModel,
          preset,
          enableBurnSubtitle: false,
          addWatermark: false,
          features: analyzeFeatures,
          styleMemory: {},
          mode: "analyze",
          progressPath, //  V8.8.2: kirim path progress
        },
        15 * 60 * 1000,
      );

      clearInterval(progressWatcher);

      if (analyzeResp.status !== 200 || !analyzeResp.data.success) {
        throw new Error(
          analyzeResp.data.error || `Analyze error (${analyzeResp.status})`,
        );
      }

      const analyzeResult = analyzeResp.data;
      console.log(
        ` [AutoClip] Analyze done  ${analyzeResult.whisperWords || 0} words`,
      );

      // === 5. Baca analysis  dapat words ===
      const analysis = JSON.parse(fs.readFileSync(analyzeFile, "utf8"));
      const words = analysis.originalWords || analysis.words || [];

      if (!words || words.length < 20) {
        throw new Error(
          `Whisper hanya dapat ${words.length} kata  audio terlalu pendek / tidak jelas`,
        );
      }

      // === 6. Panggil /auto-clip di Python ===
      const clipResp = await httpPostJSON(
        `${PYTHON_SERVER_URL}/auto-clip`,
        {
          words: words,
          target_clips: targetClips,
          umkm_enabled: userUmkmEnabled, // V9.136.0
          music_enabled: userMusicEnabled, // V9.137.0: MUSIC FLAG
        },
        60000,
      );

      if (clipResp.status !== 200 || !clipResp.data.success) {
        throw new Error(
          clipResp.data.error || `Auto-clip error (${clipResp.status})`,
        );
      }

      const clipResult = clipResp.data;
      const elapsed = Date.now() - startTime;

      // === V8.8.0: Generate thumbnail untuk setiap klip (paralel) ===
      console.log(
        ` [AutoClip] Generating ${clipResult.clips.length} thumbnail...`,
      );
      const thumbStart = Date.now();

      await Promise.all(
        clipResult.clips.map(async (clip) => {
          try {
            // Frame 2 detik dari start klip (atau 25% durasi kalau klip pendek)
            const offset = Math.min(2.0, clip.duration * 0.25);
            const ts = clip.start + offset;

            const thumbFilename = `thumb_clip${clip.id}_${Date.now()}_${uuidv4().slice(0, 4)}.jpg`;
            const thumbPath = path.join(RESULT_DIR, thumbFilename);

            const titleText = (clip.preview_text || "").slice(0, 40);

            const thumbResp = await httpPostJSON(
              `${PYTHON_SERVER_URL}/generate-thumbnail`,
              {
                sourcePath: req.file.path,
                outputPath: thumbPath,
                timestamp: ts,
                vertical: false, // thumbnail dari source, tetap 16:9
                title: titleText,
              },
              30000,
            );

            if (thumbResp.status === 200 && thumbResp.data.success) {
              clip.thumbnailFile = thumbFilename;
              clip.thumbnailUrl = `/download/${thumbFilename}`;
            } else {
              console.warn(
                ` Thumbnail klip #${clip.id} gagal: ${thumbResp.data.error || "unknown"}`,
              );
            }
          } catch (e) {
            console.warn(` Thumbnail klip #${clip.id} error: ${e.message}`);
          }
        }),
      );

      const thumbElapsed = ((Date.now() - thumbStart) / 1000).toFixed(1);
      const thumbCount = clipResult.clips.filter((c) => c.thumbnailFile).length;
      console.log(
        ` [AutoClip] ${thumbCount}/${clipResult.clips.length} thumbnail dihasilkan dalam ${thumbElapsed}s`,
      );

      // === 7. Simpan metadata untuk render nanti ===
      pendingAnalyses.set(analysisId, {
        inputPath: req.file.path,
        analyzeFile,
        userId: req.user ? req.user.id : null,
        plan: userPlan,
        isAdmin,
        preset,
        aggressiveness,
        whisperModel,
        enableBurnSubtitle: true,
        addWatermark: !isAdmin && !isPremiumPlan(userPlan),
        isAutoClip: true,
        umkmEnabled: userUmkmEnabled, // V9.136.0
        musicEnabled: userMusicEnabled, // V9.137.0: MUSIC FLAG
        clips: clipResult.clips,
        createdAt: Date.now(),
      });

      setTimeout(() => {
        try {
          if (fs.existsSync(analyzeFile)) fs.unlinkSync(analyzeFile);
        } catch (e) {}
        try {
          if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
        } catch (e) {}
        pendingAnalyses.delete(analysisId);
      }, PENDING_TTL_MS);

      console.log(
        ` [AutoClip] Selesai  ${clipResult.total_clips} klip dalam ${(elapsed / 1000).toFixed(1)}s `,
      );

        //  V9.5.0: Baca noise count dari analysis file
      let autoClipNoiseCount = 0;
      try {
        const analysisForNoise = JSON.parse(fs.readFileSync(analyzeFile, "utf8"));
        autoClipNoiseCount = (analysisForNoise.stats && analysisForNoise.stats.noise) || 0;
      } catch (e) {
        autoClipNoiseCount = 0;
      }

      res.json({
        success: true,
        analysisId,
        inputPath: req.file.path,  // V9.10.0: inputPath untuk autoclip auto-save
        videoDuration: Math.round(videoDuration * 100) / 100,
        totalClips: clipResult.total_clips,
        clips: clipResult.clips,
        method: clipResult.method,
        preset,
        aggressiveness,
        elapsed_ms: elapsed,
        whisperWords: analyzeResult.whisperWords || 0,
        noiseSegments: autoClipNoiseCount,
        umkmEnabled: userUmkmEnabled, // V9.136.0
        musicEnabled: userMusicEnabled, // V9.137.0: MUSIC FLAG
        // V8.8.6: Kirim words lengkap untuk subtitle editing
        words: words,
      });
    } catch (error) {
      console.error(" [AutoClip] Error:", error);
      if (req.file && fs.existsSync(req.file.path)) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (e) {}
      }
      res.status(500).json({ success: false, error: error.message });
    }
  },
);

// ============================================================
// V8.8.0: RENDER SINGLE CLIP  download klip individual
// ============================================================
// ============================================================
// V8.8.0: RENDER SINGLE CLIP  support caption style
// ============================================================
// V9.27.3: quota API route
// ============================================================
app.get("/api/autoclip/quota", requireAuth, async (req, res) => {
  try {
    const plan = req.user.plan || "free";
    const isPrem = isPremiumPlan(plan) || req.user.is_admin === 1;
    if (isPrem) {
      return res.json({ success: true, plan: plan, unlimited: true, is_admin: req.user.is_admin === 1 });
    }
    const used = await getTodayUsage(req.user.id);
    res.json({
      success: true,
      plan: "free",
      unlimited: false,
      used: used,
      limit: FREE_QUOTA.videosPerDay,
      remaining: Math.max(0, FREE_QUOTA.videosPerDay - used),
      limits: {
        maxClips: FREE_QUOTA.maxClips,
        maxDurationSec: FREE_QUOTA.maxDurationSec,
        maxResolution: FREE_QUOTA.maxResolution,
      },
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================
// ============================================================
// V9.61.0: MUSIC endpoints
// ============================================================

/**
 * GET /api/music/library - List semua BGM (builtin + user upload)
 */
app.get("/api/music/library", requireAuth, async (req, res) => {
  try {
    const mood = req.query.mood || null;
    let sql = `SELECT id, name, mood, duration_sec, is_builtin, file_path
               FROM music_library
               WHERE (user_id = ? OR is_builtin = TRUE)`;
    const params = [req.user.id];

    if (mood) {
      sql += ' AND mood = ?';
      params.push(mood);
    }

    sql += ' ORDER BY is_builtin DESC, mood ASC, name ASC';

    const list = await dbAll(sql, params);
    res.json({ success: true, library: list, total: list.length });
  } catch (e) {
    console.error("[Music] Library error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

/**
 * POST /api/music/config - Save music config untuk project
 */
app.post("/api/music/config", requireAuth, async (req, res) => {
  try {
    const {
      project_id,
      music_enabled,
      music_id,
      music_volume,
      music_fade_in,
      music_fade_out,
      duck_original_audio,
    } = req.body;

    // V9.78.0: MUSIC GLOBAL CONFIG  project_id boleh null (config global user)
    // Kalau null  simpan sebagai default user, dipakai semua project

    // V9.78.0: MUSIC GLOBAL CONFIG  handle project_id null
    const existing = await dbGet(
      project_id 
        ? "SELECT id FROM music_configs WHERE user_id = ? AND project_id = ?"
        : "SELECT id FROM music_configs WHERE user_id = ? AND project_id IS NULL",
      project_id ? [req.user.id, project_id] : [req.user.id]
    );

    if (existing) {
      await dbRun(
        `UPDATE music_configs SET
           music_enabled = ?, music_id = ?, music_volume = ?,
           music_fade_in = ?, music_fade_out = ?, duck_original_audio = ?,
           updated_at = NOW()
         WHERE id = ?`,
        [
          music_enabled === true,
          music_id || null,
          music_volume ?? 30,
          music_fade_in ?? 1.0,
          music_fade_out ?? 1.5,
          duck_original_audio !== false,
          existing.id,
        ]
      );
      console.log(`[Music] Config updated: user=${req.user.id} project=${project_id}`);
      res.json({ success: true, config: { id: existing.id, updated: true } });
    } else {
      const insert = await dbGet(
        `INSERT INTO music_configs
           (user_id, project_id, music_enabled, music_id, music_volume, music_fade_in, music_fade_out, duck_original_audio)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         RETURNING id`,
        [
          req.user.id,
          project_id,
          music_enabled === true,
          music_id || null,
          music_volume ?? 30,
          music_fade_in ?? 1.0,
          music_fade_out ?? 1.5,
          duck_original_audio !== false,
        ]
      );
      console.log(`[Music] Config created: user=${req.user.id} project=${project_id}`);
      res.json({ success: true, config: { id: insert.id, created: true } });
    }
  } catch (e) {
    console.error("[Music] Save error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

/**
 * GET /api/music/config/:projectId - Load music config
 */
app.get("/api/music/config/:projectId", requireAuth, async (req, res) => {
  try {
    // V9.78.0: MUSIC GLOBAL CONFIG  priority: project config > global config
    const pid = req.params.projectId;
    
    // 1. Coba cari config project
    let config = null;
    if (pid && pid !== "null" && pid !== "global") {
      config = await dbGet(
        `SELECT mc.*, ml.name AS music_name, ml.file_path AS music_file_path, ml.mood AS music_mood
         FROM music_configs mc
         LEFT JOIN music_library ml ON ml.id = mc.music_id
         WHERE mc.user_id = ? AND mc.project_id = ?
         ORDER BY mc.updated_at DESC LIMIT 1`,
        [req.user.id, pid]
      );
    }
    
    // 2. Fallback ke global config (project_id IS NULL)
    if (!config) {
      config = await dbGet(
        `SELECT mc.*, ml.name AS music_name, ml.file_path AS music_file_path, ml.mood AS music_mood
         FROM music_configs mc
         LEFT JOIN music_library ml ON ml.id = mc.music_id
         WHERE mc.user_id = ? AND mc.project_id IS NULL
         ORDER BY mc.updated_at DESC LIMIT 1`,
        [req.user.id]
      );
      if (config) {
        console.log(`[Music] Load dari global config (project=${pid || "none"})`);
      }
    }
    
    res.json({ success: true, config: config || null });
  } catch (e) {
    console.error("[Music] Load error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});


// ============================================================
// V9.135.0: USER MUSIC UPLOAD ENDPOINTS
// ============================================================

/**
 * POST /api/music/upload - Upload user music
 */
app.post("/api/music/upload", requireAuth, musicUpload.single("music"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: "Tidak ada file yang di-upload" });
    }

    const { name, mood } = req.body;
    const finalName = (name && name.trim()) || req.file.originalname.replace(/\.[^.]+$/, "");
    const finalMood = (mood && mood.trim()) || "general";

    // Get duration via ffprobe
    let durationSec = 0;
    try {
      const { stdout } = await execPromise(
        `"${FFPROBE}" -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${req.file.path}"`,
        { timeout: 10000 }
      );
      durationSec = Math.round(parseFloat(stdout.trim())) || 0;
    } catch (e) {
      console.warn("[Music] Gagal deteksi durasi:", e.message);
    }

    // Relative path untuk disimpan di DB
    const relativePath = path.relative(BASE_DIR, req.file.path).replace(/\\/g, "/");

    // Insert ke DB
    const result = await dbRun(
      `INSERT INTO music_library (user_id, name, file_path, mood, duration_sec, is_builtin)
       VALUES (?, ?, ?, ?, ?, FALSE)`,
      [req.user.id, finalName, relativePath, finalMood, durationSec]
    );

    // Get ID
    const newRow = await dbGet(
      `SELECT id, name, file_path, mood, duration_sec, is_builtin, created_at
       FROM music_library WHERE user_id = ? ORDER BY id DESC LIMIT 1`,
      [req.user.id]
    );

    console.log(`[Music]  User ${req.user.id} upload: ${req.file.filename} (${Math.round(req.file.size / 1024)} KB)`);

    res.json({
      success: true,
      music: newRow,
      message: "Musik berhasil di-upload",
    });
  } catch (e) {
    console.error("[Music] Upload error:", e.message);
    // Cleanup file kalau gagal
    if (req.file && req.file.path && fs.existsSync(req.file.path)) {
      try { fs.unlinkSync(req.file.path); } catch (e) {}
    }
    res.status(500).json({ success: false, error: e.message });
  }
});

/**
 * DELETE /api/music/my-library/:id - Delete user music
 */
// ============================================================
// V9.145.0: UPDATE (RENAME) USER MUSIC
// ============================================================
app.patch("/api/music/my-library/:id", requireAuth, async (req, res) => {
  try {
    const musicId = parseInt(req.params.id);
    if (!musicId) {
      return res.status(400).json({ success: false, error: "ID tidak valid" });
    }

    const { name, mood } = req.body || {};

    // Get music + verify ownership
    const music = await dbGet(
      "SELECT id, user_id, is_builtin FROM music_library WHERE id = ?",
      [musicId]
    );

    if (!music) {
      return res.status(404).json({ success: false, error: "Musik tidak ditemukan" });
    }
    if (music.is_builtin) {
      return res.status(403).json({ success: false, error: "Musik built-in tidak bisa diedit" });
    }
    if (music.user_id !== req.user.id) {
      return res.status(403).json({ success: false, error: "Anda tidak berhak mengedit musik ini" });
    }

    // Prepare update
    const updates = [];
    const params = [];

    if (name !== undefined && typeof name === "string") {
      const cleanName = name.trim().slice(0, 100);
      if (cleanName.length === 0) {
        return res.status(400).json({ success: false, error: "Nama tidak boleh kosong" });
      }
      updates.push("name = ?");
      params.push(cleanName);
    }

    if (mood !== undefined && typeof mood === "string") {
      const allowedMoods = ["general", "energetic", "chill", "funny", "dramatic", "happy"];
      const cleanMood = mood.trim().toLowerCase();
      if (!allowedMoods.includes(cleanMood)) {
        return res.status(400).json({ success: false, error: "Mood tidak valid" });
      }
      updates.push("mood = ?");
      params.push(cleanMood);
    }

    if (updates.length === 0) {
      return res.status(400).json({ success: false, error: "Tidak ada perubahan" });
    }

    params.push(musicId);
    await dbRun(
      "UPDATE music_library SET " + updates.join(", ") + " WHERE id = ?",
      params
    );

    // Get updated
    const updated = await dbGet(
      "SELECT id, name, mood, duration_sec, file_path FROM music_library WHERE id = ?",
      [musicId]
    );

    console.log("[Music]  Updated ID " + musicId + "  " + updated.name);
    res.json({ success: true, music: updated, message: "Musik diperbarui" });
  } catch (e) {
    console.error("[Music] Update error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

app.delete("/api/music/my-library/:id", requireAuth, async (req, res) => {
  try {
    const musicId = parseInt(req.params.id);
    if (!musicId) {
      return res.status(400).json({ success: false, error: "ID tidak valid" });
    }

    // Get music info + verify ownership
    const music = await dbGet(
      `SELECT id, user_id, file_path, is_builtin FROM music_library WHERE id = ?`,
      [musicId]
    );

    if (!music) {
      return res.status(404).json({ success: false, error: "Musik tidak ditemukan" });
    }
    if (music.is_builtin) {
      return res.status(403).json({ success: false, error: "Musik built-in tidak bisa dihapus" });
    }
    if (music.user_id !== req.user.id) {
      return res.status(403).json({ success: false, error: "Anda tidak berhak menghapus musik ini" });
    }

    // Delete file
    if (music.file_path) {
      const absPath = path.join(BASE_DIR, music.file_path);
      if (fs.existsSync(absPath)) {
        try {
          fs.unlinkSync(absPath);
          console.log(`[Music]  File deleted: ${music.file_path}`);
        } catch (e) {
          console.warn("[Music] Gagal hapus file:", e.message);
        }
      }
    }

    // Delete dari DB
    await dbRun("DELETE FROM music_library WHERE id = ?", [musicId]);

    console.log(`[Music]  User ${req.user.id} delete music ID ${musicId}`);
    res.json({ success: true, message: "Musik berhasil dihapus" });
  } catch (e) {
    console.error("[Music] Delete error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

/**
 * GET /api/music/my-library - List user music only (no builtin)
 */
app.get("/api/music/my-library", requireAuth, async (req, res) => {
  try {
    const list = await dbAll(
      `SELECT id, name, mood, duration_sec, file_path, created_at
       FROM music_library
       WHERE user_id = ? AND is_builtin = FALSE
       ORDER BY created_at DESC`,
      [req.user.id]
    );
    res.json({ success: true, library: list, total: list.length });
  } catch (e) {
    console.error("[Music] My library error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});


// ============================================================
// V9.115.0: REGENERATE THUMBNAILS  generate ulang thumbnail dari video source
// ============================================================
app.post("/api/autoclip-projects/:id/regenerate-thumbnails", requireAuth, async (req, res) => {
  try {
    const projectId = req.params.id;
    console.log(`[RegenThumb] Request for project ${projectId.slice(0, 8)}`);

    // Ambil project dari DB
    const project = await dbGet(
      "SELECT id, user_id, input_video_path, clips_json, analysis_json FROM autoclip_projects WHERE id = ? AND user_id = ?",
      [projectId, req.user.id]
    );

    if (!project) {
      return res.status(404).json({ success: false, error: "Project tidak ditemukan" });
    }

    if (!project.input_video_path || !fs.existsSync(project.input_video_path)) {
      return res.status(404).json({
        success: false,
        error: "Video source tidak ada di disk",
        videoPath: project.input_video_path
      });
    }

    // Parse clips
    let clips = project.clips_json;
    if (typeof clips === "string") {
      clips = JSON.parse(clips);
    }
    if (!Array.isArray(clips) || clips.length === 0) {
      return res.status(400).json({ success: false, error: "Tidak ada klip di project ini" });
    }

    console.log(`[RegenThumb] Regenerate ${clips.length} thumbnails dari ${path.basename(project.input_video_path)}`);

    // Regenerate parallel
    const results = [];
    for (const clip of clips) {
      try {
        const offset = Math.min(2.0, (clip.duration || 5) * 0.25);
        const ts = (clip.start || 0) + offset;
        const thumbFilename = `thumb_clip${clip.id}_${Date.now()}_${uuidv4().slice(0, 4)}.jpg`;
        const thumbPath = path.join(RESULT_DIR, thumbFilename);

        const thumbResp = await httpPostJSON(
          `${PYTHON_SERVER_URL}/generate-thumbnail`,
          {
            sourcePath: project.input_video_path,
            outputPath: thumbPath,
            timestamp: ts,
            vertical: false,
            title: (clip.preview_text || "").slice(0, 40),
          },
          30000
        );

        if (thumbResp.status === 200 && thumbResp.data && thumbResp.data.success) {
          clip.thumbnailFile = thumbFilename;
          clip.thumbnailUrl = `/download/${thumbFilename}`;
          results.push({ clipId: clip.id, status: "ok", file: thumbFilename });
          console.log(`[RegenThumb]  Clip #${clip.id}`);
        } else {
          results.push({ clipId: clip.id, status: "failed" });
          console.warn(`[RegenThumb]  Clip #${clip.id}: ${thumbResp.data?.error || "unknown"}`);
        }
      } catch (e) {
        results.push({ clipId: clip.id, status: "error", error: e.message });
        console.warn(`[RegenThumb]  Clip #${clip.id} error: ${e.message}`);
      }
    }

    // Update DB clips_json
    await dbRun(
      "UPDATE autoclip_projects SET clips_json = ? WHERE id = ?",
      [JSON.stringify(clips), projectId]
    );

    const success = results.filter(r => r.status === "ok").length;
    console.log(`[RegenThumb] Selesai: ${success}/${clips.length} sukses`);

    res.json({
      success: true,
      total: clips.length,
      regenerated: success,
      clips: clips,
      results: results,
    });
  } catch (e) {
    console.error("[RegenThumb] Error:", e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================
// V9.119.0: UPLOAD LOGO - upload logo brand untuk UMKM
// ============================================================
app.post("/api/umkm/upload-logo", requireAuth, logoUpload.single('logo'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: 'Tidak ada file yang di-upload' });
    }
    const relPath = 'uploads/umkm_logos/' + req.file.filename;
    const absPath = req.file.path;
    console.log('[UploadLogo] ? ' + req.file.filename + ' (' + Math.round(req.file.size/1024) + ' KB)');
    res.json({
      success: true,
      logo_path: relPath,
      logo_url: '/uploads/umkm_logos/' + req.file.filename,
      filename: req.file.filename,
      size: req.file.size
    });
  } catch (e) {
    console.error('[UploadLogo] Error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post("/api/umkm/delete-logo", requireAuth, async (req, res) => {
  try {
    const logoPath = (req.body && req.body.logo_path) || '';
    if (!logoPath) return res.status(400).json({ success: false, error: 'logo_path kosong' });
    // Hanya hapus di folder umkm_logos
    if (logoPath.includes('umkm_logos')) {
      const abs = path.join(__dirname, logoPath);
      if (fs.existsSync(abs)) {
        fs.unlinkSync(abs);
        console.log('[DeleteLogo] ? ' + logoPath);
      }
    }
    res.json({ success: true });
  } catch (e) {
    console.error('[DeleteLogo] Error:', e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// Serve static uploads
// V9.119.3: PUBLIC UPLOADS  hapus requireAuth biar img tag bisa akses (logo preview, dll)
app.use('/uploads', require('express').static(path.join(__dirname, 'uploads')));

// ============================================================
// V9.60.0: UMKM endpoints
// ============================================================

/**
 * POST /api/umkm/config  Save UMKM config untuk project
 */
app.post("/api/umkm/config", requireAuth, async (req, res) => {
  try {
    const {
      project_id,
      product_name,
      product_price,
      whatsapp_number,
      cta_text,
      store_name,
      template,
      show_price,
      show_wa_button,
      music_style,
      brand_color,        // V9.116.0: BRAND COLOR
      brand_color_wa,     // V9.116.0: BRAND COLOR WA
      logo_path,          // V9.119.0: LOGO
      logo_position,      // V9.119.0
      logo_show_text,     // V9.119.0
      // V9.172.0: UMKM_SAVE_DYNAMIC - konten dinamis
      discount_price,
      rating,
      show_discount,
      show_rating,
      show_free_shipping,
      show_flash_sale,
      badge,
      instagram,
      tiktok,
      shopee,
      tokopedia,
    } = req.body;

    // V9.82.0: UMKM GLOBAL CONFIG  project_id boleh null (config global user)
    // Kalau null  simpan sebagai default user, dipakai semua project

    // Cek apakah config sudah ada (null aware)
    const existing = await dbGet(
      project_id 
        ? "SELECT id FROM umkm_configs WHERE user_id = ? AND project_id = ?"
        : "SELECT id FROM umkm_configs WHERE user_id = ? AND project_id IS NULL",
      project_id ? [req.user.id, project_id] : [req.user.id]
    );

    let result;
    if (existing) {
      // Update
      await dbRun(
        `UPDATE umkm_configs SET
          product_name = ?, product_price = ?, whatsapp_number = ?,
          cta_text = ?, store_name = ?, template = ?,
          show_price = ?, show_wa_button = ?, music_style = ?,
          brand_color = ?, brand_color_wa = ?,
          logo_path = ?, logo_position = ?, logo_show_text = ?,
          discount_price = ?, rating = ?,
          show_discount = ?, show_rating = ?,
          show_free_shipping = ?, show_flash_sale = ?,
          badge = ?, instagram = ?, tiktok = ?,
          shopee = ?, tokopedia = ?,
          updated_at = NOW()
        WHERE id = ?`,
        [
          product_name || null,
          product_price || null,
          whatsapp_number || null,
          cta_text || "Order Sekarang!",
          store_name || null,
          template || "basic",
          show_price !== false,
          show_wa_button !== false,
          music_style || "energetic",
          brand_color || "#f59e0b",
          brand_color_wa || "#25D366",
          logo_path || null,
          logo_position || "top-left",
          logo_show_text !== false,
          discount_price || null,
          rating || null,
          show_discount === true,
          show_rating === true,
          show_free_shipping === true,
          show_flash_sale === true,
          badge || "none",
          instagram || null,
          tiktok || null,
          shopee || null,
          tokopedia || null,
          existing.id,
        ]
      );
      result = { id: existing.id, updated: true };
    } else {
      // Insert
      const insert = await dbGet(
        `INSERT INTO umkm_configs
          (user_id, project_id, product_name, product_price, whatsapp_number,
           cta_text, store_name, template, show_price, show_wa_button, music_style,
           brand_color, brand_color_wa,
           logo_path, logo_position, logo_show_text,
           discount_price, rating, show_discount, show_rating,
           show_free_shipping, show_flash_sale, badge,
           instagram, tiktok, shopee, tokopedia)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         RETURNING id`,
        [
          req.user.id,
          project_id,
          product_name || null,
          product_price || null,
          whatsapp_number || null,
          cta_text || "Order Sekarang!",
          store_name || null,
          template || "basic",
          show_price !== false,
          show_wa_button !== false,
          music_style || "energetic",
          brand_color || "#f59e0b",
          brand_color_wa || "#25D366",
          logo_path || null,
          logo_position || "top-left",
          logo_show_text !== false,
          // V9.172.1: UMKM_INSERT_PARAMS - konten dinamis
          discount_price || null,
          rating || null,
          show_discount === true,
          show_rating === true,
          show_free_shipping === true,
          show_flash_sale === true,
          badge || "none",
          instagram || null,
          tiktok || null,
          shopee || null,
          tokopedia || null,
        ]
      );
      result = { id: insert.id, created: true };
    }

    console.log(`[UMKM] Config saved: user=${req.user.id} project=${project_id}`);
    res.json({ success: true, config: result });
  } catch (e) {
    console.error("[UMKM] Save error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

/**
 * GET /api/umkm/config/:projectId  Load UMKM config
 */
app.get("/api/umkm/config/:projectId", requireAuth, async (req, res) => {
  try {
    // V9.82.0: UMKM GLOBAL CONFIG  priority: project config > global
    const pid = req.params.projectId;
    
    let config = null;
    if (pid && pid !== "null" && pid !== "global") {
      config = await dbGet(
        "SELECT * FROM umkm_configs WHERE user_id = ? AND project_id = ? ORDER BY updated_at DESC LIMIT 1",
        [req.user.id, pid]
      );
    }
    
    // Fallback ke global
    if (!config) {
      config = await dbGet(
        "SELECT * FROM umkm_configs WHERE user_id = ? AND project_id IS NULL ORDER BY updated_at DESC LIMIT 1",
        [req.user.id]
      );
      if (config) {
        console.log(`[UMKM] Load dari global config (project=${pid || "none"})`);
      }
    }
    
    res.json({ success: true, config: config || null });
  } catch (e) {
    console.error("[UMKM] Load error:", e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post(
  "/api/render-clip/:analysisId/:clipId",
  optionalAuth,
  async (req, res) => {
    try {
      const { analysisId, clipId } = req.params;
      let meta = pendingAnalyses.get(analysisId);
      
      // V9.180.90: DEBUG_TITIK_1
      console.log(`[DEBUG-1] req.body.culture_region: ${req.body.culture_region}`);

      
        // V9.22.1: DB fallback render-clip (load project dari history)
        if (!meta) {
          try {
            const projectRow = await dbGet(
              "SELECT id, user_id, preset, input_video_path, clips_json, analysis_json, total_clips FROM autoclip_projects WHERE id = ?",
              [analysisId]
            );

            if (projectRow) {
              console.log("[RenderClip] DB fallback: project " + analysisId.slice(0, 8));

              const analysisObj = projectRow.analysis_json || {};
              let clipsArr = [];
              if (projectRow.clips_json) {
                clipsArr = Array.isArray(projectRow.clips_json)
                  ? projectRow.clips_json
                  : (typeof projectRow.clips_json === "string"
                      ? JSON.parse(projectRow.clips_json)
                      : []);
              }
              if ((!clipsArr || !clipsArr.length) && analysisObj.clips) {
                clipsArr = analysisObj.clips;
              }

              meta = {
                isAutoClip: true,
                clips: clipsArr,
                preset: projectRow.preset || "1080p",
                addWatermark: true,
                inputPath: projectRow.input_video_path,
                analyzeFile: null,
                originalWords: analysisObj.originalWords || analysisObj.words || [],
                userId: projectRow.user_id,
                loadedFromDb: true,
              };

              pendingAnalyses.set(analysisId, meta);
              console.log("[RenderClip] Cached " + clipsArr.length + " klip dari DB");
            }
          } catch (dbErr) {
            console.warn("[RenderClip] DB fallback error:", dbErr.message);
          }
        }

        if (!meta) {
        return res.status(404).json({
          success: false,
          error: "Analysis tidak ditemukan atau expired",
        });
      }
      if (!meta.isAutoClip || !meta.clips) {
        return res
          .status(400)
          .json({ success: false, error: "Analysis ini bukan auto-clip" });
      }

      const clip = meta.clips.find((c) => String(c.id) === String(clipId));
      if (!clip) {
        return res
          .status(404)
          .json({ success: false, error: "Klip tidak ditemukan" });
      }

// V9.59.3: Render via Queue (async, non-blocking)
      const outputFilename = `Clipora_clip${clipId}_${Date.now()}.mp4`;
      const outputPath = path.join(RESULT_DIR, outputFilename);
      const progressFilename = `progress_clip_${Date.now()}.json`;
      const progressPath = path.join(PROGRESS_DIR, progressFilename);
      const renderJobId = uuidv4().replace(/-/g, "").slice(0, 12);

      // Cek quota preset
      let preset = req.body.preset || meta.preset || "1080p";
      if (req.user) {
        const _pp27 = req.user.plan || "free";
        const _pprem27 = isPremiumPlan(_pp27) || req.user.is_admin === 1;
        if (!_pprem27 && preset !== "480p" && preset !== "720p") {
          console.log("[Quota] Force 720p untuk free user");
          preset = "720p";
        }
      }

      // Hitung watermark
      let _computedWatermark = true;
      try {
        if (req.user) {
          const _wp = String(req.user.plan || "free").toLowerCase();
          const _wa = req.user.is_admin;
          const _wr = String(req.user.role || "").toLowerCase();
          const _isAdminU = (_wa === 1 || _wa === true || _wa === "1" || String(_wa).toLowerCase() === "true" || _wr === "admin" || _wr === "super_admin");
          const _isPaidP = ["pro", "business", "weekly", "monthly", "premium"].indexOf(_wp) !== -1;
          _computedWatermark = !(_isAdminU || _isPaidP);
          console.log("[RenderClip] Watermark - plan: " + _wp + ", watermark: " + _computedWatermark);
        }
      } catch (e) { console.warn("[RenderClip] Watermark calc error:", e.message); }

      // Cek custom watermark
      let customWatermarkPath = null;
      if (req.body.use_custom_watermark === true && req.user) {
        const wmPath = path.join(WATERMARK_DIR, `user_${req.user.id}.png`);
        if (fs.existsSync(wmPath)) {
          customWatermarkPath = wmPath;
          console.log(`[RenderClip] Custom watermark: user_${req.user.id}.png`);
        }
      }

      let musicConfig = null; // V9.137.0: Fix scope
      // V9.137.0: MUSIC FLAG - cek flag Music dari frontend / pendingAnalyses
      const _enableMusic =
        req.body.enable_music === 'true' ||
        (req.body.enable_music === undefined && meta.musicEnabled === true);
      if (!_enableMusic) {
        console.log('[Music] V9.137.0: SKIP MUSIC - toggle OFF');
      }
      if (_enableMusic) {
      try {
        const _musicUserId = req.user ? req.user.id : meta.userId;
        if (_musicUserId) {
          // Priority: project config > global config
          if (analysisId) {
            musicConfig = await dbGet(
              `SELECT mc.*, ml.file_path AS music_file_path, ml.name AS music_name
               FROM music_configs mc
               LEFT JOIN music_library ml ON ml.id = mc.music_id
               WHERE mc.user_id = ? AND mc.project_id = ? AND mc.music_enabled = TRUE
               ORDER BY mc.updated_at DESC LIMIT 1`,
              [_musicUserId, analysisId]
            );
          }
          
          // Fallback ke global
          if (!musicConfig) {
            musicConfig = await dbGet(
              `SELECT mc.*, ml.file_path AS music_file_path, ml.name AS music_name
               FROM music_configs mc
               LEFT JOIN music_library ml ON ml.id = mc.music_id
               WHERE mc.user_id = ? AND mc.project_id IS NULL AND mc.music_enabled = TRUE
               ORDER BY mc.updated_at DESC LIMIT 1`,
              [_musicUserId]
            );
            if (musicConfig) {
              console.log(`[Music] Pakai global config: ${musicConfig.music_name || "unknown"}`);
            }

          } else {
            console.log(`[Music] Pakai project config: ${musicConfig.music_name || "unknown"}`);
          }
        }
      } catch (musicErr) {
        console.warn("[Music] Load error:", musicErr.message);
      }
      } // end if (_enableMusic)


      // V9.82.0: UMKM GLOBAL CONFIG  load dengan priority project > global
let umkmConfig = null; // V9.136.0: Fix scope umkmConfig
          // V9.136.0: Cek flag UMKM dari frontend / pendingAnalyses
    const _enableUmkm =
      req.body.enable_umkm === 'true' ||
      (req.body.enable_umkm === undefined && meta.umkmEnabled === true);
    if (!_enableUmkm) {
      console.log('[UMKM] V9.136.0: SKIP UMKM - toggle OFF');
    }
    if (_enableUmkm) {
      try {
        const _umkmUserId = req.user ? req.user.id : meta.userId;
        if (_umkmUserId) {
          // Priority: project config
          if (analysisId) {
            umkmConfig = await dbGet(
              "SELECT * FROM umkm_configs WHERE project_id = ? AND user_id = ? ORDER BY updated_at DESC LIMIT 1",
              [analysisId, _umkmUserId]
            );
            if (umkmConfig) {
              console.log(`[UMKM] Pakai project config: ${umkmConfig.product_name || "-"}`);
            }
          }
          
          // Fallback ke global
          if (!umkmConfig) {
            umkmConfig = await dbGet(
              "SELECT * FROM umkm_configs WHERE project_id IS NULL AND user_id = ? ORDER BY updated_at DESC LIMIT 1",
              [_umkmUserId]
            );
            if (umkmConfig) {
              console.log(`[UMKM] Pakai global config: ${umkmConfig.product_name || "-"}`);
            }
          }
        }
      } catch (umkmErr) {
        console.warn("[UMKM] Load error:", umkmErr.message);
      }
    } // end if (_enableUmkm)

      // V9.94.0: Masukkan ke CUSTOM QUEUE
// V9.120.3: MUSIC RESOLVE BEFORE QUEUE  resolve music path SEBELUM push ke queue
if (musicConfig && musicConfig.music_file_path) {
  const _mp = musicConfig.music_file_path;
  if (_mp && !path.isAbsolute(_mp)) {
    const _absPath = path.join(__dirname, _mp);
    console.log(`[Music] Resolved (BEFORE queue): ${_mp}  ${_absPath}`);
    musicConfig.music_file_path = _absPath;
  }
} else {
  console.log("[Music] Skip resolve: musicConfig atau music_file_path kosong");
}

// V9.178.95: PRECUT_RENDERCLIP - potong video ke segment ini saja
    // Video full 295 MB terlalu besar  OOM. Pre-cut ke segment 30-60s.
    let _renderInputPath = meta.inputPath;
    try {
      const _fs2 = require("fs");
      const _pathMod2 = require("path");
      const { spawnSync } = require("child_process");

      const _tempDir = _pathMod2.join(__dirname, "temp");
      if (!_fs2.existsSync(_tempDir)) _fs2.mkdirSync(_tempDir, { recursive: true });

      const _precutName = `renderclip_precut_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.mp4`;
      const _precutPath = _pathMod2.join(_tempDir, _precutName);

      const _clipStart = Number(clip.start) || 0;
      const _clipEnd = Number(clip.end) || (_clipStart + 30);
      const _clipDuration = Math.min(_clipEnd - _clipStart, 60); // max 60s

      console.log(`[RenderClip] Pre-cut: ${_clipStart}s-${_clipEnd}s (durasi ${_clipDuration}s) dari ${_pathMod2.basename(meta.inputPath)}`);

      const _ffmpegCmd = process.env.FFMPEG_PATH || "C:\\ffmpeg\\bin\\ffmpeg.exe";
      const _args = [
        "-ss", String(_clipStart),
        "-i", meta.inputPath,
        "-t", String(_clipDuration),
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-crf", "23",
        "-r", "30",
        "-fps_mode", "cfr",
        "-c:a", "aac",
        "-b:a", "128k",
        "-ar", "48000",
        "-ac", "2",
        "-avoid_negative_ts", "make_zero",
        "-y", _precutPath
      ];

      const _result = spawnSync(_ffmpegCmd, _args, { encoding: "utf-8", timeout: 120000 });

      if (_result.status === 0 && _fs2.existsSync(_precutPath)) {
        const _size = Math.round(_fs2.statSync(_precutPath).size / 1024 / 1024);
        console.log(`[RenderClip]  Pre-cut OK: ${_precutName} (${_size} MB, ${_clipDuration}s)`);
        _renderInputPath = _precutPath;
      } else {
        console.warn(`[RenderClip]  Pre-cut gagal (status=${_result.status}), pakai source asli`);
        if (_result.stderr) console.warn(`  stderr: ${String(_result.stderr).substring(0, 300)}`);
      }
    } catch (e) {
      console.warn("[RenderClip] Pre-cut error:", e.message);
    }

    const jobId = queue.add(
    {
        mode: "render-clip",
        analysisId,
        clipId,
        // V9.178.99: FIX_QUEUE_FIELDS - field yang dibutuhkan worker
        outputPath,          //  WAJIB
        outputFilename,      //  WAJIB
        progressPath,        //  WAJIB
        renderJobId,         //  WAJIB
        userId: req.user ? req.user.id : null,  //  WAJIB
        payload: {           //  Worker baca payload.use_karaoke, payload.preset, dll
          // V9.180.90: DEBUG_TITIK_2
          _debug_from_req_body: req.body.culture_region,
          preset: preset,
          addWatermark: _computedWatermark,
          customWatermarkPath: customWatermarkPath,
          enable_burn_subtitle: req.body.enable_burn_subtitle !== false,
          caption_style: req.body.caption_style || null,
          custom_subtitle: req.body.custom_subtitle || null,
          title: req.body.title || "",
          vertical_crop: req.body.vertical_crop === true,
          aspect_ratio: req.body.aspect_ratio || "auto",
          umkmConfig: umkmConfig,
          musicConfig: musicConfig,
          words: req.body.words || null,
          // V9.180.81: QUEUE_CULTURE_V2
          culture_region: req.body.culture_region || null,
          use_karaoke: req.body.use_karaoke === true,
          karaoke_style: req.body.karaoke_style || "tiktok",
        },
        inputPath: _renderInputPath,   // V9.178.95: pakai pre-cut (kecil)
        // Start/end di-reset ke 0 karena video sudah dipotong
        start: 0,
        end: _renderInputPath === meta.inputPath ? clip.end : (clip.end - clip.start),
        duration: clip.duration,
        preset,
        addWatermark: _computedWatermark,
        customWatermarkPath,
        enableBurnSubtitle: req.body.enable_burn_subtitle !== false,
        captionStyle: req.body.caption_style || null,
        customSubtitle: req.body.custom_subtitle || null,  // V9.146.0
        title: req.body.title || "",
        verticalCrop: req.body.vertical_crop === true,
        aspectRatio: req.body.aspect_ratio || "auto",
        umkmConfig,  // V9.60.3: UMKM
        musicConfig,  // V9.78.0: MUSIC GLOBAL CONFIG
        words: req.body.words || null,
        useKaraoke: req.body.use_karaoke === true,
        karaokeStyle: req.body.karaoke_style || "tiktok",
    },
    { userId: req.user ? req.user.id : null, priority: 1 }
);

const stats = queue.getStats();
console.log(`[RenderClip] Klip #${clipId} masuk antrian (jobId=${jobId})`);

res.json({
    success: true,
    jobId,
    status: "queued",
    clipId: clip.id,
    queueStats: stats,
    message: "Klip masuk antrian",
});
    } catch (error) {
      console.error("[RenderClip] Error:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
);


// ============================================================
// V9.94.0: Render status endpoint (custom queue)
// ============================================================
app.get("/api/render-status/:jobId", optionalAuth, async (req, res) => {
  try {
    const { jobId } = req.params;
    if (!jobId) {
      return res.status(400).json({ success: false, error: "jobId wajib diisi" });
    }

    const job = queue.getJob(jobId);
    if (!job) {
      return res.status(404).json({ success: false, status: "not_found", error: "Job tidak ditemukan" });
    }

    // Map status custom queue  status frontend
    let mappedStatus = job.status;
    if (job.status === "queued") mappedStatus = "waiting";
    if (job.status === "processing") mappedStatus = "active";

    res.json({
      success: true,
      jobId: job.id,
      status: mappedStatus,
      rawStatus: job.status,
      progress: job.progress || 0,
      message: job.message || "",
      step: job.step || null,
      result: job.status === "completed" ? job.result : null,
      error: job.status === "failed" ? job.error : null,
    });
  } catch (error) {
    console.error("[RenderStatus] Error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================
// V9.59.4: Queue stats endpoint (untuk admin dashboard)
// ============================================================
app.get("/api/queue-stats", optionalAuth, async (req, res) => {
  try {
    if (!req.user || req.user.is_admin !== 1) {
      return res.status(403).json({ success: false, error: "Akses ditolak" });
    }

    const stats = queue.getStats();  //  pakai custom queue
    res.json({ success: true, stats });
  } catch (error) {
    console.error("[QueueStats] Error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================
// V8.9.0: AI THUMBNAIL GENERATOR (Level 1)
// ============================================================
app.post(
  "/api/thumbnail-ai/:analysisId/:clipId",
  optionalAuth,
  async (req, res) => {
    try {
      const { analysisId, clipId } = req.params;
      const meta = pendingAnalyses.get(analysisId);

      if (!meta) {
        return res.status(404).json({
          success: false,
          error: "Analysis tidak ditemukan atau expired",
        });
      }
      if (!meta.isAutoClip || !meta.clips) {
        return res
          .status(400)
          .json({ success: false, error: "Analysis ini bukan auto-clip" });
      }

      const clip = meta.clips.find((c) => String(c.id) === String(clipId));
      if (!clip) {
        return res
          .status(404)
          .json({ success: false, error: "Klip tidak ditemukan" });
      }

      // Ambil transcript untuk AI hook generation
      let transcriptText = clip.preview_text || "";
      try {
        if (fs.existsSync(meta.analyzeFile)) {
          const analysis = JSON.parse(
            fs.readFileSync(meta.analyzeFile, "utf8"),
          );
          const words = analysis.originalWords || analysis.words || [];
          // Ambil kata-kata dalam range klip
          const clipWords = words
            .filter((w) => w.start >= clip.start && w.start <= clip.end)
            .map((w) => w.word)
            .join(" ");
          if (clipWords) transcriptText = clipWords;
        }
      } catch (e) {
        console.warn(" [ThumbnailAI] Gagal ambil transcript:", e.message);
      }

      const aspect = req.body.aspect || "16:9";
      const count = parseInt(req.body.count) || 3;

      console.log(
        ` [ThumbnailAI] Klip #${clipId}  aspect=${aspect}, count=${count}`,
      );

      const resp = await httpPostJSON(
        `${PYTHON_SERVER_URL}/generate-thumbnail-ai`,
        {
          sourcePath: meta.inputPath,
          outputDir: RESULT_DIR,
          start: clip.start,
          end: clip.end,
          transcriptText: transcriptText,
          count: count,
          aspect: aspect,
        },
        120 * 1000,
      );

      if (resp.status !== 200 || !resp.data.success) {
        throw new Error(resp.data.error || `Python error (${resp.status})`);
      }

      const result = resp.data;
      // Tambahkan URL download
      if (result.options) {
        result.options = result.options.map((o) => ({
          ...o,
          url: `/download/${o.file}`,
        }));
      }

      console.log(
        ` [ThumbnailAI] ${result.options?.length || 0} opsi dihasilkan`,
      );

      res.json({
        success: true,
        options: result.options,
        count: result.count,
      });
    } catch (error) {
      console.error(" [ThumbnailAI] Error:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
);

// ============================================================
// V8.8.3: PREVIEW SUBTITLE  Generate 1 frame dengan subtitle
// ============================================================
app.post(
  "/api/preview-subtitle/:analysisId/:clipId",
  optionalAuth,
  async (req, res) => {
    try {
      const { analysisId, clipId } = req.params;
      const meta = pendingAnalyses.get(analysisId);

      if (!meta) {
        return res.status(404).json({
          success: false,
          error: "Analysis tidak ditemukan atau expired",
        });
      }
      if (!meta.isAutoClip || !meta.clips) {
        return res
          .status(400)
          .json({ success: false, error: "Analysis ini bukan auto-clip" });
      }

      const clip = meta.clips.find((c) => String(c.id) === String(clipId));
      if (!clip) {
        return res
          .status(404)
          .json({ success: false, error: "Klip tidak ditemukan" });
      }

      // Ambil setting dari request body
      const captionStyle = req.body.caption_style || null;
      const title = req.body.title || clip.preview_text || "";
      const verticalCrop = req.body.vertical_crop === true;
      const preset = req.body.preset || "720p";
      const frameOffset = parseFloat(req.body.frame_offset) || 1.5;

      // Words: dari frontend (edited) atau dari analysis file
      let words = null;
      if (
        req.body.words &&
        Array.isArray(req.body.words) &&
        req.body.words.length > 0
      ) {
        words = req.body.words;
      } else {
        try {
          if (fs.existsSync(meta.analyzeFile)) {
            const analysis = JSON.parse(
              fs.readFileSync(meta.analyzeFile, "utf8"),
            );
            words = analysis.originalWords || analysis.words || null;
          }
        } catch (e) {
          console.warn(" [Preview] Gagal baca words:", e.message);
        }
      }

      const previewFilename = `preview_${analysisId.slice(0, 8)}_${clipId}_${Date.now()}.jpg`;
      const previewPath = path.join(RESULT_DIR, previewFilename);

      console.log(
        ` [Preview] Klip #${clipId}  style=${captionStyle || "none"}, vertical=${verticalCrop}, preset=${preset}`,
      );

      const resp = await httpPostJSON(
        `${PYTHON_SERVER_URL}/preview-subtitle`,
        {
          sourcePath: meta.inputPath,
          outputPath: previewPath,
          start: clip.start,
          end: clip.end,
          captionStyle: captionStyle,
          customSubtitle: req.body.custom_subtitle || null,  // V9.146.0
          title: title,
          words: words,
          verticalCrop: verticalCrop,
          frameOffset: frameOffset,
          preset: preset,
        },
        60 * 1000,
      );

      if (resp.status !== 200 || !resp.data.success) {
        throw new Error(resp.data.error || `Python error (${resp.status})`);
      }

      const result = resp.data;
      console.log(` [Preview] Generated  ${result.size_kb} KB`);

      res.json({
        success: true,
        previewUrl: `/preview/${previewFilename}`,
        previewFile: previewFilename,
        size_kb: result.size_kb,
        timestamp: result.timestamp,
      });
    } catch (error) {
      console.error(" [Preview] Error:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
);



// ============================================================
// V8.9.0: CANCEL RENDER  kill FFmpeg di Python
// ============================================================
app.post("/api/render-cancel", optionalAuth, async (req, res) => {
  try {
    const jobId = (req.body && req.body.jobId) || null;
    console.log(
      ` [RenderCancel] User ${req.user ? req.user.id : "guest"}  jobId=${jobId || "ALL"}`,
    );

    // V9.94.0: Cancel job di custom queue
    if (jobId) {
      const job = queue.getJob(jobId);
      if (job && (job.status === "queued" || job.status === "processing")) {
        queue.forceCancel(jobId);
        console.log(` [RenderCancel] Job ${jobId} cancelled di queue`);
      }
    }

    // Forward ke Python (V8.9.20: sertakan jobId)
    const resp = await httpPostJSON(
      `${PYTHON_SERVER_URL}/cancel-render`,
      {
        jobId: jobId,
      },
      10000,
    );

    if (resp.status === 200 && resp.data.success) {
      console.log(` [RenderCancel] FFmpeg dibatalkan`);
      return res.json({ success: true, message: "FFmpeg dibatalkan" });
    }

    console.log(` [RenderCancel] Tidak ada FFmpeg aktif`);
    return res.json({ success: false, message: "Tidak ada FFmpeg aktif" });
  } catch (e) {
    console.error(` [RenderCancel] Error:`, e.message);
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================
// V8.7.0: AI VOICE OVER (edge-tts via Python)
// ============================================================
app.post(
  "/api/voiceover/generate",
  // V9.0.2: TEMP  bypass auth untuk testing (UI pakai PHP session)
  async (req, res) => {
    try {
            const { text, voice, rate, pitch, volume, emotion } = req.body || {};

      if (!text || typeof text !== "string" || text.trim().length === 0) {
        return res
          .status(400)
          .json({ success: false, error: "Teks wajib diisi" });
      }
      if (text.length > 5000) {
        return res
          .status(400)
          .json({ success: false, error: "Teks maksimal 5000 karakter" });
      }

      const filename = `voiceover_${Date.now()}_${uuidv4().slice(0, 4)}.mp3`;
      const outputPath = path.join(RESULT_DIR, filename);

      const userId = req.user ? req.user.id : 'guest';
      console.log(
        ` [VoiceOver] User ${userId}  ${text.length} chars, voice=${voice || "default"}`,
      );

      const resp = await httpPostJSON(
        `${PYTHON_SERVER_URL}/generate-voiceover`,
        {
          text: text.trim(),
          voice: voice || "id-ID-ArdiNeural",
          rate: rate || "+0%",
          pitch: pitch || "+0Hz",
          volume: volume || "+0%",
          emotion: emotion || "netral",   // LEVEL 3 PHASE 2
          outputPath,
        },
        60000,
      );

      if (resp.status !== 200 || !resp.data.success) {
        throw new Error(resp.data.error || "Voice generation gagal");
      }

      try {
        await dbRun(
          `
                INSERT INTO activity_log (user_id, action, details)
                VALUES (?, 'voiceover_generate', ?)
            `,
          [userId, `VoiceOver ${text.length} chars  ${filename}`],
        );
      } catch (e) {}

      res.json({
        success: true,
        url: `/download/${filename}`,
        filename,
        size_kb: resp.data.size_kb,
      });
    } catch (e) {
      console.error(" [VoiceOver] Error:", e);
      res.status(500).json({ success: false, error: e.message });
    }
  },
);

app.get("/api/voiceover/voices", optionalAuth, async (req, res) => {
  try {
    const r = await httpGetJSON(`${PYTHON_SERVER_URL}/voices`, 5000);
    res.json(r.data);
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================
// V9.131.0 LEVEL 4B: BULK VOICE OVER MULTI-BAHASA
// 1 script -> N bahasa sekaligus
// ============================================================
app.post(
  "/api/voiceover/bulk",
  requireAuth,
  requirePremium,
  async (req, res) => {
    try {
      const { text, emotion, languages } = req.body || {};

      // Validasi
      if (!text || typeof text !== "string" || text.trim().length === 0) {
        return res.status(400).json({ success: false, error: "Teks wajib diisi" });
      }
      if (text.length > 3000) {
        return res.status(400).json({
          success: false,
          error: "Teks maksimal 3000 karakter untuk bulk",
        });
      }
      if (!Array.isArray(languages) || languages.length === 0) {
        return res.status(400).json({
          success: false,
          error: "Pilih minimal 1 bahasa",
        });
      }
      if (languages.length > 5) {
        return res.status(400).json({
          success: false,
          error: "Maksimal 5 bahasa sekaligus",
        });
      }

      console.log(
        ` [BulkVO] User ${req.user.id}  ${languages.length} bahasa: ${languages.join(", ")}`
      );

      // Teruskan ke Python
      const resp = await httpPostJSON(
        `${PYTHON_SERVER_URL}/generate-voiceover-bulk`,
        {
          text: text.trim(),
          emotion: emotion || "netral",
          languages: languages,
          outputDir: RESULT_DIR,
        },
        180000
      );

      if (resp.status !== 200 || !resp.data.success) {
        throw new Error(resp.data.error || "Bulk generate gagal");
      }

      // Log activity
      try {
        await dbRun(
          `INSERT INTO activity_log (user_id, action, details) VALUES (?, 'bulk_voiceover', ?)`,
          [req.user.id, `Bulk VO ${languages.length} bahasa: ${languages.join(",")}`]
        );
      } catch (e) {}

      res.json({
        success: true,
        total: resp.data.total,
        success_count: resp.data.success_count,
        error_count: resp.data.error_count,
        results: resp.data.results,
        errors: resp.data.errors,
        emotion: resp.data.emotion,
        rate: resp.data.rate,
        pitch: resp.data.pitch,
      });
    } catch (e) {
      console.error(" [BulkVO] Error:", e);
      res.status(500).json({ success: false, error: e.message });
    }
  }
);


// ============================================================
// V9.132.0 LEVEL 4C: MULTI-VOICE DIALOG
// Generate dialog multi-karakter dalam 1 file MP3
// ============================================================
app.post(
  "/api/voiceover/dialog",
  requireAuth,
  requirePremium,
  async (req, res) => {
    try {
      const { dialog, emotion, pauseMs } = req.body || {};

      // Validasi
      if (!Array.isArray(dialog) || dialog.length === 0) {
        return res.status(400).json({ success: false, error: "Dialog kosong" });
      }
      if (dialog.length > 30) {
        return res.status(400).json({
          success: false,
          error: "Maksimal 30 baris dialog",
        });
      }

      const totalChars = dialog.reduce((sum, d) => sum + ((d.text || "").length), 0);
      if (totalChars > 5000) {
        return res.status(400).json({
          success: false,
          error: "Total teks maksimal 5000 karakter",
        });
      }

      console.log(
        ` [DialogVO] User ${req.user.id}  ${dialog.length} baris dialog`
      );

      // Generate filename
      const filename = `dialog_${Date.now()}_${uuidv4().slice(0, 6)}.mp3`;
      const outputPath = path.join(RESULT_DIR, filename);

      // Teruskan ke Python
      const resp = await httpPostJSON(
        `${PYTHON_SERVER_URL}/generate-voiceover-dialog`,
        {
          dialog: dialog,
          emotion: emotion || "netral",
          outputPath: outputPath,
          pauseMs: pauseMs || 300,
        },
        180000
      );

      if (resp.status !== 200 || !resp.data.success) {
        throw new Error(resp.data.error || "Dialog generate gagal");
      }

      // Log activity
      try {
        await dbRun(
          `INSERT INTO activity_log (user_id, action, details) VALUES (?, 'dialog_voiceover', ?)`,
          [req.user.id, `Dialog ${dialog.length} baris, ${totalChars} chars`]
        );
      } catch (e) {}

      res.json({
        success: true,
        url: `/download/${filename}`,
        filename: filename,
        size_kb: resp.data.size_kb,
        dialog_count: resp.data.dialog_count,
        characters: resp.data.characters,
        emotion: resp.data.emotion,
      });
    } catch (e) {
      console.error(" [DialogVO] Error:", e);
      res.status(500).json({ success: false, error: e.message });
    }
  }
);


// ============================================================
// V8.7.0: MULTI-BAHASA TRANSLATE
// ============================================================
app.post("/api/translate", requireAuth, requirePremium, async (req, res) => {
  try {
    const { text, from, to } = req.body || {};

    if (!text || typeof text !== "string" || text.trim().length === 0) {
      return res
        .status(400)
        .json({ success: false, error: "Teks wajib diisi" });
    }
    if (text.length > 5000) {
      return res
        .status(400)
        .json({ success: false, error: "Teks maksimal 5000 karakter" });
    }

    const fromCode = (from || "id").toLowerCase();
    const toCode = (to || "en").toLowerCase();

    if (fromCode === toCode) {
      return res.json({ success: true, translated: text, provider: "same" });
    }

    console.log(
      ` [Translate] User ${req.user.id}  ${fromCode}  ${toCode} (${text.length} chars)`,
    );

    const resp = await httpPostJSON(
      `${PYTHON_SERVER_URL}/translate`,
      {
        text: text.trim(),
        from: fromCode,
        to: toCode,
      },
      30000,
    );

    if (resp.status !== 200 || !resp.data.success) {
      throw new Error(resp.data.error || "Translate gagal");
    }

    try {
      await dbRun(
        `
                INSERT INTO activity_log (user_id, action, details)
                VALUES (?, 'translate', ?)
            `,
        [req.user.id, `${fromCode}${toCode}: ${text.length} chars`],
      );
    } catch (e) {}

    res.json({
      success: true,
      translated: resp.data.translated,
      from: fromCode,
      to: toCode,
      provider: resp.data.provider,
    });
  } catch (e) {
    console.error(" [Translate] Error:", e);
    res.status(500).json({ success: false, error: e.message });
  }
});

app.get("/api/translate/languages", optionalAuth, async (req, res) => {
  try {
    const r = await httpGetJSON(
      `${PYTHON_SERVER_URL}/translate-languages`,
      5000,
    );
    res.json(r.data);
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================
// V8.7.0: REFERENCE STYLE LEARNING
// ============================================================
const REF_PROFILE_DIR = path.join(UPLOAD_DIR, "reference");

if (!fs.existsSync(REF_PROFILE_DIR)) {
  fs.mkdirSync(REF_PROFILE_DIR, { recursive: true });
}

// Upload & analyze video referensi
app.post(
  "/api/reference/upload",
  requireAuth,
  upload.single("video"),
  async (req, res) => {
    try {
      if (!req.file) {
        return res
          .status(400)
          .json({ success: false, error: "Tidak ada file" });
      }

      const name = (req.body.name || "Style Saya").slice(0, 100);

      console.log(
        ` [RefStyle] User ${req.user.id}  upload: ${req.file.filename}`,
      );

      // Analyze via Python
      const resp = await httpPostJSON(
        `${PYTHON_SERVER_URL}/analyze-reference`,
        {
          videoPath: req.file.path,
          threshold: 0.3,
        },
        120000,
      );

      if (resp.status !== 200 || !resp.data.success) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (e) {}
        throw new Error(resp.data.error || "Analyze gagal");
      }

      const profile = resp.data;

      // Simpan ke DB
      const insertResult = await dbRun(
        `
            INSERT INTO user_reference_profiles 
                (user_id, name, profile_json, source_filename)
            VALUES (?, ?, ?, ?)
        `,
        [req.user.id, name, JSON.stringify(profile), req.file.originalname],
      );

      // Cleanup file (tidak perlu disimpan)
      try {
        fs.unlinkSync(req.file.path);
      } catch (e) {}

      console.log(
        ` [RefStyle] Saved  ${profile.cut_count} cuts, style: ${profile.style_label}`,
      );

      res.json({
        success: true,
        profile,
        name,
      });
    } catch (e) {
      console.error(" [RefStyle] Error:", e);
      if (req.file && fs.existsSync(req.file.path)) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (e2) {}
      }
      res.status(500).json({ success: false, error: e.message });
    }
  },
);

// List profiles user
app.get("/api/reference/list", requireAuth, async (req, res) => {
  try {
    const rows = await dbAll(
      `
            SELECT id, name, profile_json, source_filename, created_at, is_active
            FROM user_reference_profiles
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT 20
        `,
      [req.user.id],
    );

    const profiles = rows.map((r) => {
      let pj = r.profile_json;
      if (typeof pj === "string") {
        try {
          pj = JSON.parse(pj);
        } catch (e) {
          pj = {};
        }
      }
      return {
        id: r.id,
        name: r.name,
        style_label: pj.style_label || "unknown",
        cut_count: pj.cut_count || 0,
        cuts_per_minute: pj.cuts_per_minute || 0,
        avg_cut_interval: pj.avg_cut_interval || 0,
        source_filename: r.source_filename,
        created_at: r.created_at,
        is_active: r.is_active,
      };
    });

    res.json({ success: true, profiles });
  } catch (e) {
    console.error("List profiles error:", e);
    res.status(500).json({ success: false, error: e.message });
  }
});

// Delete profile
app.delete("/api/reference/:id", requireAuth, async (req, res) => {
  try {
    const result = await dbRun(
      `
            DELETE FROM user_reference_profiles
            WHERE id = ? AND user_id = ?
        `,
      [req.params.id, req.user.id],
    );

    res.json({ success: true, message: "Profile dihapus" });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================
// JOB STATUS
// ============================================================
app.get("/api/job/:jobId", jobPollingLimiter, optionalAuth, (req, res) => {
  const job = queue.getJob(req.params.jobId);
  if (!job)
    return res
      .status(404)
      .json({ success: false, error: "Job tidak ditemukan" });
  if (
    req.user &&
    job.userId &&
    job.userId !== req.user.id &&
    !req.user.is_admin
  ) {
    return res.status(403).json({ success: false, error: "Akses ditolak" });
  }
  res.json({ success: true, job });
});

app.get("/api/jobs", requireAuth, (req, res) => {
  const jobs = queue.getJobs({ userId: req.user.id });
  res.json({ success: true, jobs, stats: queue.getStats() });
});

app.delete("/api/job/:jobId", requireAuth, (req, res) => {
  const job = queue.getJob(req.params.jobId);
  if (!job)
    return res
      .status(404)
      .json({ success: false, error: "Job tidak ditemukan" });
  if (job.userId !== req.user.id && !req.user.is_admin) {
    return res.status(403).json({ success: false, error: "Akses ditolak" });
  }
  const cancelled = queue.cancel(req.params.jobId);
  if (!cancelled)
    return res
      .status(400)
      .json({ success: false, error: "Job tidak bisa dibatalkan" });
  res.json({ success: true, message: "Job dibatalkan" });
});

// ============================================================
// V8.7.0 SECURITY: Safe file path resolver (defense in depth)
// ============================================================
function safeResolveFile(baseDir, filename, allowedExts = null) {
  // 1. Tolak kalau ada karakter mencurigakan
  if (
    !filename ||
    filename.includes("..") ||
    filename.includes("/") ||
    filename.includes("\\")
  ) {
    return null;
  }
  // 2. Tolak kalau ada null byte
  if (filename.includes("\0")) {
    return null;
  }
  // 3. Whitelist extension
  if (allowedExts) {
    const ext = path.extname(filename).toLowerCase();
    if (!allowedExts.includes(ext)) return null;
  }
  // 4. Resolve + verifikasi masih di dalam baseDir
  const resolved = path.resolve(baseDir, filename);
  if (!resolved.startsWith(path.resolve(baseDir) + path.sep)) {
    return null;
  }
  return resolved;
}

app.get("/download/:filename", (req, res) => {
  const safePath = safeResolveFile(RESULT_DIR, req.params.filename, [
    ".mp4",
    ".mov",
    ".srt",
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".mp3",
    ".m4a",
    ".json",
  ]);
  if (!safePath) return res.status(400).send("Nama file tidak valid");
  if (fs.existsSync(safePath)) res.download(safePath);
  else res.status(404).send("File tidak ditemukan");
});

app.get("/preview/:filename", (req, res) => {
  const safePath = safeResolveFile(RESULT_DIR, req.params.filename, [
    ".mp4",
    ".mov",
    ".webm",
    ".jpg",
    ".jpeg",
    ".png",
  ]);
  if (!safePath) return res.status(400).send("Nama file tidak valid");
  if (fs.existsSync(safePath)) res.sendFile(safePath);
  else res.status(404).send("File tidak ditemukan");
});

app.get("/api/progress/:filename", (req, res) => {
  const safePath = safeResolveFile(PROGRESS_DIR, req.params.filename, [
    ".json",
  ]);
  if (!safePath)
    return res.status(400).json({ error: "Nama file tidak valid" });
  if (fs.existsSync(safePath)) {
    try {
      res.json(JSON.parse(fs.readFileSync(safePath, "utf8")));
    } catch (e) {
      res.status(500).json({ error: "Gagal membaca progress" });
    }
  } else {
    res.status(404).json({ error: "Progress tidak ditemukan" });
  }
});

// ============================================================
// V8.9.23: SHALLOW HEALTH (untuk uptime robot / load balancer)
// ============================================================
app.get("/api/health", (req, res) => {
  res.setHeader(
    "Cache-Control",
    "no-store, no-cache, must-revalidate, max-age=0",
  );
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  res.json({ status: "OK", timestamp: new Date().toISOString() });
});

// ============================================================
// V8.9.23: DEEP HEALTH  cek Node + DB + Python (untuk monitor)
// Return 200 kalau semua OK, 503 kalau ada yang rusak
// ============================================================
app.get("/api/health/full", async (req, res) => {
  res.setHeader("Cache-Control", "no-store");

  const checks = {
    node: {
      status: "ok",
      uptime_sec: Math.round(process.uptime()),
      memory_mb: Math.round(process.memoryUsage().rss / 1024 / 1024),
    },
    database: { status: "unknown" },
    python: { status: "unknown" },
  };

  // Check DB
  try {
    const t0 = Date.now();
    await dbAll("SELECT 1 AS ping");
    checks.database = { status: "ok", latency_ms: Date.now() - t0 };
  } catch (e) {
    checks.database = { status: "error", error: e.message.slice(0, 200) };
  }

  // Check Python
  try {
    const t0 = Date.now();
    const r = await httpGetJSON(`${PYTHON_SERVER_URL}/health`, 3000);
    checks.python = {
      status: r.status === 200 ? "ok" : "error",
      latency_ms: Date.now() - t0,
    };
  } catch (e) {
    checks.python = { status: "error", error: e.message.slice(0, 200) };
  }

  const allOk = Object.values(checks).every((c) => c.status === "ok");

  if (!allOk) {
    logger.warn("Health check degraded", { checks });
  }

  res.status(allOk ? 200 : 503).json({
    status: allOk ? "healthy" : "degraded",
    timestamp: new Date().toISOString(),
    checks,
  });
});

// ============================================================
// ADMIN - DB STATS
// ============================================================
app.get("/api/admin/db-stats", requireAuth, requireAdmin, async (req, res) => {
  try {
    const stats = await getStats();
    res.json({ success: true, stats });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ============================================================
// WEBSOCKET
// ============================================================
io.on("connection", (socket) => {
  console.log(` Socket connected: ${socket.id}`);
  // V9.3.0 FIX: verify JWT sebelum join room  cegah user menyamar
  socket.on("auth", (token) => {
    if (!token || typeof token !== "string") {
      console.warn(` Socket ${socket.id}: auth tanpa token`);
      return;
    }
    const JWT_SECRET_WS = process.env.JWT_SECRET;
    if (!JWT_SECRET_WS) {
      console.error(" JWT_SECRET tidak diset  WebSocket auth OFF");
      return;
    }
    try {
      const payload = jwt.verify(token, JWT_SECRET_WS);
      const userId = payload.userId || payload.id || payload.sub;
      if (!userId) {
        console.warn(` Socket ${socket.id}: token valid tanpa userId`);
        return;
      }
      socket.join(`user_${userId}`);
      socket.userId = userId;
      console.log(` Socket ${socket.id} joined user_${userId}`);
    } catch (e) {
      console.warn(` Socket ${socket.id}: token invalid  ${e.message}`);
      socket.emit("auth:failed", { error: "TOKEN_INVALID" });
    }
  });
});

// ============================================================
// GRACEFUL SHUTDOWN
// ============================================================
process.on("SIGINT", async () => {
  global.__SHUTTING_DOWN__ = true;
  console.log("\n  Menerima SIGINT, menutup server...");
  logger.info("Server shutdown (SIGINT)");

  if (pythonServer) {
    console.log(" Stopping Python AI server...");
    try {
      pythonServer.kill("SIGTERM");
      await new Promise((r) => setTimeout(r, 1000));
      if (!pythonServer.killed) pythonServer.kill("SIGKILL");
    } catch (e) {
      console.warn(" Failed to kill Python cleanly:", e.message);
    }
  }

  try {
    const guestObj = {};
    guestTrial.forEach((count, ip) => {
      guestObj[ip] = count;
    });
    fs.writeFileSync(GUEST_TRIAL_FILE, JSON.stringify(guestObj, null, 2));
    console.log(` Guest trial saved: ${guestTrial.size} IP`);
  } catch (e) {
    console.error(" Gagal save guest trial:", e.message);
  }
  try {
    await backupDatabase();
  } catch (e) {
    console.error("Backup error:", e.message);
  }
  process.exit(0);
});

process.on("SIGTERM", async () => {
  global.__SHUTTING_DOWN__ = true;
  console.log("\n  Menerima SIGTERM, menutup server...");
  logger.info("Server shutdown (SIGTERM)");

  if (pythonServer) {
    try {
      pythonServer.kill("SIGTERM");
      await new Promise((r) => setTimeout(r, 1000));
      if (!pythonServer.killed) pythonServer.kill("SIGKILL");
    } catch (e) {}
  }

  try {
    const _guestObj = {};
    guestTrial.forEach((count, ip) => {
      _guestObj[ip] = count;
    });
    fs.writeFileSync(GUEST_TRIAL_FILE, JSON.stringify(_guestObj, null, 2));
    console.log(` Guest trial saved: ${guestTrial.size} IP`);
  } catch (e) {}
  try {
    await backupDatabase();
  } catch (e) {}
  process.exit(0);
});

// ============================================================
// ERROR HANDLERS
// ============================================================
process.on("uncaughtException", (err) => {
  console.error(" Uncaught Exception:", err.message);
  logger.error("Uncaught Exception: " + err.message, {
    stack: err.stack,
    name: err.name,
  });
});

process.on("unhandledRejection", (reason, promise) => {
  console.error(" Unhandled Rejection:", reason);
  logger.error("Unhandled Rejection", {
    reason: reason instanceof Error ? reason.message : String(reason),
    stack: reason instanceof Error ? reason.stack : null,
  });
});

// V9.2.0: Sentry error handler (harus sebelum error middleware custom)
Sentry.setupExpressErrorHandler(app);

app.use((err, req, res, next) => {
  const userId = req.user ? req.user.id : null;
  logger.error("HTTP Error: " + err.message, {
    method: req.method,
    url: req.originalUrl,
    user_id: userId,
    stack: err.stack ? err.stack.split("\n").slice(0, 3).join(" | ") : null,
  });
  if (err.message && err.message.includes("CORS")) {
    return res
      .status(403)
      .json({ success: false, error: "Origin tidak diizinkan" });
  }
  if (err.code === "LIMIT_FILE_SIZE") {
    return res
      .status(400)
      .json({ success: false, error: "File terlalu besar (maks 500MB)" });
  }
  if (err.message && err.message.includes("tidak didukung")) {
    return res.status(400).json({ success: false, error: err.message });
  }
  console.error("Unhandled error:", err);
  res.status(500).json({ success: false, error: "Internal server error" });
});

// ============================================================
// AUTO-BACKUP, AUTO-EXPIRE, CLEANUP
// ============================================================
setInterval(
  async () => {
    try {
      console.log(" Auto-backup database...");
      await backupDatabase();
    } catch (e) {
      console.error("Auto-backup error:", e.message);
      logger.error("Auto-backup error", { error: e.message });
    }
  },
  24 * 60 * 60 * 1000,
);

setInterval(
  async () => {
    try {
      const expired = await dbAll(`
            SELECT id, user_id, plan FROM subscriptions
            WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at < NOW()
        `);
      if (expired.length === 0) return;
      console.log(` Menemukan ${expired.length} subscription expired`);
      logger.info(`Auto-expire: ${expired.length} subscription kadaluarsa`);
      for (const sub of expired) {
        await dbRun(
          `UPDATE subscriptions SET status = 'expired' WHERE id = ?`,
          [sub.id],
        );
        await dbRun(
          `UPDATE users SET plan = 'free', daily_quota = 3 WHERE id = ?`,
          [sub.user_id],
        );
        await dbRun(
          `INSERT INTO notifications (user_id, type, title, message) VALUES (?, 'subscription', 'Langganan Berakhir', ?)`,
          [
            sub.user_id,
            `Paket ${sub.plan} Anda sudah berakhir. Silakan perpanjang untuk melanjutkan.`,
          ],
        );
        console.log(`    User #${sub.user_id}  free`);
      }
    } catch (e) {
      console.error("Auto-expire error:", e.message);
      logger.error("Auto-expire error", { error: e.message });
    }
  },
  60 * 60 * 1000,
);

setInterval(
  () => {
    try {
      const deleted = logger.cleanupOldLogs(30);
      if (deleted > 0) {
        logger.info(`Cleanup log lama: ${deleted} file dihapus`);
        console.log(`  Cleanup: ${deleted} file log lama dihapus`);
      }
    } catch (e) {
      console.error("Cleanup log error:", e.message);
    }
  },
  24 * 60 * 60 * 1000,
);

// ============================================================
// V8.7.0: CLEANUP ORPHANED FILES (SRT, progress, pending, dummy)
// ============================================================
setInterval(
  () => {
    try {
      const now = Date.now();
      const MAX_AGE_MS = 24 * 60 * 60 * 1000; // 24 jam
      let cleaned = 0;

      // Cleanup .srt di results/ yang lebih tua dari 24 jam
      if (fs.existsSync(RESULT_DIR)) {
        fs.readdirSync(RESULT_DIR).forEach((f) => {
          if (f.endsWith(".srt")) {
            const fp = path.join(RESULT_DIR, f);
            try {
              const stat = fs.statSync(fp);
              if (now - stat.mtimeMs > MAX_AGE_MS) {
                fs.unlinkSync(fp);
                cleaned++;
              }
            } catch (e) {}
          }
        });
      }

      // Cleanup progress/*.json > 24 jam
      if (fs.existsSync(PROGRESS_DIR)) {
        fs.readdirSync(PROGRESS_DIR).forEach((f) => {
          if (f.endsWith(".json")) {
            const fp = path.join(PROGRESS_DIR, f);
            try {
              const stat = fs.statSync(fp);
              if (now - stat.mtimeMs > MAX_AGE_MS) {
                fs.unlinkSync(fp);
                cleaned++;
              }
            } catch (e) {}
          }
        });
      }

      // Cleanup temp/analysis_*.json & dummy_*.mp4 > 24 jam
      if (fs.existsSync(TEMP_DIR)) {
        fs.readdirSync(TEMP_DIR).forEach((f) => {
          if (f.startsWith("analysis_") || f.startsWith("dummy_")) {
            const fp = path.join(TEMP_DIR, f);
            try {
              const stat = fs.statSync(fp);
              if (now - stat.mtimeMs > MAX_AGE_MS) {
                fs.unlinkSync(fp);
                cleaned++;
              }
            } catch (e) {}
          }
        });
      }

      if (cleaned > 0) {
        console.log(`  [Cleanup V8.7.0] ${cleaned} file orphan dihapus`);
      }
    } catch (e) {
      console.error("Cleanup V8.7.0 error:", e.message);
    }
  },
  60 * 60 * 1000,
);

// ============================================================
// START SERVER
// ============================================================
async function start() {
  try {
    await initSchema();

    // V8.9.22: Pre-warm DB connection
    try {
      const warmupStart = Date.now();
      await dbAll("SELECT 1 AS warmup");
      console.log(` [DB] Warmup selesai dalam ${Date.now() - warmupStart}ms`);
    } catch (e) {
      console.warn(" [DB] Warmup gagal:", e.message);
    }

    // V8.9.21: Load pending analyses yang tersimpan di disk
    const restored = pendingAnalyses.loadAll();
    if (restored > 0) {
      console.log(
        `  [Startup] Restored ${restored} pending analysis dari disk`,
      );
    }

    await // V9.120.4: DISABLED  startPythonServer();


    server.listen(PORT, () => {
    console.log(`\n Server V9.94.0 berjalan di http://localhost:${PORT}`);
    console.log(` Queue: ${JSON.stringify(queue.getStats())}`);
      console.log(` Python AI Server: ${PYTHON_SERVER_URL}`);
      console.log(` Environment: ${process.env.NODE_ENV || "development"}`);
      console.log(` Logger aktif  log tersimpan di ./logs/`);
      console.log(` Queue: ${JSON.stringify(queue.getStats())}`);
      console.log(` WebSocket: ws://localhost:${PORT}`);
      console.log(`\n Siap!`);

      //  V9.6.0: Start backup scheduler
      if (backupScheduler) {
        backupScheduler.start();
      }

      console.log(`\n Konfigurasi Plan:`);
      console.log(
        `   Guest:    ${GUEST_QUOTA} video (lifetime), maks ${Math.floor((parseInt(process.env.GUEST_MAX_DURATION) || 60) / 60)} menit`,
      );
      console.log(
        `   Free:     ${process.env.FREE_DAILY_QUOTA || 3} video/hari, maks ${Math.floor((parseInt(process.env.FREE_MAX_DURATION) || 120) / 60)} menit`,
      );
      console.log(
        `   Pro:      ${process.env.PRO_DAILY_QUOTA || 50} video/hari, maks ${Math.floor((parseInt(process.env.PRO_MAX_DURATION) || 900) / 60)} menit`,
      );
      console.log(
        `   Business: ${process.env.BUSINESS_DAILY_QUOTA || 200} video/hari, maks ${Math.floor((parseInt(process.env.BUSINESS_MAX_DURATION) || 3600) / 60)} menit`,
      );

      console.log(`\n ADMIN MODE:`);
      console.log(`    Skip quota limit`);
      console.log(`    Skip duration limit`);
      console.log(`    Semua preset tersedia (480p - 4K)`);

      console.log(`\n FITUR V8.7.0:`);
      console.log(
        `     PERSISTENT PYTHON  model cached (analyze ~10x lebih cepat)`,
      );
      console.log(
        `     STYLE MEMORY  AI belajar dari edit manual user (PROTECT + PRIORITIZE)`,
      );
      console.log(`     MANUAL EDIT MODE  user bisa toggle/edit segmen`);
      console.log(`    Content Creator Mode (DEFAULT)  jump-cut ketat`);
      console.log(`    Burn Subtitle ke Video (hardcoded)`);
      console.log(`    CFR normalize (fix -fps_mode)`);
      console.log(`     Whisper auto-detect language + fallback retry`);
      console.log(
        `      Audio noise reduction (highpass + afftdn + loudnorm)`,
      );
      console.log(`     Retry otomatis ke model 'small' untuk audio sulit`);

      console.log(`\n FIX V8.7.0:`);
      console.log(`    Guest quota tidak hangus saat video ditolak`);
      console.log(`    FFmpeg path dari env (portability)`);
      console.log(`    Auto-cleanup SRT/progress/analysis orphan (24 jam)`);
      console.log(`    Python warmup status: GET /api/python-health`);
      console.log(`    Watchdog auto-restart Python kalau crash`);
      console.log(`    SIGTERM handler untuk production deployment`);
      console.log(
        `    Honor features per plan (Pro dapat semantic/keyword/emotion)`,
      );

      logger.info("Server started", {
        port: PORT,
        env: process.env.NODE_ENV || "development",
        version: "V8.7.0",
      });
    });
  } catch (error) {
    console.error(" Gagal start server:", error.message);
    logger.error("Gagal start server: " + error.message);
    process.exit(1);
  }
}

start();
