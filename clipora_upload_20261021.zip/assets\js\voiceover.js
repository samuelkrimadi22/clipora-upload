// ============================================================
// AI VOICE OVER — LEVEL 3
// Fitur: Preset Gaya + Riwayat + Auth + Preview
// ============================================================

(function() {
  'use strict';

  // ============================================
  // KONFIGURASI PRESET GAYA SUARA
  // ============================================
  const PRESETS = {
    berita: {
      rate: 5,
      pitch: -10,
      voice: 'id-ID-ArdiNeural',
      label: '📰 Berita',
      desc: 'Formal & berat',
    },
    storytelling: {
      rate: -5,
      pitch: -5,
      voice: 'id-ID-ArdiNeural',
      label: '📖 Storytelling',
      desc: 'Kalem & berwibawa',
    },
    iklan: {
      rate: 15,
      pitch: 10,
      voice: 'id-ID-GadisNeural',
      label: '📢 Iklan',
      desc: 'Ceria & energetik',
    },
    lucu: {
      rate: 25,
      pitch: 20,
      voice: 'id-ID-GadisNeural',
      label: '😄 Lucu',
      desc: 'Cepat & tinggi',
    },
  };

  const HISTORY_KEY = 'clipora_vo_history_v1';
  const MAX_HISTORY = 5;

  // ============================================
  // AUTH HELPER
  // ============================================
  function getAuthToken() {
    const keys = ['clipora_token', 'token', 'auth_token', 'jwt', 'access_token'];
    for (const key of keys) {
      const val = localStorage.getItem(key) || sessionStorage.getItem(key);
      if (val && val.length > 20) return val;
    }
    return null;
  }

  async function authFetch(url, options = {}) {
    const token = getAuthToken();
    const headers = Object.assign({}, options.headers || {});
    if (token) headers['Authorization'] = 'Bearer ' + token;
    return fetch(url, { ...options, headers, credentials: 'include' });
  }

  // ============================================
  // HISTORY MANAGEMENT (localStorage)
  // ============================================
  function getHistory() {
    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function saveHistory(history) {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, MAX_HISTORY)));
    } catch (e) {
      console.warn('[VoiceOver] Failed save history:', e.message);
    }
  }

  function addToHistory(item) {
    const history = getHistory();
    // Remove duplikat kalau ada (by filename)
    const filtered = history.filter(h => h.filename !== item.filename);
    filtered.unshift(item);
    saveHistory(filtered);
    renderHistory();
  }

  function removeFromHistory(filename) {
    const history = getHistory().filter(h => h.filename !== filename);
    saveHistory(history);
    renderHistory();
  }

    function clearHistory() {
    showConfirmModal({
      title: '🗑️ Hapus Semua Riwayat?',
      message: 'Semua riwayat voice over akan dihapus permanen. Tindakan ini tidak bisa dibatalkan.',
      confirmText: 'Ya, Hapus Semua',
      confirmColor: '#ef4444',
      onConfirm: () => {
        saveHistory([]);
        renderHistory();
        console.log('[VoiceOver L3] Riwayat dihapus');
      }
    });
  }

  // ============================================
  // CUSTOM CONFIRM MODAL
  // ============================================
  function showConfirmModal({ title, message, confirmText, confirmColor, onConfirm }) {
    // Hapus modal lama kalau ada
    const oldModal = document.getElementById('voCustomModal');
    if (oldModal) oldModal.remove();

    // Buat modal baru
    const modal = document.createElement('div');
    modal.id = 'voCustomModal';
    modal.innerHTML = `
      <div style="
        position: fixed; inset: 0; z-index: 999999;
        background: rgba(0, 0, 0, 0.75);
        backdrop-filter: blur(4px);
        display: flex; align-items: center; justify-content: center;
        padding: 20px;
        animation: voFadeIn 0.2s ease;
      ">
        <div style="
          background: linear-gradient(135deg, #14141f 0%, #0f0f1a 100%);
          border: 1px solid rgba(245, 158, 11, 0.3);
          border-radius: 16px;
          padding: 24px;
          max-width: 420px;
          width: 100%;
          box-shadow: 0 24px 64px rgba(0, 0, 0, 0.7);
          animation: voSlideIn 0.3s ease;
        ">
          <h3 style="
            color: #fff; font-size: 1.1rem; font-weight: 700;
            margin: 0 0 12px 0;
            display: flex; align-items: center; gap: 8px;
          ">${title}</h3>
          <p style="
            color: #94a3b8; font-size: 0.9rem; line-height: 1.6;
            margin: 0 0 20px 0;
          ">${message}</p>
          <div style="display: flex; gap: 10px;">
            <button id="voModalCancel" style="
              flex: 1; padding: 12px;
              background: rgba(255, 255, 255, 0.05);
              border: 1px solid rgba(255, 255, 255, 0.1);
              border-radius: 10px;
              color: #cbd5e1; font-size: 0.9rem; font-weight: 600;
              cursor: pointer;
              transition: all 0.2s;
            ">Batal</button>
            <button id="voModalConfirm" style="
              flex: 1; padding: 12px;
              background: ${confirmColor || '#ef4444'};
              border: none;
              border-radius: 10px;
              color: #fff; font-size: 0.9rem; font-weight: 700;
              cursor: pointer;
              transition: all 0.2s;
            ">${confirmText || 'Ya'}</button>
          </div>
        </div>
      </div>
      <style>
        @keyframes voFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes voSlideIn {
          from { transform: translateY(-20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
      </style>
    `;

    document.body.appendChild(modal);

    // Bind buttons
    const cancelBtn = modal.querySelector('#voModalCancel');
    const confirmBtn = modal.querySelector('#voModalConfirm');

    cancelBtn.addEventListener('click', () => modal.remove());
    confirmBtn.addEventListener('click', () => {
      modal.remove();
      if (typeof onConfirm === 'function') onConfirm();
    });

    // Klik backdrop untuk close
    modal.addEventListener('click', (e) => {
      if (e.target === modal || e.target.style.inset === '0') {
        modal.remove();
      }
    });

    // ESC untuk close
    const escHandler = (e) => {
      if (e.key === 'Escape') {
        modal.remove();
        document.removeEventListener('keydown', escHandler);
      }
    };
    document.addEventListener('keydown', escHandler);
  }

  // ============================================
  // RENDER HISTORY
  // ============================================
  function renderHistory() {
    const container = document.getElementById('voHistory');
    const list = document.getElementById('voHistoryList');
    if (!container || !list) return;

    const history = getHistory();
    if (history.length === 0) {
      container.style.display = 'none';
      return;
    }

    container.style.display = 'block';

    list.innerHTML = history.map((item, i) => {
      const time = new Date(item.timestamp).toLocaleString('id-ID', {
        day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'
      });
      const textPreview = (item.text || '').substring(0, 40) + (item.text.length > 40 ? '...' : '');

      return `
        <div style="display:flex; gap:8px; padding:8px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.06); border-radius:8px; align-items:center;">
          <button type="button" class="vo-history-play" data-url="${item.url}" 
            style="width:32px; height:32px; border-radius:50%; background:rgba(139,92,246,0.2); border:none; color:#c4b5fd; cursor:pointer; flex-shrink:0;">
            <i class="fas fa-play" style="font-size:11px;"></i>
          </button>
          <div style="flex:1; min-width:0;">
            <div style="font-size:11px; color:#cbd5e1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
              ${textPreview}
            </div>
            <div style="font-size:10px; color:#64748b; margin-top:2px;">
              ${time} • ${item.voice || 'default'}
            </div>
          </div>
          <a href="${item.url}" download="${item.filename}" 
            style="color:#8b5cf6; padding:6px; font-size:12px;" title="Download">
            <i class="fas fa-download"></i>
          </a>
          <button type="button" class="vo-history-delete" data-filename="${item.filename}"
            style="background:transparent; border:none; color:#ef4444; padding:6px; font-size:12px; cursor:pointer;" title="Hapus">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      `;
    }).join('');

    // Bind tombol play
    list.querySelectorAll('.vo-history-play').forEach(btn => {
      btn.addEventListener('click', function() {
        const url = this.dataset.url;
        const player = document.getElementById('voPlayer');
        const result = document.getElementById('voResult');
        if (player && result) {
          player.src = url;
          player.load();
          result.style.display = 'block';
          player.play();
          result.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      });
    });

    // Bind tombol delete
    list.querySelectorAll('.vo-history-delete').forEach(btn => {
      btn.addEventListener('click', function() {
        removeFromHistory(this.dataset.filename);
      });
    });
  }

   // ============================================
  // TOAST NOTIFICATION SYSTEM
  // ============================================
  window.showToast = function(message, type = 'info', duration = 3000) {
    const colors = {
      success: { bg: 'linear-gradient(135deg, #10b981, #059669)', icon: 'fa-check-circle' },
      error:   { bg: 'linear-gradient(135deg, #ef4444, #dc2626)', icon: 'fa-exclamation-circle' },
      warning: { bg: 'linear-gradient(135deg, #f59e0b, #d97706)', icon: 'fa-exclamation-triangle' },
      info:    { bg: 'linear-gradient(135deg, #8b5cf6, #6d28d9)', icon: 'fa-info-circle' },
    };

    const style = colors[type] || colors.info;

    // Container global (bikin kalau belum ada)
    let container = document.getElementById('voToastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'voToastContainer';
      container.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 999999;
        display: flex;
        flex-direction: column;
        gap: 10px;
        pointer-events: none;
        max-width: 400px;
      `;
      document.body.appendChild(container);
    }

    // Toast baru
    const toast = document.createElement('div');
    toast.style.cssText = `
      background: ${style.bg};
      color: #fff;
      padding: 14px 18px;
      border-radius: 12px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.5);
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 14px;
      font-weight: 500;
      pointer-events: auto;
      animation: voToastIn 0.3s ease;
      max-width: 100%;
    `;
    toast.innerHTML = `
      <i class="fas ${style.icon}" style="font-size:18px; flex-shrink:0;"></i>
      <span style="flex:1;">${message}</span>
      <button onclick="this.parentElement.remove()" 
        style="background:transparent; border:none; color:#fff; cursor:pointer; font-size:16px; opacity:0.7; padding:0 4px;">
        ×
      </button>
    `;

    container.appendChild(toast);

    // Animasi CSS (hanya sekali)
    if (!document.getElementById('voToastStyle')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'voToastStyle';
      styleEl.textContent = `
        @keyframes voToastIn {
          from { opacity: 0; transform: translateX(50px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes voToastOut {
          from { opacity: 1; transform: translateX(0); }
          to   { opacity: 0; transform: translateX(50px); }
        }
      `;
      document.head.appendChild(styleEl);
    }

    // Auto remove
    setTimeout(() => {
      toast.style.animation = 'voToastOut 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  };

  

  // ============================================
  // INIT VOICE OVER
  // ============================================
  document.addEventListener('DOMContentLoaded', function() {
    initVoiceOver();
  });

  function initVoiceOver() {
    const voText = document.getElementById('voText');
    const voVoice = document.getElementById('voVoice');
    const voRate = document.getElementById('voRate');
    const voPitch = document.getElementById('voPitch');
    const voRateVal = document.getElementById('voRateVal');
    const voPitchVal = document.getElementById('voPitchVal');
    const voGenerateBtn = document.getElementById('voGenerateBtn');
    const voResult = document.getElementById('voResult');
    const voPlayer = document.getElementById('voPlayer');
    const voDownloadBtn = document.getElementById('voDownloadBtn');
    const voResetBtn = document.getElementById('voResetBtn');
    const voClearHistory = document.getElementById('voClearHistory');
    const voEmotion = document.getElementById('voEmotion');

    if (!voText || !voGenerateBtn) {
      console.log('[VoiceOver L3] Panel tidak ditemukan');
      return;
    }

    console.log('[VoiceOver L3] Initialized');

    // Load voices + render history
    loadVoices();
    renderHistory();

    // =============================
    // SLIDER BINDING
    // =============================
    if (voRate && voRateVal) {
      voRate.addEventListener('input', function() {
        const v = parseInt(this.value);
        voRateVal.textContent = (v >= 0 ? '+' : '') + v + '%';
      });
    }

    if (voPitch && voPitchVal) {
      voPitch.addEventListener('input', function() {
        const v = parseInt(this.value);
        voPitchVal.textContent = (v >= 0 ? '+' : '') + v + 'Hz';
      });
    }

    // =============================
    // PRESET BUTTONS — LEVEL 3
    // =============================
    document.querySelectorAll('.vo-preset-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const presetKey = this.dataset.preset;
        const preset = PRESETS[presetKey];
        if (!preset) return;

        // Set slider
        if (voRate) {
          voRate.value = preset.rate;
          voRate.dispatchEvent(new Event('input'));
        }
        if (voPitch) {
          voPitch.value = preset.pitch;
          voPitch.dispatchEvent(new Event('input'));
        }
        if (voVoice && preset.voice) {
          voVoice.value = preset.voice;
        }

        // Visual feedback
        document.querySelectorAll('.vo-preset-btn').forEach(b => {
          b.style.transform = 'scale(1)';
          b.style.boxShadow = 'none';
        });
        this.style.transform = 'scale(1.05)';
        this.style.boxShadow = '0 0 20px rgba(139,92,246,0.5)';
        setTimeout(() => {
          this.style.transform = 'scale(1)';
          this.style.boxShadow = 'none';
        }, 500);

        console.log(`[VoiceOver L3] Preset applied: ${preset.label} (${preset.desc})`);
      });
    });

    // =============================
    // GENERATE BUTTON
    // =============================
    voGenerateBtn.addEventListener('click', async function() {
      const text = (voText.value || '').trim();
      const voice = voVoice ? voVoice.value : 'id-ID-ArdiNeural';
      const rateVal = voRate ? parseInt(voRate.value) : 0;
      const pitchVal = voPitch ? parseInt(voPitch.value) : 0;
      const emotion = voEmotion ? voEmotion.value : 'netral';

      if (!text) { showToast('Tulis script voice over dulu!', 'warning'); return; }
      if (text.length > 5000) { showToast('Teks maksimal 5000 karakter.', 'warning'); return; }

      const rate = (rateVal >= 0 ? '+' : '') + rateVal + '%';
      const pitch = (pitchVal >= 0 ? '+' : '') + pitchVal + 'Hz';

      const originalHTML = voGenerateBtn.innerHTML;
      voGenerateBtn.disabled = true;
      voGenerateBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';

      try {
        const res = await authFetch('/api/voiceover/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text, voice, rate, pitch, emotion })
        });

        const data = await res.json();

        if (res.status === 401) {
          showToast('Sesi login habis. Login ulang.', 'error');
          window.location.href = '/clipora/login.php';
          return;
        }
        if (res.status === 403) {
          showToast('Fitur ini untuk Pro user. Upgrade dulu ya!', 'warning');
          return;
        }

        if (data.success && data.url) {
          // Show result
          if (voPlayer) { voPlayer.src = data.url; voPlayer.load(); }
          if (voResult) voResult.style.display = 'block';

          // Save to history
          addToHistory({
            filename: data.filename,
            url: data.url,
            text: text,
            voice: voice,
            rate: rate,
            pitch: pitch,
            timestamp: Date.now(),
          });

          console.log('[VoiceOver L3] Generated:', data.filename);
        } else {
          showToast('Gagal: ' + (data.error || 'Unknown error'), 'error', 4000);
        }
      } catch (e) {
        showToast('Network error: ' + e.message, 'error');
      } finally {
        voGenerateBtn.disabled = false;
        voGenerateBtn.innerHTML = originalHTML;
      }
    });

    // =============================
    // BULK MULTI-BAHASA HANDLER — LEVEL 4B
    // =============================
    const voBulkGenerateBtn = document.getElementById('voBulkGenerateBtn');
    const voBulkResult = document.getElementById('voBulkResult');
    const voBulkResultGrid = document.getElementById('voBulkResultGrid');
    const voBulkStatus = document.getElementById('voBulkStatus');

    if (voBulkGenerateBtn) {
      voBulkGenerateBtn.addEventListener('click', async function() {
        // 1. Kumpulkan bahasa dari checkbox
        const languages = [];
        const langMap = {
          'voBulkId': 'id',
          'voBulkEn': 'en',
          'voBulkJa': 'ja',
          'voBulkZh': 'zh',
          'voBulkKo': 'ko',
          'voBulkAr': 'ar',
        };

        Object.entries(langMap).forEach(([id, code]) => {
          const cb = document.getElementById(id);
          if (cb && cb.checked) languages.push(code);
        });

        // 2. Validasi
        if (languages.length === 0) {
          showToast('Pilih minimal 1 bahasa', 'warning', 2500);
          return;
        }

        const text = (voText.value || '').trim();
        if (!text) { showToast('Tulis script dulu!', 'warning'); return; }
        if (text.length > 3000) {
          showToast('Maks 3000 karakter untuk bulk', 'warning');
          return;
        }

        const emotion = voEmotion ? voEmotion.value : 'netral';

        // 3. Loading state
        const orig = voBulkGenerateBtn.innerHTML;
        voBulkGenerateBtn.disabled = true;
        voBulkGenerateBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating ' + languages.length + ' bahasa...';
        if (voBulkStatus) {
          voBulkStatus.textContent = 'Memproses ' + languages.length + ' bahasa...';
          voBulkStatus.style.color = '#c4b5fd';
        }

        try {
          const res = await authFetch('/api/voiceover/bulk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: text, emotion: emotion, languages: languages })
          });

          const data = await res.json();

          if (res.status === 401) {
            showToast('Sesi habis, silakan login ulang', 'warning', 3000);
            window.location.href = '/clipora/login.php';
            return;
          }
          if (res.status === 403) {
            showToast('Fitur ini hanya untuk user Pro', 'error', 4000);
            return;
          }
          if (!data.success) {
            throw new Error(data.error || 'Bulk generate gagal');
          }

          // 4. Render hasil
          renderBulkResult(data.results, data.errors);

          if (voBulkStatus) {
            voBulkStatus.textContent = 'Selesai! ' + data.success_count + '/' + data.total + ' sukses';
            voBulkStatus.style.color = '#22c55e';
          }

          // 5. Save ke riwayat
          data.results.forEach(r => {
            addToHistory({
              filename: r.filename,
              url: r.url,
              text: r.text,
              voice: r.voice,
              rate: data.rate,
              pitch: data.pitch,
              timestamp: Date.now(),
              bulk: true,
              lang: r.lang,
            });
          });

          console.log('[VoiceOver L4B] Bulk generated: ' + data.success_count + '/' + data.total);

        } catch (e) {
          console.error('[BulkVO] Error:', e);
          showToast('Error: ' + e.message, 'error', 4000);
          if (voBulkStatus) {
            voBulkStatus.textContent = 'Gagal: ' + e.message;
            voBulkStatus.style.color = '#ef4444';
          }
        } finally {
          voBulkGenerateBtn.disabled = false;
          voBulkGenerateBtn.innerHTML = orig;
        }
      });
    }

    // =============================
    // RENDER BULK RESULT
    // =============================
    function renderBulkResult(results, errors) {
      if (!voBulkResult || !voBulkResultGrid) return;

      voBulkResult.style.display = 'block';

      const langFlags = {
        'id': 'ID', 'en': 'EN', 'ja': 'JP',
        'zh': 'ZH', 'ko': 'KO', 'ar': 'AR',
      };

      let html = '';

      // Render sukses
      results.forEach(r => {
        const flag = langFlags[r.lang] || 'GL';
        const textPreview = (r.text || '').substring(0, 60) + (r.text.length > 60 ? '...' : '');

        html += '<div style="display:flex; gap:12px; padding:12px; background:rgba(139,92,246,0.08); border:1px solid rgba(139,92,246,0.2); border-radius:12px; align-items:center;">';
        html += '<div style="flex:0 0 50px; text-align:center;">';
        html += '<div style="font-size:18px; font-weight:700; color:#c4b5fd;">' + flag + '</div>';
        html += '<div style="font-size:10px; color:#94a3b8; margin-top:2px;">' + r.lang.toUpperCase() + '</div>';
        html += '</div>';
        html += '<div style="flex:1; min-width:0;">';
        html += '<audio controls src="' + r.url + '" style="width:100%; height:32px; margin-bottom:6px;"></audio>';
        html += '<div style="font-size:11px; color:#94a3b8; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">';
        html += r.voice + ' - ' + r.size_kb + ' KB';
        html += '</div>';
        html += '<div style="font-size:10px; color:#64748b; margin-top:2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">';
        html += textPreview;
        html += '</div>';
        html += '</div>';
        html += '<a href="' + r.url + '" download="' + r.filename + '" style="flex:0 0 auto; color:#8b5cf6; padding:8px; font-size:14px;" title="Download">';
        html += '<i class="fas fa-download"></i>';
        html += '</a>';
        html += '</div>';
      });

      // Render error (kalau ada)
      if (errors && errors.length > 0) {
        errors.forEach(e => {
          const flag = langFlags[e.lang] || 'GL';
          html += '<div style="padding:10px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.3); border-radius:10px; font-size:12px; color:#fca5a5;">';
          html += flag + ' ' + e.lang.toUpperCase() + ': ' + e.error;
          html += '</div>';
        });
      }

      voBulkResultGrid.innerHTML = html;
    }

    // =============================
    // RESET BUTTON
    // =============================
    if (voResetBtn) {
      voResetBtn.addEventListener('click', function() {
        if (voResult) voResult.style.display = 'none';
        if (voPlayer) voPlayer.src = '';
        if (voText) voText.value = '';
        if (voRate && voRateVal) { voRate.value = 0; voRateVal.textContent = '+0%'; }
        if (voPitch && voPitchVal) { voPitch.value = 0; voPitchVal.textContent = '+0Hz'; }
      });
    }

    // =============================
    // DOWNLOAD BUTTON
    // =============================
    if (voDownloadBtn) {
      voDownloadBtn.addEventListener('click', function() {
        const src = voPlayer ? voPlayer.src : null;
        if (!src) return;
        const a = document.createElement('a');
        a.href = src;
        a.download = src.split('/').pop();
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      });
    }

    // =============================
    // CLEAR HISTORY
    // =============================
    if (voClearHistory) {
      voClearHistory.addEventListener('click', clearHistory);
    }

    // =============================
    // LOAD VOICES FROM API
    // =============================
    async function loadVoices() {
      if (!voVoice) return;
      try {
        const res = await authFetch('/api/voiceover/voices');
        const data = await res.json();
        if (data.success && Array.isArray(data.voices) && data.voices.length > 0) {
          const current = voVoice.value;
          voVoice.innerHTML = data.voices.map(v =>
            '<option value="' + v.code + '">' + v.name + '</option>'
          ).join('');
          if (current) voVoice.value = current;
          console.log('[VoiceOver L3] Loaded ' + data.voices.length + ' voices');
        }
      } catch (e) {
        console.warn('[VoiceOver L3] Load voices failed:', e.message);
      }
    }
  }

    // ============================================================
    // V9.212.0: VO TAB NAVIGATION (Solo / Bulk / Dialog)
    // ============================================================
    function initVoTabs() {
        const tabs = document.querySelectorAll('.vo-tab');
        const contents = document.querySelectorAll('.vo-tab-content');

        if (!tabs.length) {
            return;
            return;
        }

        console.log('[VO Tabs] Init — found', tabs.length, 'tabs,', contents.length, 'contents');

        tabs.forEach(function(tab) {
            tab.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();

                const targetTab = this.dataset.tab;
                console.log('[VO Tabs] Click:', targetTab);

                // Update active tab
                tabs.forEach(function(t) {
                    t.classList.remove('vo-tab-active');
                    t.classList.remove('active');
                });
                this.classList.add('vo-tab-active');

                // Update content
                contents.forEach(function(c) {
                    c.classList.remove('vo-tab-content-active');
                    c.classList.remove('active');
                });

                const targetContent = document.querySelector('.vo-tab-content[data-tab="' + targetTab + '"]');
                if (targetContent) {
                    targetContent.classList.add('vo-tab-content-active');
                    console.log('[VO Tabs] Content shown:', targetTab);
                } else {
                    console.warn('[VO Tabs] Content not found for:', targetTab);
                }
            });

            // Pastikan button tidak disabled
            tab.disabled = false;
            tab.style.pointerEvents = 'auto';
            tab.style.cursor = 'pointer';
        });

        console.log('[VO Tabs] Ready');
    }

    // Init — coba langsung, kalau belum ada tunggu DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(initVoTabs, 300);
        });
    } else {
        setTimeout(initVoTabs, 300);
    }
})();