﻿import re
from pathlib import Path

# Baca fungsi analyze_retention dari file utama
fp = Path("C:/xampp/htdocs/clipora/process_video_v8.py")
content = fp.read_text(encoding="utf-8", errors="replace")

# Cari fungsi analyze_retention
start_idx = content.find("def analyze_retention(")
if start_idx == -1:
    print("[ERROR] Fungsi analyze_retention tidak ditemukan")
    exit(1)

# Cari akhir fungsi (def berikutnya setelah analyze_retention)
next_def = content.find("\ndef ", start_idx + 10)
if next_def == -1:
    next_def = len(content)

func_code = content[start_idx:next_def]

# Buat file test dengan fungsi isolated
test_code = f'''import sys

{func_code}

# Test data
words = [
    {{"word": "Kita", "start": 0, "end": 0.3}},
    {{"word": "akan", "start": 0.4, "end": 0.6}},
    {{"word": "belajar", "start": 0.7, "end": 1.0}},
    {{"word": "eh", "start": 2.5, "end": 2.7}},
    {{"word": "cara", "start": 5.0, "end": 5.3}},
    {{"word": "membuat", "start": 5.4, "end": 5.8}},
    {{"word": "video", "start": 5.9, "end": 6.2}},
]

import json
result = analyze_retention(words, video_duration=10)
print(json.dumps(result, indent=2, ensure_ascii=False))
'''

# Tulis test file
test_path = Path("C:/xampp/htdocs/clipora/test_retention_isolated.py")
test_path.write_text(test_code, encoding="utf-8")
print(f"[OK] Test file: {test_path}")
print("=" * 60)
