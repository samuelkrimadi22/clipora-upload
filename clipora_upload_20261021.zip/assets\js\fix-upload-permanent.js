﻿// ============================================================
// V9.270.0: PERBAIKAN PERMANEN UPLOAD & PREVIEW
// ============================================================
(function() {
    "use strict";

    function initUploadFix() {
        var input = document.getElementById("acFileInput");
        if (!input) {
            setTimeout(initUploadFix, 500);
            return;
        }

        // Hindari pemasangan ganda
        if (input.dataset.permanentFixed) return;
        input.dataset.permanentFixed = "true";

        // Tangkap event saat file dipilih
        input.addEventListener("change", function() {
            if (!input.files || input.files.length === 0) return;
            
            var file = input.files[0];
            console.log("✅ [FixUpload] File dipilih:", file.name, "(" + (file.size / 1024 / 1024).toFixed(2) + " MB)");

            // 1. Tampilkan Preview Video
            var previewWrap = document.getElementById("acVideoPreviewWrap");
            var previewVideo = document.getElementById("acVideoPreview");
            if (previewWrap && previewVideo) {
                if (previewWrap) if (previewWrap) previewWrap.style.display = "block";
                previewVideo.src = URL.createObjectURL(file);
                previewVideo.load();
                console.log("✅ [FixUpload] Preview video ditampilkan!");
            } else {
                console.warn("⚠️ [FixUpload] Elemen preview tidak ditemukan.");
            }

            // 2. Tampilkan Tombol Proses
            var prosesWrapper = document.getElementById("acProsesWrapper");
            if (prosesWrapper) {
                if (prosesWrapper) if (prosesWrapper) prosesWrapper.style.display = "block";
                prosesWrapper.classList.add("visible");
                console.log("✅ [FixUpload] Tombol Proses ditampilkan!");
            } else {
                console.warn("⚠️ [FixUpload] Elemen tombol proses tidak ditemukan.");
            }

            // 3. Sembunyikan Upload Zone
            var uploadZone = document.getElementById("acUploadZone");
            if (uploadZone) {
                if (uploadZone) if (uploadZone) uploadZone.style.display = "none";
            }

            // 4. Scroll ke Preview
            if (previewWrap) {
                setTimeout(function() {
                    previewWrap.scrollIntoView({ behavior: "smooth", block: "start" });
                }, 300);
            }
        });

        console.log("✅ [FixUpload] Event listener terpasang di input file.");
    }

    // Jalankan saat DOM ready
    document.addEventListener("DOMContentLoaded", function() {
        initUploadFix();
        // Coba lagi setiap 1 detik (jika elemen belum siap)
        setInterval(initUploadFix, 1000);
    });

    console.log("[V9.270.0] FixUpload aktif!");
})();