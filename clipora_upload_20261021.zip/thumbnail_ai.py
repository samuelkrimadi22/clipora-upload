#!/usr/bin/env python3
# thumbnail_ai.py — Clipora V8.9.0 AI Thumbnail Generator (Level 1)
# ============================================================
# Fitur:
#   - Generate 3 hook text dari transcript (LLM → rule-based fallback)
#   - Pick 3 frame terbaik dari klip (face + sharpness + brightness)
#   - Overlay hook text ke frame → jadi thumbnail
# ============================================================

import os
import re
import sys
import json
import subprocess
import uuid
from pathlib import Path
from collections import Counter

import cv2
import numpy as np


# ============================================================
# HOOK GENERATOR — LLM dengan fallback chain
# ============================================================
def generate_hooks(transcript_text, count=3):
    """
    Generate hook text dari transcript.
    Fallback chain: OpenAI → Ollama → Rule-based.
    Return: list of strings (panjang == count)
    """
    if not transcript_text or not transcript_text.strip():
        return _default_hooks(count)
    
    # 1. Coba OpenAI (kalau ada API key)
    hooks = _hooks_openai(transcript_text, count)
    if hooks and len(hooks) >= count:
        return hooks[:count]
    
    # 2. Coba Ollama lokal (kalau ada)
    hooks = _hooks_ollama(transcript_text, count)
    if hooks and len(hooks) >= count:
        return hooks[:count]
    
    # 3. Rule-based fallback
    return _hooks_rule_based(transcript_text, count)


def _hooks_openai(text, count):
    """Generate hook via OpenAI API."""
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return None
    
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        
        prompt = f"""Dari transcript video ini, buat {count} judul thumbnail YouTube yang menarik perhatian (clickbait tapi jujur).

Aturan:
- Maksimal 4 kata per judul
- Pakai HURUF BESAR semua
- Bahasa Indonesia
- Buat yang bikin orang penasaran
- Jangan pakai emoji
- Jangan pakai tanda baca di akhir

Transcript:
{text[:1500]}

Return HANYA JSON array of strings, contoh: ["RAHASIA SUKSES", "MULAI DARI NOL", "TERNYATA SALAH"]"""

        response = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[{"role": "user", "content": prompt}],
            temperature=0.8,
            max_tokens=200,
        )
        
        content = response.choices[0].message.content.strip()
        
        # Parse JSON
        content = content.strip("`").replace("json\n", "").replace("```", "")
        hooks = json.loads(content)
        
        if isinstance(hooks, list):
            return [str(h).upper().strip()[:30] for h in hooks if h]
    except Exception as e:
        print(f"[Thumbnail AI] OpenAI gagal: {e}", file=sys.stderr)
    
    return None


def _hooks_ollama(text, count):
    """Generate hook via Ollama lokal (gratis)."""
    try:
        import requests
        ollama_url = os.getenv("OLLAMA_URL", "http://localhost:11434")
        model = os.getenv("OLLAMA_MODEL", "llama3.2")
        
        prompt = f"""Buat {count} judul thumbnail YouTube (Bahasa Indonesia, maks 4 kata, HURUF BESAR) dari transcript ini:

{text[:1000]}

Return hanya JSON array, contoh: ["RAHASIA SUKSES","MULAI DARI NOL"]"""
        
        r = requests.post(
            f"{ollama_url}/api/generate",
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=30,
        )
        if r.status_code == 200:
            content = r.json().get("response", "")
            # Cari JSON array
            match = re.search(r"\[.*\]", content, re.DOTALL)
            if match:
                hooks = json.loads(match.group(0))
                if isinstance(hooks, list):
                    return [str(h).upper().strip()[:30] for h in hooks if h]
    except Exception as e:
        print(f"[Thumbnail AI] Ollama gagal: {e}", file=sys.stderr)
    
    return None


def _hooks_rule_based(text, count):
    """Rule-based hook generator (selalu works, tanpa API)."""
    text_lower = text.lower()
    
    # Ekstrak keyword penting
    words = re.findall(r'\b[a-z]{4,}\b', text_lower)
    stopwords = {
        'yang', 'dengan', 'untuk', 'dari', 'tidak', 'akan', 'telah',
        'saya', 'kamu', 'kita', 'mereka', 'adalah', 'karena', 'tetapi',
        'kalau', 'juga', 'bisa', 'harus', 'sudah', 'belum', 'saja',
        'atau', 'tapi', 'jadi', 'apa', 'siapa', 'mana', 'ini', 'itu',
        'ada', 'banyak', 'sedikit', 'sangat', 'sekali', 'banget',
    }
    keywords = [w for w in words if w not in stopwords]
    
    # Ambil top 5 kata yang sering muncul
    counter = Counter(keywords)
    top_words = [w for w, _ in counter.most_common(5)]
    
    # Deteksi pola narasi
    motivasi_words = ['sukses', 'gagal', 'mulai', 'nol', 'berhasil', 'usaha', 'kerja', 'keras']
    story_words = ['cerita', 'pengalaman', 'dulu', 'waktu', 'pernah']
    
    is_motivasi = any(w in text_lower for w in motivasi_words)
    is_story = any(w in text_lower for w in story_words)
    
    hooks = []
    
    # Coba dari top keyword
    for kw in top_words[:3]:
        kw_upper = kw.upper()
        if is_motivasi:
            hooks.append(f"RAHASIA {kw_upper}")
        elif is_story:
            hooks.append(f"TERNYATA {kw_upper}")
        else:
            hooks.append(f"KENAPA {kw_upper}")
    
    # Tambah template umum
    if is_motivasi:
        hooks.append("MULAI DARI NOL")
        hooks.append("JANGAN MENYERAH")
    elif is_story:
        hooks.append("PENGALAMAN NYATA")
        hooks.append("TERNYATA SALAH")
    else:
        hooks.append("WAJIB TAHU")
        hooks.append("CARA CEPAT")
    
    # Deduplicate & limit
    seen = set()
    unique = []
    for h in hooks:
        h = h[:30]
        if h not in seen:
            seen.add(h)
            unique.append(h)
    
    return unique[:count] if unique else _default_hooks(count)


def _default_hooks(count):
    defaults = ["WAJIB TAHU", "RAHASIA SUKSES", "TERNYATA SALAH", "MULAI DARI NOL", "JANGAN LEWATKAN"]
    return defaults[:count]


# ============================================================
# FRAME PICKER — Computer vision scoring
# ============================================================
def _score_frame(frame, face_cascade):
    """Score frame 0-100. Higher = better thumbnail candidate."""
    score = 0
    
    try:
        h, w = frame.shape[:2]
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # 1. Sharpness (Laplacian variance) — hindari blur
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        if laplacian_var > 500:
            score += 30
        elif laplacian_var > 200:
            score += 20
        elif laplacian_var > 100:
            score += 10
        elif laplacian_var < 50:
            score -= 20  # blurred, penalize
        
        # 2. Brightness
        brightness = np.mean(gray)
        if 80 < brightness < 180:
            score += 15
        elif 50 < brightness < 200:
            score += 8
        elif brightness < 30 or brightness > 230:
            score -= 15  # too dark/bright
        
        # 3. Contrast
        contrast = np.std(gray)
        if contrast > 50:
            score += 10
        elif contrast > 30:
            score += 5
        
        # 4. Face detection
        if face_cascade is not None:
            small = frame
            if w > 640:
                scale = 640 / w
                small = cv2.resize(frame, (640, int(h * scale)))
            
            gray_small = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray_small, 1.2, 5, minSize=(40, 40))
            
            if len(faces) == 1:
                score += 30  # 1 face = perfect
            elif len(faces) == 2:
                score += 20
            elif len(faces) > 2:
                score += 5
            
            # Bonus kalau wajah besar
            if len(faces) > 0:
                biggest = max(faces, key=lambda f: f[2] * f[3])
                sh, sw = small.shape[:2]
                face_area_ratio = (biggest[2] * biggest[3]) / (sw * sh)
                if face_area_ratio > 0.15:
                    score += 15
                elif face_area_ratio > 0.08:
                    score += 8
        
        # 5. Center composition (hindari subject di pinggir)
        # (skip — terlalu kompleks untuk Level 1)
    
    except Exception as e:
        print(f"[Thumbnail AI] Score error: {e}", file=sys.stderr)
    
    return max(0, min(100, score))


def pick_best_frames(video_path, start, end, count=3):
    """
    Pick `count` frame terbaik dari klip.
    Return: list of dicts {frame_idx, time, path, score}
    """
    if not os.path.exists(video_path):
        return []
    
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"[Thumbnail AI] Tidak bisa buka video: {video_path}", file=sys.stderr)
        return []
    
    # Load face cascade
    face_cascade = None
    try:
        if hasattr(cv2, 'data') and hasattr(cv2, 'CascadeClassifier'):
            cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            face_cascade = cv2.CascadeClassifier(cascade_path)
            if face_cascade.empty():
                face_cascade = None
    except Exception:
        face_cascade = None
    
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = total_frames / fps if fps > 0 else 0
    
    # Clip range
    clip_dur = end - start
    if clip_dur < 1:
        cap.release()
        return []
    
    # Sample 15 frame tersebar di klip (skip 0.5s pertama & terakhir)
    safe_start = start + 0.5
    safe_end = end - 0.5
    if safe_end <= safe_start:
        safe_start = start
        safe_end = end
    
    sample_count = 15
    sample_times = [
        safe_start + (i / (sample_count - 1)) * (safe_end - safe_start)
        for i in range(sample_count)
    ]
    
    # Extract frames
    frames_data = []
    temp_dir = Path(os.path.dirname(video_path)).parent / "temp"
    temp_dir.mkdir(exist_ok=True)
    
    for i, t in enumerate(sample_times):
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ret, frame = cap.read()
        if not ret or frame is None:
            continue
        
        score = _score_frame(frame, face_cascade)
        
        # Save frame raw
        raw_path = str(temp_dir / f"thumb_frame_{uuid.uuid4().hex[:8]}.jpg")
        cv2.imwrite(raw_path, frame, [cv2.IMWRITE_JPEG_QUALITY, 92])
        
        frames_data.append({
            "frame_idx": i,
            "time": round(t, 2),
            "path": raw_path,
            "score": score,
        })
    
    cap.release()
    
    if not frames_data:
        return []
    
    # Sort by score DESC
    frames_data.sort(key=lambda x: x["score"], reverse=True)
    
    # Pick top N dengan diversity — pastikan timestamp tidak terlalu dekat
    picked = []
    min_gap_sec = max(0.5, clip_dur / (count * 2))
    
    for f in frames_data:
        if len(picked) >= count:
            break
        # Cek jarak dengan yang sudah dipilih
        too_close = any(abs(f["time"] - p["time"]) < min_gap_sec for p in picked)
        if not too_close:
            picked.append(f)
    
    # Kalau kurang dari count, ambil apa saja dari yang tersisa
    if len(picked) < count:
        for f in frames_data:
            if f not in picked:
                picked.append(f)
                if len(picked) >= count:
                    break
    
    # Cleanup frame yang tidak dipakai
    picked_paths = {p["path"] for p in picked}
    for f in frames_data:
        if f["path"] not in picked_paths:
            try:
                os.unlink(f["path"])
            except Exception:
                pass
    
    return picked[:count]


# ============================================================
# TEXT OVERLAY — FFmpeg drawtext
# ============================================================
def render_thumbnail_with_text(frame_path, hook_text, output_path,
                                font_path=None, aspect="16:9"):
    """
    Overlay hook text ke frame → jadi thumbnail.
    Output: 1280x720 (16:9) atau 720x1280 (9:16)
    """
    if not os.path.exists(frame_path):
        return False
    
    try:
        if aspect == "9:16":
            target_w, target_h = 1080, 1920
            scale_pad = (
                f"scale={target_w}:{target_h}:force_original_aspect_ratio=increase,"
                f"crop={target_w}:{target_h}"
            )
            font_size = 100
            box_border = 25
            y_pos = "h*0.72"
        else:
            target_w, target_h = 1280, 720
            scale_pad = (
                f"scale={target_w}:{target_h}:force_original_aspect_ratio=decrease,"
                f"pad={target_w}:{target_h}:(ow-iw)/2:(oh-ih)/2:black"
            )
            font_size = 72
            box_border = 20
            y_pos = "h*0.75"
        
        # Escape teks untuk drawtext
        clean_text = str(hook_text).strip()[:40]
        clean_text = clean_text.replace("\\", "").replace("'", "").replace(":", "\\:")
        clean_text = clean_text.replace("[", "").replace("]", "").replace("%", "\\%")
        
        # Font file
        if font_path and os.path.exists(font_path):
            font_escaped = font_path.replace("\\", "/").replace(":", "\\:")
            font_part = f"fontfile='{font_escaped}'"
        else:
            font_part = "font=Arial"
        
        # Build filter
        # Teks di tengah, dengan box hitam semi-transparan
        vf = (
            f"{scale_pad},"
            f"drawtext=text='{clean_text}':"
            f"fontcolor=white:"
            f"fontsize={font_size}:"
            f"bold=1:"
            f"x=(w-text_w)/2:"
            f"y={y_pos}:"
            f"box=1:boxcolor=black@0.75:boxborderw={box_border}:"
            f"shadowcolor=black@0.8:shadowx=3:shadowy=3:"
            f"{font_part}"
        )
        
        # Get FFmpeg
        from shutil import which
        ffmpeg = which("ffmpeg") or "ffmpeg"  # V9.58.8: Portable FFmpeg path
        
        args = [
            ffmpeg, "-i", frame_path,
            "-vf", vf,
            "-q:v", "2",
            output_path, "-y",
        ]
        
        result = subprocess.run(args, capture_output=True, timeout=30)
        
        if result.returncode != 0:
            err = result.stderr.decode("utf-8", errors="ignore")
            print(f"[Thumbnail AI] FFmpeg gagal: {err[-500:]}", file=sys.stderr)
            return False
        
        return os.path.exists(output_path) and os.path.getsize(output_path) > 500
    
    except Exception as e:
        print(f"[Thumbnail AI] Render error: {e}", file=sys.stderr)
        return False


# ============================================================
# MAIN FUNCTION — dipanggil dari python_server.py
# ============================================================
def generate_thumbnail_options(source_path, start, end, output_dir,
                                transcript_text="", count=3,
                                aspect="16:9", font_path=None):
    """
    Generate N opsi thumbnail dengan hook text.
    
    Return: dict {
        success: bool,
        options: [{file, hook, frameTime, score}],
        error: str (kalau gagal)
    }
    """
    try:
        if not os.path.exists(source_path):
            return {"success": False, "error": f"Source not found: {source_path}"}
        
        clip_dur = end - start
        if clip_dur < 1:
            return {"success": False, "error": "Klip terlalu pendek"}
        
        print(f"[Thumbnail AI] Generating {count} opsi untuk klip {start:.1f}s → {end:.1f}s", file=sys.stderr)
        
        # 1. Generate hooks
        hooks = generate_hooks(transcript_text, count=count)
        print(f"[Thumbnail AI] Hooks: {hooks}", file=sys.stderr)
        
        # 2. Pick frames
        frames = pick_best_frames(source_path, start, end, count=count)
        if not frames:
            return {"success": False, "error": "Tidak ada frame yang bisa diambil"}
        
        print(f"[Thumbnail AI] Picked {len(frames)} frames", file=sys.stderr)
        for f in frames:
            print(f"[Thumbnail AI]   Frame @ {f['time']}s — score {f['score']}", file=sys.stderr)
        
        # 3. Pasangkan hook dengan frame (1:1)
        options = []
        for i in range(min(len(frames), len(hooks))):
            frame = frames[i]
            hook = hooks[i]
            
            output_path = os.path.join(
                output_dir,
                f"thumb_ai_{uuid.uuid4().hex[:8]}.jpg"
            )
            
            ok = render_thumbnail_with_text(
                frame["path"], hook, output_path,
                font_path=font_path, aspect=aspect,
            )
            
            # Cleanup raw frame
            try:
                os.unlink(frame["path"])
            except Exception:
                pass
            
            if ok:
                options.append({
                    "file": os.path.basename(output_path),
                    "hook": hook,
                    "frameTime": frame["time"],
                    "score": frame["score"],
                })
        
        if not options:
            return {"success": False, "error": "Semua render thumbnail gagal"}
        
        print(f"[Thumbnail AI] ✅ {len(options)} opsi siap", file=sys.stderr)
        
        return {
            "success": True,
            "options": options,
            "count": len(options),
        }
    
    except Exception as e:
        import traceback
        print(f"[Thumbnail AI] ❌ Error: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        return {"success": False, "error": str(e)}