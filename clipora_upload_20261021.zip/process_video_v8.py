# V9.179.03: FIX_VSYNC_PY
# V9.178.94: RESTORE_SINGLE_ESC
# V9.178.92: NO_COLON_ESCAPE
# V9.117.0: UMKM LAYOUT OVERHAUL
# V9.114.0: UMKM STAGGERED
# V9.113.0: UMKM FADE ANIMATION
# V9.112.0: UMKM POLISH
# V9.60.1: UMKM render
# V9.58.7: Karaoke time offset
# V9.58.6: Decouple karaoke from caption_style
# V9.58.4: Karaoke render
# === V9.6.0: Hide CMD windows on Windows ===
import sys as _sys_platform

# V9.58.4: Karaoke render
try:
    from karaoke_style import save_karaoke_ass

    HAS_KARAOKE = True
except ImportError:
    HAS_KARAOKE = False
    print("[Karaoke] Module not found, disabled", file=sys.stderr)
_CREATE_NO_WINDOW = 0x08000000 if _sys_platform.platform == "win32" else 0
import subprocess as _sp_mod

_orig_run = _sp_mod.run
_orig_popen = _sp_mod.Popen


def _patched_run(*_args, **_kwargs):
    if _CREATE_NO_WINDOW:
        _kwargs.setdefault("creationflags", _CREATE_NO_WINDOW)
    return _orig_run(*_args, **_kwargs)


def _patched_popen(*_args, **_kwargs):
    if _CREATE_NO_WINDOW:
        _kwargs.setdefault("creationflags", _CREATE_NO_WINDOW)
    return _orig_popen(*_args, **_kwargs)


_sp_mod.run = _patched_run
_sp_mod.Popen = _patched_popen
# =====================================================

#!/usr/bin/env python3
# process_video_v8.py — Clipora V8.9.20 (Per-job Cancel + Portable Paths + LRU Cache)
import os
import sys
import json
import time
import threading
import subprocess
import shutil
import re
import warnings
from pathlib import Path
import uuid
from collections import Counter
from dotenv import load_dotenv
import cv2
import numpy as np

load_dotenv()
warnings.filterwarnings("ignore")

# ============================================================
# V8.9.20: BASE PATHS (portable — ganti hardcoded XAMPP)
# ============================================================
BASE_DIR = Path(__file__).resolve().parent
ASSETS_DIR = Path(os.getenv("CLIPORA_ASSETS_DIR", str(BASE_DIR / "assets")))
FONTS_DIR = Path(os.getenv("CLIPORA_FONTS_DIR", str(ASSETS_DIR / "fonts")))
TEMP_ROOT = Path(os.getenv("CLIPORA_TEMP_DIR", str(BASE_DIR.parent / "temp")))
print(f"[Paths] BASE_DIR={BASE_DIR}", file=sys.stderr)
print(f"[Paths] FONTS_DIR={FONTS_DIR} (exists={FONTS_DIR.exists()})", file=sys.stderr)

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

try:
    import torch
    from faster_whisper import WhisperModel
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
except ImportError as e:
    print(json.dumps({"success": False, "error": f"Core library missing: {e}"}))
    sys.exit(1)

# V8.9.14: BatchedInferencePipeline (opsional)
try:
    from faster_whisper import BatchedInferencePipeline

    HAS_BATCHED = True
except ImportError:
    HAS_BATCHED = False
    BatchedInferencePipeline = None

try:
    from sentence_transformers import SentenceTransformer

    HAS_SENTENCE_TRANSFORMERS = True
except ImportError:
    HAS_SENTENCE_TRANSFORMERS = False
    SentenceTransformer = None

try:
    from silero_vad import load_silero_vad, get_speech_timestamps

    HAS_SILERO_VAD = True
except ImportError:
    HAS_SILERO_VAD = False
    load_silero_vad = None

try:
    from pyannote.audio import Pipeline as PyannotePipeline

    HAS_PYANNOTE = True
except ImportError:
    HAS_PYANNOTE = False
    PyannotePipeline = None

try:
    from keybert import KeyBERT

    HAS_KEYBERT = True
except ImportError:
    HAS_KEYBERT = False
    KeyBERT = None

try:
    from transformers import pipeline as hf_pipeline

    HAS_TRANSFORMERS_PIPE = True
except ImportError:
    HAS_TRANSFORMERS_PIPE = False
    hf_pipeline = None

try:
    from openai import OpenAI

    HAS_OPENAI_LIB = True
except ImportError:
    HAS_OPENAI_LIB = False
    OpenAI = None

try:
    from rapidfuzz import fuzz as rf_fuzz
    from rapidfuzz.distance import Levenshtein as rf_lev

    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False
    rf_fuzz = None
    rf_lev = None

try:
    from spellchecker import SpellChecker

    HAS_SPELLCHECK = True
except ImportError:
    HAS_SPELLCHECK = False
    SpellChecker = None

# V8.8.0: Auto-Caption Style
try:
    import caption_style as cs

    HAS_CAPTION_STYLE = True
except ImportError as _e:
    HAS_CAPTION_STYLE = False
    cs = None
    print(f"[CaptionStyle] Module tidak tersedia: {_e}", file=sys.stderr)

# V9.5.0: Noise Event Detection
try:
    from services import noise_detector as nd

    HAS_NOISE_DETECTOR = True
    print("[NoiseDetect] ✅ Module loaded", file=sys.stderr)
except ImportError:
    try:
        import noise_detector as nd

        HAS_NOISE_DETECTOR = True
        print("[NoiseDetect] ✅ Module loaded (flat path)", file=sys.stderr)
    except ImportError as _e:
        HAS_NOISE_DETECTOR = False
        nd = None
        print(f"[NoiseDetect] ⚠️  Tidak tersedia: {_e}", file=sys.stderr)

# ============================================================
# CONFIG — V8.7.0
# ============================================================
AI_MODE = "local"
ENABLE_CLOUD_LLM = False

ENABLE_VAD = os.getenv("ENABLE_VAD", "true").lower() == "true"
ENABLE_DIARIZATION = False
ENABLE_KEYWORD = False
ENABLE_EMOTION = False
ENABLE_SEMANTIC = False
ENABLE_SNAPPING = os.getenv("ENABLE_SNAPPING", "true").lower() == "true"
# V9.5.0: Noise detection
ENABLE_NOISE_DETECTION = os.getenv("ENABLE_NOISE_DETECTION", "true").lower() == "true"

SEMANTIC_THRESHOLD = float(os.getenv("SEMANTIC_THRESHOLD", "0.75"))
SEMANTIC_MODEL = os.getenv("SEMANTIC_MODEL", "paraphrase-multilingual-MiniLM-L12-v2")

VAD_THRESHOLD = float(os.getenv("VAD_THRESHOLD", "0.45"))
VAD_MIN_SILENCE_MS = int(os.getenv("VAD_MIN_SILENCE_MS", "300"))

PADDING_SEC = float(os.getenv("CUT_PADDING", "0.12"))
SILENCE_PADDING_SEC = float(os.getenv("SILENCE_PADDING", "0.08"))
MIN_SEGMENT_SEC = float(os.getenv("MIN_SEGMENT", "0.35"))
WORD_SNAP_TOLERANCE = float(os.getenv("WORD_SNAP_TOL", "0.18"))
TOPIC_THRESHOLD = float(os.getenv("TOPIC_THRESHOLD", "0.55"))
PROTECT_CONTEXT_SEC = float(os.getenv("PROTECT_CONTEXT", "0.8"))
MAX_ZONE_DURATION = float(os.getenv("MAX_ZONE_DURATION", "2.5"))

CFR_FPS = int(os.getenv("CFR_FPS", "30"))
MAX_SINGLE_PASS_SEGMENTS = int(os.getenv("MAX_SINGLE_PASS_SEGMENTS", "120"))
MICRO_FADE_SEC = float(os.getenv("MICRO_FADE_SEC", "0.06"))

MAX_PHRASE_LEN = int(os.getenv("MAX_PHRASE_LEN", "5"))
PHRASE_MAX_GAP = float(os.getenv("PHRASE_MAX_GAP", "2.0"))
PHRASE_MIN_REPEATS = int(os.getenv("PHRASE_MIN_REPEATS", "2"))

SAFETY_MAX_REMOVE = float(os.getenv("SAFETY_MAX_REMOVE", "0.40"))

EMOTION_MODEL = os.getenv(
    "EMOTION_MODEL", "w11wo/indonesian-roberta-base-sentiment-classifier"
)
EMOTION_PROTECT_THRESHOLD = float(os.getenv("EMOTION_PROTECT_THRESHOLD", "0.90"))

HALLUCINATION_MIN_REPEAT = int(
    os.getenv("HALLUCINATION_MIN_REPEAT", "20")
)  # V9.9.0: 15 → 20
HALLUCINATION_MAX_RATIO = float(
    os.getenv("HALLUCINATION_MAX_RATIO", "0.15")
)  # V9.9.0: 0.5 → 0.15
HALLUCINATION_PHRASE_MIN_REPEAT = int(os.getenv("HALLUCINATION_PHRASE_MIN_REPEAT", "5"))
HALLUCINATION_PHRASE_MAX_LEN = int(os.getenv("HALLUCINATION_PHRASE_MAX_LEN", "4"))
HALLUCINATION_FREQ_MIN_COUNT = int(os.getenv("HALLUCINATION_FREQ_MIN_COUNT", "8"))
HALLUCINATION_FREQ_MAX_RATIO = float(os.getenv("HALLUCINATION_FREQ_MAX_RATIO", "0.12"))
PHRASE_REPEAT_MAX_COUNT = int(os.getenv("PHRASE_REPEAT_MAX_COUNT", "20"))
PHRASE_REPEAT_MAX_DURATION = float(os.getenv("PHRASE_REPEAT_MAX_DURATION", "8.0"))

_FEATURES_JSON = os.getenv("CLIPORA_FEATURES", "{}")
if _FEATURES_JSON and _FEATURES_JSON != "{}":
    try:
        _F = json.loads(_FEATURES_JSON)
        ENABLE_SEMANTIC = _F.get("semantic", ENABLE_SEMANTIC)
        ENABLE_KEYWORD = _F.get("keyword", ENABLE_KEYWORD)
        ENABLE_EMOTION = _F.get("emotion", ENABLE_EMOTION)
        ENABLE_DIARIZATION = _F.get("diarization", ENABLE_DIARIZATION)
        ENABLE_VAD = _F.get("vad", ENABLE_VAD)
        ENABLE_NOISE_DETECTION = _F.get("noise_detection", ENABLE_NOISE_DETECTION)
        print(f"[Config] Feature override: {_F}", file=sys.stderr)
    except Exception as e:
        print(f"[Config] Gagal parse: {e}", file=sys.stderr)

print(
    f"[Config V8.9.20] VAD={ENABLE_VAD} Semantic={ENABLE_SEMANTIC} Keyword={ENABLE_KEYWORD} "
    f"Emotion={ENABLE_EMOTION} Diarization={ENABLE_DIARIZATION} Snapping={ENABLE_SNAPPING} "
    f"RapidFuzz={HAS_RAPIDFUZZ} SpellCheck={HAS_SPELLCHECK}",
    file=sys.stderr,
)

PROCESS_MODE = "full"
ANALYSIS_JSON_PATH = None

# ============================================================
# STYLE MEMORY
# ============================================================
STYLE_MEMORY = {}
_STYLE_JSON = os.getenv("CLIPORA_STYLE_MEMORY", "{}")
if _STYLE_JSON and _STYLE_JSON != "{}":
    try:
        STYLE_MEMORY = json.loads(_STYLE_JSON)
        _cats = list(STYLE_MEMORY.get("categories", {}).keys())
        _total = STYLE_MEMORY.get("total_videos", 0)
        if _cats:
            print(
                f"[StyleMemory] Loaded {len(_cats)} categories from {_total} videos",
                file=sys.stderr,
            )
    except Exception as e:
        print(f"[StyleMemory] Parse error: {e}", file=sys.stderr)
        STYLE_MEMORY = {}

# ============================================================
# MODEL CACHES — V8.9.20: LRU untuk Whisper
# ============================================================
_WHISPER_CACHE = {}
_WHISPER_CACHE_ORDER = []
_WHISPER_MAX_CACHE = int(os.getenv("WHISPER_MAX_CACHE", "2"))
_SIM_MODEL = None
_VAD_MODEL = None
_DIARIZE_PIPELINE = None
_KW_MODEL = None
_EMOTION_PIPE = None
_BATCHED_CACHE = {}


def get_whisper_model(model_size="base"):
    """V8.9.20: LRU cache — max 2 model di RAM."""
    global _WHISPER_CACHE_ORDER

    if model_size in _WHISPER_CACHE:
        try:
            _WHISPER_CACHE_ORDER.remove(model_size)
        except ValueError:
            pass
        _WHISPER_CACHE_ORDER.append(model_size)
        return _WHISPER_CACHE[model_size]

    while len(_WHISPER_CACHE) >= _WHISPER_MAX_CACHE and _WHISPER_CACHE_ORDER:
        oldest = _WHISPER_CACHE_ORDER.pop(0)
        _WHISPER_CACHE.pop(oldest, None)
        _BATCHED_CACHE.pop(oldest, None)
        print(f"[Whisper] 🗑️  Evicted '{oldest}' dari cache (LRU)", file=sys.stderr)

    cpu_threads = max(4, (os.cpu_count() or 4))
    print(
        f"[Whisper] Loading '{model_size}' ({cpu_threads} threads from {os.cpu_count()} cores)...",
        file=sys.stderr,
    )
    _WHISPER_CACHE[model_size] = WhisperModel(
        model_size,
        device="cpu",
        compute_type="int8",
        cpu_threads=cpu_threads,
        num_workers=6,
    )
    _WHISPER_CACHE_ORDER.append(model_size)
    return _WHISPER_CACHE[model_size]


def get_batched_model(model_size="base"):
    if model_size not in _BATCHED_CACHE:
        if not HAS_BATCHED:
            print(
                f"[Whisper] ⚠️ BatchedInferencePipeline tidak tersedia — pakai mode biasa",
                file=sys.stderr,
            )
            _BATCHED_CACHE[model_size] = None
            return None
        base_model = get_whisper_model(model_size)
        try:
            _BATCHED_CACHE[model_size] = BatchedInferencePipeline(model=base_model)
            print(
                f"[Whisper] ✅ BatchedInferencePipeline ready untuk '{model_size}'",
                file=sys.stderr,
            )
        except Exception as e:
            print(f"[Whisper] ⚠️ Gagal init batched: {e}", file=sys.stderr)
            _BATCHED_CACHE[model_size] = None
    return _BATCHED_CACHE[model_size]


def get_similarity_model():
    global _SIM_MODEL
    if not HAS_SENTENCE_TRANSFORMERS:
        return None
    if _SIM_MODEL is None:
        try:
            print(f"[Semantic] Loading '{SEMANTIC_MODEL}'...", file=sys.stderr)
            _SIM_MODEL = SentenceTransformer(SEMANTIC_MODEL, device="cpu")
        except Exception as e:
            print(f"[Semantic] Gagal: {e}", file=sys.stderr)
            return None
    return _SIM_MODEL


def get_vad_model():
    global _VAD_MODEL
    if not HAS_SILERO_VAD:
        return None
    if _VAD_MODEL is None:
        try:
            print("[VAD] Loading Silero VAD...", file=sys.stderr)
            _VAD_MODEL = load_silero_vad()
        except Exception as e:
            print(f"[VAD] Gagal: {e}", file=sys.stderr)
            return None
    return _VAD_MODEL


def get_diarization_pipeline():
    global _DIARIZE_PIPELINE
    if not HAS_PYANNOTE:
        return None
    if _DIARIZE_PIPELINE is None:
        hf_token = os.getenv("HF_TOKEN")
        if not hf_token:
            return None
        try:
            _DIARIZE_PIPELINE = PyannotePipeline.from_pretrained(
                "pyannote/speaker-diarization-3.1",
                use_auth_token=hf_token,
            )
        except Exception as e:
            print(f"[Diarization] Gagal: {e}", file=sys.stderr)
            return None
    return _DIARIZE_PIPELINE


def get_keyword_model():
    global _KW_MODEL
    if not HAS_KEYBERT:
        return None
    if _KW_MODEL is None:
        try:
            _KW_MODEL = KeyBERT(model=SEMANTIC_MODEL)
        except Exception as e:
            print(f"[Keyword] Gagal: {e}", file=sys.stderr)
            return None
    return _KW_MODEL


def get_emotion_pipeline():
    global _EMOTION_PIPE
    if not HAS_TRANSFORMERS_PIPE:
        return None
    if _EMOTION_PIPE is None:
        try:
            _EMOTION_PIPE = hf_pipeline(
                "sentiment-analysis",
                model=EMOTION_MODEL,
                device=-1,
                truncation=True,
                max_length=512,
            )
        except Exception as e:
            print(f"[Emotion] Gagal: {e}", file=sys.stderr)
            return None
    return _EMOTION_PIPE


# ============================================================
# FFMPEG & FONT
# ============================================================
def find_ffmpeg():
    ffmpeg = shutil.which("ffmpeg")
    ffprobe = shutil.which("ffprobe")
    if ffmpeg and ffprobe:
        return ffmpeg, ffprobe
    win_ffmpeg = "C:\\ffmpeg\\bin\\ffmpeg.exe"
    win_ffprobe = "C:\\ffmpeg\\bin\\ffprobe.exe"
    if os.path.exists(win_ffmpeg) and os.path.exists(win_ffprobe):
        return win_ffmpeg, win_ffprobe
    raise FileNotFoundError("FFmpeg/FFprobe tidak ditemukan.")


FFMPEG_PATH, FFPROBE_PATH = find_ffmpeg()


# ============================================================
# V8.9.20: Per-job cancel management (HARUS di atas, sebelum run_ffmpeg)
# ============================================================
_ACTIVE_RENDERS = {}  # {job_id: {"proc": Popen|None, "cancel": bool, "started": float}}
_RENDERS_LOCK = threading.Lock()
_FFMPEG_LOCK = threading.Lock()
_CANCEL_REQUESTED = False  # legacy compat


def _register_render(job_id):
    with _RENDERS_LOCK:
        _ACTIVE_RENDERS[job_id] = {
            "proc": None,
            "cancel": False,
            "started": time.time(),
        }


def _unregister_render(job_id):
    with _RENDERS_LOCK:
        _ACTIVE_RENDERS.pop(job_id, None)


def _is_render_cancelled(job_id):
    with _RENDERS_LOCK:
        info = _ACTIVE_RENDERS.get(job_id)
        return info["cancel"] if info else False


def _set_render_proc(job_id, proc):
    with _RENDERS_LOCK:
        if job_id in _ACTIVE_RENDERS:
            _ACTIVE_RENDERS[job_id]["proc"] = proc


def find_font():
    """V8.9.20: Portable — pakai env / project dir, dengan fallback OS."""
    candidates = [
        str(FONTS_DIR / "Rubik-Bold.ttf"),
        str(FONTS_DIR / "Rubik-Regular.ttf"),
        "C:\\Windows\\Fonts\\Rubik-Bold.ttf",
        "C:\\Windows\\Fonts\\Rubik-Regular.ttf",
        "C:\\Windows\\Fonts\\arialbd.ttf",
        "C:\\Windows\\Fonts\\arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "/Library/Fonts/Arial.ttf",
    ]
    for f in candidates:
        if os.path.exists(f):
            print(f"[Font] ✅ Menggunakan: {f}", file=sys.stderr)
            return f
    print(
        "[Font] ⚠️ Tidak ada font ditemukan — subtitle pakai default FFmpeg",
        file=sys.stderr,
    )
    return None


FONT_PATH = find_font()


def build_subtitle_filter(srt_path, font_size=52, style_mode="default"):
    """V9.3.0: Pakai caption_style (ASS) supaya konsisten dengan auto-clip."""
    # V9.3.0: Coba pakai caption_style dulu (sama seperti auto-clip)
    if HAS_CAPTION_STYLE and cs is not None:
        try:
            ass_path = str(srt_path).replace(".srt", ".ass")
            ok_convert = cs.srt_to_ass(
                str(srt_path),
                ass_path,
                style="clean",  # style default clean pro
                title="",
                play_res=(1920, 1080),
            )
            if ok_convert and os.path.exists(ass_path):
                ass_escaped = ass_path.replace("\\", "/").replace(":", "\\:")  # V9.178.94: RESTORE_SINGLE_ESC
                fonts_dir_escaped = str(FONTS_DIR).replace("\\", "/").replace(":", "\\:")  # V9.178.94: RESTORE
                print(
                    f"[Subtitle] ✅ Pakai ASS caption style 'clean' (seperti auto-clip)",
                    file=sys.stderr,
                )
                return f"subtitles='{ass_escaped}':fontsdir='{fonts_dir_escaped}'"
        except Exception as e:
            print(f"[Subtitle] ⚠️ ASS gagal: {e} — fallback SRT", file=sys.stderr)

    # Fallback ke SRT kalau caption_style tidak tersedia
    srt_escaped = str(srt_path).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")  # V9.178.94
    style = (
        "FontName=Rubik,"
        f"FontSize={font_size},"
        "Bold=1,"
        "PrimaryColour=&H00FFFFFF,"
        "OutlineColour=&H00000000,"
        "BackColour=&H80000000,"
        "BorderStyle=3,Outline=1,Shadow=0,"
        "Alignment=2,MarginV=120"
    )
    if FONTS_DIR.exists():
        fonts_dir_escaped = str(FONTS_DIR).replace("\\", "/").replace(":", "\\:")  # V9.178.94: RESTORE
        return f"subtitles='{srt_escaped}':fontsdir='{fonts_dir_escaped}':force_style='{style}'"
    return f"subtitles='{srt_escaped}':force_style='{style}'"


def get_subtitle_font_size(preset="1080p", vertical=False):
    if vertical:
        return 52
    sizes = {
        "1080p": 52,
        "720p": 40,
        "480p": 30,
    }
    return sizes.get(preset, 52)


USE_LLM = False
client = None
available_models = []


# ============================================================
# HELPERS
# ============================================================
def get_duration(filepath):
    try:
        result = subprocess.run(
            [
                FFPROBE_PATH,
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                filepath,
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        return float(result.stdout.strip())
    except Exception:
        return 0


def get_video_dimensions(filepath):
    try:
        result = subprocess.run(
            [
                FFPROBE_PATH,
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=width,height",
                "-of",
                "csv=p=0",
                filepath,
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        parts = result.stdout.strip().split(",")
        return int(parts[0]), int(parts[1])
    except Exception:
        return 1920, 1080


def get_video_fps(filepath):
    """V8.9.22: Get video fps untuk skip CFR kalau sudah 30fps."""
    try:
        result = subprocess.run(
            [
                FFPROBE_PATH,
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=r_frame_rate",
                "-of",
                "csv=p=0",
                filepath,
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        # Format: "30/1" atau "30000/1001" (NTSC)
        fps_str = result.stdout.strip()
        if "/" in fps_str:
            num, den = fps_str.split("/")
            return float(num) / float(den) if float(den) != 0 else 30.0
        return float(fps_str)
    except Exception:
        return 0.0


def has_audio(filepath):
    try:
        result = subprocess.run(
            [
                FFPROBE_PATH,
                "-v",
                "error",
                "-select_streams",
                "a",
                "-show_entries",
                "stream=codec_type",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                filepath,
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        return result.stdout.strip() == "audio"
    except Exception:
        return False


# ============================================================
# V9.175.0: RETENTION_ANALYSIS - analisis retention score per detik
# ============================================================
def analyze_retention(words, video_duration, silence_data=None, scene_data=None):
    """
    Analisis retention score per detik berdasarkan:
    - Speech rate (WPM)
    - Gap antar kata (jeda panjang)
    - Filler words (eh, em, hmm)
    - Scene changes
    - Silence segments
    
    Returns:
        dict: {
            "overall_score": float (0-10),
            "virality": str (low/medium/high/viral),
            "timeline": list of {start, end, score, type, reason},
            "drops": list of {start, end, reason, predicted_drop},
            "suggestions": list of {type, start, end, impact}
        }
    """
    if not words or video_duration <= 0:
        return {
            "overall_score": 0,
            "virality": "unknown",
            "timeline": [],
            "drops": [],
            "suggestions": []
        }
    
    # ========================================
    # 1. BUILD TIMELINE (per detik)
    # ========================================
    timeline = []
    filler_words = {"eh", "em", "emm", "emmm", "ehmm", "hmm", "hmmm", "mmm", "um", "umm", "uhh", "ahh", "eee", "err"}
    
    # Hitung WPM (words per minute)
    total_words = len(words)
    wpm = (total_words / video_duration) * 60 if video_duration > 0 else 0
    print(f"[Retention] Total words: {total_words}, Duration: {video_duration}s, WPM: {wpm:.1f}", file=sys.stderr)
    
    # Skor WPM ideal (120-160 WPM)
    if 120 <= wpm <= 160:
        wpm_score = 2.0
    elif 100 <= wpm < 120 or 160 < wpm <= 180:
        wpm_score = 1.5
    elif 80 <= wpm < 100 or 180 < wpm <= 200:
        wpm_score = 1.0
    else:
        wpm_score = 0.5
    
    # ========================================
    # 2. ANALISIS PER SEGMEN (per 2 detik)
    # ========================================
    segment_duration = 2.0
    num_segments = int(video_duration / segment_duration) + 1
    
    for seg_idx in range(num_segments):
        seg_start = seg_idx * segment_duration
        seg_end = min(seg_start + segment_duration, video_duration)
        
        # Words dalam segmen ini
        seg_words = [w for w in words if seg_start <= w.get("start", 0) < seg_end]
        
        # Score components (0-10 total)
        score = 0.0
        reasons = []
        
        # A. Speech presence (0-2)
        if len(seg_words) >= 4:  # Minimal 4 kata per 2 detik
            score += 2.0
        elif len(seg_words) >= 2:
            score += 1.0
            reasons.append("Speech lambat")
        else:
            reasons.append("Senyap / jeda panjang")
        
        # B. Filler words (0-2, subtract)
        filler_count = sum(1 for w in seg_words if w.get("word", "").lower() in filler_words)
        if filler_count == 0:
            score += 2.0
        elif filler_count == 1:
            score += 1.0
        else:
            score += 0
            reasons.append(f"{filler_count} filler words")
        
        # C. Gap antar kata (0-2)
        if len(seg_words) >= 2:
            gaps = []
            for i in range(1, len(seg_words)):
                gap = seg_words[i].get("start", 0) - seg_words[i-1].get("end", 0)
                gaps.append(gap)
            avg_gap = sum(gaps) / len(gaps) if gaps else 0
            if avg_gap < 0.3:
                score += 2.0
            elif avg_gap < 0.6:
                score += 1.5
            elif avg_gap < 1.0:
                score += 1.0
                reasons.append("Jeda sedang")
            else:
                score += 0.5
                reasons.append("Jeda panjang")
        else:
            score += 0.5
        
        # D. Scene change (0-1)
        if scene_data:
            scene_in_seg = any(seg_start <= s < seg_end for s in scene_data)
            score += 1.0 if scene_in_seg else 0.5
        else:
            score += 0.5
        
        # E. Silence detection (0-1, subtract)
        if silence_data:
            silence_in_seg = any(seg_start <= s.get("start", 0) < seg_end for s in silence_data)
            score += 0 if silence_in_seg else 1.0
            if silence_in_seg:
                reasons.append("Silence detected")
        else:
            score += 1.0
        
        # Normalize ke 0-10
        normalized = min(10.0, (score / 8.0) * 10.0)
        
        # Tentukan tipe
        if normalized >= 8.0:
            seg_type = "peak"
        elif normalized >= 6.0:
            seg_type = "good"
        elif normalized >= 4.0:
            seg_type = "medium"
        else:
            seg_type = "drop"
        
        timeline.append({
            "start": round(seg_start, 2),
            "end": round(seg_end, 2),
            "score": round(normalized, 1),
            "type": seg_type,
            "reasons": reasons
        })
    
    # ========================================
    # 3. OVERALL SCORE
    # ========================================
    avg_score = sum(t["score"] for t in timeline) / len(timeline) if timeline else 0
    overall = round(avg_score, 1)
    
    # ========================================
    # 4. VIRALITY
    # ========================================
    if overall >= 8.5:
        virality = "viral"
    elif overall >= 7.0:
        virality = "high"
    elif overall >= 5.5:
        virality = "medium"
    else:
        virality = "low"
    
    # ========================================
    # 5. DROP POINTS
    # ========================================
    drops = []
    for t in timeline:
        if t["score"] < 4.0:
            drops.append({
                "start": t["start"],
                "end": t["end"],
                "reason": ", ".join(t["reasons"]) if t["reasons"] else "Low score",
                "predicted_drop": int(15 + (4.0 - t["score"]) * 5)  # 15-35%
            })
    
    # ========================================
    # 6. SUGGESTIONS
    # ========================================
    suggestions = []
    for t in timeline:
        if t["score"] < 4.0:
            # Cut atau speed up
            if "Senyap" in " ".join(t["reasons"]):
                suggestions.append({
                    "type": "cut",
                    "start": t["start"],
                    "end": t["end"],
                    "impact": "+1.5 score",
                    "reason": "Buang jeda panjang"
                })
            else:
                suggestions.append({
                    "type": "speedup",
                    "start": t["start"],
                    "end": t["end"],
                    "factor": 1.5,
                    "impact": "+0.8 score",
                    "reason": "Percepat bagian lambat"
                })
        elif t["score"] < 6.0:
            suggestions.append({
                "type": "zoom",
                "start": t["start"],
                "end": t["end"],
                "impact": "+0.5 score",
                "reason": "Tambah zoom untuk dramatis"
            })
    
    print(f"[Retention] Overall: {overall}/10 ({virality})", file=sys.stderr)
    print(f"[Retention] Drops: {len(drops)} points, Suggestions: {len(suggestions)}", file=sys.stderr)
    
    return {
        "overall_score": overall,
        "virality": virality,
        "wpm": round(wpm, 1),
        "timeline": timeline,
        "drops": drops,
        "suggestions": suggestions[:10]  # Top 10
    }


def extract_audio(video_path, audio_path):
    """
    V9.5.1: Audio extraction robust — hindari filter yang sering crash di FFmpeg essentials.

    Filter yang DIPAKAI (aman di essentials_build):
      - highpass, lowpass     : aman
      - afftdn                : aman
      - compand               : aman
      - loudnorm              : aman

    Filter yang DIHINDARI:
      - anlmdn  → sering ACCESS_VIOLATION di Windows essentials
      - arnndn  → butuh model RNN, tidak include di essentials
    """
    # Filter chain (versi aman — tanpa anlmdn & arnndn)
    audio_filters = (
        "highpass=f=150,"
        "lowpass=f=8500,"
        "afftdn=nr=22:nf=-32:tn=1,"
        "compand=attacks=0.05:decays=0.3:points=-80/-80|-30/-10|0/-3,"
        "loudnorm=I=-16:LRA=7:TP=-1.5"
    )

    # Percobaan 1: filter lengkap
    try:
        result = subprocess.run(
            [
                FFMPEG_PATH,
                "-i",
                video_path,
                "-vn",
                "-af",
                audio_filters,
                "-acodec",
                "pcm_s16le",
                "-ar",
                "16000",
                "-ac",
                "1",
                str(audio_path),
            ],
            capture_output=True,
            timeout=300,
        )
        if (
            result.returncode == 0
            and os.path.exists(audio_path)
            and os.path.getsize(audio_path) > 10000
        ):
            print(
                "[Extract] ✅ Audio OK (highpass + afftdn + compand + loudnorm)",
                file=sys.stderr,
            )
            return True

        # Tampilkan error FFmpeg (kalau ada)
        if result.returncode != 0:
            err = result.stderr.decode("utf-8", errors="ignore")[-500:]
            print(
                f"[Extract] Filter gagal (rc={result.returncode}): {err}",
                file=sys.stderr,
            )
    except Exception as e:
        print(f"[Extract] Exception: {e}", file=sys.stderr)

    # Percobaan 2: filter simpel — hanya highpass + loudnorm
    try:
        simple_filters = (
            "highpass=f=120," "afftdn=nr=12:nf=-25," "loudnorm=I=-18:LRA=11:TP=-1.5"
        )
        result = subprocess.run(
            [
                FFMPEG_PATH,
                "-i",
                video_path,
                "-vn",
                "-af",
                simple_filters,
                "-acodec",
                "pcm_s16le",
                "-ar",
                "16000",
                "-ac",
                "1",
                str(audio_path),
            ],
            capture_output=True,
            timeout=300,
        )
        if (
            result.returncode == 0
            and os.path.exists(audio_path)
            and os.path.getsize(audio_path) > 10000
        ):
            print("[Extract] ✅ Audio OK (simple filter)", file=sys.stderr)
            return True
    except Exception as e:
        print(f"[Extract] Simple filter exception: {e}", file=sys.stderr)

    # Percobaan 3: TANPA filter — extract mentah
    try:
        result = subprocess.run(
            [
                FFMPEG_PATH,
                "-i",
                video_path,
                "-vn",
                "-acodec",
                "pcm_s16le",
                "-ar",
                "16000",
                "-ac",
                "1",
                str(audio_path),
            ],
            capture_output=True,
            timeout=300,
        )
        if (
            result.returncode == 0
            and os.path.exists(audio_path)
            and os.path.getsize(audio_path) > 10000
        ):
            print(
                "[Extract] ✅ Audio OK (NO FILTER — fallback darurat)", file=sys.stderr
            )
            return True
    except Exception as e:
        print(f"[Extract] Raw extract exception: {e}", file=sys.stderr)

    # Semua gagal
    print("[Extract] ❌ SEMUA percobaan gagal", file=sys.stderr)
    return False


def run_ffmpeg(args, timeout=600, show_error=True, killable=False, job_id=None):
    """
    Run FFmpeg.
    V8.9.20: killable=True → Popen + track per job_id.
    """
    cmd = [FFMPEG_PATH] + args
    print(f"[FFmpeg] {' '.join(cmd[:12])}...", file=sys.stderr)

    if killable:
        track_id = job_id or "__default__"
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            _set_render_proc(track_id, proc)

            try:
                stdout, stderr = proc.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()
                print(f"[FFmpeg TIMEOUT] setelah {timeout}s", file=sys.stderr)
                return False
            finally:
                _set_render_proc(track_id, None)

            if proc.returncode != 0:
                if show_error and stderr:
                    err = stderr.decode("utf-8", errors="ignore")
                    skip_prefixes = (
                        "ffmpeg version",
                        "built with",
                        "configuration:",
                        "libav",
                        "Input #",
                        "Metadata:",
                        "major_brand",
                        "minor_version",
                        "compatible_brands",
                        "creation_time",
                        "com.android",
                        "Duration:",
                        "Stream #",
                        "Output #",
                    )
                    err_lines = [
                        l
                        for l in err.split("\n")
                        if l.strip() and not l.strip().startswith(skip_prefixes)
                    ]
                    if err_lines:
                        print(
                            f"[FFmpeg ERROR] {chr(10).join(err_lines[:20])}",
                            file=sys.stderr,
                        )
                    else:
                        raw = [l for l in err.split("\n") if l.strip()][-20:]
                        print(f"[FFmpeg RAW] {chr(10).join(raw)}", file=sys.stderr)
                return False

            return True

        except Exception as e:
            _set_render_proc(track_id, None)
            print(f"[FFmpeg EXCEPTION] {e}", file=sys.stderr)
            return False

    try:
        result = subprocess.run(cmd, capture_output=True, timeout=timeout)
        if result.returncode != 0:
            if show_error:
                err = result.stderr.decode("utf-8", errors="ignore")
                err_lines = []
                skip_prefixes = (
                    "ffmpeg version",
                    "built with",
                    "configuration:",
                    "libav",
                    "Input #",
                    "Metadata:",
                    "major_brand",
                    "minor_version",
                    "compatible_brands",
                    "creation_time",
                    "com.android",
                    "Duration:",
                    "Stream #",
                    "Output #",
                )
                for l in err.split("\n"):
                    ls = l.strip()
                    if not ls:
                        continue
                    if ls.startswith(skip_prefixes):
                        continue
                    err_lines.append(l)
                if err_lines:
                    print(
                        f"[FFmpeg ERROR] {chr(10).join(err_lines[:20])}",
                        file=sys.stderr,
                    )
                else:
                    raw_lines = [l for l in err.split("\n") if l.strip()][-20:]
                    print(f"[FFmpeg RAW] {chr(10).join(raw_lines)}", file=sys.stderr)
            return False
        return True
    except subprocess.TimeoutExpired:
        print(f"[FFmpeg TIMEOUT] setelah {timeout}s", file=sys.stderr)
        return False
    except Exception as e:
        print(f"[FFmpeg EXCEPTION] {e}", file=sys.stderr)
        return False


def cancel_active_render(job_id=None):
    """
    V8.9.20: Kill FFmpeg process per-job (atau semua kalau job_id=None).
    """
    with _RENDERS_LOCK:
        if job_id:
            targets = [job_id] if job_id in _ACTIVE_RENDERS else []
        else:
            targets = list(_ACTIVE_RENDERS.keys())

        for rid in targets:
            _ACTIVE_RENDERS[rid]["cancel"] = True

    if not targets:
        print(f"[Cancel] Tidak ada render aktif", file=sys.stderr)
        return False

    killed = 0
    for rid in targets:
        with _RENDERS_LOCK:
            proc = _ACTIVE_RENDERS.get(rid, {}).get("proc")

        if not proc:
            print(
                f"[Cancel] Render {rid}: belum ada FFmpeg aktif (flag set)",
                file=sys.stderr,
            )
            continue

        if proc.poll() is not None:
            print(f"[Cancel] Render {rid}: FFmpeg sudah selesai", file=sys.stderr)
            continue

        try:
            print(
                f"[Cancel] 🔪 Killing FFmpeg PID {proc.pid} (render={rid})...",
                file=sys.stderr,
            )
            proc.terminate()
            try:
                proc.wait(timeout=2)
                print(f"[Cancel] ✅ {rid} stopped (SIGTERM)", file=sys.stderr)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
                print(f"[Cancel] ⚠️  {rid} force-killed (SIGKILL)", file=sys.stderr)
            killed += 1
        except Exception as e:
            print(f"[Cancel] ❌ {rid} error: {e}", file=sys.stderr)

    return killed > 0


def format_time(seconds):
    if seconds < 0:
        seconds = 0
    hrs = int(seconds // 3600)
    mins = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    ms = int((seconds % 1) * 1000)
    return f"{hrs:02d}:{mins:02d}:{secs:02d},{ms:03d}"


def get_watermark_filter():
    if FONT_PATH:
        escaped = FONT_PATH.replace("\\", "/").replace(":", "\\:")
        return (
            f"drawtext=text='Clipora':fontcolor=white@0.6:fontsize=28:"
            f"x=w-tw-20:y=h-th-20:shadowcolor=black@0.5:shadowx=2:shadowy=2:"
            f"fontfile='{escaped}'"
        )
    return "drawtext=text='Clipora':fontcolor=white@0.6:fontsize=28:x=w-tw-20:y=h-th-20"


def get_quality_settings(preset):
    settings = {
        "1080p": {
            "crf": 22,
            "preset_speed": "veryfast",
            "audio_bitrate": "192k",
            "resolution": "1920x1080",
        },
        "720p": {
            "crf": 23,
            "preset_speed": "veryfast",
            "audio_bitrate": "128k",
            "resolution": "1280x720",
        },
        "480p": {
            "crf": 26,
            "preset_speed": "veryfast",
            "audio_bitrate": "96k",
            "resolution": "854x480",
        },
    }
    return settings.get(preset, settings["720p"])


def _merge_overlapping(segments, min_duration=0.3):
    if not segments:
        return []
    segments.sort(key=lambda x: x["start"])
    merged = []
    for seg in segments:
        if not merged:
            merged.append(seg)
        elif seg["start"] <= merged[-1]["end"] + 0.1:
            merged[-1]["end"] = max(merged[-1]["end"], seg["end"])
        else:
            merged.append(seg)
    return [s for s in merged if s["end"] - s["start"] > min_duration]


# ============================================================
# CFR NORMALIZE — V8.9.20
# ============================================================
def normalize_to_cfr(input_path, output_path, fps=30, job_id=None):
    if job_id and _is_render_cancelled(job_id):
        print(f"[CFR] ⏸️ Cancel requested — skip normalize", file=sys.stderr)
        return False

    # V8.9.22: Cek fps dulu. Kalau sudah ~30fps, skip normalize.
    current_fps = get_video_fps(input_path)
    if current_fps > 0:
        fps_diff = abs(current_fps - fps)
        fps_tolerance = 1.0  # toleransi 1 fps (29-31 dianggap sama)
        if fps_diff <= fps_tolerance:
            print(
                f"[CFR] ⚡ Video sudah {current_fps:.1f}fps (target {fps}fps) — SKIP normalize",
                file=sys.stderr,
            )
            # Copy file ke output (biar behavior konsisten)
            try:
                shutil.copy2(input_path, output_path)
                return True
            except Exception as e:
                print(f"[CFR] ⚠️ Gagal copy, fallback normalize: {e}", file=sys.stderr)
                # Lanjut ke normalize biasa
        else:
            print(
                f"[CFR] Video {current_fps:.1f}fps ≠ {fps}fps — perlu normalize",
                file=sys.stderr,
            )

    print(f"[CFR] Normalize ke {fps}fps...", file=sys.stderr)

    # Percobaan 1: pakai -fps_mode
    ok = run_ffmpeg(
        [
            "-i",
            input_path,
            "-vf",
            f"fps={fps}",
            "-fps_mode",
            "cfr",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "18",
            "-c:a",
            "aac",
            "-b:a",
            "192k",
            "-movflags",
            "+faststart",
            output_path,
            "-y",
        ],
        timeout=1800,
        show_error=False,
        killable=True,
        job_id=job_id,
    )
    if ok and os.path.exists(output_path) and os.path.getsize(output_path) > 1000:
        print(f"[CFR] ✅ Normalize berhasil", file=sys.stderr)
        return True

    # Percobaan 2: pakai -vsync
    if job_id and _is_render_cancelled(job_id):
        print(f"[CFR] ⏸️ Cancel requested — skip fallback 2", file=sys.stderr)
        return False
    try:
        if os.path.exists(output_path):
            os.unlink(output_path)
    except Exception:
        pass
    ok = run_ffmpeg(
        [
            "-i",
            input_path,
            "-vf",
            f"fps={fps}",
            "-fps_mode",
            "cfr",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "18",
            "-c:a",
            "aac",
            "-b:a",
            "192k",
            "-movflags",
            "+faststart",
            output_path,
            "-y",
        ],
        timeout=1800,
        show_error=False,
        killable=True,
        job_id=job_id,
    )
    if ok and os.path.exists(output_path) and os.path.getsize(output_path) > 1000:
        print(f"[CFR] ✅ Normalize berhasil", file=sys.stderr)
        return True

    # Percobaan 3: tanpa -fps_mode / -vsync
    if job_id and _is_render_cancelled(job_id):
        print(f"[CFR] ⏸️ Cancel requested — skip fallback 3", file=sys.stderr)
        return False
    try:
        if os.path.exists(output_path):
            os.unlink(output_path)
    except Exception:
        pass
    ok = run_ffmpeg(
        [
            "-i",
            input_path,
            "-vf",
            f"fps={fps}",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "18",
            "-c:a",
            "aac",
            "-b:a",
            "192k",
            "-movflags",
            "+faststart",
            output_path,
            "-y",
        ],
        timeout=1800,
        killable=True,
        job_id=job_id,
    )
    if ok and os.path.exists(output_path) and os.path.getsize(output_path) > 1000:
        print(f"[CFR] ✅ Normalize berhasil", file=sys.stderr)
        return True

    print(f"[CFR] ❌ Normalize gagal total", file=sys.stderr)
    return False


def cleanup_old_files(results_dir, max_age_days=7):
    """V8.9.20: Hapus file hasil render yang lebih tua dari max_age_days."""
    if not os.path.isdir(results_dir):
        return 0
    now = time.time()
    cutoff = now - (max_age_days * 24 * 3600)
    cleaned = 0
    try:
        for fname in os.listdir(results_dir):
            if not fname.lower().endswith(
                (".mp4", ".mov", ".webm", ".gif", ".mp3", ".srt", ".jpg", ".png")
            ):
                continue
            fpath = os.path.join(results_dir, fname)
            try:
                if os.path.getmtime(fpath) < cutoff:
                    os.unlink(fpath)
                    cleaned += 1
            except Exception:
                pass
    except Exception as e:
        print(f"[Cleanup] Error: {e}", file=sys.stderr)
    if cleaned:
        print(
            f"[Cleanup] 🗑️  {cleaned} file lama dihapus dari {results_dir}",
            file=sys.stderr,
        )
    return cleaned


# ============================================================
# SENTENCE / TOPIC
# ============================================================
def detect_sentence_boundaries(segments):
    if not segments:
        return []
    boundaries = []
    sentence_enders = ".!?"
    for i, seg in enumerate(segments):
        text = seg.get("text", "").strip()
        if not text:
            continue
        is_ending = text and text[-1] in sentence_enders
        gap_after = 0
        if i < len(segments) - 1:
            gap_after = segments[i + 1]["start"] - seg["end"]
        if (is_ending and gap_after > 0.3) or gap_after > 0.7:
            boundaries.append(
                {
                    "time": seg["end"],
                    "text": text[-50:],
                    "gap_after": round(gap_after, 2),
                }
            )
    print(f"[Sentence] {len(boundaries)} boundaries", file=sys.stderr)
    return boundaries


def snap_to_nearest_boundary(time, boundaries, max_distance=0.3):
    if not boundaries:
        return time
    closest = min(boundaries, key=lambda b: abs(b["time"] - time))
    if abs(closest["time"] - time) < max_distance:
        return closest["time"]
    return time


def check_topic_continuity(segments, min_window=3):
    if (
        not HAS_SENTENCE_TRANSFORMERS
        or not ENABLE_SEMANTIC
        or len(segments) < min_window * 2
    ):
        return []
    return []


# ============================================================
# PROTECTION
# ============================================================
def build_protected_zones(words, emotion_data, keywords_data, protect_seconds=0.8):
    return []


MOTIVATIONAL_KEYWORDS = [
    "dari nol",
    "dari bawah",
    "mulai dari",
    "sedikit demi sedikit",
    "orang sukses",
    "kesuksesan",
    "perjuangan",
    "pengorbanan",
    "jangan menyerah",
    "terus mencoba",
    "berhasil",
    "gagal",
    "bermimpi",
    "mimpi",
    "cita-cita",
    "usaha",
    "kerja keras",
    "pantang menyerah",
    "bangkit",
    "berdiri",
    "memulai",
]


def protect_important_zones(words, keywords_data, transcript_segments, padding=0.8):
    if not words:
        return []
    protected = []

    window_size = 2.0
    i = 0
    while i < len(words):
        window_end = words[i]["start"] + window_size
        count = 0
        j = i
        while j < len(words) and words[j]["start"] < window_end:
            count += 1
            j += 1
        if count >= 10:
            protected.append(
                {
                    "start": max(0, words[i]["start"] - 0.1),
                    "end": min(
                        words[j - 1]["end"] + 0.1, words[i]["start"] + window_size + 0.1
                    ),
                    "reason": "dense_speech",
                }
            )
            i = j
        else:
            i += 1

    number_pattern = re.compile(r"\d+")
    for seg in transcript_segments:
        text = seg.get("text", "")
        if number_pattern.search(text):
            protected.append(
                {
                    "start": max(0, seg["start"] - 0.3),
                    "end": seg["end"] + 0.3,
                    "reason": "has_number",
                }
            )

    if keywords_data:
        top_kw = [k["keyword"].lower() for k in keywords_data[:5]]
        for w in words:
            wc = w["word"].lower().strip(".,!?;:\"'")
            if any(kw in wc for kw in top_kw if len(kw) > 3):
                protected.append(
                    {
                        "start": max(0, w["start"] - 0.3),
                        "end": w["end"] + 0.3,
                        "reason": "keyword_zone",
                    }
                )

    full_text_lower = " ".join([w["word"].lower() for w in words])
    for kw in MOTIVATIONAL_KEYWORDS:
        if kw in full_text_lower:
            kw_words = kw.split()
            first_word = kw_words[0]
            for idx, w in enumerate(words):
                if first_word in w["word"].lower():
                    window_words = [
                        words[j]["word"].lower()
                        for j in range(idx, min(idx + len(kw_words) + 2, len(words)))
                    ]
                    window_text = " ".join(window_words)
                    if kw in window_text:
                        start_t = max(0, w["start"] - padding)
                        end_idx = min(idx + len(kw_words), len(words) - 1)
                        end_t = words[end_idx]["end"] + padding
                        protected.append(
                            {
                                "start": start_t,
                                "end": end_t,
                                "reason": f"motiv_{kw.replace(' ', '_')}",
                            }
                        )
                        break

    if not protected:
        return []

    protected.sort(key=lambda x: x["start"])
    merged = []
    for p in protected:
        if not merged:
            merged.append(p)
        elif p["start"] <= merged[-1]["end"] + 0.3:
            merged[-1]["end"] = max(merged[-1]["end"], p["end"])
            merged[-1]["reason"] += f"+{p['reason']}"
        else:
            merged.append(p)

    total = sum(p["end"] - p["start"] for p in merged)
    motiv_count = sum(1 for p in merged if "motiv_" in p.get("reason", ""))
    print(
        f"[ImportantZones] {len(merged)} zona ({total:.1f}s) — {motiv_count} motivasional",
        file=sys.stderr,
    )
    return merged


# ============================================================
# STYLE MEMORY ZONES
# ============================================================
def build_style_memory_zones(remove_segments):
    if not STYLE_MEMORY or not STYLE_MEMORY.get("categories"):
        return {"protect_zones": [], "prioritize_categories": []}

    protect_zones = []
    prioritize_categories = []
    cats = STYLE_MEMORY["categories"]
    min_samples = 5

    for cat_name, cat_data in cats.items():
        total = cat_data.get("total_shown", 0)
        keep_rate = cat_data.get("keep_rate", 1.0)
        if total < min_samples:
            continue
        if keep_rate < 0.4:
            matched = 0
            for seg in remove_segments:
                if seg.get("source") == cat_name:
                    protect_zones.append(
                        {
                            "start": max(0, seg["start"] - 0.3),
                            "end": seg["end"] + 0.3,
                            "reason": f"style_{cat_name}",
                        }
                    )
                    matched += 1
            if matched:
                print(
                    f"[StyleMemory] '{cat_name}' keep_rate={keep_rate:.2f} → PROTECT {matched} segmen",
                    file=sys.stderr,
                )
        elif keep_rate > 0.9:
            prioritize_categories.append(cat_name)
            print(
                f"[StyleMemory] '{cat_name}' keep_rate={keep_rate:.2f} → PRIORITIZE untuk cut",
                file=sys.stderr,
            )

    return {
        "protect_zones": protect_zones,
        "prioritize_categories": prioritize_categories,
    }


def apply_smart_protection(remove_segments, protected_zones):
    if not protected_zones:
        return remove_segments
    filtered = []
    removed_count = 0
    for seg in remove_segments:
        overlaps = False
        for zone in protected_zones:
            if not (seg["end"] <= zone["start"] or seg["start"] >= zone["end"]):
                overlaps = True
                break
        if not overlaps:
            filtered.append(seg)
        else:
            removed_count += 1
    print(f"[Protect] Smart: {removed_count} dibatalkan", file=sys.stderr)
    return filtered


# ============================================================
# VAD / SILENCE
# ============================================================
def detect_speech_vad(audio_path, min_silence_ms=300, threshold=0.45):
    if not HAS_SILERO_VAD or not ENABLE_VAD:
        return None
    model = get_vad_model()
    if model is None:
        return None
    try:
        from scipy.io import wavfile

        sr, wav_np = wavfile.read(audio_path)
        if wav_np.dtype == np.int16:
            wav_np = wav_np.astype(np.float32) / 32768.0
        elif wav_np.dtype == np.int32:
            wav_np = wav_np.astype(np.float32) / 2147483648.0
        else:
            wav_np = wav_np.astype(np.float32)
        if len(wav_np.shape) > 1:
            wav_np = wav_np.mean(axis=1)

        if sr != 16000:
            try:
                from scipy.signal import resample

                num_samples = int(len(wav_np) * 16000 / sr)
                wav_np = resample(wav_np, num_samples).astype(np.float32)
                sr = 16000
            except Exception as e:
                print(f"[VAD] Resample gagal: {e}", file=sys.stderr)

        wav_tensor = torch.from_numpy(wav_np).float()
        speech_ts = get_speech_timestamps(
            wav_tensor,
            model,
            sampling_rate=sr,
            min_silence_duration_ms=min_silence_ms,
            threshold=threshold,
            return_seconds=True,
        )
        segments = [
            {"start": float(t["start"]), "end": float(t["end"])} for t in speech_ts
        ]
        print(f"[VAD] {len(segments)} speech segments", file=sys.stderr)
        return segments
    except Exception as e:
        print(f"[VAD Error] {e}", file=sys.stderr)
        return None


def speech_to_silence(speech_segments, total_duration, min_silence=0.2):
    if not speech_segments:
        return []
    silence = []
    if speech_segments[0]["start"] > 0.2:
        silence.append({"start": 0, "end": speech_segments[0]["start"]})
    for i in range(len(speech_segments) - 1):
        gap_start = speech_segments[i]["end"]
        gap_end = speech_segments[i + 1]["start"]
        if gap_end - gap_start > min_silence:
            silence.append({"start": gap_start, "end": gap_end})
    last_end = speech_segments[-1]["end"]
    if total_duration - last_end > 0.2:
        silence.append({"start": last_end, "end": total_duration})
    return silence


def detect_silence_ffmpeg(audio_path, noise_db=-40, min_duration=0.4):
    cmd = [
        FFMPEG_PATH,
        "-i",
        str(audio_path),
        "-af",
        f"silencedetect=noise={noise_db}dB:d={min_duration}",
        "-f",
        "null",
        "-",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        pattern = re.compile(r"silence_end: ([\d.]+) \| silence_duration: ([\d.]+)")
        segments = []
        for match in pattern.finditer(result.stderr):
            end = float(match.group(1))
            dur = float(match.group(2))
            segments.append({"start": end - dur, "end": end})
        print(f"[Silence/FFmpeg] {len(segments)} segments", file=sys.stderr)
        return segments
    except Exception as e:
        print(f"[Silence Error] {e}", file=sys.stderr)
        return []


# ============================================================
# STUBS
# ============================================================
def detect_speakers(audio_path):
    return None


def extract_keywords(transcript_text, top_n=10):
    return []


def find_best_hooks(transcript_segments, top_n=3):
    return []


def detect_emotion(transcript_segments):
    return []


def protect_emotional_segments(emotion_data, threshold=None):
    return []


# ============================================================
# HALLUCINATION DETECTION
# ============================================================
def _detect_hallucination_loop(words, min_repeat=15):
    if len(words) < min_repeat:
        return (False, -1, -1)
    i = 0
    n = len(words)
    while i < n:
        current = words[i]["word"].lower().strip(".,!?;:\"'")
        if not current:
            i += 1
            continue
        j = i + 1
        while j < n:
            next_word = words[j]["word"].lower().strip(".,!?;:\"'")
            if next_word != current:
                break
            j += 1
        repeat_count = j - i
        if repeat_count >= min_repeat:
            gaps = []
            for k in range(i, j - 1):
                gap = words[k + 1]["start"] - words[k]["end"]
                gaps.append(gap)
            avg_gap = sum(gaps) / len(gaps) if gaps else 0
            if avg_gap < 0.15:
                return (True, i, j)
        i = j if j > i else i + 1
    return (False, -1, -1)


def _detect_hallucination_phrase_loop(words, min_repeat=5, max_phrase_len=4):
    if len(words) < min_repeat * 2:
        return (False, -1, -1, "")
    n = len(words)
    for phrase_len in range(2, max_phrase_len + 1):
        i = 0
        while i + phrase_len * min_repeat <= n:
            phrase = [
                words[i + k]["word"].lower().strip(".,!?;:\"'")
                for k in range(phrase_len)
            ]
            phrase = [w for w in phrase if w]
            if len(phrase) < 2:
                i += 1
                continue
            phrase_str = " ".join(phrase)
            count = 1
            next_start = i + phrase_len
            while next_start + phrase_len <= n:
                next_phrase = [
                    words[next_start + k]["word"].lower().strip(".,!?;:\"'")
                    for k in range(phrase_len)
                ]
                next_phrase = [w for w in next_phrase if w]
                if len(next_phrase) != len(phrase):
                    break
                same = sum(1 for a, b in zip(phrase, next_phrase) if a == b)
                sim = same / len(phrase)
                if sim >= 0.85:
                    count += 1
                    next_start += phrase_len
                else:
                    break
            if count >= min_repeat:
                return (True, i, next_start, phrase_str)
            i += 1
    return (False, -1, -1, "")


def _detect_hallucination_frequency(words, min_word_count=8, max_ratio=0.12):
    if len(words) < 20:
        return (False, None)
    counter = Counter()
    for w in words:
        clean = w["word"].lower().strip(".,!?;:\"'()[]{}")
        if clean and len(clean) >= 2:
            counter[clean] += 1
    total = len(words)
    for word, count in counter.most_common(5):
        ratio = count / total
        if count >= min_word_count and ratio > max_ratio:
            return (True, f"'{word}' muncul {count}/{total} ({ratio * 100:.1f}%)")
    return (False, None)


def _clean_hallucination(words, max_hallucination_ratio=None):
    if not words:
        return words
    if max_hallucination_ratio is None:
        max_hallucination_ratio = HALLUCINATION_MAX_RATIO
    cleaned = []
    i = 0
    n = len(words)
    removed_count = 0

    while i < n:
        is_hallu, s_idx, e_idx = _detect_hallucination_loop(
            words[i:], min_repeat=HALLUCINATION_MIN_REPEAT
        )
        if is_hallu:
            word_sample = words[i + s_idx]["word"]
            removed_count += e_idx - s_idx
            print(
                f"[Whisper] 🚫 Hallucination 1-kata: '{word_sample}' x{e_idx - s_idx} — skipping",
                file=sys.stderr,
            )
            i += e_idx
        else:
            cleaned.append(words[i])
            i += 1

    i = 0
    while i < len(cleaned):
        is_hallu, s_idx, e_idx, phrase = _detect_hallucination_phrase_loop(
            cleaned[i:],
            min_repeat=HALLUCINATION_PHRASE_MIN_REPEAT,
            max_phrase_len=HALLUCINATION_PHRASE_MAX_LEN,
        )
        if is_hallu:
            removed_count += e_idx - s_idx
            print(
                f"[Whisper] 🚫 Hallucination FRASA: '{phrase}' x{e_idx - s_idx} kata — skipping",
                file=sys.stderr,
            )
            cleaned = cleaned[:i] + cleaned[i + e_idx :]
        else:
            i += 1

    ratio = removed_count / n if n > 0 else 0
    if ratio > 0:
        print(
            f"[Whisper] Cleaned {removed_count}/{n} kata hallucination ({ratio * 100:.1f}%)",
            file=sys.stderr,
        )
    return cleaned


def _check_and_clean_words(words, label=""):
    """V8.9.20: Jangan buang total — return cleaned dengan warning."""
    if not words:
        return []
    cleaned = _clean_hallucination(
        words, max_hallucination_ratio=HALLUCINATION_MAX_RATIO
    )
    if cleaned and len(cleaned) >= 20:
        is_freq, reason = _detect_hallucination_frequency(
            cleaned,
            min_word_count=HALLUCINATION_FREQ_MIN_COUNT,
            max_ratio=HALLUCINATION_FREQ_MAX_RATIO,
        )
        if is_freq:
            print(
                f"[Whisper] ⚠️  Repetisi tinggi{label}: {reason} — "
                f"pakai dengan hati-hati (tidak dibuang)",
                file=sys.stderr,
            )
    return cleaned


def _rebuild_segments_from_words(words):
    if not words:
        return []
    segments = []
    current_group = [words[0]]
    for w in words[1:]:
        gap = w["start"] - current_group[-1]["end"]
        total_dur = w["end"] - current_group[0]["start"]
        if gap > 0.8 or len(current_group) >= 15 or total_dur > 8.0:
            segments.append(
                {
                    "start": current_group[0]["start"],
                    "end": current_group[-1]["end"],
                    "text": " ".join(x["word"] for x in current_group),
                }
            )
            current_group = [w]
        else:
            current_group.append(w)
    if current_group:
        segments.append(
            {
                "start": current_group[0]["start"],
                "end": current_group[-1]["end"],
                "text": " ".join(x["word"] for x in current_group),
            }
        )
    return segments


# ============================================================
# TRANSCRIBE — V8.9.16: Standard mode
# ============================================================
def transcribe_audio(audio_path, model_size="base"):
    try:
        model = get_whisper_model(model_size)

        print(f"[Whisper] Transkripsi ({model_size}, standard)...", file=sys.stderr)

        # V9.4.0: Context injection yang lebih spesifik
        # - Memberi petunjuk topik
        # - Memberi petunjuk pembicara
        # - Reduce hallucination
        context_prompt = (
            "Transkrip percakapan bahasa Indonesia yang jelas. "
            "Topik: motivasi, pengalaman pribadi, cerita kehidupan, "
            "bisnis, dan pengembangan diri. "
            "Pembicara: pria dewasa dengan aksen Indonesia. "
            "Gunakan ejaan yang benar dan tanda baca yang tepat."
        )

        segments_gen, info = model.transcribe(
            str(audio_path),
            word_timestamps=True,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500),
            beam_size=5,
            initial_prompt=context_prompt,
            condition_on_previous_text=False,
            no_speech_threshold=0.5,  # lebih ketat
            log_prob_threshold=-1.0,  # lebih ketat
            compression_ratio_threshold=2.2,  # lebih ketat
            temperature=0.0,
        )

        detected_lang = info.language
        lang_prob = getattr(info, "language_probability", 0.0)
        print(
            f"[Whisper] Detected lang: {detected_lang} (prob={lang_prob:.2f})",
            file=sys.stderr,
        )

        words = []
        full_segments = []

        for segment in segments_gen:
            full_segments.append(
                {
                    "start": segment.start,
                    "end": segment.end,
                    "text": segment.text,
                }
            )
            if segment.words:
                for word in segment.words:
                    words.append(
                        {
                            "word": word.word.strip(),
                            "start": word.start,
                            "end": word.end,
                        }
                    )

        print(
            f"[Whisper] RAW: {len(words)} words, {len(full_segments)} segments",
            file=sys.stderr,
        )

        original_count = len(words)
        if words:
            words = _check_and_clean_words(words, " (Whisper)")
            if len(words) != original_count:
                print(
                    f"[Whisper] Cleaned: {original_count} → {len(words)} words",
                    file=sys.stderr,
                )
                full_segments = _rebuild_segments_from_words(words)

        if words:
            sample = " ".join(w["word"] for w in words[:20])
            print(f"[Whisper] Sample: {sample}", file=sys.stderr)
        else:
            print(f"[Whisper] ⚠️ TIDAK ADA KATA terdeteksi", file=sys.stderr)

        print(
            f"[Whisper] FINAL: {len(words)} words, {len(full_segments)} segments",
            file=sys.stderr,
        )
        return {"words": words, "segments": full_segments}

    except Exception as e:
        print(f"[Whisper Error] {e}", file=sys.stderr)
        import traceback

        traceback.print_exc(file=sys.stderr)
        return None


# ============================================================
# RULE-BASED DETECTORS
# ============================================================
def detect_duplicate_segments(words, aggressiveness="medium"):
    if len(words) < 10:
        return []
    segments = []
    current = []
    for w in words:
        if not current:
            current.append(w)
        elif w["start"] - current[-1]["end"] > 0.6:
            if len(current) >= 5:
                segments.append(
                    {
                        "start": current[0]["start"],
                        "end": current[-1]["end"],
                        "text": " ".join([x["word"] for x in current]),
                    }
                )
            current = [w]
        else:
            current.append(w)
    if current and len(current) >= 5:
        segments.append(
            {
                "start": current[0]["start"],
                "end": current[-1]["end"],
                "text": " ".join([x["word"] for x in current]),
            }
        )
    if len(segments) < 2:
        return []

    threshold = (
        0.88 if aggressiveness == "low" else 0.75 if aggressiveness == "high" else 0.82
    )
    try:
        vectorizer = TfidfVectorizer().fit_transform([s["text"] for s in segments])
        similarity_matrix = cosine_similarity(vectorizer)
    except Exception:
        return []

    duplicates = []
    for i in range(len(segments)):
        for j in range(i + 1, len(segments)):
            if segments[j]["start"] - segments[i]["end"] < 3.0:
                continue
            if similarity_matrix[i][j] > threshold:
                text_i = segments[i]["text"].lower()
                text_j = segments[j]["text"].lower()
                words_i = set(text_i.split())
                words_j = set(text_j.split())
                if not words_i or not words_j:
                    continue
                jaccard = len(words_i & words_j) / len(words_i | words_j)
                if jaccard < 0.75:
                    continue
                dur_i = segments[i]["end"] - segments[i]["start"]
                dur_j = segments[j]["end"] - segments[j]["start"]
                to_remove = segments[i] if dur_i < dur_j else segments[j]
                duplicates.append(
                    {
                        "start": to_remove["start"],
                        "end": to_remove["end"],
                        "reason": "duplicate",
                    }
                )
    merged = _merge_overlapping(duplicates, min_duration=0.6)
    print(f"[Duplicate] {len(merged)} (threshold={threshold})", file=sys.stderr)
    return merged


def detect_filler_segments(words):
    filler_list = [
        "eh",
        "em",
        "emm",
        "emmm",
        "ehmm",
        "hmm",
        "hmmm",
        "mmm",
        "mmmm",
        "um",
        "umm",
        "uhh",
        "ahh",
        "ohh",
        "eee",
        "eeee",
        "aaa",
        "ann",
        "annn",
        "anu",
        "apalah",
    ]
    filler_segments = []
    i = 0
    while i < len(words):
        w = words[i]
        clean_word = w["word"].lower().strip(".,!?;:\"'")
        if clean_word in filler_list:
            prev_gap = w["start"] - words[i - 1]["end"] if i > 0 else 999
            next_gap = words[i + 1]["start"] - w["end"] if i < len(words) - 1 else 999
            if prev_gap < 0.15 and next_gap < 0.15:
                i += 1
                continue
            start = w["start"]
            end = w["end"]
            j = i + 1
            while j < len(words):
                next_clean = words[j]["word"].lower().strip(".,!?;:\"'")
                if next_clean in filler_list and words[j]["start"] - end < 0.3:
                    end = words[j]["end"]
                    j += 1
                else:
                    break
            if 0.10 < (end - start) < 1.0:
                filler_segments.append({"start": start, "end": end, "reason": "filler"})
            i = j
            continue
        i += 1
    merged = _merge_overlapping(filler_segments, min_duration=0.1)
    print(f"[Filler] {len(merged)}", file=sys.stderr)
    return merged


def detect_stutters(words):
    if len(words) < 2:
        return []
    stutters = []
    i = 0
    n = len(words)
    while i < n - 1:
        w1_raw = words[i]["word"].lower().strip(".,!?;:\"'")
        w2_raw = words[i + 1]["word"].lower().strip(".,!?;:\"'")
        if not w1_raw or not w2_raw:
            i += 1
            continue

        is_prefix = (
            len(w1_raw) >= 2
            and len(w2_raw) >= 2
            and w2_raw.startswith(w1_raw)
            and w1_raw != w2_raw
        )
        is_fuzzy = False
        if not is_prefix and len(w1_raw) >= 2 and len(w2_raw) >= 2:
            if HAS_RAPIDFUZZ:
                sim = rf_fuzz.ratio(w1_raw, w2_raw[: len(w1_raw) + 1]) / 100.0
                if sim > 0.85 and len(w2_raw) > len(w1_raw):
                    is_fuzzy = True
        if not (is_prefix or is_fuzzy):
            i += 1
            continue

        gap = words[i + 1]["start"] - words[i]["end"]
        if gap > 0.3:
            i += 1
            continue
        if len(w2_raw) > len(w1_raw) * 4:
            i += 1
            continue

        stutters.append(
            {
                "start": words[i]["start"],
                "end": words[i]["end"],
                "reason": "stutter",
            }
        )
        i += 2

    merged = _merge_overlapping(stutters, min_duration=0.1)
    print(f"[Stutter] {len(merged)} terdeteksi", file=sys.stderr)
    return merged


def detect_false_starts(words):
    false_starts = []
    i = 0
    n = len(words)

    def clean(w):
        return w["word"].lower().strip(".,!?;:\"'")

    while i < n - 3:
        pause = words[i + 1]["start"] - words[i]["end"]
        if pause < 0.6:
            i += 1
            continue
        for lookback in range(1, 4):
            if i - lookback < 0:
                break
            before_words = [clean(w) for w in words[i - lookback + 1 : i + 1]]
            before_words = [w for w in before_words if w]
            after_start = i + 1
            after_end = min(i + 7, n)
            after_words = [clean(w) for w in words[after_start:after_end]]
            after_words = [w for w in after_words if w]
            matches = sum(1 for w in before_words if w in after_words)
            if matches >= max(1, len(before_words) - 1) and matches >= 1:
                start_time = words[i - lookback + 1]["start"]
                end_time = words[i]["end"]
                dur = end_time - start_time
                if dur < 1.8:
                    false_starts.append(
                        {
                            "start": start_time,
                            "end": end_time,
                            "reason": "false_start",
                        }
                    )
                    break
        i += 1
    merged = _merge_overlapping(false_starts, min_duration=0.3)
    print(f"[FalseStart] {len(merged)}", file=sys.stderr)
    return merged


def detect_repetition_words(words, max_phrase=None, max_gap=None, min_repeats=None):
    if max_phrase is None:
        max_phrase = MAX_PHRASE_LEN
    if max_gap is None:
        max_gap = PHRASE_MAX_GAP
    if min_repeats is None:
        min_repeats = PHRASE_MIN_REPEATS
    if len(words) < 4:
        return []

    def clean(w):
        return w["word"].lower().strip(".,!?;:\"'()[]{}")

    def similarity(s1, s2):
        if HAS_RAPIDFUZZ:
            return rf_fuzz.token_set_ratio(s1, s2) / 100.0
        else:
            from difflib import SequenceMatcher

            return SequenceMatcher(None, s1, s2).ratio()

    removes = []
    i = 0
    n = len(words)
    SIMILARITY_THRESHOLD = 0.72

    while i < n - 2:
        matched = False
        for phrase_len in range(2, max_phrase + 1):
            if i + phrase_len * 2 > n:
                break
            phrase_words = words[i : i + phrase_len]
            phrase = [clean(w) for w in phrase_words]
            phrase = [w for w in phrase if w]
            if len(phrase) < 2:
                continue
            phrase_str = " ".join(phrase)
            next_start = i + phrase_len
            matches = 1
            matched_indices = [i]
            last_sim = 1.0

            while next_start + phrase_len <= n:
                next_words = words[next_start : next_start + phrase_len]
                next_phrase = [clean(w) for w in next_words]
                next_phrase = [w for w in next_phrase if w]
                if len(next_phrase) < 2:
                    break
                gap = words[next_start]["start"] - words[next_start - 1]["end"]
                if gap > max_gap:
                    break
                next_str = " ".join(next_phrase)
                sim = similarity(phrase_str, next_str)
                if sim >= SIMILARITY_THRESHOLD:
                    matches += 1
                    matched_indices.append(next_start)
                    last_sim = sim
                    next_start += phrase_len
                else:
                    break

            if matches >= min_repeats and matches <= PHRASE_REPEAT_MAX_COUNT:
                start_remove = words[matched_indices[1]]["start"]
                end_remove = words[next_start - 1]["end"]
                if end_remove - start_remove >= 0.2:
                    removes.append(
                        {
                            "start": start_remove,
                            "end": end_remove,
                            "reason": "phrase_repeat",
                            "phrase": phrase_str,
                            "count": matches,
                            "similarity": round(last_sim, 2),
                        }
                    )
                i = next_start
                matched = True
                break
            elif matches > PHRASE_REPEAT_MAX_COUNT:
                print(
                    f"[PhraseRepeat] ⚠️ SKIP '{phrase_str}' x{matches} — melebihi cap",
                    file=sys.stderr,
                )
                i = next_start
                matched = True
                break
        if not matched:
            i += 1

    merged = _merge_overlapping(removes, min_duration=0.15)
    before_filter = len(merged)
    merged = [r for r in merged if (r["end"] - r["start"]) < PHRASE_REPEAT_MAX_DURATION]
    if before_filter != len(merged):
        print(
            f"[PhraseRepeat] Filter durasi > {PHRASE_REPEAT_MAX_DURATION}s: "
            f"{before_filter - len(merged)} dibuang",
            file=sys.stderr,
        )
    for r in merged:
        print(
            f"[PhraseRepeat] '{r.get('phrase', '?')}' x{r.get('count', 2)} "
            f"@ {r['start']:.2f}s ({r['end'] - r['start']:.2f}s)",
            file=sys.stderr,
        )
    print(f"[PhraseRepeat] {len(merged)} frasa berulang dihapus", file=sys.stderr)
    return merged


def detect_semantic_duplicates(words, threshold=None):
    return []


def analyze_with_llm(transcript_text, aggressiveness="medium"):
    return []


# ============================================================
# SUBTITLE
# ============================================================
def save_subtitle(words, output_srt_path):
    if not words:
        return
    try:
        groups = []
        current = []
        for w in words:
            if not current:
                current.append(w)
                continue
            gap = w["start"] - current[-1]["end"]
            total_dur = w["end"] - current[0]["start"]
            if gap > 0.5 or len(current) >= 4 or total_dur > 1.8:
                groups.append(current)
                current = [w]
            else:
                current.append(w)
        if current:
            groups.append(current)

        with open(output_srt_path, "w", encoding="utf-8") as f:
            for i, group in enumerate(groups, 1):
                start = group[0]["start"]
                end = group[-1]["end"]
                text = " ".join(w["word"] for w in group)
                f.write(f"{i}\n{format_time(start)} --> {format_time(end)}\n{text}\n\n")

        print(
            f"[Subtitle] Saved: {output_srt_path} ({len(groups)} kalimat)",
            file=sys.stderr,
        )
    except Exception as e:
        print(f"[Subtitle Error] {e}", file=sys.stderr)


def adjust_subtitle_timestamps(words, removed_segments):
    if not words or not removed_segments:
        return words

    removed_intervals = sorted([(s["start"], s["end"]) for s in removed_segments])

    def _is_removed(t):
        for rs, re in removed_intervals:
            if rs <= t < re:
                return True
        return False

    new_words = []
    dropped = 0
    for w in words:
        orig_start = w["start"]
        orig_end = w["end"]

        if _is_removed(orig_start):
            dropped += 1
            continue

        total_removed = 0
        for rs, re in removed_intervals:
            if re <= orig_start:
                total_removed += re - rs
            elif rs < orig_start < re:
                total_removed += orig_start - rs

        new_start = max(0, orig_start - total_removed)
        new_end = max(0, orig_end - total_removed)
        new_words.append({"word": w["word"], "start": new_start, "end": new_end})

    if dropped > 0:
        print(
            f"[Subtitle] Dropped {dropped} words inside cut segments", file=sys.stderr
        )

    return new_words


# ============================================================
# VERTICAL / THUMBNAIL / MUSIC / GIF / MP3 / SCENE
# ============================================================
def detect_face_center(video_path, sample_interval=1.0):
    DEFAULT_CENTER = (0.5, 0.4)

    try:
        import cv2
    except ImportError:
        print(
            "[FaceDetect] cv2 tidak terinstall — pakai center default", file=sys.stderr
        )
        return DEFAULT_CENTER

    if not hasattr(cv2, "CascadeClassifier") or not hasattr(cv2, "data"):
        print(
            "[FaceDetect] cv2 5.x terdeteksi — CascadeClassifier dihapus, "
            "pakai center default (0.5, 0.4)",
            file=sys.stderr,
        )
        return DEFAULT_CENTER

    try:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            print(
                "[FaceDetect] Video tidak bisa dibuka — pakai center default",
                file=sys.stderr,
            )
            return DEFAULT_CENTER

        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = total_frames / fps if fps > 0 else 0

        try:
            cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        except AttributeError:
            print(
                "[FaceDetect] cv2.data tidak ada — pakai center default",
                file=sys.stderr,
            )
            cap.release()
            return DEFAULT_CENTER

        face_cascade = cv2.CascadeClassifier(cascade_path)
        if face_cascade.empty():
            print(
                "[FaceDetect] Cascade file kosong — pakai center default",
                file=sys.stderr,
            )
            cap.release()
            return DEFAULT_CENTER

        centers = []
        sample_count = min(5, max(2, int(duration / 60)))

        for i in range(sample_count):
            t = (i + 0.5) * (duration / sample_count)
            cap.set(cv2.CAP_PROP_POS_FRAMES, int(t * fps))
            ret, frame = cap.read()
            if not ret:
                continue
            h, w = frame.shape[:2]
            if w > 640:
                scale = 640 / w
                frame_small = cv2.resize(frame, (640, int(h * scale)))
            else:
                frame_small = frame

            gray = cv2.cvtColor(frame_small, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(
                gray, scaleFactor=1.2, minNeighbors=5, minSize=(40, 40)
            )
            if len(faces) > 0:
                x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
                sh, sw = frame_small.shape[:2]
                centers.append(((x + fw / 2) / sw, (y + fh / 2) / sh))

        cap.release()

        if centers:
            avg_x = sum(c[0] for c in centers) / len(centers)
            avg_y = sum(c[1] for c in centers) / len(centers)
            print(
                f"[FaceDetect] {len(centers)} wajah terdeteksi — center ({avg_x:.2f}, {avg_y:.2f})",
                file=sys.stderr,
            )
            return avg_x, avg_y

        print(
            "[FaceDetect] Tidak ada wajah terdeteksi — pakai center default",
            file=sys.stderr,
        )
        return DEFAULT_CENTER
    except Exception as e:
        print(f"[FaceDetect] Error: {e} — pakai center default", file=sys.stderr)
        return DEFAULT_CENTER


def get_vertical_crop_filter(video_path, target_w=1080, target_h=1920):
    w, h = get_video_dimensions(video_path)
    target_ratio = target_w / target_h
    if w / h > target_ratio:
        crop_h = h
        crop_w = int(h * target_ratio)
    else:
        crop_w = w
        crop_h = int(w / target_ratio)
    cx, cy = detect_face_center(video_path)
    crop_x = max(0, min(w - crop_w, int(cx * w - crop_w / 2)))
    crop_y = max(0, min(h - crop_h, int(cy * h - crop_h / 2)))
    return f"crop={crop_w}:{crop_h}:{crop_x}:{crop_y},scale={target_w}:{target_h}"


def get_aspect_ratio_filter(video_path, aspect_ratio="auto"):
    """V9.23.2: Generalisasi get_vertical_crop_filter untuk berbagai aspect ratio.

    aspect_ratio: 'auto' | '9:16' | '1:1' | '4:5' | '16:9'
    Return: string vf filter atau None kalau auto.
    """
    if not aspect_ratio or aspect_ratio == "auto":
        return None

    RATIOS = {
        "9:16": (1080, 1920, 9.0 / 16.0),
        "1:1": (1080, 1080, 1.0),
        "4:5": (1080, 1350, 4.0 / 5.0),
        "16:9": (1920, 1080, 16.0 / 9.0),
    }

    if aspect_ratio not in RATIOS:
        print(f"[AspectRatio] Unknown ratio: {aspect_ratio}", file=sys.stderr)
        return None

    target_w, target_h, target_ratio = RATIOS[aspect_ratio]
    w, h = get_video_dimensions(video_path)

    if w / h > target_ratio:
        crop_h = h
        crop_w = int(h * target_ratio)
    else:
        crop_w = w
        crop_h = int(w / target_ratio)

    if aspect_ratio in ("9:16", "4:5"):
        try:
            cx, cy = detect_face_center(video_path)
        except Exception:
            cx, cy = 0.5, 0.5
    else:
        cx, cy = 0.5, 0.5

    crop_x = max(0, min(w - crop_w, int(cx * w - crop_w / 2)))
    crop_y = max(0, min(h - crop_h, int(cy * h - crop_h / 2)))

    print(
        f"[AspectRatio] {aspect_ratio} -> crop {crop_w}x{crop_h} at ({crop_x},{crop_y}), scale to {target_w}x{target_h}",
        file=sys.stderr,
    )
    return f"crop={crop_w}:{crop_h}:{crop_x}:{crop_y},scale={target_w}:{target_h}"


def generate_thumbnail(video_path, output_thumb, title="Clipora"):
    duration = get_duration(video_path)
    timestamp = max(1, duration * 0.3)
    if FONT_PATH:
        escaped = FONT_PATH.replace("\\", "/").replace(":", "\\:")
        font_part = f":fontfile='{escaped}'"
    else:
        font_part = ":font=Arial"
    vf = (
        f"scale=1280:720:force_original_aspect_ratio=decrease,"
        f"pad=1280:720:(ow-iw)/2:(oh-ih)/2:black,"
        f"drawtext=text='{title}':fontcolor=white:fontsize=60:"
        f"x=(w-text_w)/2:y=h-th-80:"
        f"box=1:boxcolor=black@0.6:boxborderw=20{font_part}"
    )
    args = [
        "-ss",
        str(timestamp),
        "-i",
        video_path,
        "-vframes",
        "1",
        "-vf",
        vf,
        "-q:v",
        "2",
        output_thumb,
        "-y",
    ]
    return run_ffmpeg(args, timeout=60)


def mix_background_music(video_path, music_path, output_path, music_volume=0.15, fade_in=1.0, fade_out=1.5, enable_ducking=False, ducking_attack=100, ducking_release=500):
    if not os.path.exists(music_path):
        return False
    # V9.109.0: BGM FADE FINAL — pakai afade
    target_duration = 30.0
    try:
        import subprocess
        result = subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', video_path],
            capture_output=True, text=True, timeout=10
        )
        target_duration = float(result.stdout.strip())
    except Exception as e:
        print(f"[BGM] Gagal deteksi durasi: {e}", file=sys.stderr)

    fade_out_start = max(0.1, target_duration - fade_out)

    music_filters = f"volume={music_volume}"
    if fade_in > 0:
        music_filters += f",afade=t=in:st=0:d={fade_in:.3f}"
    if fade_out > 0:
        music_filters += f",afade=t=out:st={fade_out_start:.3f}:d={fade_out:.3f}"
    music_filters += ",aloop=loop=-1:size=2e+09"

    # V9.130.0: AUTO-DUCKING BGM
    if enable_ducking:
        # Sidechain compression: BGM turun otomatis saat VO bunyi
        filter_complex = (
            f"[0:a]volume=1.0[voice];"
            f"[1:a]{music_filters}[bgm];"
            f"[bgm][voice]sidechaincompress="
            f"threshold=0.05:ratio=8:"
            f"attack={ducking_attack}:release={ducking_release}:"
            f"makeup=1[ducked];"
            f"[voice][ducked]amix=inputs=2:duration=first:dropout_transition=2[out]"
        )
    else:
        # Mix biasa tanpa ducking
        filter_complex = (
            f"[0:a]volume=1.0[voice];"
            f"[1:a]{music_filters}[music];"
            f"[voice][music]amix=inputs=2:duration=first:dropout_transition=2[out]"
        )

    ducking_str = f"ducking=ON(attack={ducking_attack}ms,release={ducking_release}ms)" if enable_ducking else "ducking=OFF"
    print(f"[BGM] Mix fade_in={fade_in}s, fade_out={fade_out}s @ {fade_out_start:.2f}s, vol={music_volume} | {ducking_str}", file=sys.stderr)
    return run_ffmpeg(
        [
            "-i",
            video_path,
            "-stream_loop",
            "-1",
            "-i",
            music_path,
            "-filter_complex",
            filter_complex,
            "-map",
            "0:v",
            "-map",
            "[out]",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-b:a",
            "128k",
            "-shortest",
            output_path,
            "-y",
        ],
        timeout=600,
    )


def export_gif(video_path, output_gif, start=0, duration=5, width=480, fps=12):
    return run_ffmpeg(
        [
            "-ss",
            str(start),
            "-t",
            str(duration),
            "-i",
            video_path,
            "-vf",
            f"fps={fps},scale={width}:-1:flags=lanczos",
            "-loop",
            "0",
            output_gif,
            "-y",
        ],
        timeout=180,
    ) and os.path.exists(output_gif)


def export_mp3(video_path, output_mp3):
    return run_ffmpeg(
        [
            "-i",
            video_path,
            "-vn",
            "-acodec",
            "libmp3lame",
            "-b:a",
            "192k",
            output_mp3,
            "-y",
        ],
        timeout=180,
    ) and os.path.exists(output_mp3)


def detect_scenes(video_path, threshold=0.3):
    cmd = [
        FFMPEG_PATH,
        "-i",
        video_path,
        "-vf",
        f"select='gt(scene,{threshold})',showinfo",
        "-f",
        "null",
        "-",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        pattern = re.compile(r"pts_time:([\d.]+)")
        times = [
            float(m.group(1))
            for m in pattern.finditer(result.stderr)
            if float(m.group(1)) > 0
        ]
        duration = get_duration(video_path)
        if times and times[0] > 1:
            times.insert(0, 0)
        if times and times[-1] < duration - 1:
            times.append(duration)
        print(f"[Scene] {len(times)} scenes", file=sys.stderr)
        return times
    except Exception as e:
        print(f"[Scene Error] {e}", file=sys.stderr)
        return []


# ============================================================
# V8.9.22: Thread-local progress file (parallel-safe)
# ============================================================
import threading as _threading_progress

_progress_local = _threading_progress.local()


def set_progress_file(path):
    _progress_local.path = path


def _get_progress_file():
    return getattr(_progress_local, "path", None)


def report_progress(percent, message="", step=None):
    """V8.9.22: Progress file per-thread — aman untuk parallel render."""
    path = _get_progress_file()
    if path:
        try:
            with open(path, "w") as f:
                json.dump(
                    {
                        "progress": percent,
                        "message": message,
                        "step": step or "unknown",
                    },
                    f,
                )
        except Exception:
            pass
    print(f"PROGRESS:{percent}:{message}", file=sys.stdout)


# ============================================================
# REFERENCE STYLE LEARNING
# ============================================================
def analyze_reference_style(video_path, threshold=0.3):
    print(f"[RefStyle] Analyzing: {video_path}", file=sys.stderr)

    duration = get_duration(video_path)
    if duration <= 0:
        return {"success": False, "error": "Tidak bisa baca durasi video"}

    scene_times = detect_scenes(video_path, threshold=threshold)

    if not scene_times or len(scene_times) < 3:
        return {
            "success": True,
            "avg_cut_interval": duration,
            "median_cut_interval": duration,
            "min_cut_interval": duration,
            "max_cut_interval": duration,
            "cut_count": 0,
            "duration": round(duration, 2),
            "cuts_per_minute": 0,
            "style_label": "cinematic",
        }

    intervals = []
    for i in range(1, len(scene_times)):
        gap = scene_times[i] - scene_times[i - 1]
        if gap > 0.1:
            intervals.append(gap)

    if not intervals:
        intervals = [duration]

    intervals_sorted = sorted(intervals)
    n = len(intervals_sorted)

    avg = sum(intervals) / n
    median = intervals_sorted[n // 2]
    min_i = intervals_sorted[0]
    max_i = intervals_sorted[-1]
    cuts_per_min = (n / duration) * 60 if duration > 0 else 0

    if cuts_per_min >= 40:
        style_label = "dynamic"
    elif cuts_per_min >= 15:
        style_label = "balanced"
    elif cuts_per_min >= 5:
        style_label = "moderate"
    else:
        style_label = "cinematic"

    profile = {
        "success": True,
        "avg_cut_interval": round(avg, 2),
        "median_cut_interval": round(median, 2),
        "min_cut_interval": round(min_i, 2),
        "max_cut_interval": round(max_i, 2),
        "cut_count": n,
        "duration": round(duration, 2),
        "cuts_per_minute": round(cuts_per_min, 1),
        "style_label": style_label,
    }

    print(
        f"[RefStyle] ✅ Cut: {n} | Avg interval: {avg:.2f}s | "
        f"Cuts/min: {cuts_per_min:.1f} | Style: {style_label}",
        file=sys.stderr,
    )
    return profile


# ============================================================
# GENERATE CLIP THUMBNAIL
# ============================================================
def generate_clip_thumbnail(
    source_path, output_path, timestamp, vertical=False, title=""
):
    try:
        if not os.path.exists(source_path):
            return {"success": False, "error": f"Source not found: {source_path}"}

        if vertical:
            target_w, target_h = 720, 1280
            vf = f"scale={target_w}:{target_h}:force_original_aspect_ratio=increase,crop={target_w}:{target_h}"
        else:
            target_w, target_h = 1280, 720
            vf = (
                f"scale={target_w}:{target_h}:force_original_aspect_ratio=decrease,"
                f"pad={target_w}:{target_h}:(ow-iw)/2:(oh-ih)/2:black"
            )

        if title and FONT_PATH:
            escaped_font = FONT_PATH.replace("\\", "/").replace(":", "\\:")
            clean_title = (
                title.replace("'", "").replace(":", " ").replace("\\", "").strip()
            )
            if len(clean_title) > 40:
                clean_title = clean_title[:40].rsplit(" ", 1)[0] + "..."
            if clean_title:
                vf += (
                    f",drawtext=text='{clean_title}':"
                    f"fontcolor=white:fontsize=36:"
                    f"x=(w-text_w)/2:y=h-th-50:"
                    f"box=1:boxcolor=black@0.65:boxborderw=18:"
                    f"fontfile='{escaped_font}'"
                )

        args = [
            "-ss",
            str(timestamp),
            "-i",
            source_path,
            "-vframes",
            "1",
            "-vf",
            vf,
            "-q:v",
            "3",
            output_path,
            "-y",
        ]
        if not run_ffmpeg(args, timeout=60, show_error=False):
            return {"success": False, "error": "FFmpeg gagal generate thumbnail"}

        if not os.path.exists(output_path) or os.path.getsize(output_path) < 500:
            return {"success": False, "error": "Thumbnail kosong"}

        size_kb = os.path.getsize(output_path) / 1024
        print(
            f"[Thumbnail] ✅ {os.path.basename(output_path)} ({size_kb:.1f} KB)",
            file=sys.stderr,
        )
        return {
            "success": True,
            "file": os.path.basename(output_path),
            "size_kb": round(size_kb, 1),
        }

    except Exception as e:
        print(f"[Thumbnail] ❌ Error: {e}", file=sys.stderr)
        return {"success": False, "error": str(e)}


# ============================================================
# V8.8.3: PREVIEW SUBTITLE — V8.9.20 portable fonts
# ============================================================
def generate_subtitle_preview(
    source_path,
    output_path,
    start,
    end,
    caption_style=None,
    title="",
    words=None,
    vertical_crop=False,
    frame_offset=1.5,
    preset="720p",
):
    try:
        if not os.path.exists(source_path):
            return {"success": False, "error": f"Source not found: {source_path}"}

        clip_dur = end - start
        if clip_dur < 0.5:
            return {"success": False, "error": "Klip terlalu pendek"}

        ts_offset = min(frame_offset, clip_dur * 0.5)
        timestamp = start + ts_offset

        temp_dir = Path(os.path.dirname(source_path)).parent / "temp"
        temp_dir.mkdir(exist_ok=True)

        quality = get_quality_settings(preset)
        res_w, res_h = quality["resolution"].split("x")
        res_str = f"{res_w}:{res_h}"

        vf_parts = []
        if vertical_crop:
            vf_parts.append(get_vertical_crop_filter(source_path, 1080, 1920))
        else:
            vf_parts.append(f"scale={res_str}:force_original_aspect_ratio=decrease")
            vf_parts.append(f"pad={res_str}:(ow-iw)/2:(oh-ih)/2:black")

        srt_path = None
        ass_path = None

        if caption_style and HAS_CAPTION_STYLE and words:
            try:
                clip_words = [w for w in words if start <= w.get("start", 0) <= end]

                if clip_words:
                    shifted = [
                        {
                            "word": w.get("word", ""),
                            "start": max(0, w["start"] - start),
                            "end": max(0, w["end"] - start),
                        }
                        for w in clip_words
                    ]

                    srt_path = str(temp_dir / f"preview_{uuid.uuid4().hex[:8]}.srt")
                    save_subtitle(shifted, srt_path)

                    ass_path = str(temp_dir / f"preview_{uuid.uuid4().hex[:8]}.ass")
                    title_for_card = title[:60] if title else ""

                    play_res = (1080, 1920) if vertical_crop else (1920, 1080)

                    ok_convert = cs.srt_to_ass(
                        srt_path,
                        ass_path,
                        style=caption_style,
                        title=title_for_card,
                        play_res=play_res,
                        custom=custom_subtitle,  # V9.146.0
                    )

                    if ok_convert and os.path.exists(ass_path):
                        # V8.9.20: Portable fonts dir
                        ass_escaped = ass_path.replace("\\", "/").replace(":", "\\:")  # V9.178.94: RESTORE_SINGLE_ESC
                        fonts_dir_escaped = (
                            str(FONTS_DIR).replace("\\", "/").replace(":", "\\:")
                        )
                        vf_parts.append(
                            f"subtitles='{ass_escaped}':fontsdir='{fonts_dir_escaped}'"
                        )
                        print(
                            f"[Preview] 🎨 Caption: {caption_style} (ASS)",
                            file=sys.stderr,
                        )
                    else:
                        srt_escaped = srt_path.replace("\\", "/").replace(":", "\\:")
                        vf_parts.append(f"subtitles='{srt_escaped}'")
                        print(f"[Preview] ⚠️ ASS gagal, fallback SRT", file=sys.stderr)
                else:
                    print(
                        f"[Preview] Tidak ada words dalam range klip", file=sys.stderr
                    )
            except Exception as e:
                print(f"[Preview] Caption error: {e}", file=sys.stderr)

        args = [
            "-ss",
            str(timestamp),
            "-i",
            source_path,
            "-vframes",
            "1",
            "-vf",
            ",".join(vf_parts),
            "-q:v",
            "3",
            output_path,
            "-y",
        ]

        ok = run_ffmpeg(args, timeout=60, show_error=True)

        for f in [srt_path, ass_path]:
            if f and os.path.exists(f):
                try:
                    os.unlink(f)
                except Exception:
                    pass

        if (
            not ok
            or not os.path.exists(output_path)
            or os.path.getsize(output_path) < 500
        ):
            return {"success": False, "error": "Gagal generate preview"}

        size_kb = os.path.getsize(output_path) / 1024
        print(
            f"[Preview] ✅ {os.path.basename(output_path)} ({size_kb:.1f} KB, ts={timestamp:.2f}s)",
            file=sys.stderr,
        )

        return {
            "success": True,
            "file": os.path.basename(output_path),
            "size_kb": round(size_kb, 1),
            "timestamp": round(timestamp, 2),
        }

    except Exception as e:
        print(f"[Preview] ❌ Error: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc(file=sys.stderr)
        return {"success": False, "error": str(e)}


# ============================================================
# RENDER SINGLE CLIP — V8.9.20
# ============================================================
# V9.75.0: EMOJI AUTO - deteksi kata kunci, tambah emoji ke subtitle
EMOJI_MAP = {
    # === MAKANAN & MINUMAN ===
    "makan": "🍽️", "enak": "😋", "lezat": "🤤", "pedas": "🌶️",
    "manis": "🍰", "asin": "🧂", "gurih": "🍟",
    "kopi": "☕", "teh": "🍵", "air": "💧", "susu": "🥛",
    "nasi": "🍚", "mie": "🍜", "ayam": "🍗", "daging": "🥩",
    "kue": "🎂", "roti": "🍞", "coklat": "🍫", "es": "🧊",
    "buah": "🍎", "sayur": "🥬", "sambal": "🌶️", "restoran": "🍴",
    "jajanan": "🍡", "camilan": "🍿", "kuliner": "🍱",

    # === UANG & BELANJA ===
    "harga": "💰", "murah": "💸", "mahal": "💎", "diskon": "🔥",
    "promo": "🎉", "gratis": "🎁", "bonus": "🎊", "beli": "🛒",
    "jual": "💵", "bayar": "💳", "cash": "💵", "uang": "💰",
    "keuntungan": "📈", "hemat": "💸", "sale": "🏷️",

    # === EMOSI & REAKSI ===
    "senang": "😊", "bahagia": "😄", "sedih": "😢",
    "kaget": "😱", "terkejut": "😲", "lucu": "😂",
    "keren": "🔥", "mantap": "👍", "wow": "🤩",
    "hebat": "💪", "luar biasa": "🌟", "amazing": "✨",
    "sayang": "❤️", "cinta": "💕", "suka": "😍",
    "takut": "😨", "marah": "😠", "kesal": "😤",

    # === AKSI & AKTIVITAS ===
    "belajar": "📚", "tips": "💡", "trik": "✨", "cara": "📝",
    "jalan": "🚶", "lari": "🏃", "terbang": "✈️",
    "kerja": "💼", "usaha": "🏢", "bisnis": "📊",
    "olahraga": "🏋️", "senam": "🤸", "yoga": "🧘",
    "tidur": "😴", "bangun": "🌅", "istirahat": "☕",

    # === TEKNOLOGI & SOSMED ===
    "hp": "📱", "handphone": "📱", "internet": "🌐",
    "aplikasi": "📲", "website": "💻", "komputer": "💻",
    "instagram": "📸", "tiktok": "🎵", "youtube": "▶️",
    "video": "🎬", "foto": "📷", "live": "📡",

    # === KATA KUNCI UMUM ===
    "bagus": "✅", "baik": "👍", "benar": "✔️", "salah": "❌",
    "penting": "⚠️", "baru": "🆕", "lama": "📅",
    "cepat": "⚡", "lambat": "🐢", "mudah": "👌",
    "sulit": "😓", "gampang": "😎", "susah": "😩",
    "sukses": "🎯", "gagal": "💔", "berhasil": "🏆",

    # === KATA TANYA & SERU ===
    "apa": "❓", "siapa": "👤", "dimana": "📍", "kapan": "⏰",
    "kenapa": "🤔", "bagaimana": "🤷",
    "yo": "👋", "hai": "👋", "halo": "👋",
    "selamat": "🎉", "selamat datang": "🚪",
}

def add_emoji_to_text(text, max_emoji=3):
    """
    V9.75.0: EMOJI AUTO — deteksi kata kunci, tambah emoji
    - text: subtitle text
    - max_emoji: max emoji per baris (default 3)
    Return: text + emoji
    """
    if not text:
        return text
    
    text_lower = text.lower()
    found_emoji = []
    
    # Cari kata kunci di text (dari yang paling panjang dulu biar "luar biasa" match dulu)
    sorted_keys = sorted(EMOJI_MAP.keys(), key=len, reverse=True)
    for keyword in sorted_keys:
        if keyword in text_lower:
            emoji = EMOJI_MAP[keyword]
            if emoji not in found_emoji:
                found_emoji.append(emoji)
                if len(found_emoji) >= max_emoji:
                    break
    
    if found_emoji:
        # Gabung emoji di akhir text
        return text + " " + " ".join(found_emoji)
    return text


# V9.60.1: UMKM render overlay
def build_umkm_overlay_filters(umkm_config, font_path, play_res=(1080, 1920), clip_duration=None, brand_color=None, brand_color_wa=None, logo_path=None, logo_position="top-left", logo_show_text=True):  # V9.119.0: LOGO IN BUILD
    """
    V9.117.0: UMKM LAYOUT OVERHAUL - overlay rapi, no tabrakan, staggered animation
    Layout:
      - Store name : kiri atas (pakai brand_color)
      - Product    : kiri bawah (blok 1)
      - Harga      : kiri bawah (blok 2, di bawah product)
      - CTA WA     : tengah bawah (aman dari subtitle)
      - Subtitle   : diasumsikan di bawah, kita kasih safe zone 400px
    """
    if not umkm_config:
        return []

    filters = []
    w, h = play_res

    FADE = 0.4  # durasi fade per element

    # Default durasi kalau tidak ada
    if not clip_duration or clip_duration < 2.0:
        clip_duration = 5.0

    # V9.117.0: SAFE ZONE - subtitle diasumsikan di bawah, kasih ruang 380px
    SUBTITLE_SAFE_ZONE = 380

    # === BUILD ALPHA EXPRESSION untuk staggered ===
    def _alpha_expr(fade_in_start, fade_out_end):
        """Bikin alpha expression: fade in dari fade_in_start, fade out sebelum fade_out_end"""
        fade_in_end = fade_in_start + FADE
        fade_out_start = max(fade_in_end, fade_out_end - FADE)
        return (
            f"if(lt(t,{fade_in_start}),0,"
            f"if(lt(t,{fade_in_end}),(t-{fade_in_start})/{FADE},"
            f"if(lt(t,{fade_out_start}),1,"
            f"if(lt(t,{fade_out_end}),({fade_out_end}-t)/{FADE},0))))"
        )

    # V9.117.0: SLIDE ANIMATION - y naik 20px sambil fade in
    def _y_slide_expr(fade_in_start, base_y):
        """Return y expression: dari base_y+20 slide ke base_y"""
        fade_in_end = fade_in_start + FADE
        return (
            f"if(lt(t,{fade_in_start}),{base_y}+20,"
            f"if(lt(t,{fade_in_end}),{base_y}+20-((t-{fade_in_start})/{FADE})*20,{base_y}))"
        )

    # Fade out end (semua element fade out sebelum klip habis)
    fade_out_end = clip_duration - 0.3

    # Stagger delays (detik)
    STAGGER_STORE = 0.0
    STAGGER_PRODUCT = 0.3
    STAGGER_PRICE = 0.5
    STAGGER_CTA = 0.8

    # === POSITIONING ===
    PAD = 40

    # V9.117.0: BRAND VARIABLE - pakai warna pilihan user
    BRAND = brand_color if brand_color and brand_color.startswith("#") else "#f59e0b"
    BRAND_WA = brand_color_wa if brand_color_wa and brand_color_wa.startswith("#") else "#25D366"

    # Font path
    if font_path:
        font_escaped = font_path.replace("\\", "/").replace(":", "\\:")
        font_part = f":fontfile='{font_escaped}'"
    else:
        font_part = ":font=Arial"

    def _escape_text(t):
        if not t:
            return ""
        t = str(t).replace("\\", "\\\\\\\\").replace("'", "\\\\'")
        t = t.replace(":", "\\:").replace(",", "\\,")
        t = t.replace("[", "\\[").replace("]", "\\]")
        t = t.replace(";", "\\;").replace("=", "\\=")
        return t

    def _fmt_rupiah(n):
        """Format angka jadi Rp 200.000"""
        try:
            return "Rp " + f"{int(n):,}".replace(",", ".")
        except Exception:
            return "Rp " + str(n)

    # ============================================================
    # 1. STORE NAME - Kiri atas (fade in detik 0.0) - BRAND COLOR
    # ============================================================
    if umkm_config.get("store_name"):
        store_text = _escape_text(umkm_config.get("store_name"))
        a = _alpha_expr(STAGGER_STORE, fade_out_end)
        # V9.173.0: UMKM_VERTICAL_LAYOUT - fixed y=40
        filters.append(
            f"drawtext=text='{store_text}':"
            f"fontcolor=white:fontsize=42:"
            f"x={PAD}:y=40:"
            f"box=1:boxcolor={BRAND}@0.95:boxborderw=20:"
            f"shadowcolor=black@0.5:shadowx=2:shadowy=2:"
            f"alpha='{a}'"
            f"{font_part}"
        )

    # ============================================================
    # 2. PRODUCT NAME - Kiri bawah blok atas (fade in detik 0.3)
    # ============================================================
    if umkm_config.get("product_name"):
        product_text = _escape_text(umkm_config.get("product_name"))
        a = _alpha_expr(STAGGER_PRODUCT, fade_out_end)
        # Posisi: di atas CTA, kiri
        # V9.173.0: UMKM_VERTICAL_LAYOUT - fixed y=150
        filters.append(
            f"drawtext=text='{product_text}':"
            f"fontcolor=white:fontsize=40:"
            f"x={PAD}:y=150:"
            f"box=1:boxcolor=black@0.8:boxborderw=18:"
            f"shadowcolor=black@0.6:shadowx=2:shadowy=2:"
            f"alpha='{a}'"
            f"{font_part}"
        )

    # ============================================================
    # 3. HARGA - Kiri bawah blok bawah (fade in detik 0.5)
    # ============================================================
    if umkm_config.get("show_price") and umkm_config.get("product_price"):
        price_text = _escape_text(_fmt_rupiah(umkm_config.get("product_price")))
        a = _alpha_expr(STAGGER_PRICE, fade_out_end)
        # V9.173.0: UMKM_VERTICAL_LAYOUT - fixed y=220
        filters.append(
            f"drawtext=text='{price_text}':"
            f"fontcolor=white:fontsize=52:"
            f"x={PAD}:y=220:"
            f"box=1:boxcolor={BRAND}@0.95:boxborderw=22:"
            f"shadowcolor=black@0.7:shadowx=3:shadowy=3:"
            f"alpha='{a}'"
            f"{font_part}"
        )

    # ============================================================
    # 4. CTA WA - Bawah tengah, di atas subtitle (fade in detik 0.8)
    # ============================================================
    if umkm_config.get("show_wa_button"):
        cta_text = umkm_config.get("cta_text") or "Order Sekarang!"
        wa_number = umkm_config.get("whatsapp_number") or ""

        # V9.117.0: format nomor WA biar enak dibaca
        def _fmt_wa(n):
            digits = "".join(c for c in str(n) if c.isdigit())
            if len(digits) >= 10:
                return f"{digits[:4]}-{digits[4:8]}-{digits[8:]}"
            return digits

        if wa_number:
            cta_full = f"{cta_text}  •  WA {_fmt_wa(wa_number)}"
        else:
            cta_full = cta_text

        cta_text_esc = _escape_text(cta_full)
        a = _alpha_expr(STAGGER_CTA, fade_out_end)
        base_y = f"h-th-{SUBTITLE_SAFE_ZONE - 30}"
        filters.append(
            f"drawtext=text='{cta_text_esc}':"
            f"fontcolor=white:fontsize=46:"
            f"x=(w-tw)/2:y={base_y}:"
            f"box=1:boxcolor={BRAND_WA}@0.95:boxborderw=22:"
            f"shadowcolor=black@0.7:shadowx=3:shadowy=3:"
            f"alpha='{a}'"
            f"{font_part}"
        )

    # ============================================================
    # V9.171.0: UMKM_DYNAMIC_CONTENT - konten dinamis baru
    # ============================================================
    
    # 5. DISCOUNT PRICE - di bawah harga normal (strikethrough)
    if umkm_config.get("show_discount") and umkm_config.get("discount_price"):
        try:
            disc_text = _escape_text(_fmt_rupiah(umkm_config.get("discount_price")))
            a = _alpha_expr(STAGGER_PRICE + 0.15, fade_out_end)
            # Posisi di bawah harga: h-th-{SUBTITLE_SAFE_ZONE + 5}
        # V9.173.0: UMKM_VERTICAL_LAYOUT - fixed y=290
            filters.append(
                f"drawtext=text='{disc_text}':"
                f"fontcolor=white@0.6:fontsize=36:"
                f"x={PAD}:y=290:"
                f"box=1:boxcolor=black@0.7:boxborderw=14:"
                f"alpha='{a}'"
                f"{font_part}"
            )
        except Exception as _e:
            print(f"[UMKM] Discount render error: {_e}", file=sys.stderr)
    
    # 6. RATING - di bawah discount
    if umkm_config.get("show_rating") and umkm_config.get("rating"):
        try:
            rating_text = _escape_text(umkm_config.get("rating"))
            a = _alpha_expr(STAGGER_PRICE + 0.30, fade_out_end)
        # V9.173.0: UMKM_VERTICAL_LAYOUT - fixed y=350
            filters.append(
                f"drawtext=text='{rating_text}':"
                f"fontcolor=white:fontsize=34:"
                f"x={PAD}:y=350:"
                f"box=1:boxcolor=black@0.75:boxborderw=12:"
                f"alpha='{a}'"
                f"{font_part}"
            )
        except Exception as _e:
            print(f"[UMKM] Rating render error: {_e}", file=sys.stderr)
    
    # 7. FREE SHIPPING - di bawah rating
    if umkm_config.get("show_free_shipping"):
        try:
            a = _alpha_expr(STAGGER_PRICE + 0.45, fade_out_end)
        # V9.173.0: UMKM_VERTICAL_LAYOUT - fixed y=410
            filters.append(
                f"drawtext=text='GRATIS ONGKIR':"
                f"fontcolor=white:fontsize=32:"
                f"x={PAD}:y=410:"
                f"box=1:boxcolor=#22c55e@0.9:boxborderw=14:"
                f"alpha='{a}'"
                f"{font_part}"
            )
        except Exception as _e:
            print(f"[UMKM] Free shipping error: {_e}", file=sys.stderr)
    
    # 8. FLASH SALE - di atas product name (badge style)
    if umkm_config.get("show_flash_sale"):
        try:
            a = _alpha_expr(STAGGER_STORE + 0.1, fade_out_end)
        # V9.173.0: UMKM_VERTICAL_LAYOUT - fixed y=100
            filters.append(
                f"drawtext=text='FLASH SALE':"
                f"fontcolor=white:fontsize=36:"
                f"x={PAD}:y=100:"
                f"box=1:boxcolor=#ef4444@0.95:boxborderw=16:"
                f"shadowcolor=black@0.6:shadowx=2:shadowy=2:"
                f"alpha='{a}'"
                f"{font_part}"
            )
        except Exception as _e:
            print(f"[UMKM] Flash sale error: {_e}", file=sys.stderr)
    
    # 9. BADGE - Best Seller, New, Recommended
    badge_val = umkm_config.get("badge") or "none"
    if badge_val != "none":
        try:
            badge_map = {
                "best-seller": ("BEST SELLER", "#f59e0b"),
                "new": ("NEW ARRIVAL", "#8b5cf6"),
                "recommended": ("RECOMMENDED", "#3b82f6"),
                "limited": ("LIMITED EDITION", "#ef4444"),
            }
            badge_text, badge_color = badge_map.get(badge_val, ("", ""))
            if badge_text:
                a = _alpha_expr(STAGGER_PRODUCT - 0.1, fade_out_end)
        # V9.173.0: UMKM_VERTICAL_LAYOUT - fixed y=100
                filters.append(
                    f"drawtext=text='{badge_text}':"
                    f"fontcolor=white:fontsize=32:"
                    f"x={PAD}:y=100:"
                    f"box=1:boxcolor={badge_color}@0.95:boxborderw=14:"
                    f"shadowcolor=black@0.6:shadowx=2:shadowy=2:"
                    f"alpha='{a}'"
                    f"{font_part}"
                )
        except Exception as _e:
            print(f"[UMKM] Badge render error: {_e}", file=sys.stderr)
    
    # 10. KONTAK MULTI-PLATFORM - di bawah CTA
    ig = umkm_config.get("instagram") or ""
    tt = umkm_config.get("tiktok") or ""
    if ig or tt:
        try:
            contact_parts = []
            if ig:
                contact_parts.append(f"IG: {ig}")
            if tt:
                contact_parts.append(f"TikTok: {tt}")
            contact_text = _escape_text("  •  ".join(contact_parts))
            a = _alpha_expr(STAGGER_CTA + 0.2, fade_out_end)
            base_y = f"h-th-{SUBTITLE_SAFE_ZONE - 90}"
            filters.append(
                f"drawtext=text='{contact_text}':"
                f"fontcolor=white:fontsize=28:"
                f"x=(w-tw)/2:y={base_y}:"
                f"box=1:boxcolor=black@0.75:boxborderw=12:"
                f"alpha='{a}'"
                f"{font_part}"
            )
        except Exception as _e:
            print(f"[UMKM] Contact error: {_e}", file=sys.stderr)

    return filters


def render_single_clip(
    source_path,
    output_path,
    start,
    end,
    preset="1080p",
    add_watermark=True,
    burn_subtitle=False,
    vertical_crop=False,
    aspect_ratio="auto",  # V9.23.2: aspect_ratio param
    use_karaoke=False,  # V9.58.4: Karaoke render
    karaoke_style="tiktok",  # V9.58.4: Karaoke style
    progress_path=None,
    caption_style=None,
    custom_subtitle=None,  # V9.146.0: Custom subtitle override
    title="",
    words=None,
    custom_watermark_path=None,
    umkm_config=None,  # V9.60.2: UMKM render
    # V9.110.0: RENDER_SINGLE_CLIP MUSIC PARAMS
    enable_music=False,  # V9.110.0: Enable BGM
    music_path=None,  # V9.110.0: Path BGM file
    music_volume=0.15,  # V9.110.0: BGM volume (0-1)
    enable_ducking=False,  # V9.130.0: Auto-ducking
    ducking_attack=100,   # V9.130.0: Attack time (ms)
    ducking_release=500,  # V9.130.0: Release time (ms)
    music_fade_in=1.0,  # V9.110.0: Fade in (detik)
    music_fade_out=1.5,  # V9.110.0: Fade out (detik)
    # V9.116.0: BRAND COLOR PARAMS
    brand_color=None,  # V9.116.0: Warna brand utama
    brand_color_wa=None,  # V9.116.0: Warna WA button
    # V9.119.0: LOGO OVERLAY PARAMS
    logo_path=None,
    logo_position="top-left",
    logo_show_text=True,
    # V9.148.0: AUDIO PRO - user control
    user_audio_volume=1.0,           # V9.148.0: 0.0 - 2.0 (1.0 = normal)
    user_enable_noise_reduction=True,  # V9.148.0: toggle noise reduction
    user_enable_normalize=True,      # V9.148.0: toggle loudnorm
    user_audio_fade_in=0.0,          # V9.148.0: fade in (detik)
    user_audio_fade_out=0.0,         # V9.148.0: fade out (detik)
    job_id=None,
    culture_region=None,  # V9.180.121: APPLY_CULTURE_ASS
):
    """
    Render 1 klip. V8.9.20: Per-job cancel + validasi range.
    """
    if job_id is None:
        job_id = uuid.uuid4().hex[:12]
    _register_render(job_id)

    start_time = time.time()
    if progress_path:
        set_progress_file(progress_path)

    try:
        report_progress(0, "Memuat video sumber...", step="load")

        if not os.path.exists(source_path):
            return {"success": False, "error": f"Source video hilang: {source_path}"}

        try:
            start = max(0.0, float(start))
            end = float(end)
        except (TypeError, ValueError):
            return {
                "success": False,
                "error": f"start/end tidak valid: start={start}, end={end}",
            }

        if end <= start:
            return {
                "success": False,
                "error": f"Range tidak valid: end ({end}) <= start ({start})",
            }

        total_dur_src = get_duration(source_path)
        if total_dur_src > 0 and end > total_dur_src:
            print(
                f"[RenderClip] ⚠️  end={end:.2f}s > durasi={total_dur_src:.2f}s — clamp",
                file=sys.stderr,
            )
            end = total_dur_src

        clip_dur = end - start
        if clip_dur < 1:
            return {
                "success": False,
                "error": f"Durasi klip terlalu pendek ({clip_dur:.2f}s)",
            }

        report_progress(15, "Normalisasi CFR...", step="normalize")

        temp_dir = Path(os.path.dirname(source_path)).parent / "temp"
        temp_dir.mkdir(exist_ok=True)

        normalized = str(temp_dir / f"clip_norm_{uuid.uuid4().hex[:8]}.mp4")
        cfr_ok = normalize_to_cfr(source_path, normalized, fps=CFR_FPS, job_id=job_id)

        if _is_render_cancelled(job_id):
            print(
                f"[RenderClip] ⏸️ Dibatalkan oleh user setelah normalize",
                file=sys.stderr,
            )
            return {
                "success": False,
                "error": "Dibatalkan oleh user",
                "cancelled": True,
            }

        if not cfr_ok or not os.path.exists(normalized):
            normalized = source_path

        total_dur = get_duration(normalized)
        if total_dur > 0 and end > total_dur:
            end = total_dur
            clip_dur = end - start

        report_progress(30, f"Memotong klip {clip_dur:.1f}s...", step="cut")

        quality = get_quality_settings(preset)
        res_w, res_h = quality["resolution"].split("x")
        res_str = f"{res_w}:{res_h}"

        vf_parts = []

        # V9.60.1: UMKM render — add overlay filters
        if umkm_config:
            try:
                _umkm_filters = build_umkm_overlay_filters(
                    umkm_config=umkm_config,
                    font_path=FONT_PATH if 'FONT_PATH' in globals() else None,
                    play_res=(1080, 1920) if vertical_crop else (1920, 1080),
                    clip_duration=(end - start),  # V9.113.0: CALLER CLIP DURATION
                    brand_color=brand_color,  # V9.116.0: CALLER BRAND PASS
                    brand_color_wa=brand_color_wa  # V9.116.0
                )
                for _f in _umkm_filters:
                    vf_parts.append(_f)
                print(f"[UMKM] Applied {len(_umkm_filters)} overlay filters", file=sys.stderr)
            except Exception as _e_umkm:
                print(f"[UMKM] Overlay error: {_e_umkm}", file=sys.stderr)
        # V9.23.2: Prioritas aspect_ratio > vertical_crop
        ar_filter = (
            get_aspect_ratio_filter(normalized, aspect_ratio)
            if aspect_ratio and aspect_ratio != "auto"
            else None
        )
        if ar_filter:
            print(f"[RenderClip] Apply aspect ratio: {aspect_ratio}", file=sys.stderr)
            vf_parts.append(ar_filter)
        elif vertical_crop:

            vf_parts.append(get_vertical_crop_filter(normalized, 1080, 1920))
        else:
            vf_parts.append(f"scale={res_str}:force_original_aspect_ratio=decrease")
            vf_parts.append(f"pad={res_str}:(ow-iw)/2:(oh-ih)/2:black")

        use_custom_wm = custom_watermark_path and os.path.exists(custom_watermark_path)

        if use_custom_wm:
            print(
                f"[RenderClip] 🎨 Custom watermark aktif: {os.path.basename(custom_watermark_path)}",
                file=sys.stderr,
            )
        elif add_watermark:
            vf_parts.append(get_watermark_filter())

        srt_path = None
        # V9.58.6: Decouple karaoke from caption_style
        if use_karaoke and HAS_KARAOKE and words:
            try:
                import uuid as _uuid_k

                _k_id = _uuid_k.uuid4().hex[:8]
                karaoke_ass_path = str(temp_dir / f"karaoke_{_k_id}.ass")
                _play_res_k = (1080, 1920) if vertical_crop else (1920, 1080)

                # Pastikan variabel shifted ada
                if "shifted" not in locals():
                    clip_words = [w for w in words if start <= w.get("start", 0) <= end]
                    shifted = [
                        {
                            "word": w.get("word", ""),
                            "start": max(0, w["start"] - start),
                            "end": max(0, w["end"] - start),
                        }
                        for w in clip_words
                    ]

                # V9.58.7: Karaoke time offset (sesuaikan jika tidak sinkron)
                KARAOKE_OFFSET = 0.3  # Ubah ke 0.1, 0.2, atau -0.1 jika perlu
                adjusted_shifted = [
                    {
                        "word": w["word"],
                        "start": max(0, w["start"] + KARAOKE_OFFSET),
                        "end": max(0, w["end"] + KARAOKE_OFFSET),
                    }
                    for w in shifted
                ]

                save_karaoke_ass(
                    words=adjusted_shifted,
                    output_ass_path=karaoke_ass_path,
                    style=karaoke_style,
                    play_res=_play_res_k,
                )
                srt_path = karaoke_ass_path
                print(
                    f"[Karaoke] Generated: {karaoke_ass_path} (style={karaoke_style})",
                    file=sys.stderr,
                )
            except Exception as _e_k:
                print(
                    f"[Karaoke] Error: {_e_k}, fallback to normal SRT", file=sys.stderr
                )
                srt_path = None
        ass_path = None

        if caption_style and HAS_CAPTION_STYLE and words:
            try:
                report_progress(45, "Membuat subtitle bergaya...", step="subtitle")

                clip_words = [w for w in words if start <= w.get("start", 0) <= end]

                if clip_words:
                    shifted = [
                        {
                            "word": w.get("word", ""),
                            "start": w["start"] - start,
                            "end": w["end"] - start,
                        }
                        for w in clip_words
                    ]

                    srt_path = str(temp_dir / f"clip_subs_{uuid.uuid4().hex[:8]}.srt")
                    save_subtitle(shifted, srt_path)

                    # V9.58.4: Karaoke render — override SRT with karaoke ASS
                    if use_karaoke and HAS_KARAOKE and words:
                        try:
                            import uuid as _uuid_k

                            _k_id = _uuid_k.uuid4().hex[:8]
                            karaoke_ass_path = str(temp_dir / f"karaoke_{_k_id}.ass")
                            _play_res_k = (
                                (1080, 1920) if vertical_crop else (1920, 1080)
                            )
                            save_karaoke_ass(
                                words=shifted,
                                output_ass_path=karaoke_ass_path,
                                style=karaoke_style,
                                play_res=_play_res_k,
                            )
                            srt_path = karaoke_ass_path
                            print(
                                f"[Karaoke] Generated: {karaoke_ass_path} (style={karaoke_style})",
                                file=sys.stderr,
                            )
                        except Exception as _e_k:
                            print(
                                f"[Karaoke] Error: {_e_k}, fallback to normal SRT",
                                file=sys.stderr,
                            )

                    ass_path = str(temp_dir / f"clip_subs_{uuid.uuid4().hex[:8]}.ass")
                    title_for_card = title[:60] if title else ""

                    ok_convert = cs.srt_to_ass(
                        srt_path,
                        ass_path,
                        style=caption_style,
                        title=title_for_card,
                        custom=custom_subtitle,  # V9.146.0
                    )

                    # V9.180.121: APPLY_CULTURE_ASS
                    if ok_convert and os.path.exists(ass_path) and culture_region:
                        try:
                            from culture_adapter import adapt_subtitle_ass
                            _adapted = adapt_subtitle_ass(ass_path, culture_region)
                            if _adapted and os.path.exists(_adapted):
                                ass_path = _adapted
                                print(f"[Culture] ? Subtitle adapted: {culture_region}", file=sys.stderr)
                            else:
                                print(f"[Culture] ?? Adapt returned None/failed", file=sys.stderr)
                        except Exception as _e_c:
                            print(f"[Culture] ? Adapt error: {_e_c}", file=sys.stderr)

                    if ok_convert and os.path.exists(ass_path):
                        ass_escaped = ass_path.replace("\\", "/").replace(":", "\\:")  # V9.178.94: RESTORE_SINGLE_ESC
                        fonts_dir_escaped = (
                            str(FONTS_DIR).replace("\\", "/").replace(":", "\\:")
                        )
                        vf_parts.append(
                            f"subtitles='{ass_escaped}':fontsdir='{fonts_dir_escaped}'"
                        )
                        print(
                            f"[RenderClip] 🎨 Caption: {caption_style} (ASS)",
                            file=sys.stderr,
                        )
                    else:
                        srt_escaped = srt_path.replace("\\", "/").replace(":", "\\:")
                        vf_parts.append(f"subtitles='{srt_escaped}'")
                        print(
                            f"[RenderClip] ⚠️ ASS gagal — fallback SRT", file=sys.stderr
                        )
            except Exception as e:
                print(f"[RenderClip] Caption error: {e}", file=sys.stderr)
                srt_path = None
                ass_path = None

        # V9.148.0: AUDIO PRO - build af_parts dari user config
        af_parts = []
        
        # 1. Volume control (0.0 - 2.0, default 1.0)
        if abs(user_audio_volume - 1.0) > 0.01:
            af_parts.append(f"volume={user_audio_volume:.2f}")
            print(f"[AudioPro] Volume: {user_audio_volume:.2f}x", file=sys.stderr)
        
        # 2. Noise Reduction (highpass + lowpass + afftdn)
        if user_enable_noise_reduction:
            af_parts.append("highpass=f=80")
            af_parts.append("lowpass=f=15000")
            af_parts.append("afftdn=nr=10:nf=-25")
            print(f"[AudioPro] Noise Reduction: ON", file=sys.stderr)
        
        # 3. Normalize (loudnorm broadcast standard)
        if user_enable_normalize:
            af_parts.append("loudnorm=I=-16:LRA=11:TP=-1.5")
            print(f"[AudioPro] Normalize: ON (-16 LUFS)", file=sys.stderr)
        
        # 4. Fade In
        if user_audio_fade_in > 0:
            af_parts.append(f"afade=t=in:st=0:d={user_audio_fade_in:.2f}")
            print(f"[AudioPro] Fade In: {user_audio_fade_in:.2f}s", file=sys.stderr)
        
        # 5. Fade Out (pakai clip_dur yang sudah dihitung)
        if user_audio_fade_out > 0:
            _fade_out_start = max(0, clip_dur - user_audio_fade_out)
            af_parts.append(f"afade=t=out:st={_fade_out_start:.2f}:d={user_audio_fade_out:.2f}")
            print(f"[AudioPro] Fade Out: {user_audio_fade_out:.2f}s @ {_fade_out_start:.2f}s", file=sys.stderr)
        
        # Fallback: kalau semua OFF, minimal ada loudnorm biar aman
        if not af_parts:
            af_parts = ["loudnorm=I=-16:LRA=11:TP=-1.5"]
            print(f"[AudioPro] Fallback: loudnorm only", file=sys.stderr)

        # V9.120.0: LOGO OVERLAY - tambah logo ke vf_parts sebagai filter_complex
        _has_logo = bool(logo_path and os.path.exists(logo_path))
        _logo_x = ""
        _logo_y = ""
        if _has_logo:
            # V9.122.0: LOGO PATH ABSOLUTE — convert relative ke absolute untuk FFmpeg
            if logo_path and not os.path.isabs(logo_path):
                _possible_paths = [
                    os.path.join(os.getcwd(), logo_path),
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), logo_path),
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", logo_path),
                ]
                for _p in _possible_paths:
                    _p_norm = os.path.normpath(_p)
                    if os.path.exists(_p_norm):
                        logo_path = _p_norm
                        print(f"[Logo] Resolved: {logo_path}", file=sys.stderr)
                        break
                else:
                    print(f"[Logo] ⚠️  File tidak ditemukan di: {_possible_paths}", file=sys.stderr)
            
            _logo_path_escaped = str(logo_path).replace("\\", "/").replace(":", "\\:")
            _logo_pos = logo_position or "top-left"
            _logo_xy = {
                "top-left":     ("40", "40"),
                "top-right":    ("W-w-40", "40"),
                "bottom-left":  ("40", "H-h-40"),
                "bottom-right": ("W-w-40", "H-h-40"),
            }
            _logo_x, _logo_y = _logo_xy.get(_logo_pos, ("40", "40"))
            print(f"[Logo] ? Logo akan di-overlay: {logo_path} @ {_logo_pos} ({_logo_x},{_logo_y})", file=sys.stderr)

        args = ["-ss", str(start), "-i", normalized, "-t", str(clip_dur)]

        has_audio_stream = has_audio(normalized)

        # V9.120.0: Cek apakah butuh filter_complex (logo atau watermark)
        _need_complex = use_custom_wm or _has_logo

        if _need_complex:
            main_filters = ",".join(vf_parts) if vf_parts else "null"
            fc_parts = [f"[0:v]{main_filters}[v_main]"]
            _last_label = "v_main"

            # Logo overlay
            if _has_logo:
                fc_parts.append(f"movie='{_logo_path_escaped}',scale=200:-1[logoimg]")
                fc_parts.append(f"[{_last_label}][logoimg]overlay={_logo_x}:{_logo_y}[v_with_logo]")
                _last_label = "v_with_logo"

            # Watermark overlay
            if use_custom_wm:
                wm_path_escaped = str(custom_watermark_path).replace("\\", "/").replace(":", "\\:")
                fc_parts.append(f"movie='{wm_path_escaped}',scale=150:-1[wm]")
                fc_parts.append(f"[{_last_label}][wm]overlay=W-w-20:H-h-20[v_out]")
                _last_label = "v_out"
            else:
                # Kalau tidak ada wm tapi ada logo, label terakhir jadi v_out
                if _has_logo:
                    fc_parts[-1] = fc_parts[-1].replace("[v_with_logo]", "[v_out]")
                    _last_label = "v_out"
                else:
                    fc_parts[0] = fc_parts[0].replace("[v_main]", "[v_out]")
                    _last_label = "v_out"

            filter_complex = ";".join(fc_parts)
            args += ["-filter_complex", filter_complex]
            args += ["-map", f"[{_last_label}]"]
            if has_audio_stream:
                args += ["-map", "0:a"]
        else:
            if vf_parts:
                args += ["-vf", ",".join(vf_parts)]
        if af_parts:
            args += ["-af", ",".join(af_parts)]

        args += [
            "-c:v",
            "libx264",
            "-preset",
            quality["preset_speed"],
            "-crf",
            str(quality["crf"]),
            # V9.178.42: VSYNC_CFR_FINAL
            "-r", "30",
            "-fps_mode", "cfr",
            "-c:a",
            "aac",
            "-b:a",
            quality["audio_bitrate"],
            "-movflags",
            "+faststart",
            "-avoid_negative_ts",
            "make_zero",
            output_path,
            "-y",
        ]

        report_progress(60, "Rendering klip final...", step="render")

        if not run_ffmpeg(args, timeout=600, killable=True, job_id=job_id):
            if _is_render_cancelled(job_id):
                return {
                    "success": False,
                    "error": "Dibatalkan oleh user",
                    "cancelled": True,
                }
            print(
                f"[RenderClip DEBUG] SRT: {srt_path} | ASS: {ass_path}", file=sys.stderr
            )
            print(f"[RenderClip DEBUG] vf_parts: {vf_parts}", file=sys.stderr)
            return {"success": False, "error": "FFmpeg render gagal"}

        if not os.path.exists(output_path) or os.path.getsize(output_path) < 1000:
            for f in [srt_path, ass_path]:
                if f and os.path.exists(f):
                    try:
                        os.unlink(f)
                    except Exception:
                        pass
            return {"success": False, "error": "File output tidak valid"}

        subtitle_file_result = None
        if srt_path and os.path.exists(srt_path):
            try:
                output_dir = os.path.dirname(output_path)
                base_name = os.path.splitext(os.path.basename(output_path))[0]
                subtitle_file_result = f"{base_name}.srt"
                srt_output = os.path.join(output_dir, subtitle_file_result)
                shutil.copy2(srt_path, srt_output)
                print(
                    f"[RenderClip] ✅ SRT saved: {subtitle_file_result}",
                    file=sys.stderr,
                )
            except Exception as e:
                print(f"[RenderClip] ⚠️ Gagal save SRT: {e}", file=sys.stderr)
                subtitle_file_result = None

        try:
            if normalized != source_path and os.path.exists(normalized):
                os.unlink(normalized)
        except Exception:
            pass
        for f in [srt_path, ass_path]:
            if f and os.path.exists(f):
                try:
                    os.unlink(f)
                except Exception:
                    pass

        new_duration = get_duration(output_path)
        elapsed = time.time() - start_time
        report_progress(100, f"Selesai — {new_duration:.1f}s", step="done")

        # V9.123.0: MUSIC MIX IN RENDER_CLIP — mix BGM sebelum return
        if enable_music and music_path and os.path.exists(music_path):
            try:
                _music_mixed = str(temp_dir / f"music_{uuid.uuid4().hex[:8]}.mp4")
                _duck_str = "ducking=ON" if enable_ducking else "ducking=OFF"
                print(f"[Music] 🎵 Mixing BGM: {music_path} (vol={music_volume}, in={music_fade_in}s, out={music_fade_out}s, {_duck_str})", file=sys.stderr)
                if mix_background_music(
                    output_path,
                    music_path,
                    _music_mixed,
                    music_volume=music_volume,
                    fade_in=music_fade_in,
                    fade_out=music_fade_out,
                    enable_ducking=enable_ducking,
                    ducking_attack=ducking_attack,
                    ducking_release=ducking_release,
                ):
                    shutil.move(_music_mixed, output_path)
                    new_duration = get_duration(output_path)
                    print(f"[Music] ✅ BGM mixed → {os.path.basename(output_path)} ({new_duration:.1f}s)", file=sys.stderr)
                else:
                    print(f"[Music] ⚠️  mix_background_music return False, skip BGM", file=sys.stderr)
            except Exception as _me:
                print(f"[Music] ❌ BGM mix error: {_me}", file=sys.stderr)
        elif enable_music:
            if not music_path:
                print(f"[Music] ⚠️  enabled tapi music_path KOSONG", file=sys.stderr)
            elif not os.path.exists(music_path):
                print(f"[Music] ⚠️  File tidak ada: {music_path}", file=sys.stderr)


        return {
            "success": True,
            "mode": "render_clip",
            "originalStart": start,
            "originalEnd": end,
            "newDuration": new_duration,
            "processingTimeSeconds": round(elapsed, 1),
            "outputFile": os.path.basename(output_path),
            "captionStyle": caption_style if caption_style else None,
            "titleCard": title if title else None,
            "subtitleFile": subtitle_file_result,
        }

    finally:
        _unregister_render(job_id)


# ============================================================
# MAIN PROCESS VIDEO — V8.7.0 (unchanged behavior)
# ============================================================
def process_video(
    input_path,
    output_path,
    aggressiveness="medium",
    add_watermark=True,
    whisper_model="base",
    enable_zoom=False,
    enable_scene=False,
    enable_noise_reduction=False,
    preset="1080p",
    progress_path=None,
    enable_transition=False,
    enable_chapter=False,
    enable_summary=False,
    target_languages="id",
    batch_id=None,
    video_index=1,
    total_videos=1,
    enable_vertical_crop=False,
    enable_thumbnail=False,
    # V9.177.1: EXTEND_PROCESS_VIDEO
    retention_suggestions=None,
    enable_music=False,
    music_path=None,
    music_volume=0.15,  # V9.109.0: BGM volume
    music_fade_in=1.0,  # V9.109.0: Fade in
    music_fade_out=1.5,  # V9.109.0: Fade out
    enable_multi_format=False,
    thumbnail_title="Clipora",
    enable_burn_subtitle=True,
):

    global PADDING_SEC, SILENCE_PADDING_SEC, MIN_SEGMENT_SEC, MICRO_FADE_SEC
    global PROTECT_CONTEXT_SEC, MAX_ZONE_DURATION, SAFETY_MAX_REMOVE
    global ENABLE_SNAPPING, VAD_THRESHOLD, VAD_MIN_SILENCE_MS

    is_content_mode = aggressiveness == "content"

    if is_content_mode:
        print("=" * 60, file=sys.stderr)
        print("🎬 [Mode] CONTENT CREATOR SUPER AGRESIF (V8.7.0)", file=sys.stderr)
        print("=" * 60, file=sys.stderr)
        PADDING_SEC = 0.08
        SILENCE_PADDING_SEC = 0.04
        MIN_SEGMENT_SEC = 0.25
        MICRO_FADE_SEC = 0.05
        PROTECT_CONTEXT_SEC = 0.5
        MAX_ZONE_DURATION = 1.8
        SAFETY_MAX_REMOVE = 0.55
        ENABLE_SNAPPING = True
        VAD_THRESHOLD = 0.45
        VAD_MIN_SILENCE_MS = 250

    start_time = time.time()
    if progress_path:
        set_progress_file(progress_path)
    report_progress(0, "Memulai proses...")

    temp_dir = Path(os.path.dirname(input_path)).parent / "temp"
    temp_dir.mkdir(exist_ok=True)

    output_dir = os.path.dirname(output_path)
    base_name = os.path.splitext(os.path.basename(output_path))[0]

    print(f"[Process V8.9.20] Input: {input_path}", file=sys.stderr)
    duration = get_duration(input_path)

    report_progress(3, f"Durasi: {duration:.1f}s")

    if not has_audio(input_path):
        report_progress(100, "Tidak ada audio, copy original")
        shutil.copy2(input_path, output_path)
        return {"success": True, "originalDuration": duration, "newDuration": duration}

    report_progress(5, "Normalisasi frame rate (CFR)...")
    normalized_path = str(temp_dir / f"normalized_{uuid.uuid4().hex[:8]}.mp4")
    cfr_ok = normalize_to_cfr(input_path, normalized_path, fps=CFR_FPS)
    if not cfr_ok or not os.path.exists(normalized_path):
        normalized_path = input_path
    else:
        new_dur = get_duration(normalized_path)
        if new_dur > 0:
            duration = new_dur

    report_progress(8, "Ekstrak audio...")
    audio_path = temp_dir / f"audio_{uuid.uuid4().hex[:8]}.wav"
    if not extract_audio(normalized_path, str(audio_path)):
        report_progress(100, "Gagal ekstrak audio")
        try:
            if normalized_path != input_path and os.path.exists(normalized_path):
                os.unlink(normalized_path)
        except Exception:
            pass
        shutil.copy2(input_path, output_path)
        return {"success": True, "originalDuration": duration, "newDuration": duration}

    report_progress(12, "Mendeteksi jeda diam...")
    silence_segments = []
    vad_used = False

    if HAS_SILERO_VAD and ENABLE_VAD:
        report_progress(14, "Analisis suara (Silero VAD)...")
        speech_segments = detect_speech_vad(
            str(audio_path),
            min_silence_ms=VAD_MIN_SILENCE_MS,
            threshold=VAD_THRESHOLD,
        )
        if speech_segments is not None:
            min_sil = 0.15 if is_content_mode else 0.3
            silence_segments = speech_to_silence(
                speech_segments, duration, min_silence=min_sil
            )
            vad_used = True

    if not silence_segments:
        min_dur = 0.3 if is_content_mode else 0.6
        silence_segments = detect_silence_ffmpeg(
            str(audio_path), noise_db=-40, min_duration=min_dur
        )

        # ============================================================
    # V9.5.0: NOISE EVENT DETECTION (batuk, klik, notifikasi, dll)
    # ============================================================
    noise_segments = []
    if ENABLE_NOISE_DETECTION and HAS_NOISE_DETECTOR:
        try:
            report_progress(17, "Mendeteksi noise non-bicara...")
            noise_segments = nd.detect_noise_events(
                str(audio_path), aggressiveness=aggressiveness
            )
        except Exception as e:
            print(f"[NoiseDetect] SKIP (error): {e}", file=sys.stderr)
            noise_segments = []
    else:
        if not ENABLE_NOISE_DETECTION:
            print("[NoiseDetect] Disabled by config", file=sys.stderr)

        # V9.9.0: Auto-switch ke tiny DIHAPUS (akurasi rusak)
    if duration > 300 and whisper_model == "tiny":
        whisper_model = "base"
        print(
            f"[Whisper] Video panjang ({duration:.0f}s) - naikkan dari tiny ke base (akurasi lebih baik)",
            file=sys.stderr,
        )

    estimated_seconds = max(30, int(duration * 0.4))
    report_progress(20, f"Transkripsi Whisper...")

    whisper_done = [False]

    def whisper_ticker():
        ticker_start = time.time()
        while not whisper_done[0]:
            elapsed = time.time() - ticker_start
            pct = min(20 + (elapsed / estimated_seconds) * 8, 28)
            report_progress(
                pct,
                f"Transkripsi Whisper... ({int(elapsed // 60)}m {int(elapsed % 60)}s)",
            )
            time.sleep(3)

    ticker_thread = threading.Thread(target=whisper_ticker, daemon=True)
    ticker_thread.start()

    try:
        whisper_result = transcribe_audio(str(audio_path), model_size=whisper_model)
    finally:
        whisper_done[0] = True

    if not whisper_result:
        print("[Analyze] ❌ Transkripsi gagal — stop analyze", file=sys.stderr)
        report_progress(100, "❌ Transkripsi gagal. Cek koneksi/API.")
        return {
            "success": False,
            "error": "Transkripsi gagal. Cek koneksi internet / saldo AssemblyAI / kualitas audio.",
            "error_code": "TRANSCRIBE_FAILED",
        }

    words = whisper_result.get("words", [])
    transcript_segments = whisper_result.get("segments", [])

    if not words:
        print("[Analyze] ❌ Transkripsi hasil 0 kata — stop", file=sys.stderr)
        return {
            "success": False,
            "error": "Transkripsi tidak menghasilkan kata. Audio mungkin tidak jelas atau dalam bahasa lain.",
            "error_code": "TRANSCRIBE_EMPTY",
        }

    full_text = " ".join([w["word"] for w in words])

    report_progress(38, "Analisis rule-based...")
    duplicate_segments = detect_duplicate_segments(words, aggressiveness)
    filler_segments = detect_filler_segments(words)
    stutter_segments = detect_stutters(words)
    false_start_segments = detect_false_starts(words)
    repetition_segments = detect_repetition_words(words)

    semantic_segments = []
    keywords_data = []
    emotion_data = []
    protected_segments = []

    sentence_boundaries = []
    try:
        sentence_boundaries = detect_sentence_boundaries(transcript_segments)
    except Exception as e:
        print(f"[Sentence] SKIP: {e}", file=sys.stderr)

    smart_protected_zones = build_protected_zones(
        words, emotion_data, keywords_data, protect_seconds=PROTECT_CONTEXT_SEC
    )

    important_zones = []
    try:
        imp_padding = 0.4 if is_content_mode else 0.8
        important_zones = protect_important_zones(
            words, keywords_data, transcript_segments, padding=imp_padding
        )
    except Exception as e:
        print(f"[ImportantZones] SKIP: {e}", file=sys.stderr)

    remove_segments = []

    for seg in repetition_segments:
        remove_segments.append(
            {
                "start": seg["start"],
                "end": seg["end"],
                "source": "repetition",
                "priority": 1,
                "reason": seg.get("phrase", "frasa berulang"),
            }
        )
    for seg in false_start_segments:
        remove_segments.append(
            {
                "start": seg["start"],
                "end": seg["end"],
                "source": "false_start",
                "priority": 1,
                "reason": "salah mulai",
            }
        )
    for seg in stutter_segments:
        remove_segments.append(
            {
                "start": seg["start"],
                "end": seg["end"],
                "source": "stutter",
                "priority": 1,
                "reason": "gagap",
            }
        )
    for seg in filler_segments:
        remove_segments.append(
            {
                "start": seg["start"],
                "end": seg["end"],
                "source": "filler",
                "priority": 2,
                "reason": "kata pengisi",
            }
        )
    for seg in duplicate_segments:
        remove_segments.append(
            {
                "start": seg["start"],
                "end": seg["end"],
                "source": "duplicate",
                "priority": 3,
                "reason": "duplikat",
            }
        )
    for seg in silence_segments:
        remove_segments.append(
            {
                "start": seg["start"],
                "end": seg["end"],
                "source": "silence",
                "priority": 4,
                "reason": "jeda diam",
            }
        )

        # V9.5.0: Noise events — priority 2 (cukup penting untuk dihapus,
    # tapi bisa di-override oleh protect zones)
    for seg in noise_segments:
        remove_segments.append(
            {
                "start": seg["start"],
                "end": seg["end"],
                "source": "noise",
                "priority": 2,
                "reason": seg.get("reason", "noise"),
            }
        )

    remove_segments_backup = [dict(s) for s in remove_segments]
    total_before_protect = sum(s["end"] - s["start"] for s in remove_segments)
    print(
        f"[Removal] SEBELUM protection: {len(remove_segments)} segments, {total_before_protect:.1f}s",
        file=sys.stderr,
    )

    if smart_protected_zones:
        remove_segments = apply_smart_protection(remove_segments, smart_protected_zones)

    if important_zones:
        before_imp = len(remove_segments)
        remove_segments = apply_smart_protection(remove_segments, important_zones)
        print(
            f"[Protect] Zona penting: {before_imp - len(remove_segments)} cuts dibatalkan",
            file=sys.stderr,
        )

    style_memory_zones = []
    prioritize_cats = []
    try:
        sm_result = build_style_memory_zones(remove_segments)
        style_memory_zones = sm_result.get("protect_zones", [])
        prioritize_cats = sm_result.get("prioritize_categories", [])
        if prioritize_cats:
            for seg in remove_segments:
                if seg.get("source") in prioritize_cats:
                    seg["priority"] = min(seg.get("priority", 5), 0)
    except Exception as e:
        print(f"[StyleMemory] SKIP: {e}", file=sys.stderr)

    if style_memory_zones:
        before_sm = len(remove_segments)
        remove_segments = apply_smart_protection(remove_segments, style_memory_zones)
        print(
            f"[StyleMemory] Protect: {before_sm - len(remove_segments)} cuts dibatalkan",
            file=sys.stderr,
        )

    total_after_protect = sum(s["end"] - s["start"] for s in remove_segments)

    if total_before_protect > 2.0 and total_after_protect < total_before_protect * 0.4:
        print(
            f"[Safety] Protection terlalu agresif "
            f"({total_after_protect:.1f}s/{total_before_protect:.1f}s) — kurangi proteksi",
            file=sys.stderr,
        )

        all_zones = []
        for z in smart_protected_zones or []:
            all_zones.append({"zone": z, "dur": z["end"] - z["start"], "type": "smart"})
        for z in important_zones or []:
            all_zones.append(
                {"zone": z, "dur": z["end"] - z["start"], "type": "important"}
            )
        for z in style_memory_zones or []:
            all_zones.append({"zone": z, "dur": z["end"] - z["start"], "type": "style"})

        all_zones.sort(key=lambda x: x["dur"])
        target_min = total_before_protect * 0.6
        attempt = 0
        while total_after_protect < target_min and all_zones and attempt < 30:
            attempt += 1
            all_zones.pop(0)
            remaining_smart = [z["zone"] for z in all_zones if z["type"] == "smart"]
            remaining_imp = [z["zone"] for z in all_zones if z["type"] == "important"]
            remaining_style = [z["zone"] for z in all_zones if z["type"] == "style"]

            test_segments = [dict(s) for s in remove_segments_backup]
            if remaining_smart:
                test_segments = apply_smart_protection(test_segments, remaining_smart)
            if remaining_imp:
                test_segments = apply_smart_protection(test_segments, remaining_imp)
            if remaining_style:
                test_segments = apply_smart_protection(test_segments, remaining_style)

            total_after_protect = sum(s["end"] - s["start"] for s in test_segments)
            remove_segments = test_segments

        print(
            f"[Safety] Setelah kurangi proteksi — "
            f"{total_after_protect:.1f}s ({len(all_zones)} zona tersisa)",
            file=sys.stderr,
        )
    else:
        print(f"[Safety] Protection OK — {total_after_protect:.1f}s", file=sys.stderr)

    print(
        f"[Removal] SETELAH protection: {len(remove_segments)} segments, {total_after_protect:.1f}s",
        file=sys.stderr,
    )

    if ENABLE_SNAPPING and sentence_boundaries:
        try:
            for seg in remove_segments:
                orig_start = seg["start"]
                orig_end = seg["end"]
                seg["start"] = snap_to_nearest_boundary(
                    seg["start"], sentence_boundaries, max_distance=0.3
                )
                seg["end"] = snap_to_nearest_boundary(
                    seg["end"], sentence_boundaries, max_distance=0.3
                )
                if seg["end"] - seg["start"] < 0.2:
                    seg["start"] = orig_start
                    seg["end"] = orig_end
        except Exception as e:
            print(f"[SmartCut] SKIP: {e}", file=sys.stderr)

    remove_segments.sort(key=lambda x: x["start"])
    merged_remove = []
    for seg in remove_segments:
        if not merged_remove:
            merged_remove.append(seg)
        elif seg["start"] <= merged_remove[-1]["end"] + 0.05:
            merged_remove[-1]["end"] = max(merged_remove[-1]["end"], seg["end"])
            if seg.get("priority", 5) < merged_remove[-1].get("priority", 5):
                merged_remove[-1]["priority"] = seg["priority"]
                merged_remove[-1]["source"] = seg["source"]
                merged_remove[-1]["reason"] = seg.get("reason", seg["source"])
        else:
            merged_remove.append(seg)

    total_remove = sum([s["end"] - s["start"] for s in merged_remove])
    print(
        f"[Removal] FINAL: {len(merged_remove)} segments, total {total_remove:.1f}s",
        file=sys.stderr,
    )
    report_progress(60, f"Menghapus {len(merged_remove)} segmen")

    max_remove = duration * SAFETY_MAX_REMOVE
    print(
        f"[Safety] Max removal: {max_remove:.1f}s ({SAFETY_MAX_REMOVE * 100:.0f}%)",
        file=sys.stderr,
    )

    if total_remove > max_remove:
        priority = [s for s in merged_remove if s.get("priority", 5) <= 3]
        silence_only = [s for s in merged_remove if s["source"] == "silence"]
        final_remove = []
        current_total = 0

        for seg in priority:
            seg_dur = seg["end"] - seg["start"]
            if current_total + seg_dur <= max_remove:
                final_remove.append(seg)
                current_total += seg_dur
            else:
                remaining = max_remove - current_total
                if remaining > 0.1:
                    final_remove.append(
                        {
                            "start": seg["end"] - remaining,
                            "end": seg["end"],
                            "source": seg["source"],
                            "priority": seg.get("priority", 5),
                            "reason": seg.get("reason", seg["source"]),
                        }
                    )
                break

        if current_total < max_remove:
            silence_only.sort(key=lambda x: x["end"] - x["start"])
            for seg in silence_only:
                seg_dur = seg["end"] - seg["start"]
                if current_total + seg_dur <= max_remove:
                    final_remove.append(seg)
                    current_total += seg_dur
                else:
                    remaining = max_remove - current_total
                    if remaining > 0.1:
                        final_remove.append(
                            {
                                "start": seg["end"] - remaining,
                                "end": seg["end"],
                                "source": "silence",
                                "priority": 4,
                                "reason": "jeda diam",
                            }
                        )
                    break

        merged_remove = final_remove
        merged_remove.sort(key=lambda x: x["start"])
        
        # V9.177.0: RETENTION_AUTO_OPT — tambah retention cuts
        _retention_suggestions = options.get("retentionSuggestions") if "options" in dir() else None
        if _retention_suggestions:
            _retention_cuts = 0
            for _sug in _retention_suggestions:
                if _sug.get("type") == "cut":
                    merged_remove.append({
                        "start": float(_sug.get("start", 0)),
                        "end": float(_sug.get("end", 0)),
                        "source": "retention",
                        "priority": 5,
                        "reason": _sug.get("reason", "Retention drop"),
                    })
                    _retention_cuts += 1
            if _retention_cuts > 0:
                merged_remove.sort(key=lambda x: x["start"])
                print(f"[Retention] {_retention_cuts} retention cuts ditambahkan ke merged_remove", file=sys.stderr)
        total_remove = sum([s["end"] - s["start"] for s in merged_remove])

    if not merged_remove:
        report_progress(100, "Tidak ada segmen dihapus, copy original")
        try:
            if normalized_path != input_path and os.path.exists(normalized_path):
                os.unlink(normalized_path)
        except Exception:
            pass
        shutil.copy2(input_path, output_path)
        return {"success": True, "originalDuration": duration, "newDuration": duration}

    kept = []
    last_end = 0
    for rm in merged_remove:
        source = rm.get("source", "unknown")
        if source == "silence":
            pad_left = SILENCE_PADDING_SEC
            pad_right = SILENCE_PADDING_SEC
        else:
            pad_left = PADDING_SEC
            pad_right = PADDING_SEC

        start = max(last_end, rm["start"] - pad_left)
        end = min(rm["end"] + pad_right, duration)

        if last_end < start - 0.05:
            kept.append({"start": last_end, "end": start})
        last_end = max(last_end, end)

    if last_end < duration - 0.05:
        kept.append({"start": last_end, "end": duration})

    valid_segments = [s for s in kept if s["end"] - s["start"] > MIN_SEGMENT_SEC]
    print(
        f"[Cut] {len(valid_segments)} segmen (min {MIN_SEGMENT_SEC}s)", file=sys.stderr
    )
    
    # V9.177.1: EXTEND_PROCESS_VIDEO
    _ret_sug = retention_suggestions
    if not _ret_sug:
        try:
            import json as _json_env
            _env_val = os.environ.get("_RETENTION_SUGGESTIONS")
            if _env_val:
                _ret_sug = _json_env.loads(_env_val)
                print(f"[Retention] Loaded {len(_ret_sug)} suggestions dari env", file=sys.stderr)
        except Exception as _e_env:
            print(f"[Retention] Env parse error: {_e_env}", file=sys.stderr)
    
    if _ret_sug and len(_ret_sug) > 0:
        _applied_speedup = 0
        _applied_zoom = 0
        
        for _sug in _ret_sug:
            _sug_type = _sug.get("type")
            _sug_start = float(_sug.get("start", 0))
            _sug_end = float(_sug.get("end", 0))
            _sug_factor = float(_sug.get("factor", 1.0))
            
            if _sug_type == "speedup" and _sug_factor > 1.0:
                for _seg in valid_segments:
                    if _seg["start"] <= _sug_start and _seg["end"] >= _sug_end:
                        _seg["speed"] = _sug_factor
                        _applied_speedup += 1
                        print(f"[Retention] Speedup {_sug_factor}x @ {_sug_start:.1f}-{_sug_end:.1f}s", file=sys.stderr)
            
            elif _sug_type == "zoom" and _sug_factor > 1.0:
                for _seg in valid_segments:
                    if _seg["start"] <= _sug_start and _seg["end"] >= _sug_end:
                        _seg["zoom"] = _sug_factor
                        _applied_zoom += 1
                        print(f"[Retention] Zoom {_sug_factor}x @ {_sug_start:.1f}-{_sug_end:.1f}s", file=sys.stderr)
        
        for _seg in valid_segments:
            if "speed" not in _seg:
                _seg["speed"] = 1.0
            if "zoom" not in _seg:
                _seg["zoom"] = 1.0
        
        print(f"[Retention] Applied {_applied_speedup} speedup, {_applied_zoom} zoom", file=sys.stderr)

    # === ANALYZE MODE ===
    if PROCESS_MODE == "analyze":
        srt_preview = temp_dir / f"preview_{uuid.uuid4().hex[:8]}.srt"
        adjusted_words = adjust_subtitle_timestamps(words, merged_remove)
        srt_generated_preview = False
        if adjusted_words:
            save_subtitle(adjusted_words, str(srt_preview))
            srt_generated_preview = True

        segments_for_edit = []
        for s in merged_remove:
            segments_for_edit.append(
                {
                    "start": round(s["start"], 3),
                    "end": round(s["end"], 3),
                    "source": s.get("source", "unknown"),
                    "reason": s.get("reason", s.get("phrase", s.get("source", "cut"))),
                    "priority": s.get("priority", 5),
                    "enabled": True,
                }
            )

        analysis = {
            "version": "8.9.20",
            "inputPath": input_path,
            "duration": round(duration, 3),
            "preset": preset,
            "aggressiveness": aggressiveness,
            "whisperModel": whisper_model,
            "enableBurnSubtitle": enable_burn_subtitle,
            "addWatermark": add_watermark,
            "segments": segments_for_edit,
            "kept": valid_segments,
            "words": adjusted_words,
            "originalWords": words,
            "srtPath": str(srt_preview) if srt_generated_preview else None,
            "styleMemoryApplied": len(style_memory_zones) > 0
            or len(prioritize_cats) > 0,
            "stats": {
                "phraseRepeat": len(
                    [s for s in merged_remove if s.get("source") == "repetition"]
                ),
                "filler": len(
                    [s for s in merged_remove if s.get("source") == "filler"]
                ),
                "stutter": len(
                    [s for s in merged_remove if s.get("source") == "stutter"]
                ),
                "falseStart": len(
                    [s for s in merged_remove if s.get("source") == "false_start"]
                ),
                "silence": len(
                    [s for s in merged_remove if s.get("source") == "silence"]
                ),
                "duplicate": len(
                    [s for s in merged_remove if s.get("source") == "duplicate"]
                ),
                "noise": len([s for s in merged_remove if s.get("source") == "noise"]),
                "totalRemoved": round(total_remove, 2),
                "whisperWords": len(words),
            },
        }

        if ANALYSIS_JSON_PATH:
            with open(ANALYSIS_JSON_PATH, "w", encoding="utf-8") as f:
                json.dump(analysis, f, ensure_ascii=False, indent=2)

        try:
            if normalized_path != input_path and os.path.exists(normalized_path):
                os.unlink(normalized_path)
        except Exception:
            pass
        try:
            audio_path.unlink()
        except Exception:
            pass
        try:
            if srt_generated_preview and os.path.exists(str(srt_preview)):
                os.unlink(str(srt_preview))
        except Exception:
            pass

        report_progress(100, f"Analisis selesai — {len(merged_remove)} segmen")
        return {
            "success": True,
            "mode": "analyze",
            "analysisFile": ANALYSIS_JSON_PATH,
            "totalSegments": len(merged_remove),
            "duration": round(duration, 2),
            "styleMemoryApplied": len(style_memory_zones) > 0
            or len(prioritize_cats) > 0,
            **analysis["stats"],
        }

    # === RENDER FULL MODE ===
    scene_times = []
    if enable_scene:
        scene_times = detect_scenes(normalized_path)

    adjusted_words = adjust_subtitle_timestamps(words, merged_remove)
    srt_path = temp_dir / f"subs_{uuid.uuid4().hex[:8]}.srt"
    srt_generated = False
    if adjusted_words:
        save_subtitle(adjusted_words, str(srt_path))
        srt_generated = True

    quality = get_quality_settings(preset)

    if len(valid_segments) <= MAX_SINGLE_PASS_SEGMENTS:
        n = len(valid_segments)
        parts = []
        concat_pairs = []

        for i, seg in enumerate(valid_segments):
            s = seg["start"]
            e = seg["end"]
            seg_dur = e - s
            fade = min(MICRO_FADE_SEC, seg_dur / 3.5)
            fade_out_start = max(0, seg_dur - fade)

            # V9.177.0: RETENTION_AUTO_OPT — speedup + zoom
            _speed = seg.get("speed", 1.0)
            _zoom = seg.get("zoom", 1.0)
            
            if _speed != 1.0:
                _setpts = f"(PTS-STARTPTS)/{_speed:.4f}"
                _asetpts = f"(PTS-STARTPTS)/{_speed:.4f}"
            else:
                _setpts = "PTS-STARTPTS"
                _asetpts = "PTS-STARTPTS"
            
            if _zoom != 1.0:
                _zoom_filter = f",scale=iw*{_zoom:.4f}:ih*{_zoom:.4f},crop=iw/{_zoom:.4f}:ih/{_zoom:.4f}"
            else:
                _zoom_filter = ""
            
            parts.append(
                f"[0:v]trim=start={s:.4f}:end={e:.4f},setpts={_setpts}{_zoom_filter}[v{i}]"
            )
            parts.append(
                f"[0:a]atrim=start={s:.4f}:end={e:.4f},asetpts={_asetpts},"
                f"afade=t=in:st=0:d={fade:.3f},"
                f"afade=t=out:st={fade_out_start:.3f}:d={fade:.3f}[a{i}]"
            )
            concat_pairs.append(f"[v{i}][a{i}]")

        parts.append(f"{''.join(concat_pairs)}concat=n={n}:v=1:a=1[concat_v][concat_a]")

        v_label = "[concat_v]"
        video_post_filters = []
        if enable_burn_subtitle and srt_generated:
            sub_size = get_subtitle_font_size(preset, vertical=enable_vertical_crop)
            video_post_filters.append(
                build_subtitle_filter(str(srt_path), font_size=sub_size)
            )
        if add_watermark:
            video_post_filters.append(get_watermark_filter())

        if video_post_filters:
            parts.append(f"{v_label}{','.join(video_post_filters)}[v_out]")
            v_label_final = "[v_out]"
        else:
            v_label_final = "[concat_v]"

        audio_post = [
            "highpass=f=80",
            "lowpass=f=15000",
            "afftdn=nr=10:nf=-25",
            "compand=attacks=0.04:decays=0.25:points=-80/-80|-45/-15|-20/-8|0/-4",
            "loudnorm=I=-16:LRA=11:TP=-1.5",
        ]
        parts.append(f"[concat_a]{','.join(audio_post)}[a_out]")
        filter_complex = ";".join(parts)

        final_args = [
            "-i",
            normalized_path,
            "-filter_complex",
            filter_complex,
            "-map",
            v_label_final,
            "-map",
            "[a_out]",
            "-c:v",
            "libx264",
            "-preset",
            quality["preset_speed"],
            "-crf",
            str(quality["crf"]),
            # V9.178.42: VSYNC_CFR_FINAL
            "-r", "30",
            "-fps_mode", "cfr",
            "-c:a",
            "aac",
            "-b:a",
            quality["audio_bitrate"],
            "-movflags",
            "+faststart",
        ]
        if not enable_vertical_crop and not video_post_filters:
            final_args.extend(["-s", quality["resolution"]])
        final_args.append(output_path)

        report_progress(85, "Rendering final...")
        success = run_ffmpeg(final_args, timeout=3600)
        if (
            not success
            or not os.path.exists(output_path)
            or os.path.getsize(output_path) < 1000
        ):
            shutil.copy2(normalized_path, output_path)

    else:
        seg_files = []
        for i, seg in enumerate(valid_segments):
            if seg["end"] - seg["start"] < 0.1:
                continue
            seg_file = temp_dir / f"seg_{i}_{uuid.uuid4().hex[:8]}.mp4"
            if run_ffmpeg(
                [
                    "-ss",
                    str(seg["start"]),
                    "-to",
                    str(seg["end"]),
                    "-i",
                    normalized_path,
                    "-c:v",
                    "libx264",
                    "-preset",
                    "veryfast",
                    "-crf",
                    "20",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "192k",
                    "-avoid_negative_ts",
                    "make_zero",
                    str(seg_file),
                ],
                timeout=300,
            ):
                if seg_file.exists() and seg_file.stat().st_size > 1000:
                    seg_files.append(seg_file)

        if seg_files:
            concat_list = temp_dir / f"concat_{uuid.uuid4().hex[:8]}.txt"
            with open(concat_list, "w") as f:
                for sf in seg_files:
                    f.write(f"file '{sf.as_posix()}'\n")

            temp_concat = str(temp_dir / f"temp_concat_{uuid.uuid4().hex[:8]}.mp4")
            run_ffmpeg(
                [
                    "-f",
                    "concat",
                    "-safe",
                    "0",
                    "-i",
                    str(concat_list),
                    "-c:v",
                    "libx264",
                    "-preset",
                    "veryfast",
                    "-crf",
                    "20",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "192k",
                    "-movflags",
                    "+faststart",
                    temp_concat,
                ],
            )

            vf = []
            if enable_vertical_crop:
                vf.append(get_vertical_crop_filter(normalized_path, 1080, 1920))
            if add_watermark:
                vf.append(get_watermark_filter())
            if enable_burn_subtitle and srt_generated:
                sub_size = get_subtitle_font_size(preset, vertical=enable_vertical_crop)
                vf.append(build_subtitle_filter(str(srt_path), font_size=sub_size))

            af = [
                "highpass=f=80",
                "lowpass=f=15000",
                "afftdn=nr=10:nf=-25",
                "compand=attacks=0.04:decays=0.25:points=-80/-80|-45/-15|-20/-8|0/-4",
                "loudnorm=I=-16:LRA=11:TP=-1.5",
            ]

            fa = [
                "-i",
                temp_concat,
                "-c:v",
                "libx264",
                "-preset",
                quality["preset_speed"],
                "-crf",
                str(quality["crf"]),
                "-c:a",
                "aac",
                "-b:a",
                quality["audio_bitrate"],
                "-movflags",
                "+faststart",
                "-af",
                ",".join(af),
            ]
            if vf:
                fa.extend(["-vf", ",".join(vf)])
            else:
                fa.extend(["-s", quality["resolution"]])
            fa.append(output_path)

            if not run_ffmpeg(fa, timeout=1800):
                shutil.copy2(temp_concat, output_path)

            for f in seg_files:
                try:
                    f.unlink()
                except Exception:
                    pass
            try:
                concat_list.unlink()
            except Exception:
                pass
            try:
                Path(temp_concat).unlink()
            except Exception:
                pass
        else:
            shutil.copy2(normalized_path, output_path)

    if enable_music and music_path and os.path.exists(music_path):
        mixed_output = str(temp_dir / f"music_{uuid.uuid4().hex[:8]}.mp4")
        # V9.109.0: BGM FADE — teruskan fade params
        _mv = locals().get("music_volume", 0.15)
        _fi = locals().get("music_fade_in", 1.0)
        _fo = locals().get("music_fade_out", 1.5)
        if mix_background_music(output_path, music_path, mixed_output,
                                 music_volume=_mv, fade_in=_fi, fade_out=_fo):
            shutil.move(mixed_output, output_path)

    thumbnail_file = None
    if enable_thumbnail:
        thumbnail_file = os.path.join(output_dir, f"{base_name}_thumbnail.jpg")
        generate_thumbnail(output_path, thumbnail_file, title=thumbnail_title)

    gif_file = None
    mp3_file = None
    if enable_multi_format:
        gif_file = os.path.join(output_dir, f"{base_name}.gif")
        export_gif(output_path, gif_file)
        mp3_file = os.path.join(output_dir, f"{base_name}.mp3")
        export_mp3(output_path, mp3_file)

    try:
        if normalized_path != input_path and os.path.exists(normalized_path):
            os.unlink(normalized_path)
    except Exception:
        pass
    try:
        audio_path.unlink()
    except Exception:
        pass
    try:
        if srt_generated and os.path.exists(str(srt_path)):
            os.unlink(str(srt_path))
    except Exception:
        pass

    new_duration = get_duration(output_path)
    saved = duration - new_duration
    elapsed = time.time() - start_time
    report_progress(100, f"Selesai! Hemat {saved:.1f}s dalam {elapsed:.0f}s")

    return {
        "success": True,
        "mode": "full",
        "originalDuration": duration,
        "newDuration": new_duration,
        "silences": len([s for s in merged_remove if s["source"] == "silence"]),
        "aiSegments": 0,
        "fillerSegments": len([s for s in merged_remove if s["source"] == "filler"]),
        "stutterSegments": len([s for s in merged_remove if s["source"] == "stutter"]),
        "falseStartSegments": len(
            [s for s in merged_remove if s["source"] == "false_start"]
        ),
        "repetitionSegments": len(
            [s for s in merged_remove if s["source"] == "repetition"]
        ),
        "semanticSegments": 0,
        "llmSegments": 0,
        "sceneCount": len(scene_times) if enable_scene else 0,
        "subtitleFile": None,
        "subtitleBurned": enable_burn_subtitle and srt_generated,
        "thumbnailFile": (
            os.path.basename(thumbnail_file)
            if thumbnail_file and os.path.exists(thumbnail_file)
            else None
        ),
        "gifFile": (
            os.path.basename(gif_file)
            if gif_file and os.path.exists(gif_file)
            else None
        ),
        "mp3File": (
            os.path.basename(mp3_file)
            if mp3_file and os.path.exists(mp3_file)
            else None
        ),
        "verticalCrop": enable_vertical_crop,
        "musicMixed": enable_music and music_path is not None,
        "processingTimeSeconds": round(elapsed, 1),
        "styleMemoryApplied": len(style_memory_zones) > 0 or len(prioritize_cats) > 0,
        "whisperWords": len(words),
        "quality": {
            "preset": preset,
            "crf": quality["crf"],
            "resolution": (
                quality["resolution"] if not enable_vertical_crop else "1080x1920"
            ),
        },
    }


# ============================================================
# RENDER FROM EDITED ANALYSIS
# ============================================================
def render_from_analysis(
    analysis_path,
    output_path,
    progress_path=None,
    preset_override=None,
    add_watermark_override=None,
    burn_subtitle_override=None,
    custom_subtitle=None,  # V9.146.0: Custom subtitle override
    caption_style=None,  # V9.146.0: Caption style
):
    start_time = time.time()
    if progress_path:
        set_progress_file(progress_path)
    report_progress(0, "Memuat data analisis...")

    with open(analysis_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    input_path = data["inputPath"]
    duration = data["duration"]
    preset = preset_override or data.get("preset", "1080p")
    add_watermark = (
        add_watermark_override
        if add_watermark_override is not None
        else data.get("addWatermark", True)
    )
    enable_burn_subtitle = (
        burn_subtitle_override
        if burn_subtitle_override is not None
        else data.get("enableBurnSubtitle", True)
    )
    words = data.get("originalWords", data.get("words", []))

    if not os.path.exists(input_path):
        return {"success": False, "error": f"Input video hilang: {input_path}"}

    enabled_segments = [s for s in data["segments"] if s.get("enabled", True)]
    enabled_segments.sort(key=lambda x: x["start"])

    PADDING_L = 0.08
    SILENCE_PADDING_L = 0.04
    MIN_SEG_L = 0.25

    kept = []
    last_end = 0.0
    for rm in enabled_segments:
        src = rm.get("source", "manual")
        pad_l = SILENCE_PADDING_L if src == "silence" else PADDING_L
        pad_r = SILENCE_PADDING_L if src == "silence" else PADDING_L

        start = max(last_end, rm["start"] - pad_l)
        end = min(rm["end"] + pad_r, duration)

        if last_end < start - 0.05:
            kept.append({"start": last_end, "end": start})
        last_end = max(last_end, end)

    if last_end < duration - 0.05:
        kept.append({"start": last_end, "end": duration})

    valid_segments = [s for s in kept if s["end"] - s["start"] > MIN_SEG_L]

    if len(valid_segments) > 1:
        merged = [valid_segments[0]]
        for s in valid_segments[1:]:
            gap = s["start"] - merged[-1]["end"]
            if gap < 0.4:
                merged[-1]["end"] = s["end"]
            else:
                merged.append(s)
        if len(merged) != len(valid_segments):
            print(
                f"[Merge] {len(valid_segments)} → {len(merged)} segmen (gap < 0.4s di-merge)",
                file=sys.stderr,
            )
        valid_segments = merged

    if not valid_segments:
        report_progress(100, "Tidak ada segmen — copy original")
        shutil.copy2(input_path, output_path)
        return {
            "success": True,
            "mode": "render",
            "originalDuration": duration,
            "newDuration": duration,
            "silences": 0,
        }

    report_progress(15, "Normalisasi CFR...")
    temp_dir = Path(os.path.dirname(input_path)).parent / "temp"
    temp_dir.mkdir(exist_ok=True)
    normalized_path = str(temp_dir / f"render_norm_{uuid.uuid4().hex[:8]}.mp4")
    cfr_ok = normalize_to_cfr(input_path, normalized_path, fps=CFR_FPS)
    if not cfr_ok or not os.path.exists(normalized_path):
        normalized_path = input_path
    else:
        nd = get_duration(normalized_path)
        if nd > 0:
            duration = nd

    srt_path = temp_dir / f"subs_{uuid.uuid4().hex[:8]}.srt"
    srt_generated = False
    if words:
        adjusted = adjust_subtitle_timestamps(words, enabled_segments)
        save_subtitle(adjusted, str(srt_path))
        srt_generated = True

    quality = get_quality_settings(preset)
    report_progress(25, f"Render {len(valid_segments)} segmen...")

    if len(valid_segments) <= MAX_SINGLE_PASS_SEGMENTS:
        n = len(valid_segments)
        parts = []
        pairs = []

        for i, seg in enumerate(valid_segments):
            s, e = seg["start"], seg["end"]
            sd = e - s
            fade = min(MICRO_FADE_SEC, sd / 3.5)
            fo = max(0, sd - fade)

            parts.append(
                f"[0:v]trim=start={s:.4f}:end={e:.4f},setpts=PTS-STARTPTS[v{i}]"
            )
            parts.append(
                f"[0:a]atrim=start={s:.4f}:end={e:.4f},asetpts=PTS-STARTPTS,"
                f"afade=t=in:st=0:d={fade:.3f},afade=t=out:st={fo:.3f}:d={fade:.3f}[a{i}]"
            )
            pairs.append(f"[v{i}][a{i}]")

        parts.append(f"{''.join(pairs)}concat=n={n}:v=1:a=1[concat_v][concat_a]")

        v_label = "[concat_v]"
        vpf = []
        if add_watermark:
            vpf.append(get_watermark_filter())
        if enable_burn_subtitle and srt_generated:
            sub_size = get_subtitle_font_size(preset)
            vpf.append(build_subtitle_filter(str(srt_path), font_size=sub_size))

        if vpf:
            parts.append(f"{v_label}{','.join(vpf)}[v_out]")
            v_final = "[v_out]"
        else:
            v_final = "[concat_v]"

        audio_post = [
            "highpass=f=80",
            "lowpass=f=15000",
            "afftdn=nr=10:nf=-25",
            "compand=attacks=0.04:decays=0.25:points=-80/-80|-45/-15|-20/-8|0/-4",
            "loudnorm=I=-16:LRA=11:TP=-1.5",
        ]
        parts.append(f"[concat_a]{','.join(audio_post)}[a_out]")
        fc = ";".join(parts)

        final_args = [
            "-i",
            normalized_path,
            "-filter_complex",
            fc,
            "-map",
            v_final,
            "-map",
            "[a_out]",
            "-c:v",
            "libx264",
            "-preset",
            quality["preset_speed"],
            "-crf",
            str(quality["crf"]),
            # V9.178.42: VSYNC_CFR_FINAL
            "-r", "30",
            "-fps_mode", "cfr",
            "-c:a",
            "aac",
            "-b:a",
            quality["audio_bitrate"],
            "-movflags",
            "+faststart",
        ]
        if not vpf:
            final_args.extend(["-s", quality["resolution"]])
        final_args.append(output_path)

        report_progress(60, "Rendering...")
        if not run_ffmpeg(final_args, timeout=3600):
            shutil.copy2(normalized_path, output_path)
    else:
        seg_files = []
        for i, seg in enumerate(valid_segments):
            if seg["end"] - seg["start"] < 0.1:
                continue
            sf = temp_dir / f"rseg_{i}_{uuid.uuid4().hex[:8]}.mp4"
            if run_ffmpeg(
                [
                    "-ss",
                    str(seg["start"]),
                    "-to",
                    str(seg["end"]),
                    "-i",
                    normalized_path,
                    "-c:v",
                    "libx264",
                    "-preset",
                    "veryfast",
                    "-crf",
                    "20",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "192k",
                    "-avoid_negative_ts",
                    "make_zero",
                    str(sf),
                ],
                timeout=300,
            ):
                if sf.exists() and sf.stat().st_size > 1000:
                    seg_files.append(sf)

        if seg_files:
            cl = temp_dir / f"rc_{uuid.uuid4().hex[:8]}.txt"
            with open(cl, "w") as f:
                for sf in seg_files:
                    f.write(f"file '{sf.as_posix()}'\n")

            tc = str(temp_dir / f"rt_{uuid.uuid4().hex[:8]}.mp4")
            run_ffmpeg(
                [
                    "-f",
                    "concat",
                    "-safe",
                    "0",
                    "-i",
                    str(cl),
                    "-c:v",
                    "libx264",
                    "-preset",
                    "veryfast",
                    "-crf",
                    "20",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "192k",
                    "-movflags",
                    "+faststart",
                    tc,
                ],
            )

            vf = []
            if add_watermark:
                vf.append(get_watermark_filter())
            if enable_burn_subtitle and srt_generated:
                sub_size = get_subtitle_font_size(preset)
                vf.append(build_subtitle_filter(str(srt_path), font_size=sub_size))

            af = [
                "highpass=f=80",
                "lowpass=f=15000",
                "afftdn=nr=10:nf=-25",
                "compand=attacks=0.04:decays=0.25:points=-80/-80|-45/-15|-20/-8|0/-4",
                "loudnorm=I=-16:LRA=11:TP=-1.5",
            ]
            fa = [
                "-i",
                tc,
                "-c:v",
                "libx264",
                "-preset",
                quality["preset_speed"],
                "-crf",
                str(quality["crf"]),
                "-c:a",
                "aac",
                "-b:a",
                quality["audio_bitrate"],
                "-movflags",
                "+faststart",
                "-af",
                ",".join(af),
            ]
            if vf:
                fa.extend(["-vf", ",".join(vf)])
            else:
                fa.extend(["-s", quality["resolution"]])
            fa.append(output_path)

            if not run_ffmpeg(fa, timeout=1800):
                shutil.copy2(tc, output_path)

            for f in seg_files:
                try:
                    f.unlink()
                except Exception:
                    pass
            try:
                cl.unlink()
            except Exception:
                pass
            try:
                Path(tc).unlink()
            except Exception:
                pass
        else:
            shutil.copy2(normalized_path, output_path)

    try:
        if normalized_path != input_path and os.path.exists(normalized_path):
            os.unlink(normalized_path)
    except Exception:
        pass
    try:
        if srt_generated and os.path.exists(str(srt_path)):
            os.unlink(str(srt_path))
    except Exception:
        pass

    new_duration = get_duration(output_path)
    saved = duration - new_duration
    elapsed = time.time() - start_time
    report_progress(100, f"Selesai — hemat {saved:.1f}s")

    return {
        "success": True,
        "mode": "render",
        "originalDuration": duration,
        "newDuration": new_duration,
        "silences": len([s for s in enabled_segments if s.get("source") == "silence"]),
        "aiSegments": 0,
        "fillerSegments": len(
            [s for s in enabled_segments if s.get("source") == "filler"]
        ),
        "stutterSegments": len(
            [s for s in enabled_segments if s.get("source") == "stutter"]
        ),
        "falseStartSegments": len(
            [s for s in enabled_segments if s.get("source") == "false_start"]
        ),
        "repetitionSegments": len(
            [s for s in enabled_segments if s.get("source") == "repetition"]
        ),
        "semanticSegments": 0,
        "subtitleFile": None,
        "subtitleBurned": enable_burn_subtitle and srt_generated,
        "processingTimeSeconds": round(elapsed, 1),
    }


# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": "Usage: python process_video_v8.py <input> <output> [params...]",
                }
            )
        )
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2]
    aggressiveness = sys.argv[3] if len(sys.argv) > 3 else "medium"
    add_watermark = sys.argv[4].lower() == "true" if len(sys.argv) > 4 else True
    whisper_model = sys.argv[5] if len(sys.argv) > 5 else "base"
    enable_zoom = sys.argv[6].lower() == "true" if len(sys.argv) > 6 else False
    enable_scene = sys.argv[7].lower() == "true" if len(sys.argv) > 7 else False
    enable_noise = sys.argv[8].lower() == "true" if len(sys.argv) > 8 else False
    preset = sys.argv[9] if len(sys.argv) > 9 else "1080p"
    progress_path = sys.argv[10] if len(sys.argv) > 10 else None
    enable_transition = sys.argv[11].lower() == "true" if len(sys.argv) > 11 else False
    enable_chapter = sys.argv[12].lower() == "true" if len(sys.argv) > 12 else False
    enable_summary = sys.argv[13].lower() == "true" if len(sys.argv) > 13 else False
    target_languages = sys.argv[14] if len(sys.argv) > 14 else "id"
    batch_id = sys.argv[15] if len(sys.argv) > 15 else None
    video_index = int(sys.argv[16]) if len(sys.argv) > 16 else 1
    total_videos = int(sys.argv[17]) if len(sys.argv) > 17 else 1
    enable_vertical_crop = (
        sys.argv[18].lower() == "true" if len(sys.argv) > 18 else False
    )
    enable_thumbnail = sys.argv[19].lower() == "true" if len(sys.argv) > 19 else False
    enable_music = sys.argv[20].lower() == "true" if len(sys.argv) > 20 else False
    music_path = sys.argv[21] if len(sys.argv) > 21 and sys.argv[21] else None
    enable_multi_format = (
        sys.argv[22].lower() == "true" if len(sys.argv) > 22 else False
    )
    thumbnail_title = sys.argv[23] if len(sys.argv) > 23 else "Clipora"
    enable_burn_subtitle = (
        sys.argv[24].lower() == "true" if len(sys.argv) > 24 else True
    )
    mode = sys.argv[25] if len(sys.argv) > 25 else "full"
    analysis_json_path = sys.argv[26] if len(sys.argv) > 26 and sys.argv[26] else None

    PROCESS_MODE = mode
    ANALYSIS_JSON_PATH = analysis_json_path

    if not os.path.exists(input_path):
        print(json.dumps({"success": False, "error": f"File not found: {input_path}"}))
        sys.exit(1)

    try:
        if mode == "render":
            if not analysis_json_path or not os.path.exists(analysis_json_path):
                print(
                    json.dumps(
                        {
                            "success": False,
                            "error": "analysis json required for render mode",
                        }
                    )
                )
                sys.exit(1)
            result = render_from_analysis(
                analysis_json_path,
                output_path,
                progress_path,
                preset_override=preset,
                add_watermark_override=add_watermark,
                burn_subtitle_override=enable_burn_subtitle,
            )
        else:
            result = process_video(
                input_path,
                output_path,
                aggressiveness,
                add_watermark,
                whisper_model,
                enable_zoom,
                enable_scene,
                enable_noise,
                preset,
                progress_path,
                enable_transition,
                enable_chapter,
                enable_summary,
                target_languages,
                batch_id,
                video_index,
                total_videos,
                enable_vertical_crop,
                enable_thumbnail,
                enable_music,
                music_path,
                enable_multi_format,
                thumbnail_title,
                enable_burn_subtitle,
            )
        print(json.dumps(result))
    except Exception as e:
        import traceback

        print(
            json.dumps(
                {"success": False, "error": str(e), "trace": traceback.format_exc()}
            )
        )
        sys.exit(1)
