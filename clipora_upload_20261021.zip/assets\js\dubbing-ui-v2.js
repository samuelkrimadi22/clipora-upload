// ============================================================
// AI Dubbing UI — V9.183.0
// Tombol "Generate Dubbing" + Modal untuk Clipora
// ============================================================
(function () {
  "use strict";

  var _isGenerating = false;
  var _lastResult = null;

  // ============================================================
  // HELPER
  // ============================================================
  function _getApiUrl() {
    if (typeof window !== "undefined" && window.API_URL) {
      return window.API_URL.replace(/\/api$/, "");
    }
    if (window.CLIPORA_AUTH && window.CLIPORA_AUTH.apiUrl) {
      return window.CLIPORA_AUTH.apiUrl.replace(/\/api$/, "");
    }
    return window.location.origin;
  }

  function _getToken() {
    if (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) {
      return window.CLIPORA_AUTH.token;
    }
    try {
      return localStorage.getItem("clipora_token") || "";
    } catch (e) {
      return "";
    }
  }

  function _showToast(msg, type) {
    type = type || "info";
    var colors = {
      info: "#3b82f6",
      success: "#10b981",
      error: "#ef4444",
      warn: "#f59e0b",
    };
    var el = document.createElement("div");
    el.style.cssText =
      "position:fixed;bottom:30px;left:50%;transform:translateX(-50%);" +
      "padding:12px 20px;background:" +
      (colors[type] || colors.info) +
      ";color:#fff;border-radius:10px;font-size:14px;font-weight:600;" +
      "z-index:99999;box-shadow:0 10px 30px rgba(0,0,0,0.3);opacity:0;" +
      "transition:opacity 0.3s;";
    el.textContent = msg;
    document.body.appendChild(el);
    requestAnimationFrame(function () {
      el.style.opacity = "1";
    });
    setTimeout(function () {
      el.style.opacity = "0";
      setTimeout(function () {
        el.remove();
      }, 300);
    }, 2500);
  }

  function _getTranscript() {
    // Coba ambil dari berbagai sumber
    try {
      if (typeof window.getEditedWordsForClip === "function") {
        var clip = window.currentClip || null;
        if (clip) {
          var words = window.getEditedWordsForClip(clip);
          if (words && words.length) {
            return words.map(function (w) {
              return w.word || "";
            }).join(" ");
          }
        }
      }
    } catch (e) {}

    var ta = document.querySelector(
      "#acTranscript, textarea[id*='ranscript'], textarea[class*='ranscript']",
    );
    if (ta && ta.value && ta.value.trim().length > 5) {
      return ta.value.trim();
    }
    return null;
  }

  // ============================================================
  // V9.183.2: DYNAMIC_LANGS - Load bahasa dari API
  // ============================================================
  function _loadLanguages() {
    var url = _getApiUrl() + "/api/dubbing/languages";
    var token = _getToken();

    fetch(url, {
      headers: { Authorization: "Bearer " + token },
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        if (!data.success || !data.languages) return;

        var select = document.getElementById("acDubbingLang");
        if (!select) return;

        // Group: native vs fallback
        var nativeLangs = data.languages.filter(function (l) {
          return l.native;
        });
        var fallbackLangs = data.languages.filter(function (l) {
          return !l.native;
        });

        var html = "";

        // Native group
        if (nativeLangs.length > 0) {
          html += '<optgroup label="⭐ Suara Asli (' + nativeLangs.length + ' bahasa)">';
          nativeLangs.forEach(function (l) {
            html += '<option value="' + l.code + '">' + l.name + "</option>";
          });
          html += "</optgroup>";
        }

        // Fallback group
        if (fallbackLangs.length > 0) {
          html += '<optgroup label="🔊 Suara Indonesia (fallback — ' + fallbackLangs.length + ' bahasa)">';
          fallbackLangs.forEach(function (l) {
            html += '<option value="' + l.code + '">' + l.name + "</option>";
          });
          html += "</optgroup>";
        }

        select.innerHTML = html;
        console.log("[DubbingUI] Loaded " + data.languages.length + " languages (" + nativeLangs.length + " native + " + fallbackLangs.length + " fallback)");
      })
      .catch(function (e) {
        console.warn("[DubbingUI] Load languages error:", e.message);
        // Fallback ke hardcoded minimal
        var select = document.getElementById("acDubbingLang");
        if (select) {
          select.innerHTML =
            '<option value="jawa">🇮🇩 Jawa</option>' +
            '<option value="sunda">🇮🇩 Sunda</option>' +
            '<option value="melayu">🇲🇾 Melayu</option>' +
            '<option value="id">🇮🇩 Indonesia</option>';
        }
      });
  }


  // ============================================================
  // MODAL
  // ============================================================
  function openModal() {
    var existing = document.getElementById("acDubbingModal");
    if (existing) existing.remove();

    var modal = document.createElement("div");
    modal.id = "acDubbingModal";
    modal.style.cssText =
      "position:fixed;inset:0;background:rgba(0,0,0,0.75);z-index:99998;" +
      "display:flex;align-items:center;justify-content:center;" +
      "padding:20px;backdrop-filter:blur(8px);";

    var inner = document.createElement("div");
    inner.style.cssText =
      "background:#1a1d2e;border-radius:16px;max-width:640px;width:100%;" +
      "max-height:90vh;overflow-y:auto;box-shadow:0 25px 60px rgba(0,0,0,0.6);" +
      "border:1px solid rgba(59,130,246,0.3);";

    // Header
    var header = document.createElement("div");
    header.style.cssText =
      "padding:20px 24px;background:linear-gradient(135deg,rgba(59,130,246,0.15),rgba(16,185,129,0.15));" +
      "border-bottom:1px solid rgba(255,255,255,0.1);display:flex;justify-content:space-between;align-items:center;";
    header.innerHTML =
      '<div>' +
      '<div style="font-size:17px;font-weight:700;color:#fff;">🎙️ AI Dubbing Generator</div>' +
      '<div style="font-size:12px;color:#94a3b8;margin-top:4px;">Ubah audio video ke bahasa daerah dengan suara natural</div>' +
      "</div>";

    var closeBtn = document.createElement("button");
    closeBtn.textContent = "✕";
    closeBtn.style.cssText =
      "background:rgba(255,255,255,0.1);border:none;color:#fff;width:32px;height:32px;" +
      "border-radius:8px;cursor:pointer;font-size:16px;flex-shrink:0;font-family:inherit;";
    closeBtn.onclick = function () {
      modal.remove();
    };
    header.appendChild(closeBtn);

    // Body
    var body = document.createElement("div");
    body.style.cssText = "padding:20px 24px;";

    // Field: Bahasa
    var langField = document.createElement("div");
    langField.style.cssText = "margin-bottom:16px;";
    langField.innerHTML =
      '<label style="display:block;font-size:12px;font-weight:600;color:#93c5fd;margin-bottom:6px;">🌏 Bahasa</label>' +
      '<select id="acDubbingLang" style="width:100%;padding:10px 12px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#e8e8ef;font-size:13px;font-family:inherit;cursor:pointer;">' +
      '<option value="">Loading bahasa...</option>' +
      "</select>";

    // Field: Gender
    var genderField = document.createElement("div");
    genderField.style.cssText = "margin-bottom:16px;";
    genderField.innerHTML =
      '<label style="display:block;font-size:12px;font-weight:600;color:#93c5fd;margin-bottom:6px;">🎤 Suara</label>' +
      '<select id="acDubbingGender" style="width:100%;padding:10px 12px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#e8e8ef;font-size:13px;font-family:inherit;cursor:pointer;">' +
      '<option value="female">👩 Perempuan</option>' +
      '<option value="male">👨 Laki-laki</option>' +
      "</select>";

    // Field: Kecepatan
    var rateField = document.createElement("div");
    rateField.style.cssText = "margin-bottom:16px;";
    rateField.innerHTML =
      '<label style="display:block;font-size:12px;font-weight:600;color:#93c5fd;margin-bottom:6px;">⚡ Kecepatan</label>' +
      '<select id="acDubbingRate" style="width:100%;padding:10px 12px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#e8e8ef;font-size:13px;font-family:inherit;cursor:pointer;">' +
      '<option value="-10%">Lambat (-10%)</option>' +
      '<option value="+0%" selected>Normal</option>' +
      '<option value="+10%">Cepat (+10%)</option>' +
      '<option value="+20%">Lebih Cepat (+20%)</option>' +
      "</select>";

    // Field: Text
    var textField = document.createElement("div");
    textField.style.cssText = "margin-bottom:20px;";
    textField.innerHTML =
      '<label style="display:block;font-size:12px;font-weight:600;color:#93c5fd;margin-bottom:6px;">📝 Text yang akan di-dubbing</label>' +
      '<textarea id="acDubbingText" placeholder="Paste text di sini..." style="width:100%;min-height:120px;padding:12px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#e8e8ef;font-size:13px;font-family:inherit;line-height:1.5;resize:vertical;box-sizing:border-box;outline:none;"></textarea>' +
      '<div style="font-size:11px;color:#94a3b8;margin-top:6px;">Min. 2 karakter</div>';

    // Action buttons
    var actionRow = document.createElement("div");
    actionRow.style.cssText =
      "display:flex;gap:10px;justify-content:flex-end;margin-top:8px;";

    var cancelBtn = document.createElement("button");
    cancelBtn.textContent = "Batal";
    cancelBtn.style.cssText =
      "padding:10px 20px;background:rgba(255,255,255,0.08);color:#cbd5e1;" +
      "border:1px solid rgba(255,255,255,0.15);border-radius:8px;cursor:pointer;" +
      "font-size:13px;font-weight:600;font-family:inherit;";
    cancelBtn.onclick = function () {
      modal.remove();
    };

    var genBtn = document.createElement("button");
    genBtn.id = "acDubbingGenBtn";
    genBtn.textContent = "🎙️ Generate Dubbing";
    genBtn.style.cssText =
      "padding:10px 24px;background:linear-gradient(135deg,#3b82f6,#10b981);color:#fff;" +
      "border:none;border-radius:8px;cursor:pointer;font-size:13px;font-weight:700;" +
      "font-family:inherit;box-shadow:0 4px 12px rgba(59,130,246,0.3);";
    genBtn.onclick = function () {
      _generateDubbing(modal);
    };

    actionRow.appendChild(cancelBtn);
    actionRow.appendChild(genBtn);

    body.appendChild(langField);
    body.appendChild(genderField);
    body.appendChild(rateField);
    body.appendChild(textField);
    body.appendChild(actionRow);

    inner.appendChild(header);
    inner.appendChild(body);
    modal.appendChild(inner);
    document.body.appendChild(modal);

    // Load bahasa dari API (V9.183.2)
    _loadLanguages();

    // Auto-fill transcript kalau ada
    var ta = document.getElementById("acDubbingText");
    var transcript = _getTranscript();
    if (transcript && ta) {
      ta.value = transcript;
    }
    setTimeout(function () {
      if (ta) ta.focus();
    }, 100);

    // Close on backdrop
    modal.addEventListener("click", function (e) {
      if (e.target === modal) modal.remove();
    });

    // Close on ESC
    document.addEventListener("keydown", function escHandler(e) {
      if (e.key === "Escape") {
        modal.remove();
        document.removeEventListener("keydown", escHandler);
      }
    });
  }

  // ============================================================
  // GENERATE DUBBING
  // ============================================================
  function _generateDubbing(modal) {
    if (_isGenerating) {
      _showToast("Sedang generate, tunggu...", "warn");
      return;
    }

    var text = (document.getElementById("acDubbingText")?.value || "").trim();
    var langCode = document.getElementById("acDubbingLang")?.value || "jawa";
    var gender = document.getElementById("acDubbingGender")?.value || "female";
    var rate = document.getElementById("acDubbingRate")?.value || "+0%";

    if (text.length < 2) {
      _showToast("Text minimal 2 karakter", "warn");
      return;
    }

    _isGenerating = true;

    var btn = document.getElementById("acDubbingGenBtn");
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    }

    var url = _getApiUrl() + "/api/dubbing/generate";
    var token = _getToken();

    console.log("[Dubbing UI] Generating:", {
      textLength: text.length,
      langCode,
      gender,
      rate,
    });

    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify({
        text: text,
        langCode: langCode,
        gender: gender,
        rate: rate,
      }),
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        _isGenerating = false;
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = "🎙️ Generate Dubbing";
        }

        if (!data.success) {
          _showToast("Gagal: " + (data.error || "Unknown error"), "error");
          return;
        }

        _lastResult = data;
        modal.remove();
        _showResult(data);
      })
      .catch(function (e) {
        _isGenerating = false;
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = "🎙️ Generate Dubbing";
        }
        _showToast("Error: " + e.message, "error");
      });
  }

  // ============================================================
  // SHOW RESULT
  // ============================================================
  function _showResult(data) {
    var existing = document.getElementById("acDubbingResult");
    if (existing) existing.remove();

    var audioUrl = _getApiUrl() + data.audioUrl;

    var modal = document.createElement("div");
    modal.id = "acDubbingResult";
    modal.style.cssText =
      "position:fixed;inset:0;background:rgba(0,0,0,0.75);z-index:99998;" +
      "display:flex;align-items:center;justify-content:center;" +
      "padding:20px;backdrop-filter:blur(8px);";

    var langNames = {
      jawa: "Jawa",
      sunda: "Sunda",
      melayu: "Melayu",
      id: "Indonesia",
    };
    var genderNames = { male: "Laki-laki", female: "Perempuan" };

    var inner = document.createElement("div");
    inner.style.cssText =
      "background:#1a1d2e;border-radius:16px;max-width:520px;width:100%;" +
      "box-shadow:0 25px 60px rgba(0,0,0,0.6);border:1px solid rgba(16,185,129,0.3);" +
      "overflow:hidden;";

    inner.innerHTML =
      '<div style="padding:20px 24px;background:linear-gradient(135deg,rgba(16,185,129,0.15),rgba(59,130,246,0.15));border-bottom:1px solid rgba(255,255,255,0.1);display:flex;justify-content:space-between;align-items:center;">' +
      '<div style="font-size:16px;font-weight:700;color:#fff;">✅ Dubbing Berhasil!</div>' +
      "</div>" +
      '<div style="padding:24px;">' +
      '<div style="padding:14px;background:rgba(16,185,129,0.06);border-radius:10px;margin-bottom:16px;">' +
      '<div style="color:#e8e8ef;font-size:13px;margin-bottom:6px;">📁 <strong>' +
      data.audioFile +
      "</strong></div>" +
      '<div style="color:#94a3b8;font-size:12px;">📊 ' +
      data.sizeKB +
      " KB — 🎙️ " +
      (langNames[data.langCode] || data.langCode) +
      " — " +
      (genderNames[data.gender] || data.gender) +
      "</div>" +
      "</div>" +
      '<audio id="acDubbingAudio" controls style="width:100%;margin-bottom:16px;border-radius:8px;">' +
      '<source src="' +
      audioUrl +
      '" type="audio/mpeg">' +
      "</audio>" +
      '<div style="display:flex;gap:10px;">' +
      '<a href="' +
      audioUrl +
      '" download="' +
      data.audioFile +
      '" style="flex:1;padding:10px 16px;background:linear-gradient(135deg,#3b82f6,#10b981);color:#fff;border-radius:8px;text-align:center;text-decoration:none;font-size:13px;font-weight:700;">📥 Download</a>' +
      '<button id="acDubbingCloseBtn" style="flex:1;padding:10px 16px;background:rgba(255,255,255,0.08);color:#cbd5e1;border:1px solid rgba(255,255,255,0.15);border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;font-family:inherit;">Tutup</button>' +
      "</div>" +
      "</div>";

    document.body.appendChild(modal);

    document
      .getElementById("acDubbingCloseBtn")
      .addEventListener("click", function () {
        modal.remove();
      });

    modal.addEventListener("click", function (e) {
      if (e.target === modal) modal.remove();
    });
  }

  // ============================================================
  // PUBLIC API
  // ============================================================
  window.CliporaDubbing = {
    openModal: openModal,
    showToast: _showToast,
  };

  console.log("[DubbingUI] Ready. Use CliporaDubbing.openModal()");
})();
