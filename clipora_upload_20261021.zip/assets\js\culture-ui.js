// ============================================================
// V9.180.40: CULTURE_UI
// Frontend UI untuk AI Local Culture & Slang Adaptation
// ============================================================

(function() {
  "use strict";

  // State
  var _cultureState = {
    regions: [],
    selected: null,
    loaded: false,
    apiUrl: null,
    token: null,
  };

  // ============================================================
  // HELPER
  // ============================================================
  function _getApiUrl() {
    // V9.180.61: PAKAI window.API_URL (variabel global Clipora)
    if (typeof window !== "undefined" && window.API_URL) {
      // API_URL = "http://localhost:3000/api"
      // Kita perlu base tanpa "/api"
      return window.API_URL.replace(/\/api$/, "");
    }

    // Fallback: kalau CLIPORA_AUTH.apiUrl ada
    if (window.CLIPORA_AUTH && window.CLIPORA_AUTH.apiUrl) {
      return window.CLIPORA_AUTH.apiUrl.replace(/\/api$/, "");
    }

    // Fallback terakhir: cek port
    var origin = window.location.origin;
    if (origin === "http://localhost" || origin === "http://127.0.0.1") {
      return origin + ":3000";
    }
    return origin;
  }

  function _getToken() {
    if (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) {
      return window.CLIPORA_AUTH.token;
    }
    try {
      return localStorage.getItem("clipora_token") || "";
    } catch (e) {
      return "";
    }
  }

  // ============================================================
  // LOAD REGIONS
  // ============================================================
  async function loadRegions() {
    if (_cultureState.loaded && _cultureState.regions.length > 0) {
      return _cultureState.regions;
    }

    try {
      var api = _getApiUrl();
      var url = api + "/api/culture/regions";

      console.log("[CultureUI] Loading regions from:", url);

      var res = await fetch(url, {
        headers: {
          "Authorization": "Bearer " + _getToken(),
        },
      });

      if (!res.ok) {
        console.warn("[CultureUI] Load failed:", res.status);
        return [];
      }

      var data = await res.json();
      if (data.success && data.regions) {
        _cultureState.regions = data.regions;
        _cultureState.loaded = true;
        console.log("[CultureUI] Loaded", data.regions.length, "regions");
        return data.regions;
      }
    } catch (e) {
      console.warn("[CultureUI] Error:", e.message);
    }
    return [];
  }

  // ============================================================
  // ADAPT TEXT (Preview)
  // ============================================================
  async function adaptText(text, regionKey) {
    if (!text || !regionKey) return text;

    try {
      var api = _getApiUrl();
      var res = await fetch(api + "/api/culture/adapt-text", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + _getToken(),
        },
        body: JSON.stringify({ text: text, region: regionKey }),
      });

      if (!res.ok) return text;

      var data = await res.json();
      if (data.success) {
        return data.adapted || text;
      }
    } catch (e) {
      console.warn("[CultureUI] Adapt error:", e.message);
    }
    return text;
  }

  // ============================================================
  // RENDER UI
  // ============================================================
  function renderSelector(container) {
    if (!container) return;

    var regions = _cultureState.regions;

    var html = '<div class="ac-culture-panel">';
    html += '  <div class="ac-culture-header">';
    html += '    <i class="fas fa-globe-asia"></i>';
    html += '    <span class="ac-culture-title">Bahasa Daerah</span>';
    html += '    <span class="ac-culture-badge">' + regions.length + ' bahasa</span>';
    html += '  </div>';

    html += '  <div class="ac-culture-body">';
    html += '    <label class="ac-culture-label">Pilih bahasa untuk adaptasi subtitle:</label>';
    html += '    <select class="ac-culture-select" id="acCultureSelect">';
    html += '      <option value="">🌐 Bahasa Indonesia (default)</option>';

    regions.forEach(function(r) {
      var flag = r.flag || "🌐";
      var name = r.name || r.key;
      var lang = r.language || "";
      html += '      <option value="' + r.key + '">' + flag + ' ' + name + ' (' + lang + ')</option>';
    });

    html += '    </select>';

    html += '    <div class="ac-culture-preview" id="acCulturePreview" style="display:none;">';
    html += '      <div class="ac-culture-preview-label">Preview:</div>';
    html += '      <div class="ac-culture-preview-item">';
    html += '        <span class="ac-culture-preview-tag">Original:</span>';
    html += '        <span id="acCultureOriginal"></span>';
    html += '      </div>';
    html += '      <div class="ac-culture-preview-item">';
    html += '        <span class="ac-culture-preview-tag" style="color:#22c55e;">Adapted:</span>';
    html += '        <span id="acCultureAdapted" style="color:#22c55e;"></span>';
    html += '      </div>';
    html += '    </div>';

    html += '    <div class="ac-culture-info" id="acCultureInfo"></div>';
    html += '  </div>';
    html += '</div>';

    container.innerHTML = html;

    // Bind event
    var select = container.querySelector("#acCultureSelect");
    if (select) {
      select.addEventListener("change", function() {
        var key = this.value;
        _cultureState.selected = key || null;
        console.log("[CultureUI] Selected:", key);
        _updatePreview(key);
        _updateInfo(key);

        // Trigger event untuk render pipeline
        try {
          window.dispatchEvent(new CustomEvent("culture:changed", {
            detail: { region: key }
          }));
        } catch (e) {}
      });
    }
  }

  // ============================================================
  // PREVIEW UPDATE
  // ============================================================
  async function _updatePreview(regionKey) {
    var previewEl = document.getElementById("acCulturePreview");
    var originalEl = document.getElementById("acCultureOriginal");
    var adaptedEl = document.getElementById("acCultureAdapted");

    if (!previewEl || !originalEl || !adaptedEl) return;

    if (!regionKey) {
      previewEl.style.display = "none";
      return;
    }

    // Ambil sample text dari caption klip pertama (kalau ada)
    var sampleText = "Gila, ini keren banget! Aku suka.";
    try {
      if (window.__TL_STATE && window.__TL_STATE.clips && window.__TL_STATE.clips.length > 0) {
        var firstClip = window.__TL_STATE.clips[0];
        if (firstClip.preview_text) {
          sampleText = firstClip.preview_text;
        } else if (firstClip.caption) {
          sampleText = firstClip.caption;
        }
      }
    } catch (e) {}

    originalEl.textContent = sampleText;
    previewEl.style.display = "block";

    adaptedEl.textContent = "Memproses...";
    adaptedEl.style.opacity = "0.5";

    var adapted = await adaptText(sampleText, regionKey);
    adaptedEl.textContent = adapted;
    adaptedEl.style.opacity = "1";
  }

  // ============================================================
  // INFO UPDATE
  // ============================================================
  async function _updateInfo(regionKey) {
    var infoEl = document.getElementById("acCultureInfo");
    if (!infoEl) return;

    if (!regionKey) {
      infoEl.innerHTML = "";
      return;
    }

    // Ambil region info dari state
    var region = _cultureState.regions.find(function(r) { return r.key === regionKey; });
    if (!region) {
      infoEl.innerHTML = "";
      return;
    }

    infoEl.innerHTML = '  <div class="ac-culture-info-item">' +
      '<i class="fas fa-info-circle"></i> ' +
      'Bahasa ' + region.name + ' akan diterapkan ke subtitle video.' +
      '</div>';
  }

  // ============================================================
  // PUBLIC API
  // ============================================================
  window.CliporaCulture = {
    loadRegions: loadRegions,
    adaptText: adaptText,
    getSelected: function() { return _cultureState.selected; },
    setSelected: function(key) { _cultureState.selected = key; },
    render: function(containerId) {
      var container = document.getElementById(containerId);
      if (!container) {
        console.warn("[CultureUI] Container tidak ditemukan:", containerId);
        return;
      }

      container.innerHTML = '<div style="text-align:center;padding:20px;color:#94a3b8;">' +
        '<i class="fas fa-spinner fa-spin"></i> Loading bahasa daerah...</div>';

      loadRegions().then(function(regions) {
        if (regions.length === 0) {
          container.innerHTML = '<div style="text-align:center;padding:20px;color:#ef4444;">' +
            '<i class="fas fa-exclamation-triangle"></i> Gagal load bahasa daerah</div>';
          return;
        }
        renderSelector(container);
      });
    },
  };

  console.log("[CultureUI] Ready. Use CliporaCulture.render('containerId')");
})();
