﻿<?php
require_once __DIR__ . '/config/config.php';
if (!$isLoggedIn) { header('Location: login.php'); exit; }
require_once __DIR__ . '/includes/header.php';
?>
<link rel="icon" href="logo_clipora.png" type="image/png">
<link rel="shortcut icon" href="logo_clipora1.png" type="image/png">

<style>
    .history-hero {
        text-align: center;
        padding: 40px 20px 24px;
        max-width: 800px;
        margin: 0 auto;
    }
    .history-hero h1 {
        font-size: 2rem;
        font-weight: 800;
        margin-bottom: 10px;
        background: linear-gradient(135deg, #f59e0b, #8b5cf6);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    .history-hero p {
        color: var(--text-muted, #94a3b8);
        font-size: 0.95rem;
        line-height: 1.6;
    }

    .history-toolbar {
        max-width: 900px;
        margin: 0 auto 20px;
        display: flex;
        gap: 12px;
        align-items: center;
        padding: 0 20px;
    }
    .history-search {
        flex: 1;
        padding: 12px 16px;
        background: rgba(0, 0, 0, 0.3);
        border: 1px solid rgba(139, 92, 246, 0.25);
        border-radius: 12px;
        color: #fff;
        font-family: inherit;
        font-size: 0.9rem;
        outline: none;
    }
    .history-search:focus {
        border-color: #8b5cf6;
        box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15);
    }
    .history-new-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 22px;
        background: linear-gradient(135deg, #f59e0b, #d97706);
        color: #fff;
        text-decoration: none;
        border-radius: 12px;
        font-weight: 700;
        font-size: 0.9rem;
        white-space: nowrap;
        transition: 0.2s;
        box-shadow: 0 4px 16px rgba(245, 158, 11, 0.3);
    }
    .history-new-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(245, 158, 11, 0.4);
    }

    .history-stats {
        max-width: 900px;
        margin: 0 auto 24px;
        padding: 0 20px;
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }
    .history-stat {
        background: rgba(139, 92, 246, 0.06);
        border: 1px solid rgba(139, 92, 246, 0.15);
        border-radius: 12px;
        padding: 14px 20px;
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 140px;
    }
    .history-stat i {
        font-size: 1.3rem;
        color: #a78bfa;
    }
    .history-stat-num {
        font-size: 1.4rem;
        font-weight: 800;
        color: #fff;
        line-height: 1;
    }
    .history-stat-lbl {
        font-size: 0.7rem;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-top: 4px;
        font-weight: 700;
    }

    .history-grid-wrap {
        max-width: 900px;
        margin: 0 auto;
        padding: 0 20px 60px;
    }
    .history-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
        gap: 14px;
    }
    .ac-proj-card {
        display: flex;
        flex-direction: column;
        padding: 0;
        overflow: hidden;
    }
    .ac-proj-thumb {
        position: relative;
        width: 100%;
        aspect-ratio: 16 / 9;
        background: linear-gradient(135deg, rgba(139, 92, 246, 0.15), rgba(6, 182, 212, 0.1));
        overflow: hidden;
        cursor: pointer;
    }
    .ac-proj-thumb.no-thumb {
        background: linear-gradient(135deg, #1a1a2e, #16213e);
    }
    .ac-proj-thumb.no-thumb::before {
        content: '\f03d';
        font-family: 'Font Awesome 6 Free';
        font-weight: 900;
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.5rem;
        color: rgba(255,255,255,0.3);
    }
    .ac-proj-thumb-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
        transition: transform 0.3s;
    }
    .ac-proj-card:hover .ac-proj-thumb-img {
        transform: scale(1.05);
    }
    .ac-proj-thumb-overlay {
        position: absolute;
        inset: 0;
        background: rgba(0,0,0,0.4);
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.2s;
    }
    .ac-proj-card:hover .ac-proj-thumb-overlay {
        opacity: 1;
    }
    .ac-proj-thumb-overlay i {
        font-size: 3rem;
        color: #fff;
        text-shadow: 0 2px 12px rgba(0,0,0,0.8);
    }
    .ac-proj-body {
        padding: 14px 16px 16px;
        display: flex;
        flex-direction: column;
        flex: 1;
    }
    .ac-proj-file {
        font-size: 0.7rem;
        color: #64748b;
        margin-bottom: 10px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    .ac-proj-file i {
        opacity: 0.6;
        font-size: 0.65rem;
    }
    .ac-proj-card {
        background: rgba(0, 0, 0, 0.25);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 14px;
        padding: 16px;
        transition: 0.2s;
        position: relative;
    }
    .ac-proj-card:hover {
        background: rgba(139, 92, 246, 0.06);
        border-color: rgba(139, 92, 246, 0.3);
        transform: translateY(-2px);
    }
    .ac-proj-name {
        font-size: 0.92rem;
        font-weight: 700;
        color: #e8e8ef;
        margin-bottom: 8px;
        padding-right: 60px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .ac-proj-meta {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        font-size: 0.72rem;
        color: #94a3b8;
        margin-bottom: 12px;
    }
    .ac-proj-meta span {
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    .ac-proj-progress {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 12px;
    }
    .ac-proj-bar {
        flex: 1;
        height: 5px;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 3px;
        overflow: hidden;
    }
    .ac-proj-bar-fill {
        height: 100%;
        background: linear-gradient(90deg, #22c55e, #06b6d4);
        transition: width 0.3s;
    }
    .ac-proj-count {
        font-size: 0.72rem;
        font-weight: 700;
        color: #22c55e;
        white-space: nowrap;
    }
    .ac-proj-badge {
        position: absolute;
        top: 12px;
        right: 12px;
        font-size: 0.6rem;
        font-weight: 800;
        padding: 4px 9px;
        border-radius: 8px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .ac-proj-badge.draft { background: rgba(148, 163, 184, 0.15); color: #94a3b8; }
    .ac-proj-badge.partial { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }
    .ac-proj-badge.completed { background: rgba(34, 197, 94, 0.15); color: #22c55e; }
    .ac-proj-actions {
        display: flex;
        gap: 8px;
    }
    .ac-proj-btn {
        padding: 9px 14px;
        border-radius: 10px;
        border: none;
        font-size: 0.78rem;
        font-weight: 700;
        cursor: pointer;
        font-family: inherit;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        transition: 0.15s;
    }
    .ac-proj-btn-open {
        flex: 1;
        background: linear-gradient(135deg, #8b5cf6, #06b6d4);
        color: #fff;
    }
    .ac-proj-btn-open:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
    }
    .ac-proj-btn-del {
        padding: 9px 12px;
        background: rgba(239, 68, 68, 0.1);
        border: 1px solid rgba(239, 68, 68, 0.25);
        color: #f87171;
    }
    .ac-proj-btn-del:hover {
        background: rgba(239, 68, 68, 0.2);
        color: #ef4444;
    }

    .history-empty {
        text-align: center;
        padding: 60px 20px;
        background: rgba(0, 0, 0, 0.15);
        border: 1px dashed rgba(139, 92, 246, 0.3);
        border-radius: 16px;
    }
    .history-empty i {
        font-size: 3rem;
        color: rgba(139, 92, 246, 0.4);
        margin-bottom: 14px;
        display: block;
    }
    .history-empty h3 {
        font-size: 1.1rem;
        color: #fff;
        margin-bottom: 8px;
    }
    .history-empty p {
        color: #94a3b8;
        font-size: 0.9rem;
        margin-bottom: 20px;
    }

    .history-loading {
        text-align: center;
        padding: 60px;
        color: #94a3b8;
    }
    .history-loading i {
        font-size: 2rem;
        animation: hist-spin 1s linear infinite;
    }
    @keyframes hist-spin {
        to { transform: rotate(360deg); }
    }

    @media (max-width: 600px) {
        .history-toolbar { flex-direction: column; }
        .history-search { width: 100%; }
        .history-new-btn { width: 100%; justify-content: center; }
    }
</style>

<div class="history-hero">
    <h1>📁 Proyek Auto-Clip Saya</h1>
    <p>Semua proyek Auto-Clip yang sudah kamu simpan — lanjutkan kapan saja</p>
</div>

<div class="history-toolbar">
    <input type="text" id="histSearch" class="history-search" placeholder="🔍 Cari proyek...">
    <a href="autoclip.php" class="history-new-btn">
        <i class="fas fa-plus"></i> Buat Proyek Baru
    </a>
</div>

<div class="history-stats" id="histStats" style="display:none;">
    <div class="history-stat">
        <i class="fas fa-folder-open"></i>
        <div>
            <div class="history-stat-num" id="statTotal">0</div>
            <div class="history-stat-lbl">Total Proyek</div>
        </div>
    </div>
    <div class="history-stat">
        <i class="fas fa-film"></i>
        <div>
            <div class="history-stat-num" id="statClips">0</div>
            <div class="history-stat-lbl">Total Klip</div>
        </div>
    </div>
    <div class="history-stat">
        <i class="fas fa-check-circle" style="color: #22c55e;"></i>
        <div>
            <div class="history-stat-num" id="statRendered">0</div>
            <div class="history-stat-lbl">Ter-render</div>
        </div>
    </div>
</div>

<div class="history-grid-wrap">
    <div id="histContainer">
        <div class="history-loading">
            <i class="fas fa-spinner"></i>
            <p style="margin-top:12px;">Memuat proyek...</p>
        </div>
    </div>
</div>

<script>
(function() {
    'use strict';

    var _container = document.getElementById('histContainer');
    var _search = document.getElementById('histSearch');
    var _statsBox = document.getElementById('histStats');
    var allProjects = [];

    function _getApi() {
        return (typeof window !== 'undefined' && window.API) ? window.API
             : (window.API_URL || 'http://localhost:3000/api');
    }
    function _getToken() {
        // Coba semua kemungkinan sumber token
        if (typeof window !== 'undefined' && window.TOKEN) return window.TOKEN;
        if (window.AUTH_TOKEN) return window.AUTH_TOKEN;
        if (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) return window.CLIPORA_AUTH.token;
        try {
            var ls = localStorage.getItem('auth_token');
            if (ls) return ls;
            var ls2 = localStorage.getItem('clipora_token');
            if (ls2) return ls2;
        } catch (e) {}
        return '';
    }
    function _esc(str) {
        return String(str == null ? '' : str)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
    function _fmtDate(iso) {
        if (!iso) return '-';
        try {
            var d = new Date(iso);
            var diff = (Date.now() - d) / 1000;
            if (diff < 60) return 'baru saja';
            if (diff < 3600) return Math.floor(diff / 60) + 'm lalu';
            if (diff < 86400) return Math.floor(diff / 3600) + 'j lalu';
            if (diff < 604800) return Math.floor(diff / 86400) + 'h lalu';
            return d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
        } catch (e) { return '-'; }
    }

    function _renderCard(p) {
        var total = p.total_clips || 0;
        var done = p.rendered_count || 0;
        var pct = total > 0 ? Math.round((done / total) * 100) : 0;
        var status = p.status || 'draft';

        // V9.17.0: Ambil thumbnail dari klip pertama
        var thumbHtml;
        if (p.first_thumb_file) {
            var api = _getApi();
            var tok = _getToken();
            var thumbUrl = api + '/autoclip-projects/' + p.id + '/thumbnail?file=' + encodeURIComponent(p.first_thumb_file) + '&token=' + encodeURIComponent(tok);
            thumbHtml = '<img src="' + thumbUrl + '" alt="" class="ac-proj-thumb-img" onerror="this.style.display=\'none\';this.parentElement.classList.add(\'no-thumb\');">';
        } else {
            thumbHtml = '';
        }

        // Nama file video (basename)
        var fileName = '';
        if (p.input_video_path) {
            var parts = String(p.input_video_path).split(/[\\\/]/);
            fileName = parts[parts.length - 1] || '';
            // Potong hash angka
            fileName = fileName.replace(/^\d+_/, '').slice(0, 30);
        }

        var durText = '';
        if (p.first_clip_duration) {
            durText = Math.round(parseFloat(p.first_clip_duration)) + 's';
        }

        return '<div class="ac-proj-card" data-id="' + _esc(p.id) + '">'
            + '<div class="ac-proj-thumb">' + thumbHtml
            +   '<div class="ac-proj-thumb-overlay"><i class="fas fa-play-circle"></i></div>'
            +   '<div class="ac-proj-badge ' + status + '">' + status + '</div>'
            + '</div>'
            + '<div class="ac-proj-body">'
            + '<div class="ac-proj-name" title="' + _esc(p.name) + '">' + _esc(p.name) + '</div>'
            + '<div class="ac-proj-meta">'
            +   '<span><i class="fas fa-clock"></i> ' + _fmtDate(p.updated_at || p.created_at) + '</span>'
            +   '<span><i class="fas fa-film"></i> ' + total + ' klip</span>'
            +   (durText ? '<span><i class="fas fa-hourglass-half"></i> ' + durText + '</span>' : '')
            + '</div>'
            + (fileName ? '<div class="ac-proj-file" title="' + _esc(p.input_video_path) + '"><i class="fas fa-video"></i> ' + _esc(fileName) + '</div>' : '')
            + '<div class="ac-proj-progress">'
            +   '<div class="ac-proj-bar"><div class="ac-proj-bar-fill" style="width:' + pct + '%"></div></div>'
            +   '<span class="ac-proj-count">' + done + '/' + total + '</span>'
            + '</div>'
            + '<div class="ac-proj-actions">'
            +   '<button type="button" class="ac-proj-btn ac-proj-btn-open" data-action="open" data-id="' + _esc(p.id) + '">'
            +   '<i class="fas fa-folder-open"></i> Buka'
            +   '</button>'
            +   '<button type="button" class="ac-proj-btn ac-proj-btn-del" data-action="delete" data-id="' + _esc(p.id) + '" title="Hapus">'
            +   '<i class="fas fa-trash"></i>'
            +   '</button>'
            + '</div>'
            + '</div>'
            + '</div>';
    }

    function render() {
        var q = (_search.value || '').trim().toLowerCase();
        var list = q ? allProjects.filter(function(p) {
            return (p.name || '').toLowerCase().indexOf(q) !== -1;
        }) : allProjects;

        if (!allProjects.length) {
            _container.innerHTML = '<div class="history-empty">'
                + '<i class="fas fa-folder-open"></i>'
                + '<h3>Belum ada proyek</h3>'
                + '<p>Mulai bikin proyek Auto-Clip pertama kamu</p>'
                + '<a href="autoclip.php" class="history-new-btn" style="display:inline-flex;">'
                + '<i class="fas fa-plus"></i> Buat Sekarang'
                + '</a></div>';
            _statsBox.style.display = 'none';
            return;
        }

        if (!list.length) {
            _container.innerHTML = '<div class="history-empty">'
                + '<i class="fas fa-search"></i>'
                + '<h3>Tidak ada hasil</h3>'
                + '<p>Coba kata kunci lain</p></div>';
            return;
        }

        _container.innerHTML = '<div class="history-grid">' + list.map(_renderCard).join('') + '</div>';
        _statsBox.style.display = 'flex';
    }

    async function loadProjects() {
        try {
            var token = _getToken();
            console.log('[History] Token yang digunakan:', token ? 'ADA (panjang: ' + token.length + ')' : 'KOSONG');
            
            var res = await fetch(_getApi() + '/autoclip-projects', {
                headers: { 'Authorization': 'Bearer ' + token },
                credentials: 'same-origin'
            });
            
            console.log('[History] Response status:', res.status);
            
            if (!res.ok) {
                var errText = await res.text();
                console.error('[History] Server error response:', errText);
                throw new Error('HTTP ' + res.status + ' - ' + errText);
            }
            
            var data = await res.json();
            console.log('[History] Data dari server:', data);
            
            if (data.success && Array.isArray(data.projects)) {
                allProjects = data.projects;
                var totalClips = 0, totalRendered = 0;
                allProjects.forEach(function(p) {
                    totalClips += (p.total_clips || 0);
                    totalRendered += (p.rendered_count || 0);
                });
                document.getElementById('statTotal').textContent = allProjects.length;
                document.getElementById('statClips').textContent = totalClips;
                document.getElementById('statRendered').textContent = totalRendered;
                render();
                console.log('[History] Loaded:', allProjects.length, 'proyek');
            }
        } catch (e) {
            console.warn('[History] Error:', e);
            _container.innerHTML = '<div class="history-empty">'
                + '<i class="fas fa-exclamation-triangle" style="color:#ef4444;"></i>'
                + '<h3>Gagal memuat</h3>'
                + '<p>' + _esc(e.message) + '</p></div>';
        }
    }

    async function deleteProject(id, name) {
        var ok = window.showConfirm
            ? await window.showConfirm({
                title: 'Hapus Proyek?',
                message: 'Yakin hapus "' + name + '"? File video juga akan dihapus.',
                type: 'warning',
                okText: 'Ya, Hapus',
                cancelText: 'Batal'
            })
            : confirm('Hapus "' + name + '"?');
        if (!ok) return;

        try {
            var res = await fetch(_getApi() + '/autoclip-projects/' + id, {
                method: 'DELETE',
                headers: { 'Authorization': 'Bearer ' + _getToken() },
                credentials: 'same-origin'
            });
            var data = await res.json();
            if (data.success) {
                if (typeof toastSuccess === 'function') toastSuccess('Proyek dihapus');
                loadProjects();
            } else {
                if (typeof toastError === 'function') toastError(data.error || 'Gagal hapus');
            }
        } catch (e) {
            console.warn('[History] Delete error:', e.message);
        }
    }

    function openProject(id) {
        // Redirect ke autoclip.php?project=xxx
        window.location.href = 'autoclip.php?project=' + encodeURIComponent(id);
    }

    _container.addEventListener('click', function(e) {
        var btn = e.target.closest('.ac-proj-btn');
        if (!btn) return;
        e.stopPropagation();
        var id = btn.dataset.id;
        var action = btn.dataset.action;
        if (action === 'open') openProject(id);
        else if (action === 'delete') {
            var card = btn.closest('.ac-proj-card');
            var name = card ? card.querySelector('.ac-proj-name').textContent : '';
            deleteProject(id, name);
        }
    });

    _search.addEventListener('input', render);

    // V9.12.2: Tunggu token tersedia
    var _initTries = 0;
    function _initLoad() {
        _initTries++;
        var token = _getToken();
        if (!token && _initTries < 20) {
            setTimeout(_initLoad, 300);
            return;
        }
        if (!token) {
            console.warn('[History] Token tidak tersedia setelah retry');
            _container.innerHTML = '<div class="history-empty">'
                + '<i class="fas fa-exclamation-triangle" style="color:#ef4444;"></i>'
                + '<h3>Perlu Login</h3>'
                + '<p>Silakan login ulang untuk melihat proyek.</p>'
                + '<a href="login.php" class="history-new-btn" style="display:inline-flex;">'
                + '<i class="fas fa-sign-in-alt"></i> Login'
                + '</a></div>';
            return;
        }
        loadProjects();
    }
    _initLoad();
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>