#!/usr/bin/env python3
# caption_style.py — Clipora V8.8.4 Auto-Caption Style
# ============================================================
# Konversi SRT → ASS dengan preset style subtitle profesional.
#
# Preset: mrbeast, hormozi, tiktok, clean, podcast
#
# CHANGELOG:
#  V8.8.4 (current):
#   - FIX tiktok: outline magenta tebal → outline hitam tipis
#     (sebelumnya terlihat seperti kotak magenta jelek)
#   - FIX podcast: outline 8→6, shadow 4→3 (lebih proporsional)
#   - FIX mrbeast: outline 7→6, shadow 3→2 (cleaner)
#   - Tambah PRESET_META untuk dokumentasi visual tiap style
#  V8.8.1:
#   - FIX CRITICAL: prefix "Style: " di ASS_HEADER
#   - Support play_res untuk vertical (1080x1920)
# ============================================================

import os
import re
import sys

# ============================================================
# ASS HEADER
# ============================================================
# ⚠️ WAJIB ada "Style: " di depan {styles}. Kalau tidak, libass
# akan SKIP line ini dan fallback ke default internal (Arial
# ~20px putih polos → subtitle terlihat kecil & salah warna).
ASS_HEADER = """[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.601
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: {styles}

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


# ============================================================
# PRESET STYLES
# ============================================================
# Rumus warna ASS: &HAABBGGRR (AA=alpha, BB=blue, GG=green, RR=red)
# Contoh: &H0000E6FF = kuning (R=FF, G=E6, B=00)
#
# BorderStyle:
#   1 = Outline (garis tepi mengikuti huruf)  ← pakai ini untuk
#       subtitle yang terlihat clean, tidak seperti kotak
#   3 = Opaque Box (kotak solid di belakang teks) ← pakai untuk
#       style Mr.Hormozi yang memang kotak
#
# Outline (px) — ketebalan garis tepi:
#   1-2 = tipis (clean/minimal)
#   3-4 = sedang (TikTok, standard)
#   5-6 = tebal (MrBeast, podcast)
#   7+  = sangat tebal (bisa nyambung antar huruf — hindari)
#
# Shadow (px) — bayangan di belakang teks:
#   0   = tanpa bayangan
#   1-2 = halus
#   3-4 = tebal (untuk kontras tinggi)
# ============================================================

PRESETS = {
    # --------------------------------------------------------
    # ✨ CLEAN PRO — Default, paling universal, paling profesional
    # Putih bold dengan outline hitam sedang, tanpa kotak
    # Cocok untuk: SEMUA JENIS KONTEN
    # --------------------------------------------------------
    "clean": {
        "label": "✨ Clean Pro — Putih Bersih (Rekomendasi)",
        "style_line": (
            "Default,Rubik,85,"
            "&H00FFFFFF,"               # putih
            "&H00FFFFFF,"               # putih
            "&H00000000,"               # outline hitam
            "&H80000000,"               # back transparan
            "-1,0,0,0,"                 # bold
            "100,100,0,0,"
            "1,3,2,"                    # Outline=3, Shadow=2
            "2,80,80,110,1"
        ),
    },

    # --------------------------------------------------------
    # 🔥 MRBEAST — Kuning bold outline tebal
    # Cocok untuk: Shorts, Reels, konten viral
    # --------------------------------------------------------
    "mrbeast": {
        "label": "🔥 MrBeast — Kuning Bold",
        "style_line": (
            "Default,Rubik,90,"
            "&H0000E6FF,"               # kuning
            "&H0000E6FF,"               # kuning
            "&H00000000,"               # outline hitam
            "&H80000000,"               # back transparan
            "-1,0,0,0,"
            "100,100,0,0,"
            "1,5,2,"                    # Outline=5 (sedikit lebih tipis dari 6)
            "2,60,60,120,1"
        ),
    },

    # --------------------------------------------------------
    # 💪 HORMOZI — Putih dengan KOTAK HITAM solid
    # ⚠️ Ini style yang kamu lihat di screenshot. Kotak hitam by design.
    # Cocok untuk: quote motivasi, edukasi bisnis (gaya Alex Hormozi asli)
    # --------------------------------------------------------
    "hormozi": {
        "label": "💪 Hormozi — Putih Box Hitam",
        "style_line": (
            "Default,Rubik,85,"
            "&H00FFFFFF,"               # putih
            "&H00FFFFFF,"               # putih
            "&H00000000,"               # outline hitam
            "&HD0000000,"               # back hitam 82% (kotak)
            "-1,0,0,0,"
            "100,100,0,0,"
            "3,3,0,"                    # BorderStyle=3 = KOTAK
            "2,80,80,120,1"
        ),
    },

    # --------------------------------------------------------
    # 🎵 TIKTOK — Putih clean outline tipis
    # Cocok untuk: TikTok modern, lifestyle, tutorial
    # --------------------------------------------------------
    "tiktok": {
        "label": "🎵 TikTok — Putih Pop",
        "style_line": (
            "Default,Rubik,88,"
            "&H00FFFFFF,"               # putih
            "&H00FFFFFF,"               # putih
            "&H00000000,"               # outline HITAM (bukan magenta)
            "&H80000000,"               # back transparan
            "-1,0,0,0,"
            "100,100,0,0,"
            "1,2,1,"                    # Outline=2, Shadow=1 — paling tipis
            "2,60,60,120,1"
        ),
    },

    # --------------------------------------------------------
    # 🎙️ PODCAST — Putih besar untuk podcast
    # --------------------------------------------------------
    "podcast": {
        "label": "🎙️ Podcast — Putih Besar",
        "style_line": (
            "Default,Rubik,100,"
            "&H00FFFFFF,"
            "&H00FFFFFF,"
            "&H00000000,"
            "&H80000000,"
            "-1,0,0,0,"
            "100,100,0,0,"
            "1,4,2,"                    # Outline=4
            "2,80,80,140,1"
        ),
    },
}


# ============================================================
# PRESET METADATA (untuk API / UI documentation)
# ============================================================
PRESET_META = {
    "mrbeast": {
        "color": "#FFE600",
        "color_name": "Kuning",
        "best_for": "Shorts, Reels, konten viral motivasi",
        "visual": "Kuning bold dengan outline hitam tebal",
    },
    "hormozi": {
        "color": "#FFFFFF",
        "color_name": "Putih",
        "best_for": "Edukasi bisnis, quote motivasi, tips",
        "visual": "Putih bold dengan kotak hitam semi-transparan",
    },
    "tiktok": {
        "color": "#FFFFFF",
        "color_name": "Putih",
        "best_for": "TikTok, Reels, Shorts — clean modern",
        "visual": "Putih clean dengan outline hitam tipis",
    },
    "clean": {
        "color": "#FFFFFF",
        "color_name": "Putih",
        "best_for": "Tutorial, edukasi serius, dokumenter",
        "visual": "Putih minimalis tanpa bold, outline tipis",
    },
    "podcast": {
        "color": "#FFFFFF",
        "color_name": "Putih",
        "best_for": "Podcast panjang, wawancara, talk show",
        "visual": "Putih bold besar dengan outline tebal",
    },
}


def get_available_styles():
    """Return list of presets untuk API endpoint /caption-styles."""
    return [{"code": code, "label": data["label"]} for code, data in PRESETS.items()]


def get_style_meta(style):
    """Return metadata untuk style tertentu (warna, use case)."""
    return PRESET_META.get(style, {})


# ============================================================
# TIME CONVERSION
# ============================================================
# ============================================================
# V9.146.0: CUSTOM OVERRIDE — modify style_line dari user input
# ============================================================
def _modify_style_line(style_line, custom):
    """
    Modify style_line ASS dengan custom override dari user.
    
    Format ASS style_line (comma-separated):
    Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,
    Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,
    Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
    
    custom dict boleh punya key:
    - font: string (Fontname)
    - size: int (Fontsize)
    - color: hex string "#RRGGBB" (PrimaryColour) → convert ke ASS format
    - outline_color: hex string (OutlineColour)
    - outline_width: int (Outline)
    - shadow: int (Shadow)
    - position: "top"|"middle"|"bottom" (Alignment)
    - bold: bool (Bold)
    - bg_enabled: bool (BorderStyle 3=box, 1=outline)
    - bg_color: hex (BackColour)
    - bg_opacity: float 0-1
    """
    if not custom:
        return style_line
    
    parts = style_line.split(",")
    if len(parts) < 23:
        return style_line
    
    # Helper: hex "#FFFFFF" → ASS "&H00FFFFFF" (AABBGGRR)
    def hex_to_ass(hex_color, alpha_hex="00"):
        hex_color = hex_color.lstrip("#").upper()
        if len(hex_color) != 6:
            return None
        R = hex_color[0:2]
        G = hex_color[2:4]
        B = hex_color[4:6]
        return f"&H{alpha_hex}{B}{G}{R}"
    
    # Apply overrides
    if custom.get("font"):
        parts[1] = str(custom["font"]).strip()
    
    if custom.get("size"):
        try:
            parts[2] = str(int(custom["size"]))
        except:
            pass
    
    if custom.get("color"):
        ass_color = hex_to_ass(custom["color"])
        if ass_color:
            parts[3] = ass_color
    
    if custom.get("outline_color"):
        ass_outline = hex_to_ass(custom["outline_color"])
        if ass_outline:
            parts[5] = ass_outline
    
    if custom.get("bold") is not None:
        parts[7] = "-1" if custom["bold"] else "0"
    
    if custom.get("outline_width") is not None:
        try:
            parts[16] = str(int(custom["outline_width"]))
        except:
            pass
    
    if custom.get("shadow") is not None:
        try:
            parts[17] = str(int(custom["shadow"]))
        except:
            pass
    
    # Position: 1=bottom-left, 2=bottom-center, 3=bottom-right,
    #           4=middle-left, 5=middle-center, 6=middle-right,
    #           7=top-left, 8=top-center, 9=top-right
    position_map = {
        "bottom": "2",
        "middle": "5",
        "top": "8",
    }
    if custom.get("position") and custom["position"] in position_map:
        parts[18] = position_map[custom["position"]]
    
    # Background box
    if custom.get("bg_enabled") is not None:
        if custom["bg_enabled"]:
            parts[15] = "3"  # BorderStyle: Opaque Box
            # Background color with opacity
            bg_color = custom.get("bg_color", "#000000")
            bg_opacity = float(custom.get("bg_opacity", 0.5))
            # Alpha: 0=opaque, 255=transparent
            alpha_hex = format(int((1 - bg_opacity) * 255), "02X")
            ass_bg = hex_to_ass(bg_color, alpha_hex)
            if ass_bg:
                parts[6] = ass_bg  # BackColour
            # Disable shadow kalau box
            parts[17] = "0"
        else:
            parts[15] = "1"  # BorderStyle: Outline (default)
    
    return ",".join(parts)


def _srt_time_to_ass(srt_time):
    """Convert SRT time '00:00:01,234' → ASS time '0:00:01.23'."""
    m = re.match(r"(\d+):(\d+):(\d+)[,.](\d+)", srt_time.strip())
    if not m:
        return "0:00:00.00"

    h, mn, s, ms = m.groups()
    cs = int(ms[:2]) if len(ms) >= 2 else int(ms.ljust(2, "0"))
    return f"{int(h)}:{int(mn):02d}:{int(s):02d}.{cs:02d}"


# ============================================================
# MAIN CONVERTER
# ============================================================
def srt_to_ass(srt_path, ass_path, style="mrbeast", title="", play_res=None, custom=None):
    """
    Konversi file SRT → ASS dengan style preset.

    Args:
        srt_path:  Path file SRT input
        ass_path:  Path file ASS output
        style:     Key preset (mrbeast, hormozi, tiktok, clean, podcast)
        title:     Text title card (opsional, tampil 2 detik pertama di atas)
        play_res:  Tuple (width, height). Default (1920, 1080).
                   Untuk vertical pakai (1080, 1920).
        custom:    V9.146.0: Dict custom override
                   {font, size, color, outline_color, outline_width, shadow,
                    position, bold, bg_enabled, bg_color, bg_opacity}

    Returns:
        True kalau berhasil, False kalau gagal.
    """
    if style not in PRESETS:
        print(f"[CaptionStyle] ⚠️ Style '{style}' tidak dikenal — fallback ke mrbeast", file=sys.stderr)
        style = "mrbeast"

    if not os.path.exists(srt_path):
        print(f"[CaptionStyle] ❌ SRT tidak ada: {srt_path}", file=sys.stderr)
        return False

    style_line = PRESETS[style]["style_line"]
    
    # V9.146.0: Apply custom override dari user
    if custom and isinstance(custom, dict):
        try:
            style_line = _modify_style_line(style_line, custom)
            print(f"[CaptionStyle] 🎨 Custom override applied: {list(custom.keys())}", file=sys.stderr)
        except Exception as _ce:
            print(f"[CaptionStyle] ⚠️ Custom override error: {_ce}", file=sys.stderr)

    # Baca SRT
    try:
        with open(srt_path, "r", encoding="utf-8") as f:
            srt_content = f.read()
    except Exception as e:
        print(f"[CaptionStyle] ❌ Baca SRT gagal: {e}", file=sys.stderr)
        return False

    # Split SRT jadi blok
    blocks = re.split(r"\n\s*\n", srt_content.strip())
    events = []

    # Title card (2 detik pertama, posisi atas center)
    if title:
        clean_title = title.strip().replace("\n", " ")[:60]
        clean_title = clean_title.replace("\\", "").replace("{", "(").replace("}", ")")
        if clean_title:
            title_text = f"{{\\an8\\fs54\\b1}}{clean_title}"
            events.append({
                "start": "0:00:00.00",
                "end": "0:00:02.00",
                "text": title_text,
                "style": "Default",
            })

    # Parse subtitle blocks
    for block in blocks:
        lines = [l.strip() for l in block.split("\n") if l.strip()]
        if len(lines) < 2:
            continue

        timing_line = None
        text_lines = []
        for i, line in enumerate(lines):
            if " --> " in line:
                timing_line = line
                text_lines = lines[i + 1:]
                break

        if not timing_line:
            continue

        try:
            start_srt, end_srt = timing_line.split(" --> ")
            start_ass = _srt_time_to_ass(start_srt)
            end_ass = _srt_time_to_ass(end_srt)
        except Exception:
            continue

        text = " ".join(text_lines).strip()
        if not text:
            continue

        # Escape karakter yang bentrok dengan ASS override tag
        text = text.replace("\\", "").replace("{", "(").replace("}", ")")

        events.append({
            "start": start_ass,
            "end": end_ass,
            "text": text,
            "style": "Default",
        })

    if not events:
        print("[CaptionStyle] ❌ Tidak ada event — SRT kosong?", file=sys.stderr)
        return False

    # Build header
    header = ASS_HEADER.format(styles=style_line)

    # Override PlayRes kalau diberikan (untuk vertical crop)
    if play_res and isinstance(play_res, (list, tuple)) and len(play_res) == 2:
        pr_x, pr_y = int(play_res[0]), int(play_res[1])
        header = header.replace("PlayResX: 1920", f"PlayResX: {pr_x}")
        header = header.replace("PlayResY: 1080", f"PlayResY: {pr_y}")

    # Build events
    event_lines = []
    for ev in events:
        event_lines.append(
            f"Dialogue: 0,{ev['start']},{ev['end']},{ev['style']},,0,0,0,,{ev['text']}"
        )

    # Tulis ASS
    try:
        with open(ass_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(header)
            f.write("\n".join(event_lines))
            f.write("\n")
    except Exception as e:
        print(f"[CaptionStyle] ❌ Tulis ASS gagal: {e}", file=sys.stderr)
        return False

    # Log info
    play_info = ""
    if play_res:
        play_info = f" [PlayRes {play_res[0]}x{play_res[1]}]"

    print(
        f"[CaptionStyle][V8.8.4] ✅ {style} → {os.path.basename(ass_path)} "
        f"({len(events)} events){play_info}",
        file=sys.stderr,
    )

    # Debug dump
    try:
        with open(ass_path, "r", encoding="utf-8") as _f:
            head = _f.read(600)
        print(f"[CaptionStyle][V8.8.4] 📄 ASS preview:\n{head}\n---", file=sys.stderr)
    except Exception as _e:
        print(f"[CaptionStyle][V8.8.4] ⚠️ Gagal baca ASS: {_e}", file=sys.stderr)

    return True


# ============================================================
# V9.147.0: FONT MAP
# ============================================================
FONT_MAP = {
    "Rubik": "Rubik-Bold.ttf",
    "Anton": "Anton-Regular.ttf",
    "BebasNeue": "BebasNeue-Regular.ttf",
    "Poppins": "Poppins-Bold.ttf",
    "Montserrat": "Montserrat-Bold.ttf",
    "MontserratBlack": "Montserrat-Black.ttf",
    "ArchivoBlack": "ArchivoBlack-Regular.ttf",
    "Inter": "Inter-VariableFont_opsz,wght.ttf",
    "Righteous": "Righteous-Regular.ttf",
}

def get_font_file(font_name):
    """V9.147.0: Ambil nama file TTF dari nama font."""
    if not font_name:
        return "Rubik-Bold.ttf"
    return FONT_MAP.get(font_name, font_name + "-Bold.ttf")


# ============================================================
# STANDALONE TEST
# ============================================================
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python caption_style.py <input.srt> <output.ass> [style] [title] [WxH]")
        print("Styles:", ", ".join(PRESETS.keys()))
        print("Example: python caption_style.py in.srt out.ass mrbeast \"Judul\" 1080x1920")
        sys.exit(1)

    srt_in = sys.argv[1]
    ass_out = sys.argv[2]
    style_in = sys.argv[3] if len(sys.argv) > 3 else "mrbeast"
    title_in = sys.argv[4] if len(sys.argv) > 4 else ""

    play_res_in = None
    if len(sys.argv) > 5:
        try:
            w, h = sys.argv[5].lower().split("x")
            play_res_in = (int(w), int(h))
        except Exception:
            print(f"[Warn] Format PlayRes invalid: {sys.argv[5]} — pakai default 1920x1080",
                  file=sys.stderr)

    ok = srt_to_ass(srt_in, ass_out, style=style_in, title=title_in, play_res=play_res_in)
    print("OK" if ok else "FAIL")