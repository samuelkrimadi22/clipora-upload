/* ============================================================
   project-modal.js — V1.0.0
   Modal custom untuk input nama proyek (replace window.prompt)
   ============================================================ */
window._showProjectNameModal = function (defaultValue) {
    return new Promise(function (resolve) {
        var overlay = document.createElement("div");
        overlay.id = "_prjNameModal";
        overlay.style.cssText = "position:fixed;inset:0;z-index:99999;background:rgba(5,5,12,0.75);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:20px;opacity:0;transition:opacity 0.2s;";

        var html = '';
        html += '<div id="_prjNameCard" style="background:linear-gradient(165deg, #15152b 0%, #0f0f1e 100%);border:1px solid rgba(139,92,246,0.35);border-radius:20px;padding:32px 28px 24px;max-width:440px;width:100%;box-shadow:0 30px 80px rgba(139,92,246,0.25), 0 0 0 1px rgba(139,92,246,0.1) inset;transform:scale(0.92) translateY(10px);transition:transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);position:relative;">';
        html += '<div style="width:64px;height:64px;border-radius:16px;background:linear-gradient(135deg, rgba(139,92,246,0.25), rgba(6,182,212,0.15));border:1px solid rgba(139,92,246,0.4);display:flex;align-items:center;justify-content:center;margin:0 auto 18px;box-shadow:0 8px 24px rgba(139,92,246,0.35);">';
        html += '<i class="fas fa-save" style="font-size:1.6rem;color:#a78bfa;"></i></div>';
        html += '<h3 style="text-align:center;margin:0 0 8px;font-size:1.25rem;font-weight:700;background:linear-gradient(135deg, #a78bfa, #22d3ee);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">Simpan Proyek</h3>';
        html += '<p style="text-align:center;margin:0 0 22px;color:#94a3b8;font-size:0.85rem;line-height:1.5;">Beri nama proyek supaya mudah dicari nanti</p>';
        html += '<label style="display:block;font-size:0.72rem;font-weight:700;color:#a78bfa;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:8px;"><i class="fas fa-tag"></i> Nama Proyek</label>';
        html += '<input id="_prjNameInput" type="text" maxlength="100" placeholder="Misal: Video Tutorial Memasak..." style="width:100%;padding:14px 16px;background:rgba(0,0,0,0.4);border:2px solid rgba(139,92,246,0.3);border-radius:12px;color:#fff;font-size:0.95rem;font-family:inherit;outline:none;transition:0.2s;box-sizing:border-box;">';
        html += '<div style="display:flex;justify-content:space-between;margin-top:8px;font-size:0.7rem;">';
        html += '<span style="color:#94a3b8;"><i class="fas fa-info-circle"></i> Tekan Enter untuk simpan</span>';
        html += '<span id="_prjCharCount" style="color:#64748b;">0/100</span></div>';
        html += '<div style="display:flex;gap:10px;margin-top:24px;">';
        html += '<button id="_prjCancelBtn" type="button" style="flex:1;padding:12px 16px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.15);border-radius:12px;color:#94a3b8;font-weight:600;font-size:0.9rem;cursor:pointer;font-family:inherit;transition:0.15s;">Batal</button>';
        html += '<button id="_prjSaveBtn" type="button" style="flex:2;padding:12px 16px;background:linear-gradient(135deg, #8b5cf6, #06b6d4);border:none;border-radius:12px;color:#fff;font-weight:700;font-size:0.9rem;cursor:pointer;font-family:inherit;box-shadow:0 4px 20px rgba(139,92,246,0.4);transition:0.15s;display:flex;align-items:center;justify-content:center;gap:8px;"><i class="fas fa-check"></i> Simpan</button>';
        html += '</div></div>';

        overlay.innerHTML = html;
        document.body.appendChild(overlay);

        requestAnimationFrame(function () {
            overlay.style.opacity = "1";
            document.getElementById("_prjNameCard").style.transform = "scale(1) translateY(0)";
        });

        var input = document.getElementById("_prjNameInput");
        var charCount = document.getElementById("_prjCharCount");
        var saveBtn = document.getElementById("_prjSaveBtn");
        var cancelBtn = document.getElementById("_prjCancelBtn");

        input.value = defaultValue || "";
        setTimeout(function () { input.focus(); input.select(); }, 100);

        function updateCount() { charCount.textContent = input.value.length + "/100"; }
        input.addEventListener("input", updateCount);
        updateCount();

        input.addEventListener("focus", function () {
            input.style.borderColor = "#8b5cf6";
            input.style.boxShadow = "0 0 0 4px rgba(139,92,246,0.15)";
        });
        input.addEventListener("blur", function () {
            input.style.borderColor = "rgba(139,92,246,0.3)";
            input.style.boxShadow = "none";
        });

        function close(result) {
            overlay.style.opacity = "0";
            document.getElementById("_prjNameCard").style.transform = "scale(0.92) translateY(10px)";
            setTimeout(function () { overlay.remove(); resolve(result); }, 200);
        }

        saveBtn.addEventListener("click", function () {
            var val = input.value.trim();
            if (!val) {
                input.style.borderColor = "#ef4444";
                input.style.boxShadow = "0 0 0 4px rgba(239,68,68,0.15)";
                input.focus();
                return;
            }
            close(val);
        });
        cancelBtn.addEventListener("click", function () { close(null); });

        input.addEventListener("keydown", function (e) {
            if (e.key === "Enter") { e.preventDefault(); saveBtn.click(); }
            else if (e.key === "Escape") { e.preventDefault(); close(null); }
        });

        overlay.addEventListener("click", function (e) { if (e.target === overlay) close(null); });
    });
};

console.log("[ProjectModal] _showProjectNameModal ready");
