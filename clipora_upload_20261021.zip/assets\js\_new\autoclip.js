/**
 * autoclip.js - Clipora Auto-Clip UI + Timeline
 * REWRITTEN VERSION - Clean, no mojibake, all critical fixes applied
 * ============================================================
 * Fitur:
 * - Upload video + preview
 * - Analyze AI (panggil /api/autoclip/analyze)
 * - Timeline editor (drag, trim, reorder)
 * - Render klip (single / batch)
 * - Draft save/load (localStorage)
 * - Subtitle edit
 * - Watermark upload
 * - Music background
 * - Clip preview modal
 * - Caption generator
 * ============================================================
 */
(function () {
  "use strict";

  // ============================================================
  // GLOBAL CONFIG
  // ============================================================
  const API = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.apiUrl) || "/api";
  const BASE = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.baseUrl) || "";
  const TOKEN = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || "";

  console.log("[AutoClip UI] Loaded");

  // ============================================================
  // DOM CACHE
  // ============================================================
  const $zone = document.getElementById("acUploadZone");
  const $pickBtn = document.getElementById("acPickBtn");
  const $fileInput = document.getElementById("acFileInput");
  var $progress = document.getElementById("acProgress");
  const $progressFill = document.getElementById("acProgressFill");
  const $progressText = document.getElementById("acProgressText");
  const $progressDetail = document.getElementById("acProgressDetail");
  const $targetClips = document.getElementById("acTargetClips");
  const $preset = document.getElementById("acPreset");
  const $captionStyle = document.getElementById("acCaptionStyle");
  const $karaokeToggle = document.getElementById("acKaraokeToggle");
  const $karaokeStyle = document.getElementById("acKaraokeStyle");
  const $karaokeStyleWrap = document.getElementById("acKaraokeStyleWrap");
  const $titleInput = document.getElementById("acTitleInput");
  const $acVerticalCrop = document.getElementById("acVerticalCrop");
  const $acNoiseDetection = document.getElementById("acNoiseDetection");

  // Watermark elements
  const $acWatermarkSection = document.getElementById("acWatermarkSection");
  const $acWmEnabled = document.getElementById("acWmEnabled");
  const $acWmImage = document.getElementById("acWmImage");
  const $acWmEmpty = document.getElementById("acWmEmpty");
  const $acWmFileInput = document.getElementById("acWmFileInput");
  const $acWmUploadBtn = document.getElementById("acWmUploadBtn");
  const $acWmDeleteBtn = document.getElementById("acWmDeleteBtn");

  // Timeline elements
  const $timelineEditor = document.getElementById("acTimelineEditor");
  const $tlNewVideoBtn = document.getElementById("tlNewVideoBtn");
  const $tlTimeline = document.getElementById("tlTimeline");
  const $tlPool = document.getElementById("tlPool");
  const $tlVideo = document.getElementById("tlVideo");
  const $tlPreviewPlay = document.getElementById("tlPreviewPlay");
  const $tlPreviewMute = document.getElementById("tlPreviewMute");
  const $tlPreviewTime = document.getElementById("tlPreviewTime");
  const $tlRenderAllBtn = document.getElementById("tlRenderAllBtn");
  const $tlDownloadZipBtn = document.getElementById("tlDownloadZipBtn");
  const $tlResetBtn2 = document.getElementById("tlResetBtn2");
  const $tlRenderProgress = document.getElementById("tlRenderProgress");
  const $tlRpCounter = document.getElementById("tlRpCounter");
  const $tlRpPercent = document.getElementById("tlRpPercent");
  const $tlRpFill = document.getElementById("tlRpFill");
  const $tlRpLog = document.getElementById("tlRpLog");

  if (!$zone) return;

  // ============================================================
  // STATE
  // ============================================================
  let currentFile = null;
  let currentAnalysisId = null;
  let currentVideoUrl = null;
  let draggedClipId = null;
  let draggedFrom = null;
  let renderedResults = [];
  let selectedClips = new Set();
  let watermarkHasFile = false;
  let watermarkEnabled = false;

  const MAX_PARALLEL_RENDERS = 3;
  const activeAbortControllers = new Set();
  let currentAbortController = null;

  const renderState = {
    cancelled: false,
    running: false,
    failedClips: [],
    successResults: [],
  };

  // ============================================================
  // TOAST HELPER
  // ============================================================
  function tlToast(message, type = "info", duration = 4000) {
    let container = document.getElementById("tlToastContainer");
    if (!container) {
      container = document.createElement("div");
      container.id = "tlToastContainer";
      container.className = "tl-toast-container";
      document.body.appendChild(container);
    }
    const icons = { success: "fa-check-circle", error: "fa-times-circle", warning: "fa-exclamation-triangle", info: "fa-info-circle" };
    const toast = document.createElement("div");
    toast.className = "tl-toast " + type;
    const icon = document.createElement("i");
    icon.className = "fas " + (icons[type] || icons.info);
    const body = document.createElement("div");
    body.className = "tl-toast-body";
    body.textContent = message;
    const closeBtn = document.createElement("button");
    closeBtn.className = "tl-toast-close";
    closeBtn.innerHTML = "&times;";
    toast.appendChild(icon);
    toast.appendChild(body);
    toast.appendChild(closeBtn);
    container.appendChild(toast);
    setTimeout(() => toast.classList.add("show"), 10);
    const closeToast = () => {
      toast.classList.remove("show");
      setTimeout(() => toast.remove(), 300);
    };
    closeBtn.addEventListener("click", closeToast);
    if (duration > 0) setTimeout(closeToast, duration);
    return toast;
  }

  const toastInfo = (msg) => tlToast(msg, "info");
  const toastSuccess = (msg) => tlToast(msg, "success");
  const toastError = (msg) => tlToast(msg, "error");
  const toastWarning = (msg) => tlToast(msg, "warning");

  // ============================================================
  // PROGRESS BAR
  // ============================================================
  function setProgress(pct, text, detail) {
    $progress = document.getElementById("acProgress");
    if ($progress) $progress.style.display = "block";
    const fill = document.getElementById("acProgressFill");
    const txt = document.getElementById("acProgressText");
    const det = document.getElementById("acProgressDetail");
    if (fill) fill.style.width = Math.max(0, Math.min(100, pct)) + "%";
    if (txt && text) txt.textContent = text;
    if (det && detail) det.textContent = detail;
  }

  function hideProgress() {
    const p = document.getElementById("acProgress");
    if (p) p.style.display = "none";
  }

  // ============================================================
  // SOCKET PROGRESS
  // ============================================================
  let progressSocketBound = false;
  let progressSocketRetry = 0;
  const MAX_SOCKET_RETRY = 30;

  function bindProgressSocket() {
    if (progressSocketBound) return;
    if (window.socket && typeof window.socket.on === "function") {
      window.socket.on("autoclip:progress", (data) => {
        if (!window.__AC_WAITING && !currentAnalysisId) return;
        if (data && typeof data.progress === "number") {
          setProgress(Math.max(0, Math.min(100, data.progress)), "Menganalisis video...", data.message || "");
        }
      });
      window.socket.on("autoclip:render-progress", (data) => {
        if (!renderState.running) return;
        if (!data || typeof data.progress !== "number") return;
        updateRenderStepUI(Math.max(0, Math.min(100, data.progress)), data.step || "unknown", data.message || "");
      });
      progressSocketBound = true;
      console.log("[AutoClip] Progress listener bound to socket");
      return;
    }
    progressSocketRetry++;
    if (progressSocketRetry > MAX_SOCKET_RETRY) {
      console.warn("[AutoClip] Socket tidak tersedia setelah " + MAX_SOCKET_RETRY + "s");
      return;
    }
    setTimeout(bindProgressSocket, 1000);
  }
  bindProgressSocket();

  // ============================================================
  // DRAFT AUTO-SAVE
  // ============================================================
  const DRAFT_KEY = "clipora_autoclip_draft_v1";
  const DRAFT_MAX_AGE_MS = 60 * 60 * 1000;
  const DRAFT_AUTOSAVE_INTERVAL_MS = 10000;
  let draftAutoSaveTimer = null;

  function saveDraft() {
    try {
      const st = window.__TL_STATE;
      if (!st || !currentAnalysisId) return;
      const draft = {
        version: 1,
        savedAt: Date.now(),
        analysisId: currentAnalysisId,
        videoName: currentFile ? currentFile.name : null,
        videoSize: currentFile ? currentFile.size : 0,
        videoDuration: st.videoDuration || 0,
        timeline: st.timeline || [],
        pool: st.pool || [],
        initial: st.initial || [],
        subtitles: st.subtitles || [],
        settings: {
          captionStyle: $captionStyle ? $captionStyle.value : "",
          karaokeEnabled: $karaokeToggle ? $karaokeToggle.checked : false,
          karaokeStyle: $karaokeStyle ? $karaokeStyle.value : "tiktok",
          preset: $preset ? $preset.value : "1080p",
          title: $titleInput ? $titleInput.value.trim() : "",
          targetClips: $targetClips ? $targetClips.value : "5",
        },
        selectedClips: [...selectedClips],
        meta: {
          totalClips: (st.timeline ? st.timeline.length : 0) + (st.pool ? st.pool.length : 0),
          subtitleCount: st.subtitles ? st.subtitles.length : 0,
        },
      };
      localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      console.log("[Draft] Saved " + draft.meta.totalClips + " klip, " + draft.meta.subtitleCount + " subtitle");
    } catch (e) {
      console.warn("[Draft] Gagal save:", e.message);
    }
  }

  function loadDraft() {
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (!raw) return null;
      const draft = JSON.parse(raw);
      if (!draft || draft.version !== 1) return null;
      const age = Date.now() - (draft.savedAt || 0);
      if (age > DRAFT_MAX_AGE_MS) { clearDraft(); return null; }
      if (!draft.analysisId || !draft.timeline || draft.timeline.length === 0) return null;
      return draft;
    } catch (e) {
      console.warn("[Draft] Gagal load:", e.message);
      return null;
    }
  }

  function clearDraft() {
    try { localStorage.removeItem(DRAFT_KEY); console.log("[Draft] Dihapus"); } catch (e) {}
  }

  function startDraftAutoSave() {
    stopDraftAutoSave();
    draftAutoSaveTimer = setInterval(saveDraft, DRAFT_AUTOSAVE_INTERVAL_MS);
    console.log("[Draft] Auto-save aktif (tiap 10s)");
  }

  function stopDraftAutoSave() {
    if (draftAutoSaveTimer) {
      clearInterval(draftAutoSaveTimer);
      draftAutoSaveTimer = null;
    }
  }

  function formatDraftAge(savedAt) {
    const diff = Date.now() - savedAt;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "beberapa detik yang lalu";
    if (mins < 60) return mins + " menit yang lalu";
    return Math.floor(mins / 60) + " jam yang lalu";
  }

  // ============================================================
  // FILE PICKER
  // ============================================================
  if ($pickBtn) $pickBtn.addEventListener("click", (e) => { e.stopPropagation(); $fileInput.click(); });
  if ($zone) $zone.addEventListener("click", () => $fileInput.click());
  if ($fileInput) $fileInput.addEventListener("change", (e) => { const file = e.target.files[0]; if (file) handleFile(file); });
  if ($zone) {
    $zone.addEventListener("dragover", (e) => { e.preventDefault(); $zone.classList.add("dragover"); });
    $zone.addEventListener("dragleave", () => $zone.classList.remove("dragover"));
    $zone.addEventListener("drop", (e) => {
      e.preventDefault();
      $zone.classList.remove("dragover");
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    });
  }

  // ============================================================
  // HANDLE FILE
  // ============================================================
  async function handleFile(file) {
    if (!TOKEN) { toastError("Anda harus login dulu"); return; }
    const maxSize = 500 * 1024 * 1024;
    if (file.size > maxSize) { toastError("File terlalu besar (maks 500MB)"); return; }

    currentFile = file;
    renderedResults = [];
    window.__AC_WAITING = true;
    if (currentVideoUrl) URL.revokeObjectURL(currentVideoUrl);
    currentVideoUrl = URL.createObjectURL(file);

    if ($zone) $zone.style.display = "none";
    document.body.classList.add("ac-preview-mode");

    var _vpWrap = document.getElementById("acVideoPreviewWrap");
    if (_vpWrap) _vpWrap.style.display = "block";

    var _newPreview = document.getElementById("acVideoPreview");
    if (_newPreview && currentVideoUrl) {
      _newPreview.src = currentVideoUrl;
      _newPreview.load();
    }
    var _editorPreview = document.getElementById("editorContainer");
    if (_editorPreview) _editorPreview.style.display = "none";

    var _pw = document.getElementById("acProsesWrapper");
    if (_pw) {
      _pw.style.display = "block";
      _pw.classList.add("visible");
      setTimeout(function () { _pw.scrollIntoView({ behavior: "smooth", block: "center" }); }, 500);
    }
    console.log("[AutoClip] Video siap - tunggu klik tombol Proses Video");
  }

  // ============================================================
  // PROSES BUTTON
  // ============================================================
  function _initProsesBtn() {
    var _btn = document.getElementById("acProsesBtn");
    var _wrapper = document.getElementById("acProsesWrapper");
    if (!_btn) { console.warn("[AutoClip] acProsesBtn tidak ada"); return; }
    if (_btn._bound) return;
    _btn._bound = true;
    _btn.addEventListener("click", async function () {
      if (_btn.disabled) return;
      if (!currentFile) { toastError("Upload video dulu"); return; }
      if (window.__AC_PROCESSING__ === true) return;
      window.__AC_PROCESSING__ = true;

      document.body.classList.remove("ac-preview-mode");
      var _ec2 = document.getElementById("editorContainer");
      if (_ec2) _ec2.style.display = "none";
      var _cp2 = document.getElementById("controlPanel");
      if (_cp2) _cp2.style.display = "none";
      _btn.disabled = true;
      _btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Memproses...</span>';
      if (_wrapper) _wrapper.style.display = "none";
      document.body.classList.add("ac-analyzing");
      var _prog = document.getElementById("acProgress");
      if (_prog) _prog.style.display = "block";
      try {
        await uploadAndAnalyze(currentFile);
      } catch (e) {
        console.error("ERR:", e);
        toastError("Gagal: " + e.message);
        resetUI();
      } finally {
        window.__AC_PROCESSING__ = false;
        _btn.disabled = false;
        _btn.innerHTML = '<i class="fas fa-magic"></i> <span>Proses Video Sekarang</span>';
      }
    });
    console.log("[AutoClip] Handler tombol Proses Video siap");
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", _initProsesBtn);
  } else {
    setTimeout(_initProsesBtn, 100);
  }

  // Video preview close
  (function initVideoPreviewClose() {
    function bind() {
      var closeBtn = document.getElementById("acVideoPreviewClose");
      var wrap = document.getElementById("acVideoPreviewWrap");
      if (!closeBtn || !wrap) { setTimeout(bind, 500); return; }
      if (closeBtn._bound) return;
      closeBtn._bound = true;
      closeBtn.addEventListener("click", function () {
        if (wrap) wrap.style.display = "none";
      });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind);
    else setTimeout(bind, 500);
  })();

  // ============================================================
  // UPLOAD + ANALYZE
  // ============================================================
  async function uploadAndAnalyze(file) {
    const fd = new FormData();
    fd.append("video", file);
    fd.append("targetClips", $targetClips ? $targetClips.value : "5");
    fd.append("preset", $preset ? $preset.value : "1080p");
    fd.append("captionStyle", $captionStyle ? $captionStyle.value : "clean");
    fd.append("karaokeEnabled", $karaokeToggle && $karaokeToggle.checked ? "true" : "false");
    if ($karaokeStyle) fd.append("karaokeStyle", $karaokeStyle.value);
    if ($titleInput && $titleInput.value.trim()) fd.append("title", $titleInput.value.trim());
    if ($acVerticalCrop) fd.append("verticalCrop", $acVerticalCrop.checked ? "true" : "false");
    if ($acNoiseDetection) fd.append("noiseDetection", $acNoiseDetection.checked ? "true" : "false");

    setProgress(0, "Mengunggah video...", "");
    const xhr = new XMLHttpRequest();
    xhr.open("POST", API + "/autoclip/analyze");
    xhr.setRequestHeader("Authorization", "Bearer " + TOKEN);

    xhr.upload.onprogress = function (e) {
      if (e.lengthComputable) {
        const pct = Math.round((e.loaded / e.total) * 30);
        setProgress(pct, "Mengunggah video...", Math.round((e.loaded / e.total) * 100) + "%");
      }
    };

    xhr.onload = function () {
      try {
        const data = JSON.parse(xhr.responseText);
        if (xhr.status >= 200 && xhr.status < 300 && data.success) {
          currentAnalysisId = data.analysisId;
          window.__AC_WAITING = false;
          showResult(data, 0);
          setProgress(100, "Selesai!", "");
          setTimeout(hideProgress, 1000);
        } else {
          toastError(data.error || "Gagal memproses video");
          resetUI();
        }
      } catch (e) {
        toastError("Gagal parse response: " + e.message);
        resetUI();
      }
    };

    xhr.onerror = function () {
      toastError("Network error");
      resetUI();
    };

    xhr.send(fd);
  }

  // ============================================================
  // SHOW RESULT (Init timeline)
  // ============================================================
  function showResult(data, tab) {
    console.log("[AutoClip] showResult:", data);

    window.__TL_STATE = {
      analysisId: data.analysisId,
      clips: data.clips ? data.clips.slice() : [],
      timeline: data.clips ? data.clips.slice() : [],
      pool: [],
      initial: data.clips ? data.clips.slice() : [],
      videoDuration: data.videoDuration || 0,
      preset: data.preset || "1080p",
      aggressiveness: data.aggressiveness || "content",
      words: data.words || [],
      originalWords: data.words ? JSON.parse(JSON.stringify(data.words)) : [],
      subtitles: [],
      selectedClips: [],
      videoUrl: currentVideoUrl || (API + "/autoclip-projects/" + (data._projectId || data.analysisId) + "/video?token=" + encodeURIComponent(TOKEN)),
      _loadedFromDB: data._loadedFromDB || false,
      _projectId: data._projectId || null,
      _projectName: data._projectName || null,
    };

    document.body.classList.remove("ac-analyzing");
    document.body.classList.add("ac-timeline-active");

    if ($timelineEditor) $timelineEditor.style.display = "block";
    if ($tlVideo && window.__TL_STATE.videoUrl) {
      $tlVideo.src = window.__TL_STATE.videoUrl;
      $tlVideo.load();
    }

    var metaEl = document.getElementById("tlHeaderMeta");
    if (metaEl) {
      metaEl.innerHTML = '<strong>' + (data.clips ? data.clips.length : 0) + ' klip</strong> &middot; ' + (data.videoDuration ? Math.round(data.videoDuration) + 's' : '') + ' &middot; ' + (data.preset || '1080p');
    }

    renderTimeline();
    renderPool();
    updateRenderAllBtnLabel();
    startDraftAutoSave();
    toastSuccess(data.clips ? data.clips.length + " klip siap dirender");
  }

  // ============================================================
  // RENDER TIMELINE
  // ============================================================
  function renderTimeline() {
    const st = window.__TL_STATE;
    if (!st || !$tlTimeline) return;
    const clips = st.timeline || [];
    $tlTimeline.innerHTML = "";
    if (clips.length === 0) {
      $tlTimeline.innerHTML = '<div class="tl-empty"><i class="fas fa-inbox"></i><p>Belum ada klip di timeline</p></div>';
      return;
    }
    clips.forEach((clip, i) => {
      const el = document.createElement("div");
      el.className = "tl-clip";
      el.dataset.clipId = clip.id;
      el.draggable = true;
      const isSelected = selectedClips.has(String(clip.id));
      if (isSelected) el.classList.add("checked");
      el.innerHTML =
        '<div class="tl-clip-check">' +
          '<input type="checkbox" class="tl-clip-checkbox" data-clip-id="' + clip.id + '"' + (isSelected ? " checked" : "") + ">" +
          '<span class="tl-clip-check-mark"></span>' +
        "</div>" +
        '<div class="tl-clip-thumb">' +
          '<div class="tl-clip-num">#' + (i + 1) + "</div>" +
          '<div class="tl-clip-dur">' + (clip.duration ? clip.duration.toFixed(1) + "s" : "") + "</div>" +
        "</div>" +
        '<div class="tl-clip-meta">' +
          '<div class="tl-clip-text">' + (clip.preview_text || "Klip #" + clip.id) + "</div>" +
          '<div class="tl-clip-time">' + fmtTime(clip.start) + " - " + fmtTime(clip.end) + "</div>" +
        "</div>" +
        '<button type="button" class="tl-clip-delete" data-clip-id="' + clip.id + '" title="Hapus"><i class="fas fa-trash"></i></button>';
      $tlTimeline.appendChild(el);
    });
    // Bind delete
    $tlTimeline.querySelectorAll(".tl-clip-delete").forEach((btn) => {
      btn.addEventListener("click", (e) => { e.stopPropagation(); removeFromTimeline(btn.dataset.clipId); });
    });
    // Bind checkbox
    $tlTimeline.querySelectorAll(".tl-clip-checkbox").forEach((cb) => {
      cb.addEventListener("change", (e) => {
        const id = cb.dataset.clipId;
        if (cb.checked) selectedClips.add(id); else selectedClips.delete(id);
        updateRenderAllBtnLabel();
      });
    });
    console.log("[AutoClip] Timeline rendered: " + clips.length + " klip");
  }

  // ============================================================
  // RENDER POOL
  // ============================================================
  function renderPool() {
    const st = window.__TL_STATE;
    if (!st || !$tlPool) return;
    const pool = st.pool || [];
    $tlPool.innerHTML = "";
    const cnt = document.getElementById("tlPoolCount");
    if (cnt) cnt.textContent = "Pool (" + pool.length + ")";
    if (pool.length === 0) {
      $tlPool.innerHTML = '<div class="tl-empty"><i class="fas fa-check-circle"></i><p>Semua klip sudah di timeline</p></div>';
      return;
    }
    pool.forEach((clip) => {
      const el = document.createElement("div");
      el.className = "tl-clip";
      el.dataset.clipId = clip.id;
      el.innerHTML =
        '<div class="tl-clip-thumb"><div class="tl-clip-num">#' + clip.id + "</div></div>" +
        '<div class="tl-clip-meta"><div class="tl-clip-text">' + (clip.preview_text || "Klip #" + clip.id) + "</div></div>" +
        '<button type="button" class="tl-clip-add" data-clip-id="' + clip.id + '" title="Tambah ke timeline"><i class="fas fa-plus"></i></button>';
      $tlPool.appendChild(el);
    });
    $tlPool.querySelectorAll(".tl-clip-add").forEach((btn) => {
      btn.addEventListener("click", (e) => { e.stopPropagation(); addToTimeline(btn.dataset.clipId); });
    });
  }

  // ============================================================
  // UTILITY
  // ============================================================
  function fmtTime(sec) {
    if (!sec || sec < 0) return "0:00";
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return m + ":" + String(s).padStart(2, "0");
  }

  function removeFromTimeline(clipId) {
    const st = window.__TL_STATE;
    if (!st) return;
    const idx = st.timeline.findIndex((c) => String(c.id) === String(clipId));
    if (idx === -1) return;
    const clip = st.timeline.splice(idx, 1)[0];
    if (clip) st.pool.push(clip);
    renderTimeline();
    renderPool();
    updateRenderAllBtnLabel();
  }

  function addToTimeline(clipId) {
    const st = window.__TL_STATE;
    if (!st) return;
    const idx = st.pool.findIndex((c) => String(c.id) === String(clipId));
    if (idx === -1) return;
    const clip = st.pool.splice(idx, 1)[0];
    if (clip) st.timeline.push(clip);
    renderTimeline();
    renderPool();
    updateRenderAllBtnLabel();
  }

  function updateRenderAllBtnLabel() {
    const st = window.__TL_STATE;
    if (!$tlRenderAllBtn || !st) return;
    const total = (st.timeline || []).length;
    const sel = selectedClips.size;
    const label = $tlRenderAllBtn.querySelector("span");
    if (label) label.textContent = sel > 0 ? "Render " + sel + " Terpilih" : "Render Semua (" + total + ")";
    if ($tlDownloadZipBtn) $tlDownloadZipBtn.disabled = renderedResults.length === 0;
  }

  // ============================================================
  // RENDER STEPS
  // ============================================================
  const STEP_NAMES = {
    load: { icon: "[in]", label: "Memuat video" },
    normalize: { icon: "[norm]", label: "Normalisasi CFR" },
    cut: { icon: "[cut]", label: "Memotong klip" },
    subtitle: { icon: "[sub]", label: "Buat subtitle" },
    render: { icon: "[render]", label: "Render final" },
    finalize: { icon: "[final]", label: "Finalisasi" },
    done: { icon: "[done]", label: "Selesai" },
    unknown: { icon: "[wait]", label: "Memproses" },
  };

  function ensureStepLabel() {
    let el = document.getElementById("tlRpStepLabel");
    if (el) return el;
    const rpBar = document.querySelector(".tl-rp-bar");
    if (!rpBar) return null;
    el = document.createElement("div");
    el.id = "tlRpStepLabel";
    el.style.cssText = "display:none;align-items:center;gap:8px;padding:8px 14px;margin-bottom:10px;background:rgba(139,92,246,0.10);border:1px solid rgba(139,92,246,0.25);border-radius:10px;font-size:0.82rem;font-weight:700;color:#a78bfa;font-family:inherit;";
    rpBar.parentNode.insertBefore(el, rpBar);
    return el;
  }

  function updateRenderStepUI(pct, step, msg) {
    if ($tlRpFill) $tlRpFill.style.width = pct + "%";
    if ($tlRpPercent) $tlRpPercent.textContent = pct + "%";
    const labelEl = ensureStepLabel();
    if (labelEl) {
      const info = STEP_NAMES[step] || STEP_NAMES.unknown;
      labelEl.style.display = "flex";
      labelEl.innerHTML = '<span style="font-size:1.1rem;">' + info.icon + '</span><span>' + info.label + '</span><span style="margin-left:auto;font-family:monospace;font-size:0.75rem;opacity:0.7;">' + pct + "%</span>";
    }
  }

  function hideStepLabel() {
    const el = document.getElementById("tlRpStepLabel");
    if (el) el.style.display = "none";
  }

  function appendRenderLog(msg, type) {
    if (!$tlRpLog) return;
    const line = document.createElement("div");
    line.style.cssText = "padding:4px 0;font-size:0.75rem;color:" + (type === "err" ? "#ef4444" : type === "ok" ? "#22c55e" : "#94a3b8") + ";";
    line.textContent = msg;
    $tlRpLog.appendChild(line);
    $tlRpLog.scrollTop = $tlRpLog.scrollHeight;
  }

  // ============================================================
  // RESET UI
  // ============================================================
  function resetUI() {
    if ($zone) $zone.style.display = "block";
    document.body.classList.remove("ac-preview-mode", "ac-analyzing", "ac-timeline-active");
    if ($timelineEditor) $timelineEditor.style.display = "none";
    hideProgress();
    currentFile = null;
    currentAnalysisId = null;
    if (currentVideoUrl) { URL.revokeObjectURL(currentVideoUrl); currentVideoUrl = null; }
    window.__TL_STATE = null;
    selectedClips.clear();
    renderedResults = [];
    stopDraftAutoSave();
  }

  // ============================================================
  // EXPOSE GLOBALS
  // ============================================================
  window.showResult = showResult;
  window.loadAutoclipProjectFromData = function (project) {
    var aj = project.analysis_json;
    var cj = project.clips_json;
    if (typeof aj === "string") { try { aj = JSON.parse(aj); } catch (e) { aj = {}; } }
    if (typeof cj === "string") { try { cj = JSON.parse(cj); } catch (e) { cj = []; } }
    aj = aj || {};
    cj = cj || [];
    if (typeof currentAnalysisId !== "undefined") currentAnalysisId = aj.analysisId || project.id;
    var _api = typeof API !== "undefined" ? API : "/api";
    var _tok = typeof TOKEN !== "undefined" ? TOKEN : "";
    window.currentVideoUrl = _api + "/autoclip-projects/" + project.id + "/video?token=" + encodeURIComponent(_tok);
    if (typeof window.setCurrentAutoclipProjectId === "function") window.setCurrentAutoclipProjectId(project.id);
    var data = {
      analysisId: aj.analysisId || project.id,
      inputPath: project.input_video_path,
      videoDuration: aj.videoDuration || 0,
      totalClips: cj.length,
      clips: cj,
      method: aj.method || "loaded",
      preset: aj.preset || project.preset || "1080p",
      aggressiveness: aj.aggressiveness || "content",
      whisperWords: aj.whisperWords || 0,
      words: aj.words || [],
      noiseSegments: 0,
      _loadedFromDB: true,
      _projectId: project.id,
      _projectName: project.name,
    };
    window.__TL_STATE = {
      analysisId: data.analysisId,
      clips: cj.slice(),
      timeline: cj.slice(),
      pool: [],
      initial: cj.slice(),
      videoDuration: data.videoDuration,
      preset: data.preset,
      aggressiveness: data.aggressiveness,
      words: data.words || [],
      originalWords: data.words ? JSON.parse(JSON.stringify(data.words)) : [],
      subtitles: [],
      selectedClips: [],
      videoUrl: window.currentVideoUrl,
      _loadedFromDB: true,
      _projectId: project.id,
      _projectName: project.name,
    };
    if (typeof window.__AC_WAITING !== "undefined") window.__AC_WAITING = false;
    showResult(data, 0);
    setTimeout(function () {
      var vUrl = window.currentVideoUrl;
      if (!vUrl) return;
      var tlVideo = document.getElementById("tlVideo");
      if (tlVideo) { tlVideo.src = vUrl; tlVideo.load(); }
      var editorVideo = document.getElementById("editorVideo");
      if (editorVideo) { editorVideo.src = vUrl; editorVideo.load(); }
      var bigPreview = document.getElementById("acVideoPreview");
      if (bigPreview) { bigPreview.src = vUrl; bigPreview.load(); }
    }, 300);
  };

  console.log("[AutoClip] Functions exposed to window");
})();