/* timeline-undo.js - V1.0.0
   Undo/Redo untuk semua perubahan timeline
   Pakai API CliporaEditor.getSegments() + setSegments() */
(function initTimelineUndo() {
    'use strict';

    var undoStack = [];
    var redoStack = [];
    var MAX_STACK = 30;
    var isRestoring = false;

    function snapshot() {
        if (isRestoring) return;
        if (!window.CliporaEditor || !window.CliporaEditor.getSegments) return;
        var segs = window.CliporaEditor.getSegments();
        var st = window.CliporaEditor.getState ? window.CliporaEditor.getState() : {};
        return {
            segments: JSON.parse(JSON.stringify(segs)),
            duration: st.duration,
            ts: Date.now(),
        };
    }

    function pushHistory() {
        if (isRestoring) return;
        var snap = snapshot();
        if (!snap) return;
        // Cegah duplikat
        var last = undoStack[undoStack.length - 1];
        if (last && JSON.stringify(last.segments) === JSON.stringify(snap.segments)) return;
        undoStack.push(snap);
        if (undoStack.length > MAX_STACK) undoStack.shift();
        redoStack = []; // reset redo saat ada aksi baru
        updateUI();
    }

    function restore(snap) {
        if (!snap || !window.CliporaEditor) return false;
        isRestoring = true;
        try {
            if (window.CliporaEditor.setSegments) {
                window.CliporaEditor.setSegments({
                    segments: snap.segments,
                    duration: snap.duration,
                });
            }
            if (typeof currentAnalysisData !== 'undefined' && currentAnalysisData) {
                currentAnalysisData.segments = JSON.parse(JSON.stringify(snap.segments));
            }
            if (typeof renderTimeline === 'function') renderTimeline();
            if (typeof renderStats === 'function') renderStats();
            return true;
        } catch (e) {
            console.error('[Undo] restore error:', e);
            return false;
        } finally {
            setTimeout(function() { isRestoring = false; }, 100);
        }
    }

    function undo() {
        if (undoStack.length < 2) {
            showToast('Tidak ada yang bisa di-undo');
            return false;
        }
        var current = undoStack.pop(); // simpan current
        redoStack.push(current);
        var prev = undoStack[undoStack.length - 1];
        restore(prev);
        showToast('Undo (' + (undoStack.length - 1) + ' tersisa)');
        console.log('[Undo] Restore ke snapshot ke-' + (undoStack.length - 1));
        updateUI();
        return true;
    }

    function redo() {
        if (redoStack.length === 0) {
            showToast('Tidak ada yang bisa di-redo');
            return false;
        }
        var next = redoStack.pop();
        undoStack.push(next);
        restore(next);
        showToast('Redo');
        console.log('[Undo] Redo');
        updateUI();
        return true;
    }

    function showToast(msg) {
        var t = document.createElement('div');
        t.textContent = msg;
        t.style.cssText = 'position:fixed;bottom:40px;left:50%;transform:translateX(-50%);background:rgba(15,15,30,0.95);border:1px solid rgba(139,92,246,0.5);color:#e8e8ef;padding:10px 20px;border-radius:24px;font-size:0.85rem;font-weight:600;z-index:99999;box-shadow:0 8px 32px rgba(0,0,0,0.5);pointer-events:none;';
        document.body.appendChild(t);
        setTimeout(function() { t.style.opacity = '0'; t.style.transition = 'opacity 0.3s'; }, 1200);
        setTimeout(function() { t.remove(); }, 1600);
    }

    function updateUI() {
        var u = document.getElementById('_undoBtn');
        var r = document.getElementById('_redoBtn');
        if (u) {
            u.disabled = undoStack.length < 2;
            u.style.opacity = undoStack.length < 2 ? '0.3' : '1';
        }
        if (r) {
            r.disabled = redoStack.length === 0;
            r.style.opacity = redoStack.length === 0 ? '0.3' : '1';
        }
    }

    function attachUI() {
        var ctrl = document.getElementById('_zoomCtrlFinal');
        if (!ctrl || document.getElementById('_undoBtn')) return;

        var bstyle = 'width:30px;height:28px;border:1px solid rgba(139,92,246,0.35);border-radius:6px;cursor:pointer;background:rgba(139,92,246,0.1);color:#e8e8ef;font-size:1rem;display:inline-flex;align-items:center;justify-content:center;font-family:inherit;transition:background 0.15s;font-weight:600;';

        var undoBtn = document.createElement('button');
        undoBtn.id = '_undoBtn';
        undoBtn.type = 'button';
        undoBtn.title = 'Undo (Ctrl+Z)';
        undoBtn.style.cssText = bstyle;
        undoBtn.innerHTML = '↶';

        var redoBtn = document.createElement('button');
        redoBtn.id = '_redoBtn';
        redoBtn.type = 'button';
        redoBtn.title = 'Redo (Ctrl+Shift+Z)';
        redoBtn.style.cssText = bstyle;
        redoBtn.innerHTML = '↷';

        undoBtn.addEventListener('click', undo);
        redoBtn.addEventListener('click', redo);

        // Insert di kiri control zoom (sebelum label "Zoom")
        var firstChild = ctrl.firstChild;
        ctrl.insertBefore(undoBtn, firstChild);
        ctrl.insertBefore(redoBtn, undoBtn.nextSibling);

        console.log('[Undo] UI attached');
        updateUI();
    }

    function hookMutations() {
        var track = document.getElementById('teTrack');
        if (!track) { setTimeout(hookMutations, 500); return; }

        // MutationObserver: catat setiap perubahan segmen
        var observer = new MutationObserver(function(muts) {
            if (isRestoring) return;
            // Debounce — tunggu 100ms biar tidak spam
            clearTimeout(window._undoDebounce);
            window._undoDebounce = setTimeout(pushHistory, 150);
        });
        observer.observe(track, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['class', 'style'],
        });
        console.log('[Undo] Observer attached');
    }

    function run() {
        if (!window.CliporaEditor) { setTimeout(run, 500); return; }

        console.log('[Undo] Init');

        // Snapshot awal
        setTimeout(function() {
            pushHistory();
            console.log('[Undo] Initial snapshot recorded');
        }, 800);

        attachUI();
        hookMutations();

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            if (!e.ctrlKey && !e.metaKey) return;
            var tag = (document.activeElement && document.activeElement.tagName) || '';
            if (tag === 'INPUT' || tag === 'TEXTAREA') return;

            if (e.key === 'z' && !e.shiftKey) {
                e.preventDefault();
                undo();
            } else if ((e.key === 'z' && e.shiftKey) || e.key === 'y') {
                e.preventDefault();
                redo();
            }
        });

        console.log('[Undo] Ready — Ctrl+Z untuk undo');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() { setTimeout(run, 2000); });
    } else {
        setTimeout(run, 2000);
    }
})();
