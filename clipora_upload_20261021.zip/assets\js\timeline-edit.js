/* ============================================================
   timeline-edit.js — V4.0.0 (SIMPEL)
   HANYA: Drag segmen + Double-click copy segmen
   TIDAK ADA: klik area kosong bikin cut, tooltip, panel
   ============================================================ */
(function initTimelineEdit() {
    'use strict';

    function getSegments() {
        if (window.CliporaEditor && window.CliporaEditor.getSegments) {
            return window.CliporaEditor.getSegments();
        }
        if (typeof currentAnalysisData !== 'undefined' && currentAnalysisData && currentAnalysisData.segments) {
            return currentAnalysisData.segments;
        }
        return [];
    }

    function getDuration() {
        if (window.CliporaEditor && window.CliporaEditor.getState) {
            var st = window.CliporaEditor.getState();
            if (st && st.duration > 0) return st.duration;
        }
        var v = document.getElementById('editorVideo');
        if (v && v.duration > 0 && isFinite(v.duration)) return v.duration;
        return 0;
    }

    function run() {
        var track = document.getElementById('teTrack');
        if (!track) { setTimeout(run, 500); return; }
        if (track.dataset.edit4Ready === '1') return;
        track.dataset.edit4Ready = '1';

        console.log('[Edit4] Init — drag + double-click only');

        // CSS: hide tooltip, cursor
        if (!document.getElementById('_edit4Style')) {
            var st = document.createElement('style');
            st.id = '_edit4Style';
            st.textContent = [
                '.te-segment { cursor: grab !important; user-select: none; }',
                '.te-segment.dragging { cursor: grabbing !important; opacity: 0.8; }',
                '.te-tooltip, .te-segment-tooltip, [class*="tooltip"] { display: none !important; }',
            ].join('\n');
            document.head.appendChild(st);
        }

        var dragState = null;
        var blockClick = false;

        // ==== POINTER DOWN: mulai drag ====
        track.addEventListener('pointerdown', function(e) {
            if (e.button !== 0) return;
            // V9.3.0: Skip kalau klik tombol copy
            if (e.target.closest('.te-segment-copy-btn')) return;
            var segEl = e.target.closest('.te-segment');
            if (!segEl) return;
            if (e.target.classList.contains('te-segment-handle')) return;

            var segId = segEl.dataset.id;
            var segs = getSegments();
            var seg = segs.find(function(s) { return String(s.id) === String(segId); });
            
            // V9.5.0: Fallback — cari by DOM position kalau ID tidak match
            if (!seg) {
                var _dur = getDuration();
                if (_dur > 0) {
                    var _leftPct = parseFloat(segEl.style.left) || 0;
                    var _widthPct = parseFloat(segEl.style.width) || 0;
                    var _startT = (_leftPct / 100) * _dur;
                    var _endT = ((_leftPct + _widthPct) / 100) * _dur;
                    for (var _i = 0; _i < segs.length; _i++) {
                        if (Math.abs(segs[_i].start - _startT) < 0.2 && Math.abs(segs[_i].end - _endT) < 0.2) {
                            seg = segs[_i];
                            segId = seg.id;
                            console.log('[Edit4] Fallback by position');
                            break;
                        }
                    }
                }
            }
            
            if (!seg) {
                console.warn('[Edit4] Segmen tidak ditemukan: ' + segId + ' (total: ' + segs.length + ')');
                return;
            }

            dragState = {
                segId: segId, segEl: segEl,
                startX: e.clientX,
                origStart: seg.start, origEnd: seg.end,
                dragging: false, newStart: null, newEnd: null
            };
        });

        // ==== POINTER MOVE: geser ====
        document.addEventListener('pointermove', function(e) {
            if (!dragState) return;
            var dx = e.clientX - dragState.startX;

            if (!dragState.dragging && Math.abs(dx) > 5) {
                dragState.dragging = true;
                dragState.segEl.classList.add('dragging');
                document.body.style.userSelect = 'none';
            }
            if (dragState.dragging) {
                var dur = getDuration();
                if (!dur) return;
                var rect = track.getBoundingClientRect();
                var dt = (dx / rect.width) * dur;
                var segDur = dragState.origEnd - dragState.origStart;
                var ns = Math.max(0, dragState.origStart + dt);
                var ne = ns + segDur;
                if (ne > dur) { ne = dur; ns = ne - segDur; }
                dragState.newStart = ns;
                dragState.newEnd = ne;
                dragState.segEl.style.left = (ns / dur * 100) + '%';
                dragState.segEl.style.width = (segDur / dur * 100) + '%';
            }
        });

        // ==== POINTER UP: simpan posisi ====
        document.addEventListener('pointerup', function() {
            if (!dragState) return;
            var wasDrag = dragState.dragging;
            var id = dragState.segId;
            var ns = dragState.newStart, ne = dragState.newEnd;
            var el = dragState.segEl;

            el.classList.remove('dragging');
            document.body.style.userSelect = '';
            dragState = null;

            if (wasDrag && ns !== null) {
                blockClick = true;
                setTimeout(function() { blockClick = false; }, 100);
                if (window.CliporaEditor && window.CliporaEditor.updateSegment) {
                    window.CliporaEditor.updateSegment(id, ns, ne);
                    console.log('[Edit4] Moved segmen ' + id + ' → ' + ns.toFixed(2) + 's - ' + ne.toFixed(2) + 's');
                }
                
                // V9.5.0: Sync ke currentAnalysisData + setSegments
                try {
                    if (typeof currentAnalysisData !== 'undefined' && currentAnalysisData && currentAnalysisData.segments) {
                        var _segs = currentAnalysisData.segments;
                        var _hit = null;
                        for (var _k = 0; _k < _segs.length; _k++) {
                            if (String(_segs[_k].id) === String(id)) { _hit = _segs[_k]; break; }
                        }
                        if (!_hit) {
                            // Fallback by position
                            var _bestD = 999;
                            for (var _m = 0; _m < _segs.length; _m++) {
                                var _d = Math.abs(_segs[_m].start - ns);
                                if (_d < _bestD) { _bestD = _d; _hit = _segs[_m]; }
                            }
                        }
                        if (_hit && _bestD < 1) {
                            _hit.start = parseFloat(ns);
                            _hit.end = parseFloat(ne);
                            if (window.CliporaEditor && window.CliporaEditor.setSegments) {
                                window.CliporaEditor.setSegments({
                                    segments: JSON.parse(JSON.stringify(_segs)),
                                    duration: currentAnalysisData.duration || 0,
                                });
                            }
                            console.log('[Edit4] Sync OK → ' + ns.toFixed(2) + 's');
                        }
                    }
                } catch (e) { console.warn('[Edit4] Sync error:', e); }
            }
        });

        // ==== CLICK: toggle cut/keep (kecuali habis drag) ====
        track.addEventListener('click', function(e) {
            // V9.3.1: Skip tombol copy — biarkan timeline-copy.js handle
            if (e.target.closest('.te-segment-copy-btn')) return;
            if (blockClick) { e.stopImmediatePropagation(); e.preventDefault(); return; }
            var segEl = e.target.closest('.te-segment');
            if (!segEl) return; // klik area kosong = TIDAK ADA AKSI
            if (e.target.classList.contains('te-segment-handle')) return;

            var segId = segEl.dataset.id;
            var segs = getSegments();
            var seg = segs.find(function(s) { return String(s.id) === String(segId); });
            if (!seg) return;

            seg.enabled = !seg.enabled;
            if (typeof currentAnalysisData !== 'undefined' && currentAnalysisData) {
                currentAnalysisData.segments = segs;
            }
            if (typeof renderTimeline === 'function') renderTimeline();
            if (typeof renderStats === 'function') renderStats();
            console.log('[Edit4] Toggle ' + segId + ' → ' + (seg.enabled ? 'CUT' : 'KEEP'));
            e.stopImmediatePropagation();
        }, true);

        // ==== DOUBLE-CLICK: copy segmen ====
        track.addEventListener('dblclick', function(e) {
            var segEl = e.target.closest('.te-segment');
            if (!segEl) return;
            var segId = segEl.dataset.id;

            if (window.CliporaEditor && window.CliporaEditor.duplicateSegment) {
                var res = window.CliporaEditor.duplicateSegment(segId);
                if (res) {
                    console.log('[Edit4] Duplicated segmen ' + segId + ' → baru di ' + res.start.toFixed(2) + 's - ' + res.end.toFixed(2) + 's');
                }
            }
            e.preventDefault();
            e.stopImmediatePropagation();
        }, true);

        console.log('[Edit4] Ready — drag, click toggle, double-click copy');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() { setTimeout(run, 1000); });
    } else {
        setTimeout(run, 1000);
    }
})();


/* ============================================================
   V7.0.0: Timeline Zoom (final, sesuai struktur Clipora)
   Struktur:
     teTimelineViewport (scrollable)
       teTimelineZoomWrap (target width)
         teTimeline
           teTrack
   ============================================================ */
(function initZoomFinal() {
    'use strict';

    var MIN = 1;
    var MAX = 10;
    var zoom = 1;
    var viewport, wrap, label;

    function apply() {
        if (!wrap) return;
        // Set width berdasarkan zoom. Viewport akan scroll otomatis.
        wrap.style.width = (zoom * 100) + '%';
        wrap.style.minWidth = (zoom * 100) + '%';
        wrap.style.transition = 'width 0.15s ease-out';

        if (label) label.textContent = Math.round(zoom * 100) + '%';

        var btnIn = document.getElementById('_zIn');
        var btnOut = document.getElementById('_zOut');
        if (btnIn) btnIn.disabled = zoom >= MAX;
        if (btnOut) btnOut.disabled = zoom <= MIN;

        if (btnIn) btnIn.style.opacity = zoom >= MAX ? '0.35' : '1';
        if (btnOut) btnOut.style.opacity = zoom <= MIN ? '0.35' : '1';

        console.log('[Zoom] ' + Math.round(zoom * 100) + '%');
    }

    function setZoom(z) {
        z = Math.max(MIN, Math.min(MAX, z));
        if (Math.abs(z - zoom) < 0.01) return;
        zoom = z;
        apply();
    }

    function run() {
        viewport = document.getElementById('teTimelineViewport');
        wrap = document.getElementById('teTimelineZoomWrap');
        if (!viewport || !wrap) { setTimeout(run, 500); return; }
        if (viewport.dataset.zoomFinal === '1') return;
        viewport.dataset.zoomFinal = '1';

        console.log('[Zoom] Init — target=' + wrap.id);

        // Buat control bar — di atas viewport, rata kanan
        var ctrl = document.createElement('div');
        ctrl.id = '_zoomCtrlFinal';
        ctrl.style.cssText = [
            'display:flex;justify-content:flex-end;align-items:center;',
            'gap:6px;padding:6px 4px 8px;',
            'font-family:inherit;font-size:0.78rem;color:#e8e8ef;',
        ].join('');

        function bstyle() {
            return 'width:30px;height:28px;border:1px solid rgba(139,92,246,0.35);' +
                'border-radius:6px;cursor:pointer;' +
                'background:rgba(139,92,246,0.1);color:#e8e8ef;font-size:1rem;' +
                'display:inline-flex;align-items:center;justify-content:center;' +
                'font-family:inherit;transition:background 0.15s;font-weight:600;';
        }

        ctrl.innerHTML =
            '<span style="color:#94a3b8;font-size:0.7rem;text-transform:uppercase;letter-spacing:0.5px;font-weight:700;">Zoom</span>' +
            '<button id="_zOut" type="button" title="Zoom out (Ctrl −)" style="' + bstyle() + '">−</button>' +
            '<span id="_zLabel" style="min-width:52px;text-align:center;font-weight:700;color:#a78bfa;font-size:0.8rem;">100%</span>' +
            '<button id="_zIn" type="button" title="Zoom in (Ctrl +)" style="' + bstyle() + '">+</button>' +
            '<button id="_zReset" type="button" title="Reset (Ctrl 0)" style="' + bstyle() + 'font-size:0.65rem;">1:1</button>';

        viewport.parentElement.insertBefore(ctrl, viewport);

        label = document.getElementById('_zLabel');

        // Bind klik
        document.getElementById('_zIn').addEventListener('click', function() { setZoom(zoom + 0.5); });
        document.getElementById('_zOut').addEventListener('click', function() { setZoom(zoom - 0.5); });
        document.getElementById('_zReset').addEventListener('click', function() { setZoom(1); });

        // Hover effect
        ['_zIn', '_zOut', '_zReset'].forEach(function(id) {
            var b = document.getElementById(id);
            if (!b) return;
            b.addEventListener('mouseenter', function() { b.style.background = 'rgba(139,92,246,0.3)'; });
            b.addEventListener('mouseleave', function() { b.style.background = 'rgba(139,92,246,0.1)'; });
        });

        // Ctrl + wheel scroll
        viewport.addEventListener('wheel', function(e) {
            if (!e.ctrlKey && !e.metaKey) return;
            e.preventDefault();
            var delta = e.deltaY > 0 ? -0.25 : 0.25;
            if (zoom >= 4) delta *= 2;
            setZoom(zoom + delta);
        }, { passive: false });

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            if (!e.ctrlKey && !e.metaKey) return;
            var t = (document.activeElement && document.activeElement.tagName) || '';
            if (t === 'INPUT' || t === 'TEXTAREA') return;
            if (e.key === '=' || e.key === '+') { e.preventDefault(); setZoom(zoom + 0.5); }
            else if (e.key === '-' || e.key === '_') { e.preventDefault(); setZoom(zoom - 0.5); }
            else if (e.key === '0') { e.preventDefault(); setZoom(1); }
        });

        // Touch: 2-finger pinch
        var pinchStart = null, pinchZoom = 1;
        viewport.addEventListener('touchstart', function(e) {
            if (e.touches.length === 2) {
                var dx = e.touches[0].clientX - e.touches[1].clientX;
                var dy = e.touches[0].clientY - e.touches[1].clientY;
                pinchStart = Math.hypot(dx, dy);
                pinchZoom = zoom;
            }
        }, { passive: true });
        viewport.addEventListener('touchmove', function(e) {
            if (e.touches.length === 2 && pinchStart) {
                e.preventDefault();
                var dx = e.touches[0].clientX - e.touches[1].clientX;
                var dy = e.touches[0].clientY - e.touches[1].clientY;
                var d = Math.hypot(dx, dy);
                setZoom(pinchZoom * (d / pinchStart));
            }
        }, { passive: false });
        viewport.addEventListener('touchend', function(e) {
            if (e.touches.length < 2) pinchStart = null;
        });

        console.log('[Zoom] Ready');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() { setTimeout(run, 1200); });
    } else {
        setTimeout(run, 1200);
    }
})();
