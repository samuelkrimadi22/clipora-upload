﻿// ============================================================
// V9.182.0: HISTORY FIX SUPER AGRESIF
// ============================================================
(function() {
    "use strict";

    var checkInterval = null;

    function renderHistory() {
        // 1. Cek token
        if (!window.CLIPORA_AUTH || !window.CLIPORA_AUTH.token) {
            return false;
        }

        // 2. Cek apakah container kita sudah ada
        if (document.getElementById("forceHistoryContainer")) {
            return true;
        }

        // 3. Buat container dengan posisi fixed (tidak bisa disembunyikan)
        var container = document.createElement("div");
        container.id = "forceHistoryContainer";
        container.style.cssText = "position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: #0f0f1a; z-index: 2147483647; overflow-y: auto; padding: 40px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; box-sizing: border-box;";
        container.innerHTML = '<div style="max-width: 900px; margin: 0 auto;"><h2 style="color: #fff; border-bottom: 1px solid #333; padding-bottom: 15px;">⏳ Memuat Riwayat Proyek...</h2></div>';
        document.body.appendChild(container);

        // 4. Ambil data
        fetch("http://localhost:3000/api/autoclip-projects", {
            headers: { "Authorization": "Bearer " + window.CLIPORA_AUTH.token }
        })
        .then(res => res.json())
        .then(data => {
            var html = '<div style="max-width: 900px; margin: 0 auto;">';
            html += '<h2 style="color: #fff; border-bottom: 1px solid #333; padding-bottom: 15px; margin-bottom: 20px;">📁 Semua Riwayat Proyek (' + data.projects.length + ')</h2>';
            
            data.projects.forEach(function(p) {
                html += `
                    <div style="background: #1e1e2d; padding: 15px; margin-bottom: 10px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #333;">
                        <div>
                            <h4 style="margin: 0; color: #fff; font-size: 16px;">${p.name}</h4>
                            <p style="margin: 5px 0 0 0; font-size: 13px; color: #888;">${new Date(p.created_at).toLocaleString()}</p>
                        </div>
                        <a href="autoclip.php?project=${p.id}" style="background: #8b5cf6; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold; font-size: 14px; white-space: nowrap;">Buka Proyek</a>
                    </div>
                `;
            });
            
            html += '</div>';
            container.innerHTML = html;
            console.log("✅ [ForceHistory] 40 proyek dirender dengan posisi fixed!");
        })
        .catch(err => {
            container.innerHTML = '<div style="max-width: 900px; margin: 0 auto;"><h2 style="color: #ef4444;">❌ Gagal memuat data</h2><p style="color: #fff;">' + err.message + '</p></div>';
            console.error("❌ [ForceHistory] Gagal:", err);
        });

        return true;
    }

    // Jalankan saat DOM ready
    function start() {
        if (renderHistory()) {
            // Berhenti mencoba
            return;
        }

        // Jika belum berhasil (token belum siap), coba lagi tiap 1 detik
        var attempts = 0;
        checkInterval = setInterval(function() {
            attempts++;
            if (renderHistory() || attempts > 30) {
                clearInterval(checkInterval);
            }
        }, 1000);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start);
    } else {
        start();
    }

    console.log("[ForceHistory] Modul aktif (V9.182.0)");
})();