<?php
// render.php — Halaman render terpisah (V2.2.0)
require_once __DIR__ . '/config/config.php';

// Redirect login SEBELUM output apapun
if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Baru include header
require_once __DIR__ . '/includes/header.php';

// Set flag: mode render
$RENDER_MODE = true;
$projectId = $_GET['project'] ?? '';
?>

<link rel="stylesheet" href="assets/css/style.css">

<main class="container render-main">
    <div class="render-header">
        <h1><i class="fas fa-film"></i> Render Video</h1>
        <p>Edit timeline, pilih kualitas, lalu klik "Render Video Final"</p>
    </div>

    <!-- EDITOR DIMUAT LANGSUNG DI SINI (bukan lewat control_panel) -->
    <?php 
    // Set flag supaya control_panel.php hanya render bagian editor
    $RENDER_ONLY_EDITOR = true;
    require_once __DIR__ . '/includes/control_panel.php'; 
    ?>
</main>

<style>
/* ============================================ */
/* RENDER PAGE — CLEAN LAYOUT                   */
/* ============================================ */
body.render-page {
    background: #0a0a0f !important;
}

.render-main {
    padding: 30px 16px 60px !important;
    max-width: 1400px !important;
    width: 100% !important;
    margin: 0 auto !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    box-sizing: border-box !important;
}

.render-header {
    text-align: center;
    margin-bottom: 24px;
    max-width: 700px;
    width: 100%;
}

.render-header h1 {
    font-size: 1.6rem;
    margin: 0 0 8px 0;
    color: #f1f5f9;
    font-weight: 800;
}

.render-header h1 i {
    color: #f59e0b;
}

.render-header p {
    color: #94a3b8;
    font-size: 0.9rem;
    margin: 0;
}

/* ============================================ */
/* SEMBUNYIKAN CONTROL PANEL, TAMPILKAN EDITOR */
/* ============================================ */
.render-page #controlPanel {
    display: contents !important; /* Supaya anak-anaknya bisa di-manage terpisah */
}

.render-page #controlPanel > .panel-title,
.render-page #controlPanel > .info-box,
.render-page #controlPanel > .setting-group:not(#editorContainer),
.render-page #controlPanel > .compact-lock-card,
.render-page #controlPanel > #voiceoverSection,
.render-page #controlPanel > #translateSection,
.render-page #controlPanel > #rapikanBtn,
.render-page #controlPanel > #quotaExhaustedNotice,
.render-page #controlPanel > .watermark-notice,
/* Biarkan progress-box tampil */

/* Editor container — full width */
.render-page #editorContainer {
    display: block !important;
    margin: 0 !important;
    width: 100% !important;
    max-width: 100% !important;
}

/* Hilangkan style kotak gelap di sekeliling editor */
.render-page .control-panel {
    background: transparent !important;
    border: none !important;
    padding: 0 !important;
    box-shadow: none !important;
    max-width: 100% !important;
    width: 100% !important;
}

/* Timeline editor — full width */
.render-page .timeline-editor-wrap {
    max-width: 100% !important;
    width: 100% !important;
    padding: 0 !important;
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;
}

/* Player — lebih besar dan proporsional */
.render-page .te-player-wrap {
    max-width: 100% !important;
    width: 100% !important;
    aspect-ratio: 16/9 !important;
    max-height: 520px !important;
    border-radius: 12px !important;
    margin-bottom: 16px !important;
}

/* ============================================ */
/* RESPONSIVE — MOBILE & TABLET                 */
/* ============================================ */
@media (max-width: 1024px) {
    .render-main {
        padding: 20px 12px 40px !important;
    }
    
    .render-page .te-player-wrap {
        max-height: 400px !important;
    }
}

@media (max-width: 640px) {
    .render-main {
        padding: 16px 8px 40px !important;
    }
    
    .render-header h1 {
        font-size: 1.2rem !important;
    }
    
    .render-header p {
        font-size: 0.78rem !important;
    }
    
    .render-page .te-player-wrap {
        max-height: 220px !important;
        border-radius: 8px !important;
    }
    
    /* Stats jadi 1 kolom */
    .render-page .te-stats {
        grid-template-columns: 1fr !important;
        gap: 8px !important;
        padding: 10px !important;
    }
    
    .render-page .te-stat-item {
        display: grid !important;
        grid-template-columns: auto 1fr auto !important;
        align-items: center !important;
        gap: 10px !important;
        padding: 12px 14px !important;
        text-align: left !important;
    }
    
    .render-page .te-stat-label {
        justify-content: flex-start !important;
        margin-bottom: 0 !important;
        font-size: 0.72rem !important;
    }
    
    .render-page .te-stat-value {
        font-size: 1.3rem !important;
        justify-self: end !important;
    }
    
    /* Quick mode jadi 1 kolom */
    .render-page .te-qm-buttons {
        grid-template-columns: 1fr !important;
        gap: 8px !important;
    }
    
    .render-page .te-qm-btn {
        flex-direction: row !important;
        text-align: left !important;
        padding: 12px !important;
        gap: 12px !important;
    }
    
    .render-page .te-qm-icon {
        font-size: 1.4rem !important;
        flex-shrink: 0 !important;
    }
    
    .render-page .te-qm-text {
        flex: 1 !important;
    }
    
    .render-page .te-qm-badge {
        position: static !important;
        margin-left: auto !important;
    }
    
    /* Aksi cepat jadi 1 kolom */
    .render-page .qa-grid {
        grid-template-columns: 1fr !important;
    }
    
    /* Format export jadi 3 kecil */
    .render-page .te-format-grid {
        grid-template-columns: repeat(3, 1fr) !important;
        gap: 6px !important;
    }
    
    .render-page .te-format-name {
        font-size: 0.65rem !important;
    }
    
    /* Timeline lebih pendek */
    .render-page .te-timeline {
        height: 60px !important;
    }
    
    .render-page .te-segment {
        top: 8px !important;
        height: 44px !important;
    }
    
    /* Tombol aksi full width */
    .render-page .te-actions {
        flex-direction: column !important;
    }
    
    .render-page .te-btn-primary,
    .render-page .te-btn-secondary {
        width: 100% !important;
        justify-content: center !important;
    }
    
    /* Quality selector full width */
    .render-page .te-quality-row {
        flex-direction: column !important;
        align-items: stretch !important;
    }
    
    .render-page .te-quality-select {
        width: 100% !important;
        min-width: unset !important;
    }
    
    /* Segment info */
    .render-page .te-si-actions {
        grid-template-columns: 1fr !important;
    }
}

@media (max-width: 380px) {
    .render-page .te-stat-value {
        font-size: 1.1rem !important;
    }
    
    .render-header h1 {
        font-size: 1.1rem !important;
    }
}

/* ============================================ */
/* BATASI LEBAR EDITOR — AGAR PROPORSIONAL      */
/* ============================================ */

/* Container utama — jangan terlalu lebar */
.render-page .render-main {
    max-width: 1100px !important;
    padding: 30px 20px 60px !important;
}

/* Editor wrap — full width container */
.render-page .timeline-editor-wrap {
    max-width: 100% !important;
    width: 100% !important;
    padding: 24px !important;
    margin: 0 auto !important;
    background: rgba(15, 23, 42, 0.5) !important;
    border: 1px solid rgba(139, 92, 246, 0.15) !important;
    border-radius: 16px !important;
}

/* Player — max 900px, center */
.render-page .te-player-wrap {
    max-width: 100% !important;
    width: 100% !important;
    aspect-ratio: 16/9 !important;
    max-height: 500px !important;
    margin: 0 auto 20px !important;
    border-radius: 12px !important;
}

/* Header editor — rapikan */
.render-page .te-header {
    margin-bottom: 20px !important;
}

.render-page .te-header h3 {
    font-size: 1.1rem !important;
}

.render-page .te-subtitle {
    font-size: 0.82rem !important;
}

/* Stats — 4 kolom rapi */
.render-page .te-stats {
    grid-template-columns: repeat(4, minmax(0, 1fr)) !important;
    gap: 12px !important;
    padding: 14px !important;
    margin-bottom: 20px !important;
}

/* Accordion pengaturan lanjutan */
.render-page .te-accordion {
    margin-top: 16px !important;
}

/* ============================================ */
/* RESPONSIVE — TABLET                          */
/* ============================================ */
@media (max-width: 1024px) {
    .render-page .render-main {
        max-width: 100% !important;
        padding: 20px 16px 40px !important;
    }
    
    .render-page .timeline-editor-wrap {
        padding: 18px !important;
    }
    
    .render-page .te-player-wrap {
        max-height: 400px !important;
    }
    
    .render-page .te-stats {
        grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
    }
}

/* ============================================ */
/* RESPONSIVE — MOBILE                          */
/* ============================================ */
@media (max-width: 640px) {
    .render-page .render-main {
        padding: 16px 10px 40px !important;
    }
    
    .render-page .timeline-editor-wrap {
        padding: 14px !important;
        border-radius: 12px !important;
    }
    
    .render-page .te-player-wrap {
        max-height: 220px !important;
        border-radius: 8px !important;
    }
    
    .render-page .te-header h3 {
        font-size: 0.95rem !important;
    }
    
    .render-page .te-subtitle {
        font-size: 0.72rem !important;
    }
    
    /* Stats jadi 1 kolom */
    .render-page .te-stats {
        grid-template-columns: 1fr !important;
        gap: 8px !important;
        padding: 10px !important;
    }
    
    .render-page .te-stat-item {
        display: grid !important;
        grid-template-columns: auto 1fr auto !important;
        align-items: center !important;
        gap: 10px !important;
        padding: 12px 14px !important;
        text-align: left !important;
    }
    
    .render-page .te-stat-label {
        justify-content: flex-start !important;
        margin-bottom: 0 !important;
    }
    
    .render-page .te-stat-value {
        justify-self: end !important;
    }
}

/* ============================================ */
/* OPTIMASI FINAL — PLAYER COMPACT              */
/* ============================================ */

/* Player — kurangi max-height agar editor lebih compact */
.render-page .te-player-wrap {
    max-height: 380px !important;   /* dari 500px */
    margin: 0 auto 16px !important;
}

/* Header editor — lebih compact */
.render-page .te-header {
    margin-bottom: 14px !important;
    padding-bottom: 12px !important;
    border-bottom: 1px solid rgba(139, 92, 246, 0.1) !important;
}

/* Stats — lebih compact */
.render-page .te-stats {
    padding: 12px !important;
    gap: 10px !important;
    margin-bottom: 14px !important;
}

.render-page .te-stat-item {
    padding: 12px 8px !important;
}

.render-page .te-stat-label {
    font-size: 0.65rem !important;
    margin-bottom: 5px !important;
}

.render-page .te-stat-value {
    font-size: 1.3rem !important;
}

/* Editor wrap — sedikit lebih compact */
.render-page .timeline-editor-wrap {
    padding: 20px !important;
}

/* Container utama — lebih lega */
.render-page .render-main {
    max-width: 1100px !important;
    padding: 24px 16px 40px !important;
}

/* ============================================ */
/* TABLET                                       */
/* ============================================ */
@media (max-width: 1024px) {
    .render-page .te-player-wrap {
        max-height: 340px !important;
    }
    
    .render-page .render-main {
        padding: 20px 14px 36px !important;
    }
}

/* ============================================ */
/* MOBILE — PLAYER LEBIH PENDEK                 */
/* ============================================ */
@media (max-width: 640px) {
    .render-page .te-player-wrap {
        max-height: 200px !important;
    }
    
    .render-page .timeline-editor-wrap {
        padding: 14px !important;
    }
    
    .render-page .te-stats {
        padding: 10px !important;
    }
    
    .render-page .te-stat-item {
        padding: 10px 12px !important;
    }
    
    .render-page .te-stat-value {
        font-size: 1.15rem !important;
    }
}

/* ============================================ */
/* V12.0.0: FORCE TAMPILKAN DROPDOWN KUALITAS   */
/* ============================================ */

/* Bar container */
.render-page .te-quality-bar {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    padding: 14px 16px !important;
    background: linear-gradient(135deg, rgba(139, 92, 246, 0.06), rgba(6, 182, 212, 0.04)) !important;
    border: 1px solid rgba(139, 92, 246, 0.2) !important;
    border-radius: 12px !important;
    margin-top: 16px !important;
    height: auto !important;
    max-height: none !important;
    overflow: visible !important;
}

/* Head (label + hint) */
.render-page .te-quality-head {
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    gap: 12px !important;
    margin-bottom: 10px !important;
    flex-wrap: wrap !important;
    height: auto !important;
}

.render-page .te-quality-label {
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    color: #e2e8f0 !important;
    font-size: 0.85rem !important;
    font-weight: 700 !important;
    visibility: visible !important;
    opacity: 1 !important;
}

.render-page .te-quality-label i {
    color: #8b5cf6 !important;
    display: inline-block !important;
}

.render-page .te-quality-hint {
    display: inline-block !important;
    font-size: 0.72rem !important;
    color: #94a3b8 !important;
    font-style: italic !important;
    visibility: visible !important;
    opacity: 1 !important;
}

/* Row container untuk select + tombol upgrade */
.render-page .te-quality-row {
    display: flex !important;
    align-items: center !important;
    gap: 10px !important;
    flex-wrap: wrap !important;
    visibility: visible !important;
    opacity: 1 !important;
    height: auto !important;
    min-height: 44px !important;
}

/* DROPDOWN SELECT — paksa tampil */
.render-page .te-quality-select,
.render-page select#qualitySelect,
.render-page #qualitySelect {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    position: static !important;
    width: 100% !important;
    min-width: 240px !important;
    max-width: 100% !important;
    height: auto !important;
    min-height: 44px !important;
    padding: 12px 40px 12px 16px !important;
    background-color: rgba(0, 0, 0, 0.4) !important;
    background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23a78bfa' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e") !important;
    background-repeat: no-repeat !important;
    background-position: right 12px center !important;
    background-size: 16px !important;
    border: 1.5px solid rgba(139, 92, 246, 0.4) !important;
    border-radius: 10px !important;
    color: #e2e8f0 !important;
    font-size: 0.88rem !important;
    font-weight: 600 !important;
    font-family: inherit !important;
    cursor: pointer !important;
    outline: none !important;
    box-sizing: border-box !important;
    -webkit-appearance: none !important;
    -moz-appearance: none !important;
    appearance: none !important;
    text-indent: 0 !important;
    transform: none !important;
    filter: none !important;
    clip: auto !important;
    clip-path: none !important;
    overflow: visible !important;
}

.render-page .te-quality-select option,
.render-page select#qualitySelect option {
    background: #1e1b2e !important;
    color: #ffffff !important;
    padding: 10px !important;
    font-size: 0.88rem !important;
}

.render-page .te-quality-select:hover {
    border-color: rgba(139, 92, 246, 0.7) !important;
    background-color: rgba(0, 0, 0, 0.5) !important;
}

.render-page .te-quality-select:focus {
    border-color: #8b5cf6 !important;
    box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2) !important;
}

/* ============================================ */
/* V10.1.0: PAKSA TAMPILKAN PROGRESS BAR         */
/* ============================================ */
#progressContainer {
    display: none; /* Default tersembunyi, akan dimunculkan oleh JS */
}

#progressContainer[style*="display: block"] {
    display: block !important;
    margin: 20px auto !important;
    max-width: 600px !important;
    padding: 20px !important;
    background: rgba(15, 23, 42, 0.6) !important;
    border: 1px solid rgba(139, 92, 246, 0.3) !important;
    border-radius: 16px !important;
}

#progressContainer[style*="display: block"],
#progressContainer[style*="display:block"] {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    height: auto !important;
    max-height: none !important;
    overflow: visible !important;
    position: relative !important;
    z-index: 9999 !important;
    margin: 20px auto !important;
    padding: 20px !important;
    background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(6, 182, 212, 0.05)) !important;
    border: 2px solid rgba(139, 92, 246, 0.3) !important;
    border-radius: 16px !important;
    max-width: 600px !important;
    box-shadow: 0 8px 32px rgba(139, 92, 246, 0.2) !important;
}

#progressContainer .progress-bar {
    display: block !important;
    visibility: visible !important;
    height: 36px !important;
    background: rgba(0, 0, 0, 0.4) !important;
    border-radius: 30px !important;
    overflow: hidden !important;
    margin-bottom: 12px !important;
}

#progressContainer .progress-fill {
    display: flex !important;
    visibility: visible !important;
    height: 100% !important;
    background: linear-gradient(135deg, #8b5cf6, #06b6d4) !important;
    align-items: center !important;
    justify-content: center !important;
    font-weight: 700 !important;
    color: white !important;
    font-size: 0.9rem !important;
    transition: width 0.5s ease !important;
}

#progressContainer .progress-text {
    display: block !important;
    visibility: visible !important;
    text-align: center !important;
    color: #e2e8f0 !important;
    font-size: 0.95rem !important;
    font-weight: 600 !important;
    margin-bottom: 8px !important;
}

#progressContainer .progress-detail {
    display: block !important;
    visibility: visible !important;
    text-align: center !important;
    color: #94a3b8 !important;
    font-size: 0.82rem !important;
    line-height: 1.5 !important;
}

/* ============================================ */
/* V11.0.0: FULLSCREEN PROGRESS OVERLAY          */
/* ============================================ */
#cliporaRenderProgress {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(10, 15, 25, 0.92);
    backdrop-filter: blur(8px);
    z-index: 2147483647;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

#cliporaRenderProgress.active {
    display: flex;
}

#cliporaRenderProgress .crp-card {
    background: linear-gradient(145deg, #1e293b, #0f172a);
    border: 1px solid rgba(139, 92, 246, 0.4);
    border-radius: 24px;
    padding: 40px 32px;
    max-width: 480px;
    width: 100%;
    text-align: center;
    box-shadow: 0 30px 80px rgba(0,0,0,0.7), 0 0 60px rgba(139, 92, 246, 0.2);
    animation: crpSlideIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
}

@keyframes crpSlideIn {
    from { transform: scale(0.9) translateY(20px); opacity: 0; }
    to { transform: scale(1) translateY(0); opacity: 1; }
}

#cliporaRenderProgress .crp-icon {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(139, 92, 246, 0.2), rgba(6, 182, 212, 0.1));
    border: 2px solid rgba(139, 92, 246, 0.4);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;
    font-size: 2rem;
    color: #a78bfa;
    animation: crpPulse 2s ease-in-out infinite;
}

@keyframes crpPulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(139, 92, 246, 0.4); }
    50% { box-shadow: 0 0 0 15px rgba(139, 92, 246, 0); }
}

#cliporaRenderProgress .crp-title {
    font-size: 1.4rem;
    font-weight: 800;
    color: #f1f5f9;
    margin: 0 0 8px;
}

#cliporaRenderProgress .crp-subtitle {
    font-size: 0.9rem;
    color: #94a3b8;
    margin: 0 0 28px;
}

#cliporaRenderProgress .crp-bar-wrap {
    background: rgba(0, 0, 0, 0.5);
    border-radius: 20px;
    height: 24px;
    overflow: hidden;
    margin-bottom: 16px;
    border: 1px solid rgba(139, 92, 246, 0.2);
    position: relative;
}

#cliporaRenderProgress .crp-bar-fill {
    height: 100%;
    width: 0%;
    background: linear-gradient(90deg, #8b5cf6, #06b6d4);
    border-radius: 20px;
    transition: width 0.5s ease;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding-right: 10px;
    font-size: 0.75rem;
    font-weight: 700;
    color: white;
    box-shadow: 0 0 20px rgba(139, 92, 246, 0.6);
}

#cliporaRenderProgress .crp-percent {
    font-size: 2.5rem;
    font-weight: 900;
    background: linear-gradient(135deg, #a78bfa, #06b6d4);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 12px;
    line-height: 1;
}

#cliporaRenderProgress .crp-status {
    font-size: 0.85rem;
    color: #cbd5e1;
    min-height: 22px;
}

/* ============================================ */
/* V15.0.0: SEMBUNYIKAN ELEMEN INDEX DI RENDER  */
/* ============================================ */
body.render-page #rapikanBtn,
body.render-page #quotaExhaustedNotice,
body.render-page .quota-widget,
body.render-page #aggressiveness,
body.render-page #contentCreatorMode,
body.render-page #whisperModel,
body.render-page .setting-group:not(#editorContainer),
body.render-page .info-box,
body.render-page .watermark-notice,
body.render-page .compact-lock-card,
body.render-page #voiceoverSection,
body.render-page #translateSection,
body.render-page .te-quality-bar,
body.render-page .te-quick-modes,
body.render-page .te-format-section,
body.render-page .te-quick-actions,
body.render-page #saveProjectBtn,
body.render-page #resetEditsBtn {
    display: none !important;
    visibility: hidden !important;
    height: 0 !important;
    margin: 0 !important;
    padding: 0 !important;
    overflow: hidden !important;
    opacity: 0 !important;
    pointer-events: none !important;
}

/* Sembunyikan judul kontrol panel */
body.render-page #controlPanel > .panel-title {
    display: none !important;
}

/* Sembunyikan notifikasi kuota habis */
body.render-page #quotaExhaustedNotice,
body.render-page .alert-danger,
body.render-page .quota-alert {
    display: none !important;
}
</style>

<script>
    window.__PROJECT_ID__ = '<?= htmlspecialchars($projectId) ?>';
    window.__RENDER_PAGE__ = true;
    document.body.classList.add('render-page');
</script>


<!-- V17.0.0: FULLSCREEN PROGRESS OVERLAY (Enhanced) -->
<div id="cliporaRenderProgress">
    <div class="crp-card">
        <div class="crp-icon"><i class="fas fa-magic"></i></div>
        <h2 class="crp-title">Merender Video Anda</h2>
        <p class="crp-subtitle">
            Setelah selesai, Anda akan <strong style="color: #fbbf24;">otomatis diarahkan ke halaman download</strong>.
        </p>
        <div class="crp-percent" id="crpPercent">0%</div>
        <div class="crp-bar-wrap">
            <div class="crp-bar-fill" id="crpBarFill"></div>
        </div>
        <div class="crp-status" id="crpStatus">Menyiapkan...</div>
        
        <!-- V17.0.0: Info tambahan agar user tenang menunggu -->
        <div style="margin-top: 20px; padding: 14px 16px; background: rgba(59, 130, 246, 0.08); border: 1px solid rgba(59, 130, 246, 0.25); border-radius: 12px; font-size: 0.8rem; color: #cbd5e1; text-align: left; line-height: 1.6;">
            <div style="margin-bottom: 6px;">💡 <strong>Tips:</strong></div>
            <div style="padding-left: 16px; margin-bottom: 3px;">• Jangan tutup tab ini sampai selesai</div>
            <div style="padding-left: 16px; margin-bottom: 3px;">• Anda bisa lanjut kerja setelah download muncul</div>
            <div style="padding-left: 16px;">• Estimasi: 3–15 menit (tergantung durasi video)</div>
        </div>
    </div>
</div>


<!-- ============================================================ -->
<!-- SCRIPT NOTIFIKASI PAKSA (ANTI GAGAL & Z-INDEX MAXIMAL)       -->
<!-- ============================================================ -->
<script>
(function() {
    window.showCustomToast = function(message, type = 'success') {
        const oldToast = document.getElementById('cliporaForceToast');
        if (oldToast) oldToast.remove();
        const toast = document.createElement('div');
        toast.id = 'cliporaForceToast';
        const colors = { success: { bg: '#22c55e', icon: 'fa-check-circle' }, error: { bg: '#ef4444', icon: 'fa-times-circle' }, info: { bg: '#3b82f6', icon: 'fa-info-circle' } };
        const style = colors[type] || colors.success;
        toast.style.cssText = `position: fixed !important; top: 20px !important; right: 20px !important; z-index: 2147483647 !important; display: flex !important; align-items: center !important; gap: 12px !important; padding: 16px 24px !important; background: ${style.bg} !important; color: #ffffff !important; border-radius: 12px !important; box-shadow: 0 10px 40px rgba(0,0,0,0.5) !important; font-family: sans-serif !important; font-size: 16px !important; font-weight: bold !important; pointer-events: none !important; transform: translateX(150%) !important; transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) !important;`;
        toast.innerHTML = `<i class="fas ${style.icon}" style="font-size:20px !important;"></i><span>${message}</span>`;
        document.body.appendChild(toast);
        setTimeout(() => { toast.style.transform = 'translateX(0) !important'; }, 10);
        setTimeout(() => { toast.style.transform = 'translateX(150%) !important'; setTimeout(() => toast.remove(), 400); }, 3000);
    };
})();
</script>

<!-- ============================================================ -->
<!-- SCRIPT SIMPAN PROYEK (V11.0.0 - CLEAN & ANTI DUPLIKAT)       -->
<!-- ============================================================ -->
<script>
(function() {
    if (window.__SAVE_PROJECT_FINAL__) return;
    window.__SAVE_PROJECT_FINAL__ = true;
    document.addEventListener('click', async function(e) {
        const btn = e.target.closest('#saveProjectBtn');
        if (!btn) return;
        e.preventDefault();
        e.stopPropagation();
        if (btn.disabled) return;
        if (typeof currentAnalysisData === 'undefined' || !currentAnalysisData) return window.showCustomToast('Belum ada data analisis.', 'error');
        const originalHTML = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...';
        try {
            const token = localStorage.getItem('token') || (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || '';
            if (!token) throw new Error('Token login tidak ditemukan.');
            const name = "Proyek " + new Date().toLocaleString('id-ID', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
            const payload = {
                name: name.trim(),
                inputVideoPath: currentAnalysisData.inputPath,
                analysisJson: currentAnalysisData,
                preset: (document.getElementById("qualitySelect") || {}).value || currentAnalysisData.preset || "720p",
                enableBurnSubtitle: currentAnalysisData.enableBurnSubtitle !== false,
                addWatermark: currentAnalysisData.addWatermark !== false,
            };
            if (currentAnalysisData.translatedWords && currentAnalysisData.translatedWords.length > 0) payload.translatedWords = currentAnalysisData.translatedWords;
            if (currentAnalysisData.translatedSegments && currentAnalysisData.translatedSegments.length > 0) payload.translatedSegments = currentAnalysisData.translatedSegments;
            if (currentAnalysisData.translateTarget) payload.translateTarget = currentAnalysisData.translateTarget;
            const apiUrl = (typeof API_URL !== 'undefined' ? API_URL : 'http://localhost:3000/api') + '/projects';
            const response = await fetch(apiUrl, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }, body: JSON.stringify(payload) });
            const data = await response.json();
            if (response.ok && data.success) {
                if (data.projectId) localStorage.setItem('clipora_saved_projects', JSON.stringify([data.projectId]));
                window.showCustomToast('Proyek berhasil disimpan!', 'success');
            } else { throw new Error(data.error || 'Gagal menyimpan proyek.'); }
        } catch (error) {
            window.showCustomToast('Gagal: ' + error.message, 'error');
        } finally {
            btn.disabled = false;
            btn.innerHTML = originalHTML;
        }
    }, true);
})();
</script>

<!-- ============================================================ -->
<!-- SCRIPT UTAMA: LOAD PROYEK, VIDEO, STIKER & PERBAIKAN IKON    -->
<!-- ============================================================ -->
<script>
(function() {
    const urlParams = new URLSearchParams(window.location.search);
    const projectId = urlParams.get('project');
    if (!projectId) return;
    if (window.__RENDER_PROJECT_LOADED__) return;
    window.__RENDER_PROJECT_LOADED__ = true;

    console.log("🔄 [Render] Memuat proyek:", projectId);

    const token = localStorage.getItem('token') || (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || '';
    const apiUrl = (typeof API_URL !== 'undefined' ? API_URL : 'http://localhost:3000/api');

    fetch(apiUrl + '/projects/' + projectId + '/use', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token } })
    .then(res => res.json())
    .then(data => {
        if (!data.success) throw new Error(data.error || 'Gagal memuat proyek');
        console.log("✅ [Render] Proyek dimuat:", data);
        
        // 1. Simpan Data Global
        window.currentAnalysisId = data.analysisId;
        window.currentProjectId = data.projectId;
        window.currentAnalysisData = data.analysis;

        // 2. Set Video Source
        const videoEl = document.getElementById('editorVideo');
        if (videoEl && data.analysis.inputPath) {
            let inputPath = data.analysis.inputPath.replace(/\\/g, "/");
            let uploadsIdx = inputPath.indexOf("/uploads/");
            let videoSrc = "";
            if (uploadsIdx !== -1) {
                let pathParts = window.location.pathname.split("/").filter(Boolean);
                let projectDir = pathParts.length > 0 && pathParts[0] !== "uploads" ? "/" + pathParts[0] : "";
                videoSrc = projectDir + inputPath.substring(uploadsIdx);
            } else {
                videoSrc = "uploads/" + inputPath.split("/").pop();
            }
            console.log("🎥 [Render] Set video src:", videoSrc);
            videoEl.src = videoSrc;
            videoEl.load(); 
        }

        // 3. Panggil renderEditor (Tampilkan UI)
        if (typeof renderEditor === 'function') {
            renderEditor(data.analysis);
        } else if (window.CliporaEditor && typeof window.CliporaEditor.start === 'function') {
            window.CliporaEditor.start(data.analysis);
        }

        // 4. Perbaikan Ikon (Hemat, Seimbang, Halus, dll)
        setTimeout(function() {
            var qmButtons = document.querySelectorAll('.te-qm-btn');
            qmButtons.forEach(function(btn) {
                var textEl = btn.querySelector('.te-qm-text');
                if (!textEl) return;
                var rawText = textEl.innerText || textEl.textContent;
                var cleanText = rawText.replace(/[^a-zA-Z ]/g, '').trim(); 
                var iconHtml = '';
                if (cleanText.includes('Hemat')) {
                    iconHtml = '<i class="fas fa-bolt" style="color:#f59e0b; font-size:1.4rem; margin-bottom:8px; display:block;"></i>';
                    textEl.innerHTML = 'Hemat';
                } else if (cleanText.includes('Seimbang')) {
                    iconHtml = '<i class="fas fa-balance-scale" style="color:#06b6d4; font-size:1.4rem; margin-bottom:8px; display:block;"></i>';
                    textEl.innerHTML = 'Seimbang';
                } else if (cleanText.includes('Halus')) {
                    iconHtml = '<i class="fas fa-feather" style="color:#8b5cf6; font-size:1.4rem; margin-bottom:8px; display:block;"></i>';
                    textEl.innerHTML = 'Halus';
                }
                if (iconHtml && !btn.querySelector('i')) {
                    btn.insertAdjacentHTML('afterbegin', iconHtml);
                }
            });
            console.log("[Fix Icon] Selesai!");
        }, 1500);

        // 5. Paksa Load Filmstrip (Stiker)
        setTimeout(function() {
            if (typeof loadFilmstripStream === 'function') {
                console.log("[Render] Memicu loadFilmstripStream manual...");
                loadFilmstripStream();
            } else {
                console.warn("[Render] loadFilmstripStream tidak ditemukan!");
            }
        }, 1500);

        return;
    })
    .catch(err => {
        console.error("❌ [Render] Gagal:", err);
        if (window.showCustomToast) {
            window.showCustomToast('Gagal memuat proyek: ' + err.message, 'error');
        }
    });
})();
</script>

<script>
// ============================================================
// PERBAIKAN TOMBOL PLAY/PAUSE DI TENGAH VIDEO (OVERLAY)
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    // Kita tunggu 2 detik agar elemen video dan tombol sudah dirender oleh main.js
    setTimeout(function() {
        console.log("[Fix Play Button] Memasang event listener...");

        const video = document.getElementById('editorVideo');
        const playBtn = document.getElementById('tePlayBtn'); // Tombol bulat di tengah
        const overlay = document.querySelector('.te-player-overlay'); // Area overlay

        if (!video) {
            console.warn("[Fix Play Button] Video tidak ditemukan!");
            return;
        }

        // 1. Fungsi untuk update ikon tombol
        function updateButtonIcon() {
            if (!playBtn) return;
            if (video.paused) {
                // Jika video pause, tampilkan ikon Play (segitiga)
                playBtn.innerHTML = '<i class="fas fa-play"></i>';
                playBtn.style.opacity = '1';
            } else {
                // Jika video main, tampilkan ikon Pause (garis dua)
                playBtn.innerHTML = '<i class="fas fa-pause"></i>';
                playBtn.style.opacity = '1'; // Biarkan terlihat saat hover
            }
        }

        // 2. Pasang event listener ke tombol Play
        if (playBtn) {
            // Hapus event lama (jika ada) dengan clone
            const newPlayBtn = playBtn.cloneNode(true);
            playBtn.parentNode.replaceChild(newPlayBtn, playBtn);
            
            // Pasang event baru
            newPlayBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation(); // Mencegah klik tembus ke video
                
                if (video.paused) {
                    video.play();
                } else {
                    video.pause();
                }
                updateButtonIcon();
            });
        }

        // 3. Pasang event listener ke video (agar ikon update saat play/pause via kontrol video)
        video.addEventListener('play', updateButtonIcon);
        video.addEventListener('pause', updateButtonIcon);

        // 4. Opsional: Klik di area video (selain tombol) juga bisa play/pause
        if (overlay) {
            overlay.addEventListener('click', function(e) {
                // Jika yang diklik adalah tombol play, biarkan event tombol yang handle
                if (e.target.closest('#tePlayBtn') || e.target.closest('.te-play-btn')) return;
                
                if (video.paused) {
                    video.play();
                } else {
                    video.pause();
                }
                updateButtonIcon();
            });
        }

        // Update ikon pertama kali
        updateButtonIcon();
        console.log("[Fix Play Button] Selesai dipasang!");

    }, 2000); // Jeda 2 detik agar editor siap
});
</script>



<script>
// ============================================================
// V14.0.0: FORCE REHYDRATE + REDIRECT KE DOWNLOAD PAGE
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    let isRehydrating = false; 

    document.addEventListener('click', async function(e) {
        const btn = e.target.closest('#renderFinalBtn');
        if (!btn) return;

        if (isRehydrating) return;
        
        const urlParams = new URLSearchParams(window.location.search);
        const projectId = urlParams.get('project');
        
        if (projectId) {
            e.preventDefault(); 
            e.stopPropagation();

            console.log("🔄 [Guard] Memaksa rehydrate proyek sebelum render...");
            isRehydrating = true;
            
            const origText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyiapkan data...';

            try {
                const token = localStorage.getItem('token') || (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || '';
                const apiUrl = (typeof API_URL !== 'undefined' ? API_URL : 'http://localhost:3000/api');
                
                // 1. Rehydrate
                const res = await fetch(apiUrl + '/projects/' + projectId + '/use', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }
                });
                const data = await res.json();

                if (data.success && data.analysisId) {
                    console.log("✅ [Guard] Rehydrate sukses. ID:", data.analysisId);
                    window.currentAnalysisId = data.analysisId;
                    if (typeof currentAnalysisId !== 'undefined') currentAnalysisId = data.analysisId;

                    isRehydrating = false; // Buka kunci guard

                    // 2. Panggil fungsi renderFinal dengan AWAIT
                    if (window.CliporaEditor && typeof window.CliporaEditor.renderFinal === 'function') {
                        console.log("🚀 [Guard] Memulai render...");
                        
                        // Tunggu render selesai
                        await window.CliporaEditor.renderFinal();
                        
                        // Kembalikan tombol (meskipun halaman akan redirect)
                        btn.disabled = false;
                        btn.innerHTML = origText;

                        // 3. REDIRECT KE HALAMAN DOWNLOAD
                        // Cek apakah render sukses (mendapatkan hasil video)
                        const result = window.__CLIPORA_LAST_RESULT__;
                        if (result && result.filename) {
                            let files = [];
                            if (result.filename) files.push(result.filename);
                            if (result.outputFilename) files.push(result.outputFilename);
                            if (result.downloadUrl) files.push(result.downloadUrl.split("/").pop());
                            
                            // Hapus duplikat
                            files = [...new Set(files)].filter(Boolean);
                            
                            if (files.length > 0) {
                                let dlUrl = "download-page.php?files=" + encodeURIComponent(files.join("|"));
                                dlUrl += "&origDur=" + encodeURIComponent(result.originalDuration || 0);
                                dlUrl += "&newDur=" + encodeURIComponent(result.newDuration || 0);
                                dlUrl += "&silences=" + encodeURIComponent(result.silences || 0);
                                dlUrl += "&filler=" + encodeURIComponent(result.fillerSegments || 0);
                                dlUrl += "&ai=" + encodeURIComponent(result.aiSegments || 0);
                                dlUrl += "&filesize=" + encodeURIComponent(result.filesize || 0);
                                dlUrl += "&filename=" + encodeURIComponent(result.filename || "");
                                
                                console.log("[Guard] ✅ Render selesai! Redirect ke:", dlUrl);
                                window.location.replace(dlUrl);
                            }
                        } else {
                            console.warn("[Guard] Render selesai, tapi tidak ada data file untuk didownload.");
                            isRehydrating = false;
                        }
                    } else {
                        throw new Error("CliporaEditor.renderFinal tidak tersedia");
                    }
                } else {
                    throw new Error(data.error || "Gagal rehydrate");
                }

            } catch (err) {
                console.error("❌ [Guard] Gagal:", err);
                if (window.showCustomToast) window.showCustomToast("Gagal: " + err.message, "error");
                btn.disabled = false;
                btn.innerHTML = origText;
                isRehydrating = false; 
            }
        }
    }, true); 
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>