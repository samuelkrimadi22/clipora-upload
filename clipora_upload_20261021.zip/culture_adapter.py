# ============================================================
# V9.180.20: CULTURE ADAPTER
# AI Local Culture & Slang Adaptation
# ============================================================
import os
import json
import re
import sys

CULTURE_DB_PATH = os.path.join(os.path.dirname(__file__), "data", "culture", "regions.json")

_culture_cache = None


def load_culture_db():
    """Load database culture ke memory."""
    global _culture_cache
    if _culture_cache is not None:
        return _culture_cache

    try:
        # V9.180.22: Fix UTF-8 BOM
        with open(CULTURE_DB_PATH, "r", encoding="utf-8-sig") as f:
            _culture_cache = json.load(f)
        print(f"[Culture] Loaded {len(_culture_cache)} regions", file=sys.stderr)
        return _culture_cache
    except Exception as e:
        print(f"[Culture] Error load: {e}", file=sys.stderr)
        return {}


def reload_culture_db():
    """Force reload database."""
    global _culture_cache
    _culture_cache = None
    return load_culture_db()


def get_region_info(region_key):
    """Ambil info satu region."""
    db = load_culture_db()
    return db.get(region_key, {})


def list_regions():
    """List semua region yang tersedia."""
    db = load_culture_db()
    return [
        {
            "key": k,
            "name": v.get("name", k),
            "language": v.get("language", ""),
            "capital": v.get("capital", ""),
            "flag": v.get("flag", ""),
        }
        for k, v in db.items()
    ]


# V9.180.25: FIX_DOUBLE_REPLACE
def _preserve_case(original, replacement):
    """Preserve case dari original ke replacement."""
    if not original or not replacement:
        return replacement
    if original.isupper():
        return replacement.upper()
    if original.istitle():
        return replacement.capitalize()
    return replacement


def adapt_text_for_region(text, region_key):
    """
    Adapt text (subtitle) untuk region tertentu.
    V9.180.26: FIX - Double replacement + preserve case.
    """
    region = get_region_info(region_key)
    if not region:
        return text

    # Kumpulkan SEMUA mapping (pronouns + slang)
    all_mappings = {}

    # Pronouns
    pronouns = region.get("pronouns", {})
    for standard, locals_list in pronouns.items():
        if locals_list:
            all_mappings[standard] = locals_list[0]

    # Slang
    slang = region.get("slang", {})
    for standard, local in slang.items():
        all_mappings[standard] = local

    if not all_mappings:
        return text

    # Sort by panjang DESCENDING (longest first)
    sorted_mappings = sorted(all_mappings.items(), key=lambda x: len(x[0]), reverse=True)

    # Escape semua keys
    patterns = [re.escape(k) for k, v in sorted_mappings]
    combined_pattern = r"\b(" + "|".join(patterns) + r")\b"

    # Build mapping dict (lowercase -> replacement)
    mapping_dict = {k.lower(): v for k, v in sorted_mappings}

    def replacer(match):
        original_word = match.group(0)
        replacement = mapping_dict.get(original_word.lower())
        if replacement is None:
            return original_word
        return _preserve_case(original_word, replacement)

    # Replace SEKALIGUS (tidak akan double)
    adapted = re.sub(combined_pattern, replacer, text, flags=re.IGNORECASE)

    return adapted

def get_culture_visual(region_key):
    """Ambil visual config untuk region."""
    region = get_region_info(region_key)
    if not region:
        return {}

    return {
        "colors": region.get("colors", {}),
        "patterns": region.get("patterns", []),
        "fonts": region.get("fonts", []),
        "music": region.get("music", []),
    }


def get_culture_full(region_key):
    """Ambil semua info region (untuk UI)."""
    region = get_region_info(region_key)
    if not region:
        return None

    return {
        "key": region_key,
        "name": region.get("name", ""),
        "language": region.get("language", ""),
        "capital": region.get("capital", ""),
        "flag": region.get("flag", ""),
        "greetings": region.get("greetings", []),
        "cultural": region.get("cultural", {}),
        "colors": region.get("colors", {}),
        "patterns": region.get("patterns", []),
        "music": region.get("music", []),
        "fonts": region.get("fonts", []),
        "humor": region.get("humor", ""),
    }


def _adapt_karaoke_text(text, region_key):
    """
    V9.180.130: KARAOKE_ADAPT
    Adapt teks karaoke yang berisi tag {\\k30}, {\\kf50}, dll.
    Tag dipertahankan, teks di-adapt.
    """
    # Regex untuk match tag karaoke
    karaoke_tag_pattern = r"(\{\\[kK][f]?\d+\})"

    # Split teks berdasarkan tag karaoke
    parts = re.split(karaoke_tag_pattern, text)

    adapted_parts = []
    for part in parts:
        if re.match(karaoke_tag_pattern, part):
            # Tag karaoke — pertahankan
            adapted_parts.append(part)
        else:
            # Teks biasa — adapt
            if part.strip():
                leading = len(part) - len(part.lstrip())
                trailing = len(part) - len(part.rstrip())
                core = part.strip()
                adapted_core = adapt_text_for_region(core, region_key)
                adapted_parts.append(
                    " " * leading + adapted_core + " " * trailing
                )
            else:
                adapted_parts.append(part)

    return "".join(adapted_parts)


def adapt_subtitle_ass(ass_path, region_key, output_path=None):
    """
    Adapt ASS subtitle untuk region tertentu.
    V9.180.130: Support karaoke ASS (tag \\k30, \\kf50, dll).
    """
    if not os.path.exists(ass_path):
        print(f"[Culture] File tidak ada: {ass_path}", file=sys.stderr)
        return None

    if output_path is None:
        base = ass_path.rsplit(".", 1)[0]
        output_path = f"{base}_{region_key}.ass"

    try:
        with open(ass_path, "r", encoding="utf-8") as f:
            content = f.read()

        lines = content.split("\n")
        adapted_lines = []
        changes = 0
        karaoke_lines = 0

        for line in lines:
            if line.startswith("Dialogue:"):
                # Format: Dialogue: 0,0:00:00.00,0:00:05.00,Default,,0,0,0,,TEXT
                parts = line.split(",", 9)
                if len(parts) >= 10:
                    original_text = parts[9]

                    # V9.180.130: Deteksi karaoke tag
                    if re.search(r"\{\\[kK][f]?\d+\}", original_text):
                        adapted_text = _adapt_karaoke_text(original_text, region_key)
                        karaoke_lines += 1
                    else:
                        adapted_text = adapt_text_for_region(original_text, region_key)

                    if adapted_text != original_text:
                        changes += 1
                    parts[9] = adapted_text
                    line = ",".join(parts)
            adapted_lines.append(line)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(adapted_lines))

        karaoke_info = f" [{karaoke_lines} karaoke]" if karaoke_lines > 0 else ""
        print(
            f"[Culture] Adapted subtitle → {output_path} ({changes} lines changed{karaoke_info})",
            file=sys.stderr,
        )
        return output_path
    except Exception as e:
        print(f"[Culture] Error adapt ASS: {e}", file=sys.stderr)
        return None

