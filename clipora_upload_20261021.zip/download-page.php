﻿<?php
// download-page.php — V10.1.0 (Redesign: Clipora Branding)
require_once __DIR__ . '/config/config.php';

// Ambil info dari URL parameter (dikirim dari main.js)
$origDur = floatval($_GET['origDur'] ?? 0);
$newDur = floatval($_GET['newDur'] ?? 0);
$silences = intval($_GET['silences'] ?? 0);
$fillerCount = intval($_GET['filler'] ?? 0);
$aiCount = intval($_GET['ai'] ?? 0);
$stutterCount = intval($_GET['stutter'] ?? 0);
$falseStartCount = intval($_GET['falseStart'] ?? 0);
$subtitleBurned = intval($_GET['subtitleBurned'] ?? 0) === 1;
$filesize = floatval($_GET['filesize'] ?? 0);
$filename = $_GET['filename'] ?? '';

$saved = $origDur - $newDur;
$savedPct = $origDur > 0 ? round(($saved / $origDur) * 100) : 0;

function fmtDur($sec) {
    if ($sec <= 0) return '-';
    if ($sec < 60) return round($sec, 1) . 's';
    $m = floor($sec / 60);
    $s = round($sec % 60);
    return $m . 'm ' . $s . 's';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Download Video - Clipora</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg-dark: #0f111a;
            --bg-card: #1a1d2d;
            --text-main: #ffffff;
            --text-muted: #94a3b8;
            --gold-primary: #f59e0b;
            --gold-hover: #d97706;
            --purple-accent: #8b5cf6;
            --success: #22c55e;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--bg-dark);
            background-image: radial-gradient(circle at 50% 0%, rgba(139, 92, 246, 0.15) 0%, transparent 60%);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            max-width: 480px;
            width: 100%;
            background: var(--bg-card);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 24px;
            padding: 32px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(255, 255, 255, 0.02) inset;
            animation: slideUp 0.5s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ============ HEADER ============ */
        .header {
            text-align: center;
            margin-bottom: 28px;
        }

        .icon-wrapper {
            width: 64px;
            height: 64px;
            background: rgba(34, 197, 94, 0.1);
            border: 2px solid rgba(34, 197, 94, 0.3);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            color: var(--success);
            font-size: 1.8rem;
            box-shadow: 0 0 20px rgba(34, 197, 94, 0.15);
        }

        .header h1 {
            font-size: 1.4rem;
            font-weight: 700;
            margin-bottom: 8px;
            background: linear-gradient(135deg, #fff, #cbd5e1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .header p {
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        /* ============ INFO CARD ============ */
        .info-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 24px;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.85rem;
        }

        .info-label {
            color: var(--text-muted);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .info-value {
            font-weight: 600;
            color: var(--text-main);
        }

        .info-value.highlight {
            color: var(--success);
        }
        
        .info-value.danger {
            color: #ef4444;
        }

        /* ============ DOWNLOAD BUTTON ============ */
        .btn-download {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, var(--gold-primary), var(--gold-hover));
            color: white;
            text-decoration: none;
            border-radius: 14px;
            font-weight: 700;
            font-size: 1rem;
            margin-bottom: 16px;
            border: none;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(245, 158, 11, 0.3);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-download::before {
            content: '';
            position: absolute;
            top: 0; left: -100%;
            width: 100%; height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: 0.5s;
        }

        .btn-download:hover::before {
            left: 100%;
        }

        .btn-download:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 32px rgba(245, 158, 11, 0.45);
        }

        .btn-download:active {
            transform: translateY(0);
        }

        .btn-download i {
            font-size: 1.2rem;
        }

        /* ============ SECONDARY BUTTON ============ */
        .btn-secondary {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            padding: 14px;
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-muted);
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.85rem;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.2s;
            cursor: pointer;
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-main);
        }

        /* ============ FOOTER ============ */
        .footer-note {
            text-align: center;
            margin-top: 24px;
            font-size: 0.75rem;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .footer-note i {
            color: var(--purple-accent);
        }

        /* ============ RESPONSIVE ============ */
        @media (max-width: 480px) {
            .container {
                padding: 24px;
                border-radius: 20px;
            }
            .header h1 { font-size: 1.2rem; }
            .btn-download { padding: 16px; font-size: 0.9rem; }
        }
    </style>
</head>
<body>

    <div class="container">
        
        <!-- HEADER -->
        <div class="header">
            <div class="icon-wrapper">
                <i class="fas fa-check"></i>
            </div>
            <h1>Video Berhasil Dirapikan!</h1>
            <p>Silakan download hasil edit Anda di bawah ini.</p>
        </div>

        <!-- INFO CARD (Hanya muncul kalau ada data durasi) -->
        <?php if ($origDur > 0): ?>
        <div class="info-card">
            <div class="info-row">
                <span class="info-label"><i class="fas fa-clock"></i> Durasi Asli</span>
                <span class="info-value"><?= fmtDur($origDur) ?></span>
            </div>
            <div class="info-row">
                <span class="info-label"><i class="fas fa-scissors"></i> Dipotong (<?= $savedPct ?>%)</span>
                <span class="info-value danger">-<?= fmtDur($saved) ?></span>
            </div>
            <div class="info-row" style="border-top: 1px solid rgba(255,255,255,0.06); padding-top: 12px; margin-top: 4px;">
                <span class="info-label"><i class="fas fa-video"></i> Hasil Akhir</span>
                <span class="info-value highlight"><?= fmtDur($newDur) ?></span>
            </div>
        </div>
        <?php endif; ?>

        <!-- DOWNLOAD BUTTONS -->
        <?php
        $filesParam = $_GET['files'] ?? '';
        $fileList = array_filter(explode('|', $filesParam));
        
        if (!empty($fileList)):
            $idx = 1;
            foreach ($fileList as $file):
                $fileClean = trim($file);
                if (empty($fileClean)) continue;
                $downloadUrl = 'download.php?file=' . urlencode($fileClean);
        ?>
        
        <a href="<?= $downloadUrl ?>" class="btn-download" download>
            <i class="fas fa-download"></i>
            <span>Download Klip #<?= $idx ?></span>
            <span style="font-size:0.75rem; opacity:0.8; font-weight:400;">(<?= htmlspecialchars($fileClean) ?>)</span>
        </a>

        <?php
                $idx++;
            endforeach;
        else:
        ?>
        <div style="padding:20px;text-align:center;color:#94a3b8;font-size:0.85rem;">
            <i class="fas fa-exclamation-triangle" style="font-size:2rem;color:#f59e0b;margin-bottom:8px;display:block;"></i>
            Tidak ada file untuk didownload
        </div>
        <?php endif; ?>

        <!-- TOMBOL KEMBALI -->
        <a href="index.php" class="btn-secondary">
            <i class="fas fa-rotate-left"></i>
            <span>Kembali ke Beranda</span>
        </a>

        <!-- FOOTER NOTE -->
        <div class="footer-note">
            <i class="fas fa-shield-alt"></i>
            <span>File aman & akan dihapus otomatis</span>
        </div>

    </div>

</body>
</html>