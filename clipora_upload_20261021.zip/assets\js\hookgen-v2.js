// ============================================================
// AI Hook Generator UI — V9.182.0
// Tombol "Generate Judul" + Modal hasil untuk Clipora
// ============================================================
(function () {
  "use strict";

  // ============================================================
  // STATE
  // ============================================================
  var _isGenerating = false;
  var _lastResult = null;

  // ============================================================
  // HELPER
  // ============================================================
  function _getApiUrl() {
    if (typeof window !== "undefined" && window.API_URL) {
      return window.API_URL.replace(/\/api$/, "");
    }
    if (window.CLIPORA_AUTH && window.CLIPORA_AUTH.apiUrl) {
      return window.CLIPORA_AUTH.apiUrl.replace(/\/api$/, "");
    }
    var origin = window.location.origin;
    if (origin === "http://localhost" || origin === "http://127.0.0.1") {
      return origin + ":3000";
    }
    return origin;
  }

  function _getToken() {
    if (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) {
      return window.CLIPORA_AUTH.token;
    }
    try {
      return localStorage.getItem("clipora_token") || "";
    } catch (e) {
      return "";
    }
  }

  function _showToast(msg, type) {
    type = type || "info";
    var colors = {
      info: "#3b82f6",
      success: "#10b981",
      error: "#ef4444",
      warn: "#f59e0b",
    };
    var el = document.createElement("div");
    el.style.cssText =
      "position:fixed;bottom:30px;left:50%;transform:translateX(-50%);" +
      "padding:12px 20px;background:" +
      (colors[type] || colors.info) +
      ";color:#fff;border-radius:10px;font-size:14px;font-weight:600;" +
      "z-index:99999;box-shadow:0 10px 30px rgba(0,0,0,0.3);opacity:0;" +
      "transition:opacity 0.3s;";
    el.textContent = msg;
    document.body.appendChild(el);
    requestAnimationFrame(function () {
      el.style.opacity = "1";
    });
    setTimeout(function () {
      el.style.opacity = "0";
      setTimeout(function () {
        el.remove();
      }, 300);
    }, 2500);
  }

  function _copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(text)
        .then(function () {
          _showToast("✓ Tersalin ke clipboard", "success");
        })
        .catch(function () {
          _fallbackCopy(text);
        });
    } else {
      _fallbackCopy(text);
    }
  }

  function _fallbackCopy(text) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.style.cssText = "position:fixed;opacity:0;";
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand("copy");
      _showToast("✓ Tersalin ke clipboard", "success");
    } catch (e) {
      _showToast("Gagal copy", "error");
    }
    ta.remove();
  }

  function _escapeHtml(s) {
    if (!s) return "";
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // ============================================================
  // GET TRANSCRIPT
  // ============================================================
  function _getTranscript() {
    // Coba ambil dari berbagai sumber
    // 1. Dari words di klip yang sedang aktif
    try {
      if (typeof window.getEditedWordsForClip === "function") {
        var clip = window.currentClip || null;
        if (clip) {
          var words = window.getEditedWordsForClip(clip);
          if (words && words.length) {
            return words.map(function (w) {
              return w.word || "";
            }).join(" ");
          }
        }
      }
    } catch (e) {}

    // 2. Dari textarea transcript di UI
    var ta = document.querySelector(
      "#acTranscript, textarea[id*='ranscript'], textarea[class*='ranscript']",
    );
    if (ta && ta.value && ta.value.trim().length > 20) {
      return ta.value.trim();
    }

    // 3. Dari elemen preview subtitle
    var subPreview = document.querySelector(
      "#acSubtitlePreview, .ac-subtitle-text, [data-transcript]",
    );
    if (subPreview) {
      var txt = subPreview.value || subPreview.textContent || "";
      if (txt.trim().length > 20) return txt.trim();
    }

    // 4. Prompt user manual kalau semua gagal
    return null;
  }

  // ============================================================
  // GENERATE HOOKS
  // ============================================================
  function generateHooks() {
    if (_isGenerating) {
      _showToast("Sedang generate, tunggu...", "warn");
      return;
    }

    var transcript = _getTranscript();

    // V9.182.1: CUSTOM_TRANSCRIPT_MODAL
    if (!transcript || transcript.length < 20) {
      _showTranscriptModal();
      return;
    }

    _doGenerateHooks(transcript);
  }

  // ============================================================
  // TRANSCRIPT MODAL (V9.182.1)
  // ============================================================
  function _showTranscriptModal() {
    var existing = document.getElementById("acTranscriptModal");
    if (existing) existing.remove();

    var modal = document.createElement("div");
    modal.id = "acTranscriptModal";
    modal.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,0.75);z-index:99998;display:flex;align-items:center;justify-content:center;padding:20px;backdrop-filter:blur(8px);";

    var inner = document.createElement("div");
    inner.style.cssText = "background:#1a1d2e;border-radius:16px;max-width:640px;width:100%;box-shadow:0 25px 60px rgba(0,0,0,0.6);border:1px solid rgba(139,92,246,0.3);overflow:hidden;";

    // Header
    var header = document.createElement("div");
    header.style.cssText = "padding:20px 24px;background:linear-gradient(135deg,rgba(139,92,246,0.15),rgba(236,72,153,0.15));border-bottom:1px solid rgba(255,255,255,0.1);display:flex;justify-content:space-between;align-items:center;";

    var headerText = document.createElement("div");
    var title = document.createElement("div");
    title.style.cssText = "font-size:17px;font-weight:700;color:#fff;";
    title.textContent = "Paste Transcript Video";
    var subtitle = document.createElement("div");
    subtitle.style.cssText = "font-size:12px;color:#94a3b8;margin-top:4px;";
    subtitle.textContent = "Transcript tidak terdeteksi otomatis. Paste di bawah untuk generate judul, hook, dan caption.";
    headerText.appendChild(title);
    headerText.appendChild(subtitle);

    var closeBtn = document.createElement("button");
    closeBtn.textContent = "X";
    closeBtn.style.cssText = "background:rgba(255,255,255,0.1);border:none;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:14px;flex-shrink:0;font-family:inherit;";
    closeBtn.onclick = function () { modal.remove(); };

    header.appendChild(headerText);
    header.appendChild(closeBtn);

    // Body
    var body = document.createElement("div");
    body.style.cssText = "padding:20px 24px;";

    var label = document.createElement("label");
    label.style.cssText = "display:block;font-size:12px;font-weight:600;color:#93c5fd;margin-bottom:8px;";
    label.textContent = "Transcript / Deskripsi Video (min 20 karakter)";

    var ta = document.createElement("textarea");
    ta.id = "acTranscriptInput";
    ta.placeholder = "Paste transcript di sini...";
    ta.style.cssText = "width:100%;min-height:180px;padding:14px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#e8e8ef;font-size:13px;font-family:inherit;line-height:1.5;resize:vertical;box-sizing:border-box;outline:none;";

    var counterRow = document.createElement("div");
    counterRow.style.cssText = "display:flex;justify-content:space-between;align-items:center;margin-top:8px;";
    var counter = document.createElement("div");
    counter.id = "acTranscriptCount";
    counter.style.cssText = "font-size:11px;color:#94a3b8;";
    counter.textContent = "0 karakter";
    var hint = document.createElement("div");
    hint.style.cssText = "font-size:11px;color:#94a3b8;";
    hint.textContent = "Min. 20 karakter";
    counterRow.appendChild(counter);
    counterRow.appendChild(hint);

    // Footer actions
    var footer = document.createElement("div");
    footer.style.cssText = "display:flex;gap:10px;justify-content:flex-end;margin-top:20px;";

    var cancelBtn = document.createElement("button");
    cancelBtn.type = "button";
    cancelBtn.textContent = "Batal";
    cancelBtn.style.cssText = "padding:10px 20px;background:rgba(255,255,255,0.08);color:#cbd5e1;border:1px solid rgba(255,255,255,0.15);border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;font-family:inherit;";
    cancelBtn.onclick = function () { modal.remove(); };

    var genBtn = document.createElement("button");
    genBtn.type = "button";
    genBtn.textContent = "Generate Sekarang";
    genBtn.style.cssText = "padding:10px 24px;background:linear-gradient(135deg,#8b5cf6,#ec4899);color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:13px;font-weight:700;font-family:inherit;box-shadow:0 4px 12px rgba(139,92,246,0.3);";

    function submitTranscript() {
        var value = (ta.value || "").trim();
        if (value.length < 20) {
            _showToast("Transcript minimal 20 karakter", "warn");
            ta.focus();
            return;
        }
        modal.remove();
        _doGenerateHooks(value);
    }

    genBtn.onclick = submitTranscript;

    // Live counter
    ta.addEventListener("input", function () {
        var len = ta.value.trim().length;
        counter.textContent = len + " karakter";
        counter.style.color = len >= 20 ? "#10b981" : "#94a3b8";
    });

    // Ctrl+Enter submit
    ta.addEventListener("keydown", function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
            e.preventDefault();
            submitTranscript();
        }
    });

    footer.appendChild(cancelBtn);
    footer.appendChild(genBtn);

    body.appendChild(label);
    body.appendChild(ta);
    body.appendChild(counterRow);
    body.appendChild(footer);

    inner.appendChild(header);
    inner.appendChild(body);
    modal.appendChild(inner);

    document.body.appendChild(modal);

    setTimeout(function () { ta.focus(); }, 100);

    // Close on backdrop
    modal.addEventListener("click", function (e) {
        if (e.target === modal) modal.remove();
    });

    // Close on ESC
    document.addEventListener("keydown", function escHandler(e) {
        if (e.key === "Escape") {
            modal.remove();
            document.removeEventListener("keydown", escHandler);
        }
    });
  }

    // ============================================================
  // GENERATE (V9.182.1)
  // ============================================================
  function _doGenerateHooks(transcript) {
    var titleHint = "";
    var titleEl = document.getElementById("acTitleInput");
    if (titleEl && titleEl.value) titleHint = titleEl.value.trim();

    _isGenerating = true;

    // Update tombol
    var btn = document.getElementById("acHookGenBtn");
    if (btn) {
      btn.disabled = true;
      btn.innerHTML =
        '<i class="fas fa-spinner fa-spin"></i> Generating... (bisa 10-30 detik)';
    }

    var url = _getApiUrl() + "/api/generate-hooks";
    var token = _getToken();

    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify({
        transcript: transcript,
        title_hint: titleHint,
        max_judul: 10,
      }),
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        _isGenerating = false;
        if (btn) {
          btn.disabled = false;
          btn.innerHTML =
            '<i class="fas fa-magic"></i> Generate Judul + Hook + Caption';
        }

        if (!data.success) {
          _showToast("Gagal: " + (data.error || "Unknown error"), "error");
          return;
        }

        _lastResult = data;
        _showModal(data);
      })
      .catch(function (e) {
        _isGenerating = false;
        if (btn) {
          btn.disabled = false;
          btn.innerHTML =
            '<i class="fas fa-magic"></i> Generate Judul + Hook + Caption';
        }
        _showToast("Error: " + e.message, "error");
      });
  }

  // ============================================================
  // MODAL
  // ============================================================
  function _showModal(data) {
    var existing = document.getElementById("acHookGenModal");
    if (existing) existing.remove();

    var modal = document.createElement("div");
    modal.id = "acHookGenModal";
    modal.style.cssText =
      "position:fixed;inset:0;background:rgba(0,0,0,0.75);z-index:99998;" +
      "display:flex;align-items:center;justify-content:center;" +
      "padding:20px;backdrop-filter:blur(8px);";

    var judulHtml = (data.judul || [])
      .map(function (j, i) {
        return (
          '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;' +
          'padding:10px 12px;background:rgba(59,130,246,0.06);border-radius:8px;margin-bottom:8px;">' +
          '<div style="flex:1;font-size:13px;color:#e8e8ef;">' +
          '<span style="color:#93c5fd;font-weight:600;margin-right:8px;">' +
          (i + 1) +
          ".</span>" +
          _escapeHtml(j) +
          "</div>" +
          '<button onclick="window.CliporaHookGen.copyItem(this)" data-copy="' +
          _escapeHtml(j).replace(/"/g, "&quot;") +
          '" style="flex-shrink:0;padding:6px 10px;background:rgba(59,130,246,0.2);color:#93c5fd;' +
          'border:1px solid rgba(59,130,246,0.4);border-radius:6px;cursor:pointer;font-size:11px;font-weight:600;">' +
          '<i class="fas fa-copy"></i></button>' +
          "</div>"
        );
      })
      .join("");

    var hookHtml = (data.hook || [])
      .map(function (h, i) {
        return (
          '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;' +
          'padding:10px 12px;background:rgba(236,72,153,0.06);border-radius:8px;margin-bottom:8px;">' +
          '<div style="flex:1;font-size:13px;color:#e8e8ef;font-style:italic;">' +
          '<span style="color:#ec4899;font-weight:600;margin-right:8px;font-style:normal;">' +
          (i + 1) +
          ".</span>" +
          _escapeHtml(h) +
          "</div>" +
          '<button onclick="window.CliporaHookGen.copyItem(this)" data-copy="' +
          _escapeHtml(h).replace(/"/g, "&quot;") +
          '" style="flex-shrink:0;padding:6px 10px;background:rgba(236,72,153,0.2);color:#ec4899;' +
          'border:1px solid rgba(236,72,153,0.4);border-radius:6px;cursor:pointer;font-size:11px;font-weight:600;">' +
          '<i class="fas fa-copy"></i></button>' +
          "</div>"
        );
      })
      .join("");

    var captionHtml = (data.caption || [])
      .map(function (c) {
        var tags = (c.hashtags || []).join(" ");
        var platform = (c.platform || "").toLowerCase();
        var icons = { tiktok: "🎵", instagram: "📷", youtube: "▶️" };
        var icon = icons[platform] || "📱";
        var copyData = (c.text || "") + "\n\n" + tags;
        return (
          '<div style="padding:12px;background:rgba(16,185,129,0.06);border-radius:8px;margin-bottom:10px;">' +
          '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">' +
          '<div style="color:#10b981;font-weight:600;font-size:12px;text-transform:uppercase;">' +
          icon +
          " " +
          _escapeHtml(c.platform || "") +
          "</div>" +
          '<button onclick="window.CliporaHookGen.copyItem(this)" data-copy="' +
          _escapeHtml(copyData).replace(/"/g, "&quot;") +
          '" style="padding:4px 8px;background:rgba(16,185,129,0.2);color:#10b981;' +
          'border:1px solid rgba(16,185,129,0.4);border-radius:5px;cursor:pointer;font-size:10px;font-weight:600;">' +
          '<i class="fas fa-copy"></i> Copy</button>' +
          "</div>" +
          '<div style="color:#e8e8ef;font-size:13px;margin-bottom:6px;line-height:1.4;">' +
          _escapeHtml(c.text || "") +
          "</div>" +
          (tags
            ? '<div style="color:#93c5fd;font-size:11px;font-family:monospace;">' +
              _escapeHtml(tags) +
              "</div>"
            : "") +
          "</div>"
        );
      })
      .join("");

    modal.innerHTML =
      '<div style="background:#1a1d2e;border-radius:16px;max-width:780px;width:100%;' +
      "max-height:90vh;display:flex;flex-direction:column;overflow:hidden;" +
      'box-shadow:0 25px 60px rgba(0,0,0,0.6);border:1px solid rgba(139,92,246,0.3);">' +
      // Header
      '<div style="padding:20px 24px;background:linear-gradient(135deg,rgba(139,92,246,0.15),rgba(236,72,153,0.15));' +
      'border-bottom:1px solid rgba(255,255,255,0.1);display:flex;justify-content:space-between;align-items:center;">' +
      '<div>' +
      '<div style="font-size:18px;font-weight:700;color:#fff;">✨ AI Hook Generator</div>' +
      '<div style="font-size:12px;color:#94a3b8;margin-top:2px;">' +
      "Topik: " +
      _escapeHtml(data.topik_utama || "-") +
      " • Target: " +
      _escapeHtml(data.target_audiens || "-") +
      " • Mood: " +
      _escapeHtml(data.mood || "-") +
      "</div>" +
      "</div>" +
      '<button onclick="document.getElementById(\'acHookGenModal\').remove()" ' +
      'style="background:rgba(255,255,255,0.1);border:none;color:#fff;width:32px;height:32px;' +
      'border-radius:8px;cursor:pointer;font-size:18px;">×</button>' +
      "</div>" +
      // Body
      '<div style="padding:20px 24px;overflow-y:auto;flex:1;">' +
      // Judul Section
      '<div style="margin-bottom:20px;">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">' +
      '<div style="font-size:14px;font-weight:700;color:#93c5fd;">📌 JUDUL (' +
      (data.judul || []).length +
      ")</div>" +
      '<button onclick="window.CliporaHookGen.copyAll(\'judul\')" style="padding:5px 10px;background:rgba(59,130,246,0.2);' +
      'color:#93c5fd;border:1px solid rgba(59,130,246,0.4);border-radius:6px;cursor:pointer;font-size:11px;font-weight:600;">' +
      "📋 Copy All</button>" +
      "</div>" +
      judulHtml +
      "</div>" +
      // Hook Section
      '<div style="margin-bottom:20px;">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">' +
      '<div style="font-size:14px;font-weight:700;color:#ec4899;">🎣 HOOK (' +
      (data.hook || []).length +
      ")</div>" +
      '<button onclick="window.CliporaHookGen.copyAll(\'hook\')" style="padding:5px 10px;background:rgba(236,72,153,0.2);' +
      'color:#ec4899;border:1px solid rgba(236,72,153,0.4);border-radius:6px;cursor:pointer;font-size:11px;font-weight:600;">' +
      "📋 Copy All</button>" +
      "</div>" +
      hookHtml +
      "</div>" +
      // Caption Section
      '<div style="margin-bottom:10px;">' +
      '<div style="font-size:14px;font-weight:700;color:#10b981;margin-bottom:10px;">📱 CAPTION (' +
      (data.caption || []).length +
      ")</div>" +
      captionHtml +
      "</div>" +
      "</div>" +
      "</div>";

    document.body.appendChild(modal);

    // Close on backdrop click
    modal.addEventListener("click", function (e) {
      if (e.target === modal) modal.remove();
    });

    // Close on ESC
    document.addEventListener("keydown", function escHandler(e) {
      if (e.key === "Escape") {
        modal.remove();
        document.removeEventListener("keydown", escHandler);
      }
    });
  }

  // ============================================================
  // PUBLIC API
  // ============================================================
  window.CliporaHookGen = {
    generate: generateHooks,
    copyItem: function (btn) {
      var text = btn.getAttribute("data-copy") || "";
      _copyText(text);
    },
    copyAll: function (type) {
      if (!_lastResult) return;
      var arr = _lastResult[type] || [];
      var text = arr
        .map(function (item) {
          if (typeof item === "string") return "• " + item;
          return "• " + (item.text || "") + "\n  " + (item.hashtags || []).join(" ");
        })
        .join("\n\n");
      _copyText(text);
    },
    showToast: _showToast,
  };

  console.log("[HookGenUI] Ready. Use CliporaHookGen.generate()");
})();
