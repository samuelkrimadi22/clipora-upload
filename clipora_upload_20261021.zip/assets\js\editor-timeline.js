// V9.90.0: Disable auto-open download modal
/**

// ============================================
// HELPER: Bersihkan karakter aneh (mojibake)
// ============================================
function cleanText(text) {
    if (!text) return '';
    return String(text)
        .replace(/??/g, '??')
        .replace(/??�/g, '??')
        .replace(//g, '')
        .replace(//g, '')
        .replace(//g, '')
        .replace(//g, '')
        .replace(//g, '')
        .replace(//g, '')
        .replace(//g, '')
        .replace(//g, '')
        .replace(//g, '')
        .trim();
}
 * editor-timeline.js � Clipora V8.7.0 Timeline Editor
 * ============================================================
 * Menghidupkan semua fitur editor di control_panel.php:
 *
 *  ? Render timeline (filmstrip + ruler + segments)
 *  ? Klik segmen ? toggle ON/OFF (dipotong / dibiarkan)
 *  ? Drag handle kiri/kanan ? resize segmen
 *  ? Klik timeline ? seek video
 *  ? Playhead mengikuti video (smooth)
 *  ? Preview mode ? skip segmen cut saat playback
 *  ? Quick mode (Hemat/Seimbang/Halus) ? bulk toggle by priority
 *  ? Reset ke rekomendasi AI
 *  ? Render final via POST /api/render/:analysisId
 *  ? Poll progress & tampilkan hasil
 *
 * Cara pakai (dari upload.js / control panel):
 *
 *   window.CliporaEditor.start({
 *       analysisId:         'uuid-dari-analyze',
 *       videoUrl:           URL.createObjectURL(file)  // atau '/download/xxx.mp4'
 *       duration:           123.45,
 *       segments:           [...],      // array dari server
 *       stats:              {...},      // opsional
 *       preset:             '720p',
 *       enableBurnSubtitle: true,
 *       addWatermark:       true
 *   });
 *
 * Atau dispatch event:
 *   window.dispatchEvent(new CustomEvent('clipora:analysis-ready', { detail: {...} }));
 */
(function () {
'use strict';

// ============================================================
// CONSTANTS
// ============================================================
const API = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.apiUrl) || '/api';
const TOKEN = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || '';
const MIN_SEG = 0.20;            // durasi minimum segmen (detik)
const POLL_INTERVAL = 1500;      // ms antar poll progress
const FILMSTRIP_COUNT = 12;      // jumlah frame thumbnail

const SOURCE_META = {
    silence:     { icon: '<i class="fas fa-volume-mute"></i>',    label: 'Jeda diam' },
    filler:      { icon: '<i class="fas fa-comment-dots"></i>',   label: 'Kata pengisi' },
    stutter:     { icon: '<i class="fas fa-wave-square"></i>',    label: 'Gagap' },
    false_start: { icon: '<i class="fas fa-pause-circle"></i>',   label: 'Salah mulai' },
    repetition:  { icon: '<i class="fas fa-redo"></i>',           label: 'Frasa berulang' },
    duplicate:   { icon: '<i class="fas fa-users"></i>',          label: 'Duplikat' },
    noise:       { icon: '<i class="fas fa-volume-up"></i>',      label: 'Noise', color: "#ec4899" },
    manual:      { icon: '<i class="fas fa-cut"></i>',            label: 'Manual' },
    unknown:     { icon: '<i class="fas fa-cut"></i>',            label: 'Potong' }
};

// Priority: makin kecil = makin "aman" dipotong (silence/filler)
// Quick mode mengubah enable berdasarkan priority threshold
const QUICK_MODE_PRIORITY = {
    aggressive: 4,   // semua priority <= 4 ? cut
    balanced:   3,   // priority <= 3 ? cut
    gentle:     2    // priority <= 2 ? cut
};

// ============================================================
// STATE
// ============================================================
const state = {
    analysisId: null,
    videoUrl: null,
    duration: 0,
    segments: [],           // {id, start, end, source, reason, priority, enabled}
    segmentsBackup: [],     // untuk reset
    stats: null,
    preset: '720p',
    enableBurnSubtitle: true,
    addWatermark: true,

    activeSegmentId: null,
    isRendering: false,
    isPreviewPlaying: false,
    filmstripLoaded: false,

    rafId: null,            // untuk playhead loop
    previewRafId: null,      // untuk preview tick
    styleMemorySent: false 
};

// ============================================================
// DOM CACHE
// ============================================================
const els = {};

function cacheEls() {
    els.container     = document.getElementById('editorContainer');
    els.wrap          = document.getElementById('timelineEditorWrap');
    els.video         = document.getElementById('editorVideo');
    els.playBtn       = document.getElementById('tePlayBtn');
    els.previewBadge  = document.getElementById('tePreviewBadge');
    els.stats         = document.getElementById('editorStats');

    els.timeline      = document.getElementById('teTimeline');
    els.track         = document.getElementById('teTrack');
    els.filmstrip     = document.getElementById('teFilmstrip');
    els.playhead      = document.getElementById('tePlayhead');
    els.viewport      = document.getElementById('teTimelineViewport');
    els.zoomWrap      = document.getElementById('teTimelineZoomWrap');
    els.timeRuler     = document.getElementById('teTimeRuler');

    els.segInfo       = document.getElementById('teSegmentInfo');
    els.siIcon        = document.getElementById('teSiIcon');
    els.siReason      = document.getElementById('teSiReason');
    els.siTime        = document.getElementById('teSiTime');
    els.siDelete      = document.getElementById('teSiDelete');
    els.siKeep        = document.getElementById('teSiKeep');
    els.siCut         = document.getElementById('teSiCut');

    els.previewBigBtn = document.getElementById('tePlayPreviewBig');
    els.ppbIcon       = document.getElementById('tePpbIcon');
    els.ppbTitle      = document.getElementById('tePpbTitle');
    els.ppbSubtitle   = document.getElementById('tePpbSubtitle');
    els.previewTime   = document.getElementById('tePreviewTime');
    els.previewBadgeLive = document.getElementById('tePreviewLiveBadge');

    els.qualitySelect = document.getElementById('qualitySelect');
    els.renderBtn     = document.getElementById('renderFinalBtn');
    els.resetBtn      = document.getElementById('resetEditsBtn');
    els.closeBtn      = document.getElementById('editorCloseBtn');

    els.resultBox     = document.getElementById('resultBox');
    els.resultTitle   = document.getElementById('resultTitle');
    els.durationInfo  = document.getElementById('durationInfo');
    els.statsGrid     = document.getElementById('statsGrid');
    els.openDlBtn     = document.getElementById('openDownloadModalBtn');

    els.progressBox   = document.getElementById('progressContainer');
    els.progressFill  = document.getElementById('progressFill');
    els.progressText  = document.getElementById('progressText');
    els.progressDetail= document.getElementById('progressDetail');
}

// ============================================================
// HELPERS
// ============================================================
function $(id) { return document.getElementById(id); }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

function fmt(t) {
    if (!isFinite(t) || t < 0) t = 0;
    const m = Math.floor(t / 60);
    const s = Math.floor(t % 60);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}
function fmtMs(t) {
    if (!isFinite(t) || t < 0) t = 0;
    const m = Math.floor(t / 60);
    const s = Math.floor(t % 60);
    const ms = Math.floor((t % 1) * 100);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(ms).padStart(2, '0')}`;
}
function escapeHtml(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function authHeaders(extra) {
    const h = Object.assign({}, extra || {});
    if (TOKEN) h['Authorization'] = 'Bearer ' + TOKEN;
    return h;
}

// ============================================================
// INIT
// ============================================================
function showQuickActionResult(action, result) {
    // Buat atau update tombol download di bawah tombol Quick Action
    var btnMap = {
        'silence': 'qaSilenceBtn',
        'speed': 'qaSpeedBtn',
        'music': 'qaMusicBtn',
        'trim': 'qaTrimBtn'
    };
    var btn = document.getElementById(btnMap[action]);
    if (!btn || !result.downloadUrl) return;
    
    // Cari container
    var container = btn.closest('.qa-grid');
    if (!container) return;
    
    // Hapus notif lama kalau ada
    var oldNotif = container.querySelector('.qa-result-notif');
    if (oldNotif) oldNotif.remove();
    
    // Buat notif baru
    var notif = document.createElement('div');
    notif.className = 'qa-result-notif';
    notif.style.cssText = 'grid-column: 1 / -1; padding: 10px 14px; background: linear-gradient(135deg, rgba(34,197,94,0.15), rgba(16,185,129,0.1)); border: 1px solid rgba(34,197,94,0.3); border-radius: 10px; display: flex; align-items: center; gap: 10px; margin-top: 8px; animation: qaResultIn 0.3s ease;';
    notif.innerHTML = 
        '<span style="font-size: 18px;">?</span>' +
        '<span style="flex: 1; font-size: 12px; color: #4ade80; font-weight: 600;">Video hasil siap di-download</span>' +
        '<a href="' + result.downloadUrl + '" download style="padding: 6px 14px; background: linear-gradient(135deg, #22c55e, #16a34a); color: white; border-radius: 8px; font-size: 11px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 5px;">' +
        '  <i class="fas fa-download"></i> Download' +
        '</a>';
    
    container.appendChild(notif);
    
    // Auto remove setelah 30 detik
    setTimeout(function() {
        if (notif.parentNode) {
            notif.style.opacity = '0';
            setTimeout(function() { notif.remove(); }, 300);
        }
    }, 30000);
}

function init() {
    // V8.8.0: Silent skip kalau bukan halaman editor (index.php)
    const container = document.getElementById('editorContainer');
    if (!container) return;

    cacheEls();
    if (!els.container) return;

    bindEvents();
    startPlayheadLoop();
    console.log('[Editor] Ready');
}

// ============================================================
// START � dipanggil setelah /api/analyze sukses
// ============================================================
function start(data) {
    if (!data || !data.analysisId) {
        console.error('[Editor] start() butuh analysisId');
        return;
    }
    if (!els.container) cacheEls();

    // Normalisasi segments ? tambah id unik
    const segs = (data.segments || []).map((s, i) => ({
        id: i,
        start: parseFloat(s.start) || 0,
        end: parseFloat(s.end) || 0,
        source: s.source || 'unknown',
        reason: s.reason || s.source || 'Potong',
        priority: (s.priority == null ? 5 : s.priority),
        enabled: s.enabled !== false   // default: true (akan dipotong)
    })).filter(s => s.end > s.start);

    Object.assign(state, {
        analysisId: data.analysisId,
        videoUrl: data.videoUrl || null,
        duration: parseFloat(data.duration) || 0,
        segments: segs,
        segmentsBackup: JSON.parse(JSON.stringify(segs)),
        stats: data.stats || null,
        preset: data.preset || state.preset,
        enableBurnSubtitle: data.enableBurnSubtitle !== false,
        addWatermark: data.addWatermark !== false,
        activeSegmentId: null,
        isPreviewPlaying: false,
        filmstripLoaded: false,
        styleMemorySent: false
    });

    // Set video src
    if (els.video && state.videoUrl) {
        els.video.src = state.videoUrl;
        els.video.load();
        if (!state.duration) {
            els.video.addEventListener('loadedmetadata', () => {
                state.duration = els.video.duration;
                renderRuler();
                renderSegments();
            }, { once: true });
        }
    }

    // Sync preset ke selector
    if (els.qualitySelect && state.preset) {
        const opt = Array.from(els.qualitySelect.options).find(o => o.value === state.preset);
        if (opt && !opt.disabled) els.qualitySelect.value = state.preset;
    }

    // Show container & reset UI kecil
    els.container.style.display = 'block';
    if (els.resultBox) els.resultBox.style.display = 'none';
    if (els.segInfo) els.segInfo.style.display = 'none';
    if (els.previewBadge) els.previewBadge.style.display = 'none';
    if (els.previewBadgeLive) els.previewBadgeLive.style.display = 'none';
    if (els.progressBox) els.progressBox.style.display = 'none';

    // V9.131.3: SAFE RENDERALL - function tidak ada, panggil yang benar
    try {
        if (typeof renderStats === 'function') renderStats();
        if (typeof renderRuler === 'function') renderRuler();
        if (typeof renderSegments === 'function') renderSegments();
    } catch (e) {
        console.warn('[Timeline] render error:', e.message);
    }
    generateFilmstrip();

    // Scroll ke editor
    setTimeout(() => {
        els.container.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
}

// ============================================================
// RENDER � STATS
// ============================================================
function renderStats() {
    if (!els.stats) return;
    const total = state.duration || 0;
    let cutEnabled = 0, cutDuration = 0;
    state.segments.forEach(s => {
        if (s.enabled) {
            cutEnabled++;
            cutDuration += (s.end - s.start);
        }
    });
    const keptDuration = Math.max(0, total - cutDuration);
    const keptPct = total > 0 ? Math.round((keptDuration / total) * 100) : 0;

    els.stats.innerHTML = `
        <div class="te-stat-item">
            <div class="te-stat-label">Durasi Asli</div>
            <div class="te-stat-value">${fmt(total)}</div>
        </div>
        <div class="te-stat-item">
            <div class="te-stat-label">Akan Dipotong</div>
            <div class="te-stat-value danger">${cutEnabled} segmen</div>
        </div>
        <div class="te-stat-item">
            <div class="te-stat-label">Durasi Hasil</div>
            <div class="te-stat-value success">${fmt(keptDuration)}</div>
        </div>
        <div class="te-stat-item">
            <div class="te-stat-label">Hemat</div>
            <div class="te-stat-value primary">${100 - keptPct}%</div>
        </div>
    `;
}

// ============================================================
// RENDER � TIME RULER
// ============================================================
function renderRuler() {
    if (!els.timeRuler) return;
    const d = state.duration;
    if (!d) { els.timeRuler.innerHTML = ''; return; }

    // Pilih step agar ~6-10 mark
    const steps = [1, 2, 5, 10, 15, 30, 60, 120, 300];
    let step = steps[steps.length - 1];
    for (const s of steps) {
        if (d / s <= 10) { step = s; break; }
    }

    const marks = [];
    for (let t = 0; t <= d + 0.001; t += step) {
        const pct = (t / d) * 100;
        marks.push(`<span class="te-time-mark" style="left:${pct}%">${fmt(t)}</span>`);
    }
    els.timeRuler.innerHTML = marks.join('');
}

// ============================================================
// RENDER � SEGMENTS
// ============================================================
function renderSegments() {
    if (!els.track) return;

    // Bersihkan segment lama (jangan hapus filmstrip / bg)
    els.track.querySelectorAll('.te-segment').forEach(el => el.remove());

    if (!state.duration) return;

    state.segments.forEach(seg => {
        const el = createSegmentEl(seg);
        els.track.appendChild(el);
    });

    // Re-apply selected
    if (state.activeSegmentId != null) {
        const el = els.track.querySelector(`.te-segment[data-id="${state.activeSegmentId}"]`);
        if (el) el.classList.add('selected');
    }
}

function createSegmentEl(seg) {
    const el = document.createElement('div');
    el.className = 'te-segment ' + (seg.enabled ? 'cut' : 'keep');
    el.dataset.id = seg.id;

    // Left / width dalam persen
    const leftPct = (seg.start / state.duration) * 100;
    const widthPct = ((seg.end - seg.start) / state.duration) * 100;
    el.style.left = leftPct + '%';
    el.style.width = widthPct + '%';

    // Label
    const meta = SOURCE_META[seg.source] || SOURCE_META.unknown;
    const dur = (seg.end - seg.start).toFixed(1);
    el.innerHTML = `
        <div class="te-segment-handle left" data-side="left"></div>
        <span class="te-segment-label">${meta.icon} ${dur}s</span>
        <div class="te-segment-handle right" data-side="right"></div>
    `;

    // V1.0.2: Klik body ? TOGGLE LANGSUNG (cut �� keep)
    el.addEventListener('click', (e) => {
        if (e.target.classList.contains('te-segment-handle')) return;
        e.stopPropagation();
        // Ctrl/Shift + klik = buka panel detail
        if (e.ctrlKey || e.shiftKey) {
            onSegmentClick(seg.id);
            return;
        }
        seg.enabled = !seg.enabled;
        updateSegmentClass(seg);
        if (typeof renderStats === 'function') renderStats();
        el.style.transform = 'scale(0.95)';
        setTimeout(function(){ el.style.transform = ''; }, 100);
        console.log('[Timeline] Toggle: ' + seg.id + ' -> ' + (seg.enabled ? 'cut' : 'keep'));
    });

    // Drag handle
    el.querySelectorAll('.te-segment-handle').forEach(h => {
        h.addEventListener('pointerdown', (e) => {
            e.stopPropagation();
            startResize(e, seg.id, h.dataset.side);
        });
    });

    // Tooltip
    el.addEventListener('mouseenter', (e) => showTooltip(e, seg));
    el.addEventListener('mouseleave', hideTooltip);
    el.addEventListener('mousemove', moveTooltip);

    return el;
}

function updateSegmentEl(seg) {
    if (!els.track) return;
    const el = els.track.querySelector(`.te-segment[data-id="${seg.id}"]`);
    if (!el) return;
    const leftPct = (seg.start / state.duration) * 100;
    const widthPct = ((seg.end - seg.start) / state.duration) * 100;
    el.style.left = leftPct + '%';
    el.style.width = widthPct + '%';
    const meta = SOURCE_META[seg.source] || SOURCE_META.unknown;
    const dur = (seg.end - seg.start).toFixed(1);
    const labelEl = el.querySelector('.te-segment-label');
    if (labelEl) labelEl.textContent = `${meta.icon} ${dur}s`;
}

// ============================================================
// SEGMENT INTERACTION
// ============================================================
function onSegmentClick(id) {
    const seg = state.segments.find(s => s.id === id);
    if (!seg) return;

    // Kalau segmen ini sudah selected ? toggle enabled
    if (state.activeSegmentId === id) {
        seg.enabled = !seg.enabled;
        updateSegmentClass(seg);
        updateInfoPanel();
        renderStats();
    } else {
        selectSegment(id);
    }
}

function selectSegment(id) {
    state.activeSegmentId = id;
    if (els.track) {
        els.track.querySelectorAll('.te-segment').forEach(el => {
            el.classList.toggle('selected', Number(el.dataset.id) === id);
        });
    }
    updateInfoPanel();
    renderStats();
}

function updateSegmentClass(seg) {
    if (!els.track) return;
    const el = els.track.querySelector(`.te-segment[data-id="${seg.id}"]`);
    if (!el) return;
    el.classList.toggle('cut', seg.enabled);
    el.classList.toggle('keep', !seg.enabled);
}

function startResize(e, id, side) {
    const seg = state.segments.find(s => s.id === id);
    if (!seg || !els.timeline) return;

    e.preventDefault();
    const rect = els.timeline.getBoundingClientRect();
    const startX = e.clientX;
    const origStart = seg.start;
    const origEnd = seg.end;

    function onMove(ev) {
        const dx = ev.clientX - startX;
        const dt = (dx / rect.width) * state.duration;
        if (side === 'left') {
            seg.start = clamp(origStart + dt, 0, seg.end - MIN_SEG);
        } else {
            seg.end = clamp(origEnd + dt, seg.start + MIN_SEG, state.duration);
        }
        updateSegmentEl(seg);
        if (state.activeSegmentId === id) updateInfoPanel();
    }
    function onUp() {
        document.removeEventListener('pointermove', onMove);
        document.removeEventListener('pointerup', onUp);
        document.body.style.userSelect = '';
        renderStats();
    }
    document.body.style.userSelect = 'none';
    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup', onUp);
}

function deleteSegment(id) {
    const idx = state.segments.findIndex(s => s.id === id);
    if (idx < 0) return;
    state.segments.splice(idx, 1);
    if (state.activeSegmentId === id) {
        state.activeSegmentId = null;
        if (els.segInfo) els.segInfo.style.display = 'none';
    }
    renderSegments();
    renderStats();
}

// ============================================================
// V9.132.0: KEYBOARD COPY/PASTE
// ============================================================
var _clipboardSegment = null;  // Simpan segment yang di-copy

function copySegment() {
    if (!state.activeSegmentId) {
        if (typeof toastInfo === "function") toastInfo("Pilih segmen dulu sebelum copy");
        return false;
    }
    var seg = state.segments.find(function(s) { return s.id === state.activeSegmentId; });
    if (!seg) return false;
    _clipboardSegment = {
        start: seg.start,
        end: seg.end,
        enabled: seg.enabled
    };
    if (typeof toastSuccess === "function") toastSuccess("Segmen disalin (" + (seg.end - seg.start).toFixed(2) + "s)");
    console.log("[Timeline] Copy segment:", _clipboardSegment);
    return true;
}

function pasteSegment() {
    if (!_clipboardSegment) {
        if (typeof toastInfo === "function") toastInfo("Tidak ada segmen di clipboard");
        return false;
    }
    var dur = _clipboardSegment.end - _clipboardSegment.start;
    // Cari posisi paste: setelah segment terpilih, atau di akhir timeline
    var pasteStart = 0;
    if (state.activeSegmentId) {
        var activeSeg = state.segments.find(function(s) { return s.id === state.activeSegmentId; });
        if (activeSeg) pasteStart = activeSeg.end;
    } else {
        // Cari segmen terakhir
        var lastEnd = 0;
        state.segments.forEach(function(s) { if (s.end > lastEnd) lastEnd = s.end; });
        pasteStart = lastEnd;
    }
    // Validasi: tidak melebihi durasi
    if (pasteStart + dur > state.duration) {
        pasteStart = Math.max(0, state.duration - dur);
    }
    if (pasteStart < 0 || dur <= 0) {
        if (typeof toastError === "function") toastError("Tidak bisa paste segmen");
        return false;
    }
    var newSeg = {
        id: Date.now() + Math.floor(Math.random() * 1000),
        start: pasteStart,
        end: Math.min(pasteStart + dur, state.duration),
        enabled: _clipboardSegment.enabled
    };
    state.segments.push(newSeg);
    state.segments.sort(function(a, b) { return a.start - b.start; });
    selectSegment(newSeg.id);
    renderSegments();
    renderStats();
    if (typeof toastSuccess === "function") toastSuccess("Segmen di-paste (" + dur.toFixed(2) + "s)");
    console.log("[Timeline] Paste segment:", newSeg);
    return true;
}

function cutSegment() {
    if (copySegment()) {
        deleteSegment(state.activeSegmentId);
        if (typeof toastInfo === "function") toastInfo("Segmen di-cut");
    }
}

function duplicateSegment() {
    if (!state.activeSegmentId) {
        if (typeof toastInfo === "function") toastInfo("Pilih segmen dulu");
        return false;
    }
    var seg = state.segments.find(function(s) { return s.id === state.activeSegmentId; });
    if (!seg) return false;
    var dur = seg.end - seg.start;
    var pasteStart = seg.end;
    if (pasteStart + dur > state.duration) {
        pasteStart = Math.max(0, state.duration - dur);
    }
    var dup = {
        id: Date.now() + Math.floor(Math.random() * 1000),
        start: pasteStart,
        end: Math.min(pasteStart + dur, state.duration),
        enabled: seg.enabled
    };
    state.segments.push(dup);
    state.segments.sort(function(a, b) { return a.start - b.start; });
    selectSegment(dup.id);
    renderSegments();
    renderStats();
    if (typeof toastSuccess === "function") toastSuccess("Segmen diduplikat");
    return true;
}

// ============================================================
// INFO PANEL
// ============================================================
function updateInfoPanel() {
    const id = state.activeSegmentId;
    const seg = state.segments.find(s => s.id === id);
    if (!seg || !els.segInfo) {
        if (els.segInfo) els.segInfo.style.display = 'none';
        return;
    }

    const meta = SOURCE_META[seg.source] || SOURCE_META.unknown;
    if (els.siIcon) els.siIcon.textContent = meta.icon;
    if (els.siReason) els.siReason.textContent = seg.reason || meta.label;
    if (els.siTime) els.siTime.textContent = `${fmtMs(seg.start)} ? ${fmtMs(seg.end)} (${(seg.end - seg.start).toFixed(2)}s)`;

    // Highlight tombol aktif
    if (els.siKeep) els.siKeep.classList.toggle('active', !seg.enabled);
    if (els.siCut)  els.siCut.classList.toggle('active', seg.enabled);

    els.segInfo.style.display = 'flex';
}

// ============================================================
// QUICK MODE
// ============================================================
function applyQuickMode(mode) {
    const threshold = QUICK_MODE_PRIORITY[mode];
    if (threshold == null) return;

    state.segments.forEach(seg => {
        // Priority kecil = "aman dipotong" (silence, filler, stutter)
        // Priority besar = "kurang yakin" (duplicate, dll)
        seg.enabled = (seg.priority <= threshold);
    });

    renderSegments();
    renderStats();
    if (state.activeSegmentId != null) updateInfoPanel();

    // Highlight tombol
    document.querySelectorAll('.te-qm-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.mode === mode);
    });

    console.log(`[Editor] Quick mode: ${mode} (priority <= ${threshold})`);
}

// ============================================================
// PLAYHEAD LOOP
// ============================================================
function startPlayheadLoop() {
    function tick() {
        if (els.playhead && els.video && state.duration > 0) {
            const t = els.video.currentTime || 0;
            const pct = clamp((t / state.duration) * 100, 0, 100);
            els.playhead.style.left = pct + '%';

            if (state.isPreviewPlaying && els.previewTime) {
                els.previewTime.textContent = `${fmt(t)} / ${fmt(state.duration)}`;
            }

            // Auto-scroll viewport kalau playhead keluar view
            if (!els.video.paused && els.viewport) {
                const timelineRect = els.timeline.getBoundingClientRect();
                const viewRect = els.viewport.getBoundingClientRect();
                const px = (pct / 100) * timelineRect.width + (timelineRect.left - viewRect.left);
                if (px < 40 || px > viewRect.width - 40) {
                    const targetScroll = els.viewport.scrollLeft + (px - viewRect.width / 2);
                    els.viewport.scrollTo({ left: targetScroll, behavior: 'smooth' });
                }
            }
        }
        state.rafId = requestAnimationFrame(tick);
    }
    tick();
}

// ============================================================
// PREVIEW MODE � skip segmen yang enabled (cut)
// ============================================================
function togglePreview() {
    if (!els.video) return;

    if (state.isPreviewPlaying) {
        stopPreview();
    } else {
        startPreview();
    }
}

function startPreview() {
    if (!els.video || !state.duration) return;

    state.isPreviewPlaying = true;

    // UI state
    if (els.previewBadge) els.previewBadge.style.display = 'inline-flex';
    if (els.previewBadgeLive) els.previewBadgeLive.style.display = 'inline-flex';
    if (els.previewBigBtn) els.previewBigBtn.classList.add('playing');
    if (els.ppbIcon) els.ppbIcon.className = 'fas fa-stop';
    if (els.ppbTitle) els.ppbTitle.textContent = 'Stop Preview';
    if (els.ppbSubtitle) els.ppbSubtitle.textContent = 'Sedang memutar hasil potongan...';
    if (els.timeline) els.timeline.classList.add('preview-mode');

    // Mulai dari 0 kalau di akhir
    if (els.video.currentTime >= state.duration - 0.1) {
        els.video.currentTime = 0;
    }
    els.video.play().catch(() => {});

    // Tick � skip segmen cut
    function tick() {
        if (!state.isPreviewPlaying) return;
        const v = els.video;
        if (!v.paused) {
            const t = v.currentTime;
            // Cari segmen enabled yang mencakup t
            const seg = state.segments.find(s => s.enabled && t >= s.start && t < s.end);
            if (seg) {
                // Skip ke end segmen
                v.currentTime = Math.min(seg.end + 0.02, state.duration);
                flashSegment(seg.id);
            }
            // Selesai?
            if (v.currentTime >= state.duration - 0.05) {
                stopPreview();
                return;
            }
        }
        state.previewRafId = requestAnimationFrame(tick);
    }
    state.previewRafId = requestAnimationFrame(tick);
}

function stopPreview() {
    state.isPreviewPlaying = false;
    if (state.previewRafId) {
        cancelAnimationFrame(state.previewRafId);
        state.previewRafId = null;
    }
    if (els.video) els.video.pause();

    if (els.previewBadge) els.previewBadge.style.display = 'none';
    if (els.previewBadgeLive) els.previewBadgeLive.style.display = 'none';
    if (els.previewBigBtn) els.previewBigBtn.classList.remove('playing');
    if (els.ppbIcon) els.ppbIcon.className = 'fas fa-play';
    if (els.ppbTitle) els.ppbTitle.textContent = 'Putar Preview Hasil';
    if (els.ppbSubtitle) els.ppbSubtitle.textContent = 'Dengar & lihat hasil potongan sebelum render final';
    if (els.timeline) els.timeline.classList.remove('preview-mode');
}

function flashSegment(id) {
    if (!els.track) return;
    const el = els.track.querySelector(`.te-segment[data-id="${id}"]`);
    if (!el) return;
    el.classList.add('te-skipping');
    setTimeout(() => el.classList.remove('te-skipping'), 500);
}

// ============================================================
// FILMSTRIP � generate thumbnail di background
// ============================================================
async function generateFilmstrip() {
    if (!els.filmstrip || !state.videoUrl) return;

    els.filmstrip.innerHTML = `<div class="te-filmstrip-loading"><i class="fas fa-spinner fa-spin"></i> Memuat frame...</div>`;

    try {
        const frames = await extractFrames(state.videoUrl, FILMSTRIP_COUNT);
        if (!frames.length) throw new Error('No frames');
        els.filmstrip.innerHTML = '';
        frames.forEach(src => {
            const img = document.createElement('img');
            img.src = src;
            img.alt = '';
            els.filmstrip.appendChild(img);
        });
        state.filmstripLoaded = true;
    } catch (e) {
        console.warn('[Editor] Filmstrip gagal:', e);
        els.filmstrip.innerHTML = `<div class="te-filmstrip-loading">Preview frame tidak tersedia</div>`;
    }
}

function extractFrames(url, count) {
    return new Promise((resolve) => {
        const video = document.createElement('video');
        video.src = url;
        video.muted = true;
        video.preload = 'auto';
        video.crossOrigin = 'anonymous';

        const cleanup = () => {
            video.removeAttribute('src');
            video.load();
        };

        video.addEventListener('error', () => { cleanup(); resolve([]); }, { once: true });

        video.addEventListener('loadeddata', async () => {
            try {
                const dur = video.duration;
                if (!dur || !isFinite(dur)) { cleanup(); return resolve([]); }

                // Ukuran kecil untuk efisiensi
                const W = 160;
                const ratio = video.videoHeight / video.videoWidth || 9 / 16;
                const H = Math.round(W * ratio);

                const canvas = document.createElement('canvas');
                canvas.width = W;
                canvas.height = H;
                const ctx = canvas.getContext('2d');
                const out = [];

                for (let i = 0; i < count; i++) {
                    const t = (dur * (i + 0.5)) / count;
                    await seekVideo(video, t);
                    try {
                        ctx.drawImage(video, 0, 0, W, H);
                        out.push(canvas.toDataURL('image/jpeg', 0.5));
                    } catch (err) {
                        // Skip frame gagal
                    }
                }
                cleanup();
                resolve(out);
            } catch (e) {
                cleanup();
                resolve([]);
            }
        }, { once: true });
    });
}

function seekVideo(video, t) {
    return new Promise((resolve) => {
        const onSeeked = () => {
            video.removeEventListener('seeked', onSeeked);
            resolve();
        };
        video.addEventListener('seeked', onSeeked);
        video.currentTime = t;
        // Timeout pengaman
        setTimeout(() => {
            video.removeEventListener('seeked', onSeeked);
            resolve();
        }, 3000);
    });
}



// ============================================================
// RENDER FINAL
// ============================================================
async function renderFinal() {
    if (window.currentAnalysisId) {
    state.analysisId = window.currentAnalysisId;
    }
    if (state.isRendering) return;
    if (!state.analysisId) {
        if (window.toastError) window.toastError('Analysis tidak ditemukan');
        return;
    }

    // Ambil preset terbaru dari selector
    if (els.qualitySelect) state.preset = els.qualitySelect.value;

    // Persiapkan payload
    const payload = {
        segments: state.segments.map(s => ({
            start: +s.start.toFixed(3),
            end: +s.end.toFixed(3),
            source: s.source,
            reason: s.reason,
            priority: s.priority,
            enabled: !!s.enabled
        })),
        preset: state.preset,
        enable_burn_subtitle: state.enableBurnSubtitle,
        add_watermark: state.addWatermark
    };

    // V9.305.0: Integrasi fitur baru
    try {
        if (typeof window.getEditorRenderOptions === 'function') {
            const newOpts = window.getEditorRenderOptions();
            if (newOpts.vertical_crop !== undefined) payload.vertical_crop = newOpts.vertical_crop;
            if (newOpts.aspect_ratio) payload.aspect_ratio = newOpts.aspect_ratio;
            if (newOpts.formats) payload.export_formats = newOpts.formats;
            if (newOpts.enable_burn_subtitle !== undefined) payload.enable_burn_subtitle = newOpts.enable_burn_subtitle;
            if (newOpts.caption_style) payload.caption_style = newOpts.caption_style;
            console.log('[Render] Features:', newOpts);
        }
        if (window.teQuickActionState) {
            const qa = window.teQuickActionState;
            if (qa.removeSilence) payload.remove_silence = true;
            if (qa.speed && qa.speed !== 1) payload.speed = qa.speed;
            if (qa.autoMusic) payload.add_music = true;
            if (qa.maxDuration) payload.max_duration = qa.maxDuration;
            console.log('[Render] QuickActions:', qa);
        }
    } catch (e) { console.warn('[Render] Error:', e.message); }

    // Stop preview kalau sedang jalan
    if (state.isPreviewPlaying) stopPreview();

    state.isRendering = true;
    if (els.renderBtn) {
        els.renderBtn.disabled = true;
        els.renderBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
    }

    // V10.0.9: TAMPILKAN PROGRESS BOX SEBELUM REQUEST
    if (els.progressBox) els.progressBox.style.display = 'block';
    setProgress(5, 'Mengirim permintaan render...');

    try {
        // V10.0.9: SELALU pakai state.analysisId (hasil rehydrate)
        let _renderId = state.analysisId;
        console.log("[Editor] Menggunakan state.analysisId:", _renderId);

        const r = await fetch(`${API}/render/${_renderId}`, {
            method: 'POST',
            headers: authHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(payload)
        });
        const data = await r.json();

        if (!r.ok || !data.success) {
            throw new Error(data.error || `Server error (${r.status})`);
        }

        const jobId = data.jobId;
        if (!jobId) throw new Error('jobId tidak diterima dari server');

        console.log('[Editor] Render job:', jobId);
        
        // V10.0.9: Update progress sebelum polling
        setProgress(10, 'Memproses video...');
        
        const result = await pollJob(jobId);

// =========================================================
// V15.0.0: POTONG KUOTA SETELAH RENDER SUKSES
// =========================================================
if (TOKEN) {
    try {
        console.log("[Quota] Mengirim permintaan potong kuota ke server...");
        await fetch(`${API}/user/quota/use`, {
            method: 'POST',
            headers: authHeaders({ 'Content-Type': 'application/json' })
        });
        console.log("[Quota] Kuota berhasil dipotong!");
    } catch (e) {
        console.warn("[Quota] Gagal memotong kuota:", e);
    }
}
// =========================================================

showResult(result);

        // V8.8.0: Kirim delta style memory (non-blocking)
        // Kalau gagal, tidak mengganggu UX render
        sendStyleMemoryDelta().catch(() => {});
    } catch (e) {
        console.error('[Editor] Render error:', e);
        if (window.toastError) window.toastError('Render gagal: ' + e.message);
        setProgress(0, '');
        if (els.progressBox) els.progressBox.style.display = 'none';
    } finally {
    state.isRendering = false;
    if (els.renderBtn) {
        els.renderBtn.disabled = false;
        els.renderBtn.innerHTML = '<i class="fas fa-wand-sparkles"></i> <span>Render Video Final</span>';
    }
    // V13.0.0: overlay ditutup oleh setProgress(100) atau event render-completed
}
}

async function pollJob(jobId) {
    let lastPct = -1;
    // Batas aman (30 menit)
    const maxIter = 30 * 60 * 1000 / POLL_INTERVAL;
    for (let i = 0; i < maxIter; i++) {
        const r = await fetch(`${API}/job/${jobId}`, {
            headers: authHeaders(),
            cache: 'no-store'
        });
        if (!r.ok) throw new Error(`Poll job gagal (${r.status})`);
        const d = await r.json();

        if (!d.success || !d.job) throw new Error(d.error || 'Job tidak ditemukan');
        const job = d.job;

        // Update progress
        if (typeof job.progress === 'number' && job.progress !== lastPct) {
            lastPct = job.progress;
            setProgress(job.progress, job.message || 'Memproses...');
        }

        if (job.status === 'completed') {
            setProgress(100, 'Selesai!');
            await sleep(400);
            return job.result || {};
        }
        if (job.status === 'failed') {
            throw new Error(job.error || 'Job gagal');
        }

        await sleep(POLL_INTERVAL);
    }
    throw new Error('Timeout menunggu render');
}

function setProgress(pct, msg) {
    if (!els.progressBox) return;
    els.progressBox.style.display = 'block';
    const v = clamp(Math.round(pct), 0, 100);
    if (els.progressFill) {
        els.progressFill.style.width = v + '%';
        els.progressFill.textContent = v + '%';
    }
    if (els.progressText && msg) els.progressText.textContent = msg;
    if (els.progressDetail && msg) els.progressDetail.textContent = msg;

    // V13.0.0: SYNC ke overlay render.php (single source of truth)
    if (window.__RENDER_PAGE__) {
        var overlay = document.getElementById('cliporaRenderProgress');
        var percentEl = document.getElementById('crpPercent');
        var barFill = document.getElementById('crpBarFill');
        var statusEl = document.getElementById('crpStatus');
        if (overlay && v > 0 && v < 100) {
            overlay.classList.add('active');
            if (percentEl) percentEl.textContent = v + '%';
            if (barFill) barFill.style.width = v + '%';
            if (statusEl && msg) statusEl.textContent = msg;
        } else if (overlay && v >= 100) {
            if (percentEl) percentEl.textContent = '100%';
            if (barFill) barFill.style.width = '100%';
            if (statusEl) statusEl.textContent = 'Selesai!';
            setTimeout(function () {
                overlay.classList.remove('active');
            }, 800);
        }
    }
}

// ============================================================
// RESULT
// ============================================================
function showResult(result) {
    if (!els.resultBox) return;

    // ============================================================
    // V14.0.0: JIKA DI HALAMAN RENDER -> LANGSUNG KE HALAMAN DOWNLOAD
    // ============================================================
    if (window.__RENDER_PAGE__) {
        console.log("[Editor] Render selesai. Menyiapkan redirect ke download-page...");
        
        if (els.progressBox) els.progressBox.style.display = 'none';
        window.__CLIPORA_LAST_RESULT__ = result;

        // Siapkan URL tujuan download
        if (result && (result.filename || result.downloadUrl)) {
            let files = [];
            if (result.filename) files.push(result.filename);
            if (result.outputFilename) files.push(result.outputFilename);
            if (result.downloadUrl) files.push(result.downloadUrl.split("/").pop());
            
            // Hapus nama file duplikat
            files = [...new Set(files)].filter(Boolean);
            
            if (files.length > 0) {
                let dlUrl = "download-page.php?files=" + encodeURIComponent(files.join("|"));
                dlUrl += "&origDur=" + encodeURIComponent(result.originalDuration || 0);
                dlUrl += "&newDur=" + encodeURIComponent(result.newDuration || 0);
                dlUrl += "&silences=" + encodeURIComponent(result.silences || 0);
                dlUrl += "&filler=" + encodeURIComponent(result.fillerSegments || 0);
                dlUrl += "&ai=" + encodeURIComponent(result.aiSegments || 0);
                dlUrl += "&filesize=" + encodeURIComponent(result.filesize || 0);
                dlUrl += "&filename=" + encodeURIComponent(result.filename || "");
                
                console.log("🚀 [Redirect] Pindah ke:", dlUrl);
                
                // Beri jeda 1 detik agar user sempat melihat angka 100% di layar
                setTimeout(function() {
                    window.location.replace(dlUrl);
                }, 1000);
                
                return; // STOP di sini. Jangan tampilkan kotak "Video Berhasil" di halaman render.
            }
        }
        
        // Jika tidak ada file, beri peringatan
        if (window.toastError) window.toastError('Render selesai, tapi data file tidak ditemukan.');
        return;
    }
    // ============================================================


    // ============================================================
    // KODE DI BAWAH INI HANYA BERJALAN DI HALAMAN INDEX (BUKAN RENDER)
    // ============================================================
    
    // Sembunyikan progress
    if (els.progressBox) els.progressBox.style.display = 'none';

    // Simpan result untuk modal download
    window.__CLIPORA_LAST_RESULT__ = result;

    // Update result box
    const saved = result.saved || 0;
    const savedPct = result.savedPercent || 0;
    if (els.durationInfo) {
        els.durationInfo.innerHTML = `
            <div class="duration-text">
                🔴 <strong>${fmt(result.originalDuration || 0)}</strong>
                ➡️ <strong style="color:var(--success);">${fmt(result.newDuration || 0)}</strong>
                <span style="color:var(--primary);font-weight:700;margin-left:8px;">
                    (Hemat ${saved.toFixed(1)}s / ${savedPct}%)
                </span>
            </div>
        `;
    }

    if (els.statsGrid) {
        const st = {
            silences:        result.silences || 0,
            filler:          result.fillerSegments || 0,
            stutter:         result.stutterSegments || 0,
            falseStart:      result.falseStartSegments || 0,
            repetition:      result.repetitionSegments || 0,
            filesizeMB:      result.filesize || 0
        };
        els.statsGrid.innerHTML = `
            <div class="stat-item"><span class="stat-num">${st.silences}</span><span class="stat-lbl">🤐 Diam</span></div>
            <div class="stat-item"><span class="stat-num">${st.filler}</span><span class="stat-lbl">🗣️ Pengisi</span></div>
            <div class="stat-item"><span class="stat-num">${st.stutter}</span><span class="stat-lbl">😖 Gagap</span></div>
            <div class="stat-item"><span class="stat-num">${st.falseStart}</span><span class="stat-lbl">🛑 Salah mulai</span></div>
            <div class="stat-item"><span class="stat-num">${st.repetition}</span><span class="stat-lbl">🔁 Berulang</span></div>
            <div class="stat-item"><span class="stat-num">${parseFloat(st.filesizeMB || 0).toFixed(1)} MB</span><span class="stat-lbl">💾 Ukuran</span></div>
        `;
    }

    els.resultBox.style.display = 'block';
    els.resultBox.scrollIntoView({ behavior: 'smooth', block: 'center' });

    // Dispatch event untuk integrasi dengan sistem lain (mis. update kuota)
    try {
        window.dispatchEvent(new CustomEvent('clipora:render-completed', { detail: result }));
    } catch (e) {}

    // Auto-refresh quota kalau fungsi tersedia
    if (typeof window.refreshQuotaInline === 'function') {
        setTimeout(() => window.refreshQuotaInline(), 1000);
    }

    if (window.toastSuccess) window.toastSuccess('✅ Video berhasil dirapikan!');
}

// ============================================================
// RESET / CLOSE
// ============================================================
function resetEdits() {
    if (!confirm('Reset semua edit ke rekomendasi AI?')) return;

    state.segments = JSON.parse(JSON.stringify(state.segmentsBackup));
    state.activeSegmentId = null;
    if (els.segInfo) els.segInfo.style.display = 'none';

    // Reset quick mode ke default (aggressive)
    document.querySelectorAll('.te-qm-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.mode === 'aggressive');
    });

    renderSegments();
    renderStats();
    if (window.toastInfo) window.toastInfo('�� Reset ke rekomendasi AI');
}

function closeEditor() {
    if (state.isPreviewPlaying) stopPreview();
    if (els.video) {
        els.video.pause();
        els.video.removeAttribute('src');
        els.video.load();
    }
    if (els.container) els.container.style.display = 'none';

    // Reset state
    Object.assign(state, {
        analysisId: null,
        videoUrl: null,
        duration: 0,
        segments: [],
        segmentsBackup: [],
        activeSegmentId: null,
        isRendering: false,
        isPreviewPlaying: false,
        filmstripLoaded: false
    });

    // Hide progress & result
    if (els.progressBox) els.progressBox.style.display = 'none';
    if (els.resultBox) els.resultBox.style.display = 'none';
    if (els.segInfo) els.segInfo.style.display = 'none';

    console.log('[Editor] Closed');
}

// ============================================================
// TOOLTIP
// ============================================================
let tooltipEl = null;

function ensureTooltip() {
    if (tooltipEl) return tooltipEl;
    tooltipEl = document.createElement('div');
    tooltipEl.className = 'te-tooltip';
    document.body.appendChild(tooltipEl);
    return tooltipEl;
}

function showTooltip(e, seg) {
    const meta = SOURCE_META[seg.source] || SOURCE_META.unknown;
    const tip = ensureTooltip();
    tip.innerHTML = `
        <div class="te-tt-reason">${meta.icon} ${escapeHtml(seg.reason || meta.label)}</div>
        <div class="te-tt-time">${fmtMs(seg.start)} ? ${fmtMs(seg.end)} (${(seg.end - seg.start).toFixed(2)}s)</div>
        <div class="te-tt-hint">Klik = ${seg.enabled ? 'biarkan' : 'potong'} �� Drag ujung = atur</div>
    `;
    tip.style.display = 'block';
    moveTooltip(e);
}

function moveTooltip(e) {
    if (!tooltipEl) return;
    const pad = 14;
    let x = e.clientX + pad;
    let y = e.clientY + pad;
    const rect = tooltipEl.getBoundingClientRect();
    if (x + rect.width > window.innerWidth - 8) x = e.clientX - rect.width - pad;
    if (y + rect.height > window.innerHeight - 8) y = e.clientY - rect.height - pad;
    tooltipEl.style.left = x + 'px';
    tooltipEl.style.top = y + 'px';
}

function hideTooltip() {
    if (tooltipEl) tooltipEl.style.display = 'none';
}

// ============================================================
// EVENT BINDING
// ============================================================
function bindEvents() {
    // Close
    if (els.closeBtn) els.closeBtn.addEventListener('click', closeEditor);

    // Reset
    if (els.resetBtn) els.resetBtn.addEventListener('click', resetEdits);

    // Render final
    if (els.renderBtn) els.renderBtn.addEventListener('click', renderFinal);

    // Preview toggle (2 tombol: overlay + big button)
    if (els.playBtn) {
        els.playBtn.addEventListener('click', () => {
            if (!els.video) return;
            if (els.video.paused) els.video.play(); else els.video.pause();
        });
    }
    if (els.previewBigBtn) els.previewBigBtn.addEventListener('click', togglePreview);

    // Sync ikon play/pause overlay
    if (els.video && els.playBtn) {
        els.video.addEventListener('play', () => {
            const i = els.playBtn.querySelector('i');
            if (i) i.className = 'fas fa-pause';
        });
        els.video.addEventListener('pause', () => {
            const i = els.playBtn.querySelector('i');
            if (i) i.className = 'fas fa-play';
        });
        els.video.addEventListener('seeked', () => {
            // Kalau user seek manual, stop preview
            if (state.isPreviewPlaying) { /* biarkan */ }
        });
        els.video.addEventListener('ended', () => {
            if (state.isPreviewPlaying) stopPreview();
        });
    }

    // V1.0.2: Klik timeline = toggle cut/keep (bukan seek)
    if (els.timeline) {
        els.timeline.addEventListener('click', (e) => {
            if (e.target.closest('.te-segment')) return;
            if (!state.duration) return;
            const rect = els.timeline.getBoundingClientRect();
            const pct = clamp((e.clientX - rect.left) / rect.width, 0, 1);
            const clickTime = pct * state.duration;
            const hit = state.segments.find(s => clickTime >= s.start && clickTime <= s.end);
            if (hit) {
                hit.enabled = !hit.enabled;
                updateSegmentClass(hit);
                console.log('[Timeline] Toggle existing: ' + (hit.enabled ? 'cut' : 'keep'));
            } else {
                const cutStart = Math.max(0, clickTime - 0.5);
                const cutEnd = Math.min(state.duration, clickTime + 0.5);
                state.segments.push({
                    id: Date.now(),
                    start: cutStart,
                    end: cutEnd,
                    source: 'manual',
                    reason: 'user_click',
                    priority: 5,
                    enabled: true,
                });
                state.segments.sort((a, b) => a.start - b.start);
                console.log('[Timeline] Cut baru: ' + cutStart.toFixed(2) + 's -> ' + cutEnd.toFixed(2) + 's');
            }
            if (typeof renderTimeline === 'function') renderTimeline();
            if (typeof renderStats === 'function') renderStats();
        });
    }

    // V1.0.2: Klik time ruler = seek
    var ruler = document.getElementById('teTimeRuler');
    if (ruler) {
        ruler.style.cursor = 'pointer';
        ruler.addEventListener('click', (e) => {
            if (!els.video || !state.duration) return;
            var rrect = ruler.getBoundingClientRect();
            var rpct = clamp((e.clientX - rrect.left) / rrect.width, 0, 1);
            els.video.currentTime = rpct * state.duration;
            console.log('[Timeline] Seek: ' + (rpct * state.duration).toFixed(2) + 's');
        });
    }

    // Quick mode buttons
    document.querySelectorAll('.te-qm-btn').forEach(btn => {
        btn.addEventListener('click', () => applyQuickMode(btn.dataset.mode));
    });

    // Segment info actions
    if (els.siKeep) {
        els.siKeep.addEventListener('click', () => {
            const seg = state.segments.find(s => s.id === state.activeSegmentId);
            if (!seg) return;
            seg.enabled = false;
            updateSegmentClass(seg);
            updateInfoPanel();
            renderStats();
        });
    }
    if (els.siCut) {
        els.siCut.addEventListener('click', () => {
            const seg = state.segments.find(s => s.id === state.activeSegmentId);
            if (!seg) return;
            seg.enabled = true;
            updateSegmentClass(seg);
            updateInfoPanel();
            renderStats();
        });
    }
    if (els.siDelete) {
        els.siDelete.addEventListener('click', () => {
            if (state.activeSegmentId == null) return;
            deleteSegment(state.activeSegmentId);
        });
    }

    // Download button (dari result box)
    if (els.openDlBtn) {
        els.openDlBtn.addEventListener('click', () => {
            const result = window.__CLIPORA_LAST_RESULT__;
            if (!result) return;
            // Coba panggil fungsi modal yang sudah ada
            if (typeof window.openDownloadModal === 'function') {
                window.openDownloadModal(result);
            } else {
                // Fallback: dispatch event
                window.dispatchEvent(new CustomEvent('clipora:open-download-modal', { detail: result }));
                // Atau langsung download
// V9.37.3: Set href clean + save download info
                if (result.downloadUrl) {
                    var _dlUrl = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.baseUrl || "") + result.downloadUrl;
                    var _dlFilename = result.filename || "clipora.mp4";
                    window.__lastDownloadInfo = { url: _dlUrl, filename: _dlFilename, filesize: result.filesize || 0 };
                    console.log("[V9.37.3] Download info saved:", _dlFilename);

                    setTimeout(function() {
                        var selectors = ["#modalDownloadVideoBtn", "#downloadModal a.dl-primary", ".dl-primary"];
                        for (var _i = 0; _i < selectors.length; _i++) {
                            var btn = document.querySelector(selectors[_i]);
                            if (btn && btn.tagName === "A") {
                                btn.href = _dlUrl;
                                btn.setAttribute("download", _dlFilename);
                                console.log("[V9.37.3] href set:", _dlFilename);
                                break;
                            }
                        }
                    }, 300);
                }
                
                // V9.91.0: NO REDIRECT � removed auto-redirect code
                // V9.132.1: REMOVE ORPHAN BLOCK - block rusak dari patch V9.91.0
            }
        });
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Skip kalau editor tidak terbuka
        if (!els.container || els.container.style.display === 'none') return;
        // Skip kalau fokus di input
        const tag = (document.activeElement && document.activeElement.tagName) || '';
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

        if (e.code === 'Space') {
            e.preventDefault();
            if (els.video) {
                if (els.video.paused) els.video.play(); else els.video.pause();
            }
        } else if (e.key === 'Delete' || e.key === 'Backspace') {
            if (state.activeSegmentId != null) {
                e.preventDefault();
                deleteSegment(state.activeSegmentId);
            }
        } else if (e.key === 'ArrowLeft') {
            if (els.video) els.video.currentTime = Math.max(0, els.video.currentTime - 1);
        } else if (e.key === 'ArrowRight') {
            if (els.video) els.video.currentTime = Math.min(state.duration, els.video.currentTime + 1);
        } else if (e.key === 'Escape') {
            if (state.activeSegmentId != null) {
                state.activeSegmentId = null;
                if (els.segInfo) els.segInfo.style.display = 'none';
                if (els.track) els.track.querySelectorAll('.te-segment').forEach(el => el.classList.remove('selected'));
            }
        }
    });

// ============================================================
// V9.132.0: KEYBOARD COPY/PASTE HANDLER
// ============================================================
document.addEventListener("keydown", function(e) {
    // Skip kalau di input/textarea
    var t = (document.activeElement && document.activeElement.tagName) || "";
    if (t === "INPUT" || t === "TEXTAREA") return;

    var isCtrl = e.ctrlKey || e.metaKey;
    if (!isCtrl) return;

    var key = (e.key || "").toLowerCase();

    if (key === "c") {
        // Skip kalau user lagi select text
        var sel = window.getSelection();
        if (sel && sel.toString().length > 0) return;
        if (copySegment()) e.preventDefault();
    } else if (key === "v") {
        if (pasteSegment()) e.preventDefault();
    } else if (key === "x") {
        var sel2 = window.getSelection();
        if (sel2 && sel2.toString().length > 0) return;
        if (cutSegment()) e.preventDefault();
    } else if (key === "d") {
        if (duplicateSegment()) e.preventDefault();
    }
}, true);  // useCapture = true biar dapet duluan
}

// ============================================================
// V8.8.0: STYLE MEMORY � kirim delta edit user ke backend
// ============================================================
async function sendStyleMemoryDelta() {
    if (!TOKEN) return;
    if (!state.segmentsBackup || state.segmentsBackup.length === 0) return;
    if (state.styleMemorySent) {
        console.log('[StyleMemory] Delta sudah dikirim untuk analysis ini � skip');
        return;
    }

    try {
        // 1. Hitung total segmen per kategori (dari AI recommendation awal)
        const categories = {};
        for (const seg of state.segmentsBackup) {
            const src = seg.source || 'unknown';
            if (!categories[src]) {
                categories[src] = { total_shown: 0, enabled_by_user: 0, disabled_by_user: 0 };
            }
            categories[src].total_shown++;
        }

        // 2. Hitung user choices (dari state current)
        for (const [src, cat] of Object.entries(categories)) {
            const enabledCount = state.segments.filter(
                s => (s.source || 'unknown') === src && s.enabled
            ).length;
            cat.enabled_by_user = enabledCount;
            // Yang dihapus dianggap "user tidak setuju" ? masuk disabled
            cat.disabled_by_user = cat.total_shown - enabledCount;
        }

        // 3. Buang kategori yang total 0
        for (const [k, v] of Object.entries(categories)) {
            if (v.total_shown === 0) delete categories[k];
        }

        if (Object.keys(categories).length === 0) return;

        // 4. Kirim ke backend
        const res = await fetch(`${API}/user/style-memory`, {
            method: 'POST',
            headers: authHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ delta: { categories } })
        });
        const data = await res.json();

        if (data.success) {
            state.styleMemorySent = true;
            console.log('[StyleMemory] ? Delta sent:', categories);
            console.log(`[StyleMemory] Total learned: ${data.total_videos} videos`);
        } else {
            console.warn('[StyleMemory] ���� Server rejected:', data.error);
        }
    } catch (e) {
        console.warn('[StyleMemory] Failed to send:', e.message);
    }
}

// ============================================================
// PUBLIC API
// ============================================================
window.CliporaEditor = {
    start,
    hide: closeEditor,
    reset: resetEdits,
    renderFinal: renderFinal,
    _setProgress: setProgress,
    getSegments: () => state.segments.map(s => Object.assign({}, s)),
    getState: () => Object.assign({}, state),
    setSegments: (data) => {
        try {
            if (!data || !data.segments) return false;
            state.segments = data.segments.map(function(seg) {
                return {
                    id: seg.id || Date.now() + Math.random(),
                    start: parseFloat(seg.start),
                    end: parseFloat(seg.end),
                    source: seg.source || 'manual',
                    reason: seg.reason || 'restore',
                    priority: seg.priority || 5,
                    enabled: seg.enabled !== false,
                };
            });
            state.duration = parseFloat(data.duration) || state.duration || 0;
            state.activeSegmentId = null;
            if (typeof renderSegments === 'function') renderSegments();
            if (typeof renderStats === 'function') renderStats();
            if (typeof renderTimeRuler === 'function') renderTimeRuler();
            return true;
        } catch (e) {
            console.error('[setSegments] Error:', e);
            return false;
        }
    },
    // V2.1.0: Edit API � drag/duplicate/delete segment
    updateSegment: (id, newStart, newEnd) => {
        const seg = state.segments.find(s => String(s.id) === String(id));
        if (!seg) return null;
        seg.start = Math.max(0, newStart);
        seg.end = Math.min(state.duration, newEnd);
        if (seg.end <= seg.start) seg.end = seg.start + 0.1;
        // V9.2.0: Sync ke currentAnalysisData
        if (typeof currentAnalysisData !== 'undefined' && currentAnalysisData) {
            currentAnalysisData.segments = state.segments.map(function(x) {
                return { id: x.id, start: x.start, end: x.end, source: x.source, reason: x.reason, priority: x.priority, enabled: x.enabled };
            });
        }
        if (typeof renderSegments === 'function') renderSegments();
        if (typeof renderStats === 'function') renderStats();
        return { start: seg.start, end: seg.end };
    },
    duplicateSegment: (id) => {
        const seg = state.segments.find(s => String(s.id) === String(id));
        if (!seg) return null;
        const segDur = seg.end - seg.start;
        let newStart = seg.end + 0.1;
        let newEnd = newStart + segDur;
        if (newEnd > state.duration) {
            newStart = seg.start - segDur - 0.1;
            newEnd = newStart + segDur;
            if (newStart < 0) { newStart = 0; newEnd = Math.min(segDur, state.duration); }
        }
        const newSeg = {
            id: Date.now(),
            start: newStart,
            end: newEnd,
            source: seg.source || 'manual',
            reason: (seg.reason || 'duplicate') + '_copy',
            priority: seg.priority || 5,
            enabled: seg.enabled,
        };
        state.segments.push(newSeg);
        state.segments.sort((a, b) => a.start - b.start);
        
        // V9.2.0: SYNC ke currentAnalysisData juga biar auto-sync tidak overwrite
        if (typeof currentAnalysisData !== 'undefined' && currentAnalysisData) {
            currentAnalysisData.segments = state.segments.map(function(x) {
                return {
                    id: x.id,
                    start: x.start,
                    end: x.end,
                    source: x.source,
                    reason: x.reason,
                    priority: x.priority,
                    enabled: x.enabled,
                };
            });
        }
        
        if (typeof renderSegments === 'function') renderSegments();
        if (typeof renderStats === 'function') renderStats();
        console.log('[Duplicate] OK. Total segs: ' + state.segments.length);
        return { id: newSeg.id, start: newStart, end: newEnd };
    },
    deleteSegmentById: (id) => {
        const idx = state.segments.findIndex(s => String(s.id) === String(id));
        if (idx < 0) return false;
        state.segments.splice(idx, 1);
        if (typeof renderSegments === 'function') renderSegments();
        if (typeof renderStats === 'function') renderStats();
        return true;
    },
    // V1.0.1: API publik � user bisa klik untuk potong/keep segment
    toggleSegmentAt: (timeSec) => {
        if (!state || !state.segments) return null;
        const segs = state.segments;
        const hit = segs.find(s => timeSec >= s.start && timeSec <= s.end);
        if (hit) {
            hit.enabled = !hit.enabled;
            if (typeof renderTimeline === 'function') renderTimeline();
            return { action: 'toggle', enabled: hit.enabled, start: hit.start, end: hit.end };
        }
        // Tidak ada segmen � bikin cut baru 1 detik
        const cutStart = Math.max(0, timeSec - 0.5);
        const cutEnd = Math.min(state.duration || 0, timeSec + 0.5);
        if (cutEnd <= cutStart) return null;
        const newSeg = {
            id: Date.now(),
            start: cutStart,
            end: cutEnd,
            source: 'manual',
            reason: 'user_click',
            priority: 5,
            enabled: true,
        };
        segs.push(newSeg);
        segs.sort((a, b) => a.start - b.start);
        if (typeof renderTimeline === 'function') renderTimeline();
        return { action: 'add', start: cutStart, end: cutEnd };
    }
};

// Event-based integration
window.addEventListener('clipora:analysis-ready', (e) => {
    try {
        start(e.detail || {});
    } catch (err) {
        console.error('[Editor] Event handler error:', err);
    }
});

// Auto-init
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

})();


/* ============================================================
   V2.0.0: Keep-click handler � pakai API resmi CliporaEditor
   ============================================================ */
(function initKeepClick() {
    function run() {
        const track = document.getElementById("teTrack");
        if (!track) { setTimeout(run, 500); return; }
        if (!window.CliporaEditor || !window.CliporaEditor.toggleSegmentAt) {
            console.warn("[Timeline] CliporaEditor API belum siap, retry...");
            setTimeout(run, 500); return;
        }
        if (track.dataset.keepClickReady === "1") return;
        track.dataset.keepClickReady = "1";

        console.log("[Timeline] Keep-click siap (API mode)");

        // Inject CSS
        if (!document.getElementById("_keepClickStyle")) {
            const st = document.createElement("style");
            st.id = "_keepClickStyle";
            st.textContent = [
                ".te-timeline-bg, .te-track-bg, .te-keep-zone { cursor: pointer !important; }",
                ".te-timeline-bg:hover, .te-track-bg:hover {",
                "  background: rgba(139,92,246,0.15) !important;",
                "  box-shadow: inset 0 0 0 2px rgba(139,92,246,0.4);",
                "}",
                ".te-segment.keep { cursor: pointer; transition: 0.15s; }",
                ".te-segment.keep:hover { box-shadow: 0 0 0 2px rgba(139,92,246,0.6), 0 0 12px rgba(139,92,246,0.4); }",
                ".te-segment.keep::after {",
                "  content: '2702';",
                "  position: absolute;",
                "  right: 6px; top: 50%; transform: translateY(-50%);",
                "  font-size: 0.8rem; color: rgba(255,255,255,0.5);",
                "  opacity: 0; transition: opacity 0.15s; pointer-events: none;",
                "}",
                ".te-segment.keep:hover::after { opacity: 1; }",
                ".te-timeline-hint-tip {",
                "  position: fixed; background: rgba(15,15,30,0.95);",
                "  border: 1px solid rgba(139,92,246,0.5); border-radius: 8px;",
                "  padding: 8px 12px; font-size: 0.75rem; color: #e8e8ef;",
                "  pointer-events: none; z-index: 99999;",
                "  box-shadow: 0 4px 20px rgba(0,0,0,0.6); display: none;",
                "}",
            ].join("\n");
            document.head.appendChild(st);
        }

        // Tooltip
        let tip = document.getElementById("_keepClickTip");
        if (!tip) {
            tip = document.createElement("div");
            tip.id = "_keepClickTip";
            tip.className = "te-timeline-hint-tip";
            tip.textContent = "Klik untuk potong bagian ini";
            document.body.appendChild(tip);
        }

        // Handler click
        track.addEventListener("click", function (e) {
            if (e.target.closest(".te-segment")) return;

            const state = window.CliporaEditor.getState();
            if (!state || !state.duration || state.duration <= 0) {
                console.warn("[Timeline] duration tidak valid");
                return;
            }

            const rect = track.getBoundingClientRect();
            const pct = (e.clientX - rect.left) / rect.width;
            const clickTime = pct * state.duration;

            const res = window.CliporaEditor.toggleSegmentAt(clickTime);
            console.log("[Timeline] toggleSegmentAt:", res);

            if (typeof updateStats === "function") {
                try { updateStats(); } catch (err) { console.warn(err); }
            }

            // Sync ke currentAnalysisData
            if (typeof currentAnalysisData !== "undefined" && currentAnalysisData) {
                const gs = window.CliporaEditor.getSegments();
                currentAnalysisData.segments = gs;
            }
        });

        // Tooltip mousemove
        track.addEventListener("mousemove", function (e) {
            if (e.target.closest(".te-segment")) {
                tip.style.display = "none";
                return;
            }
            tip.style.display = "block";
            tip.style.left = (e.clientX + 12) + "px";
            tip.style.top = (e.clientY + 12) + "px";
        });
        track.addEventListener("mouseleave", function () { tip.style.display = "none"; });

        console.log("[Timeline] Semua handler siap");
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", function () { setTimeout(run, 1500); });
    } else {
        setTimeout(run, 1500);
    }
})();


/* ============================================================
   V9.36.1: Download Notification
   ============================================================ */
(function initDownloadNotification() {
    'use strict';

    if (window.__DOWNLOAD_NOTIF_INSTALLED) return;
    window.__DOWNLOAD_NOTIF_INSTALLED = true;

    window.showDownloadNotification = function(url, filename, filesize) {
        // V9.36.2: Save last download info untuk tombol UI
        window.__lastDownloadInfo = { url: url, filename: filename, filesize: filesize };
        
        // V9.36.3: Dedupe - kalau notification untuk URL sama masih ada, skip
        var existing = document.getElementById('acDownloadNotif');
        if (existing) {
            var existingUrl = existing.dataset.downloadUrl || '';
            var existingTime = parseInt(existing.dataset.createdAt || '0');
            var now = Date.now();
            if (existingUrl === url && (now - existingTime) < 30000) {
                console.log('[Download Notif] Skipped duplicate (URL sama, <30s)');
                return;
            }
            existing.remove();
        }

        var sizeText = '';
        if (filesize) {
            var mb = parseFloat(filesize);
            if (!isNaN(mb) && mb > 0) {
                sizeText = mb.toFixed(1) + ' MB';
            }
        }

        var notif = document.createElement('div');
        notif.id = 'acDownloadNotif';
        notif.style.cssText = [
            'position: fixed',
            'bottom: 24px',
            'right: 24px',
            'z-index: 999999',
            'max-width: 380px',
            'width: calc(100vw - 48px)',
            'background: linear-gradient(165deg, #1e293b, #0f172a)',
            'border: 1px solid rgba(139, 92, 246, 0.4)',
            'border-radius: 16px',
            'padding: 18px',
            'box-shadow: 0 20px 60px rgba(0,0,0,0.6), 0 0 40px rgba(139, 92, 246, 0.15)',
            'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            'color: #e2e8f0',
            'animation: acNotifSlideIn 0.3s ease',
            'display: flex',
            'flex-direction: column',
            'gap: 14px'
        ].join(';');

        var iconHtml = '<div style="width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,#8b5cf6,#06b6d4);display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;">??</div>';

        var bodyHtml = '<div style="flex:1;min-width:0;">' +
            '<div style="font-weight:700;font-size:0.92rem;color:#f1f5f9;margin-bottom:4px;">Video siap di-download!</div>' +
            '<div style="font-size:0.75rem;color:#94a3b8;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' +
            (filename || 'clipora.mp4') +
            (sizeText ? ' � ' + sizeText : '') +
            '</div>' +
            '</div>';

        var headerHtml = '<div style="display:flex;align-items:center;gap:12px;">' + iconHtml + bodyHtml + '</div>';

        var btnWrap = '<div style="display:flex;gap:8px;">' +
            '<button type="button" id="acDownloadNowBtn" style="flex:1;padding:11px 16px;border:none;border-radius:10px;background:linear-gradient(135deg,#8b5cf6,#06b6d4);color:#fff;font-weight:700;font-size:0.85rem;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:7px;">' +
            '�� Download Sekarang' +
            '</button>' +
            '<button type="button" id="acDownloadLaterBtn" style="padding:11px 16px;border:1px solid rgba(148,163,184,0.3);border-radius:10px;background:transparent;color:#94a3b8;font-weight:600;font-size:0.85rem;cursor:pointer;font-family:inherit;">' +
            'Nanti' +
            '</button>' +
            '</div>';

        notif.innerHTML = headerHtml + btnWrap;

        if (!document.getElementById('acDownloadNotifStyle')) {
            var style = document.createElement('style');
            style.id = 'acDownloadNotifStyle';
            style.textContent = '@keyframes acNotifSlideIn { from { transform: translateX(120%); opacity: 0; } to { transform: translateX(0); opacity: 1; } } @keyframes acNotifSlideOut { from { transform: translateX(0); opacity: 1; } to { transform: translateX(120%); opacity: 0; } }';
            document.head.appendChild(style);
        }

        notif.dataset.downloadUrl = url;
        notif.dataset.createdAt = Date.now().toString();
        document.body.appendChild(notif);

        function closeNotif() {
            notif.style.animation = 'acNotifSlideOut 0.25s ease';
            setTimeout(function() { notif.remove(); }, 250);
        }

        var downloadBtn = document.getElementById('acDownloadNowBtn');
        var _alreadyDownloaded = false;

        downloadBtn.addEventListener('click', function() {
            if (_alreadyDownloaded) return;
            _alreadyDownloaded = true;
            downloadBtn.disabled = true;
            downloadBtn.innerHTML = '�� Mengunduh...';

                           // V9.61.3: window.open fix (hapus baris a.remove() yang error)
            var win = window.open(url, '_blank');
            if (!win) {
                prompt('Popup diblokir. Copy URL ini ke browser:', url);
            }
            console.log('[Download Notif] Opened:', filename);

            console.log('[Download Notif] Download triggered:', filename);

            setTimeout(function() {
                downloadBtn.innerHTML = '? Terdownload!';
                downloadBtn.style.background = 'linear-gradient(135deg,#22c55e,#16a34a)';
                setTimeout(closeNotif, 1200);
            }, 600);
        });

        document.getElementById('acDownloadLaterBtn').addEventListener('click', closeNotif);

        var autoClose = setTimeout(closeNotif, 30000);
        downloadBtn.addEventListener('click', function() { clearTimeout(autoClose); });
    };

    console.log('[Download Notif] V9.36.1 ready');
})();


/* ============================================================
   V9.36.2: Intercept download button
   - Semua klik pada tombol "Download Video Final" ? notification
   - Cegah download langsung
   ============================================================ */





/* ============================================================
   V9.38.0: Reset URL after download
   - Setelah user klik Download, hapus ?project= dari URL
   - Refresh ? halaman reset ke upload form
   ============================================================ */
(function initResetAfterDownload() {
    'use strict';

    if (window.__V9380_INSTALLED) return;
    window.__V9380_INSTALLED = true;

    document.addEventListener('click', function(e) {
        var btn = e.target.closest('#modalDownloadVideoBtn, #downloadModal a.dl-primary, #downloadModal a[download]');
        if (!btn) return;

        // Skip kalau bukan link download
        if (btn.tagName !== 'A') return;

        console.log('[V9.38.0] Download clicked � akan reset URL setelah 2s');

        // Delay 2 detik biar download sempat trigger dulu
        setTimeout(function() {
            try {
                // Hapus query params
                var cleanUrl = window.location.pathname;
                if (window.history && window.history.replaceState) {
                    window.history.replaceState({}, document.title, cleanUrl);
                    console.log('[V9.38.0] URL reset ke:', cleanUrl);
                }

                // Set flag biar kalau ada handler refresh lain, tahu
                try {
                    sessionStorage.setItem('clipora_just_downloaded', Date.now().toString());
                } catch (err) {}

                console.log('[V9.38.0] Refresh sekarang akan kembali ke upload form');
            } catch (err) {
                console.warn('[V9.38.0] Reset error:', err.message);
            }
        }, 2000);
    }, true);

    console.log('[V9.38.0] Reset-after-download ready');
})();

// ============================================================
// V9.301.0: FITUR BARU � Multi-Format + Auto-Subtitle
// ============================================================
(function() {
    'use strict';
    
    // State global
    window.teEditorOptions = window.teEditorOptions || {
        selectedFormats: ['original'],
        autoSubtitle: true,
        subtitleStyle: 'tiktok'
    };
    
    // Wait DOM ready
    function showQuickActionResult(action, result) {
    // Buat atau update tombol download di bawah tombol Quick Action
    var btnMap = {
        'silence': 'qaSilenceBtn',
        'speed': 'qaSpeedBtn',
        'music': 'qaMusicBtn',
        'trim': 'qaTrimBtn'
    };
    var btn = document.getElementById(btnMap[action]);
    if (!btn || !result.downloadUrl) return;
    
    // Cari container
    var container = btn.closest('.qa-grid');
    if (!container) return;
    
    // Hapus notif lama kalau ada
    var oldNotif = container.querySelector('.qa-result-notif');
    if (oldNotif) oldNotif.remove();
    
    // Buat notif baru
    var notif = document.createElement('div');
    notif.className = 'qa-result-notif';
    notif.style.cssText = 'grid-column: 1 / -1; padding: 10px 14px; background: linear-gradient(135deg, rgba(34,197,94,0.15), rgba(16,185,129,0.1)); border: 1px solid rgba(34,197,94,0.3); border-radius: 10px; display: flex; align-items: center; gap: 10px; margin-top: 8px; animation: qaResultIn 0.3s ease;';
    notif.innerHTML = 
        '<span style="font-size: 18px;">?</span>' +
        '<span style="flex: 1; font-size: 12px; color: #4ade80; font-weight: 600;">Video hasil siap di-download</span>' +
        '<a href="' + result.downloadUrl + '" download style="padding: 6px 14px; background: linear-gradient(135deg, #22c55e, #16a34a); color: white; border-radius: 8px; font-size: 11px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 5px;">' +
        '  <i class="fas fa-download"></i> Download' +
        '</a>';
    
    container.appendChild(notif);
    
    // Auto remove setelah 30 detik
    setTimeout(function() {
        if (notif.parentNode) {
            notif.style.opacity = '0';
            setTimeout(function() { notif.remove(); }, 300);
        }
    }, 30000);
}

function init() {
        // Format buttons
        // V9.501.0: Single-select format handler (cuma 1 aktif)
        document.querySelectorAll('.te-format-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const format = this.dataset.format;
                
                // Remove te-format-active dari SEMUA tombol
                document.querySelectorAll('.te-format-btn').forEach(b => {
                    b.classList.remove('te-format-active');
                });
                
                // Tambahkan te-format-active ke tombol yang diklik
                this.classList.add('te-format-active');
                
                // Update selectedFormats  cuma 1 format
                window.teEditorOptions.selectedFormats = [format];
                
                console.log('[Format] Selected:', format);
                
                // Update counter
                updateFormatCounter();
            });
        });
        
        // Helper: Update counter format
        function updateFormatCounter() {
            var counter = document.getElementById('formatCounter');
            if (!counter) {
                var grid = document.querySelector('.te-format-grid');
                if (!grid) return;
                counter = document.createElement('div');
                counter.id = 'formatCounter';
                counter.style.cssText = 'margin-top: 10px; font-size: 11px; color: #a78bfa; text-align: center; font-weight: 600;';
                grid.parentNode.appendChild(counter);
            }
            
            var format = window.teEditorOptions.selectedFormats[0] || 'original';
            
            var formatLabels = {
                'original': ' Original (Rasio Asli)',
                '9:16': ' TikTok (9:16)',
                '1:1': ' Instagram (1:1)',
                '16:9': ' YouTube (16:9)'
            };
            
            counter.textContent = ' Format: ' + (formatLabels[format] || format);
        }
        
        // Auto-Subtitle toggle
        const toggle = document.getElementById('teAutoSubtitleToggle');
        if (toggle) {
            toggle.addEventListener('change', function() {
                window.teEditorOptions.autoSubtitle = this.checked;
                console.log('[Editor] Auto-Subtitle:', this.checked ? 'ON' : 'OFF');
            });
        }
        
        // Subtitle style
        const styleSelect = document.getElementById('teSubtitleStyle');
        if (styleSelect) {
            styleSelect.addEventListener('change', function() {
                window.teEditorOptions.subtitleStyle = this.value;
                console.log('[Editor] Subtitle style:', this.value);
            });
        }
        
        console.log('[Editor] ? Fitur baru loaded: Multi-Format + Auto-Subtitle');
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        setTimeout(init, 500);
    }
    
    // Fungsi untuk dipanggil saat render
    window.getEditorRenderOptions = function() {
        const opts = window.teEditorOptions;
        return {
            vertical_crop: opts.selectedFormats.includes('9:16'),
            aspect_ratio: opts.selectedFormats[0] || 'auto',
            enable_burn_subtitle: opts.autoSubtitle,
            caption_style: opts.subtitleStyle,
            formats: opts.selectedFormats
        };
    };
})();

// ============================================================
// V9.304.0: QUICK ACTIONS BAR
// ============================================================
(function() {
    'use strict';
    
    function getAnalysisId() {
        // V9.307.0: Coba semua sumber
        console.log('[QuickAction] Cari analysisId...');
        
        // 1. Dari state internal (kalau ada)
        if (typeof state !== 'undefined' && state.analysisId) {
            console.log('[QuickAction]  dari state:', state.analysisId);
            return state.analysisId;
        }
        
        // 2. Dari CliporaEditor API
        if (window.CliporaEditor && typeof window.CliporaEditor.getState === 'function') {
            var st = window.CliporaEditor.getState();
            if (st && st.analysisId) {
                console.log('[QuickAction]  dari CliporaEditor:', st.analysisId);
                return st.analysisId;
            }
        }
        
        // 3. Dari global currentAnalysisData (main.js)
        try {
            if (typeof currentAnalysisData !== 'undefined' && currentAnalysisData && currentAnalysisData.analysisId) {
                console.log('[QuickAction]  dari currentAnalysisData:', currentAnalysisData.analysisId);
                return currentAnalysisData.analysisId;
            }
        } catch (e) {
            console.log('[QuickAction] currentAnalysisData tidak accessible');
        }
        
        // 4. Dari window.currentAnalysisData
        if (window.currentAnalysisData && window.currentAnalysisData.analysisId) {
            console.log('[QuickAction]  dari window.currentAnalysisData:', window.currentAnalysisData.analysisId);
            return window.currentAnalysisData.analysisId;
        }
        
        // 5. Dari window.currentAnalysisId
        if (window.currentAnalysisId) {
            console.log('[QuickAction]  dari window.currentAnalysisId:', window.currentAnalysisId);
            return window.currentAnalysisId;
        }
        
        // 6. Dari URL
        var urlParams = new URLSearchParams(window.location.search);
        var id = urlParams.get('project') || urlParams.get('analysis');
        if (id) {
            console.log('[QuickAction]  dari URL:', id);
            return id;
        }
        
        console.warn('[QuickAction]  analysisId TIDAK DITEMUKAN');
        return null;
    }
    
    function getClipId() {
        return window.currentClipId || '1';
    }
    
    // V9.310.0: Simple progress � update tombol text
    function updateBtnProgress(btn, action, progress, status) {
        if (!btn) return;
        
        var originalHTML = btn.getAttribute('data-original-html');
        if (!originalHTML) {
            originalHTML = btn.innerHTML;
            btn.setAttribute('data-original-html', originalHTML);
        }
        
        var icon = {
            'silence': '??�',
            'speed': '?',
            'music': '��',
            'trim': '����'
        }[action] || '��';
        
        if (status === 'completed' || progress >= 100) {
            // Selesai
            btn.innerHTML = 
                '<span style="font-size:20px;">?</span>' +
                '<span style="font-size:12px;font-weight:600;color:#4ade80;">Berhasil!</span>' +
                '<small style="font-size:9px;color:#94a3b8;">Klik untuk ulang</small>';
            btn.style.borderColor = '#22c55e';
            btn.style.background = 'rgba(34, 197, 94, 0.1)';
            
            // Reset setelah 3 detik
            setTimeout(function() {
                btn.innerHTML = originalHTML;
                btn.style.borderColor = '';
                btn.style.background = '';
                btn.removeAttribute('data-original-html');
            }, 3000);
            
        } else if (status === 'failed') {
            // Gagal
            btn.innerHTML = 
                '<span style="font-size:20px;">��</span>' +
                '<span style="font-size:12px;font-weight:600;color:#ef4444;">Gagal</span>' +
                '<small style="font-size:9px;color:#94a3b8;">Coba lagi</small>';
            btn.style.borderColor = '#ef4444';
            
            setTimeout(function() {
                btn.innerHTML = originalHTML;
                btn.style.borderColor = '';
                btn.removeAttribute('data-original-html');
            }, 3000);
            
        } else {
            // Loading
            btn.innerHTML = 
                '<span style="font-size:20px;">��</span>' +
                '<span style="font-size:12px;font-weight:600;color:#c4b5fd;">' + progress + '%</span>' +
                '<small style="font-size:9px;color:#94a3b8;">Memproses...</small>';
            btn.style.borderColor = '#8b5cf6';
            btn.style.background = 'linear-gradient(135deg, rgba(139, 92, 246, 0.2), rgba(109, 40, 217, 0.1))';
        }
        
        // Tambah progress bar di bawah tombol (opsional)
        var existing = btn.querySelector('.qa-inline-progress');
        if (!existing && status !== 'completed' && status !== 'failed') {
            var bar = document.createElement('div');
            bar.className = 'qa-inline-progress';
            bar.style.cssText = 'position:absolute;bottom:0;left:0;right:0;height:3px;background:rgba(255,255,255,0.1);overflow:hidden;';
            bar.innerHTML = '<div style="height:100%;width:' + progress + '%;background:linear-gradient(90deg,#8b5cf6,#ec4899);transition:width 0.5s;"></div>';
            btn.style.position = 'relative';
            btn.style.overflow = 'hidden';
            btn.appendChild(bar);
        } else if (existing && status !== 'completed' && status !== 'failed') {
            var fill = existing.querySelector('div');
            if (fill) fill.style.width = progress + '%';
        }
    }

    async function quickAction(action, payload) {
        var analysisId = getAnalysisId();
        var clipId = getClipId();

        if (!analysisId) {
            showToast('Tidak ada analysis ID. Upload video dulu.', 'warning');
            return;
        }

        // Cari tombol yang di-klik
        var btnMap = {
            'silence': 'qaSilenceBtn',
            'speed': 'qaSpeedBtn',
            'music': 'qaMusicBtn',
            'trim': 'qaTrimBtn'
        };
        var btn = document.getElementById(btnMap[action]);
        
        // Set loading state
        if (btn) {
            btn.classList.add('qa-loading');
            btn.disabled = true;
        }

        try {
            console.log('[QuickAction] ' + action + ':', payload);

            // Tampilkan toast loading
            var toastMsg = {
                'silence': ' Menghapus jeda...',
                'speed': ' Mengubah kecepatan ke 1.5x...',
                'music': ' Menambahkan musik...',
                'trim': ' Memotong video jadi 60 detik...'
            }[action] || ' Memproses...';

            showToast(toastMsg, 'info');

            // Bangun payload untuk server
            var renderPayload = {
                // Data dasar
                analysisId: analysisId,
                segments: (typeof window.CliporaEditor !== 'undefined' && 
                          typeof window.CliporaEditor.getSegments === 'function') 
                          ? window.CliporaEditor.getSegments() 
                          : [],
                preset: (document.getElementById('qualitySelect') || {}).value || '1080p',
                
                // Setting dari fitur baru (Multi-Format + Auto-Subtitle)
                enable_burn_subtitle: true,
                caption_style: 'tiktok',
                vertical_crop: false,
                aspect_ratio: 'auto',
                
                // Quick Action specific
                remove_silence: action === 'silence',
                speed: action === 'speed' ? 1.5 : 1,
                add_music: action === 'music',
                max_duration: action === 'trim' ? 60 : null
            };

            // Ambil setting dari Multi-Format + Auto-Subtitle
            if (typeof window.getEditorRenderOptions === 'function') {
                var newOpts = window.getEditorRenderOptions();
                renderPayload.enable_burn_subtitle = newOpts.enable_burn_subtitle;
                renderPayload.caption_style = newOpts.caption_style;
                renderPayload.vertical_crop = newOpts.vertical_crop;
                renderPayload.aspect_ratio = newOpts.aspect_ratio;
                renderPayload.export_formats = newOpts.formats;
            }

            console.log('[QuickAction] Sending to server:', renderPayload);

            // Kirim ke server endpoint /api/render
            var API = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.apiUrl) || '/api';
            var authToken = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || '';
            
            var response = await fetch(API + '/render/' + analysisId, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + authToken
                },
                body: JSON.stringify(renderPayload)
            });

            var data = await response.json();

            if (!response.ok || !data.success) {
                throw new Error(data.error || 'Server error');
            }

            console.log('[QuickAction] Server response:', data);
            
            showToast(' ' + ({
                'silence': 'Jeda berhasil dihapus!',
                'speed': 'Kecepatan diubah ke 1.5x!',
                'music': 'Musik berhasil ditambahkan!',
                'trim': 'Video dipotong jadi 60 detik!'
            }[action] || 'Berhasil!'), 'success');

            // Kalau ada job ID, mulai polling status
            if (data.jobId) {
                pollRenderStatus(data.jobId, action, btn);
            }

        } catch (e) {
            console.error('[QuickAction] Error:', e);
            showToast(' Error: ' + e.message, 'error');
        } finally {
            // Reset loading state
            if (btn) {
                btn.classList.remove('qa-loading');
                btn.disabled = false;
            }
        }
    }

    // ============================================================
    // V9.309.0: PROGRESS OVERLAY
    // ============================================================
    function updateQuickActionProgress(action, progress, status, message) {
        var btnMap = {
            'silence': 'qaSilenceBtn',
            'speed': 'qaSpeedBtn',
            'music': 'qaMusicBtn',
            'trim': 'qaTrimBtn'
        };
        var btn = document.getElementById(btnMap[action]);
        if (!btn) return;

        var overlay = btn.querySelector('.qa-progress-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.className = 'qa-progress-overlay';
            overlay.innerHTML = 
                '<div class="qa-progress-inner">' +
                '  <div class="qa-progress-bar">' +
                '    <div class="qa-progress-fill"></div>' +
                '  </div>' +
                '  <div class="qa-progress-text">' +
                '    <span class="qa-progress-pct">0%</span>' +
                '    <span class="qa-progress-msg">Memproses...</span>' +
                '  </div>' +
                '</div>';
            btn.style.position = 'relative';
            btn.style.overflow = 'hidden';
            btn.appendChild(overlay);
        }

        var fill = overlay.querySelector('.qa-progress-fill');
        var pct = overlay.querySelector('.qa-progress-pct');
        var msg = overlay.querySelector('.qa-progress-msg');

        fill.style.width = progress + '%';
        pct.textContent = progress + '%';
        
        var msgMap = {
            'silence': 'Menghapus jeda...',
            'speed': 'Percepat video...',
            'music': 'Menambahkan musik...',
            'trim': 'Memotong 60 detik...'
        };
        msg.textContent = message || msgMap[action] || 'Memproses...';
    }

    function hideQuickActionProgress(action) {
        var btnMap = {
            'silence': 'qaSilenceBtn',
            'speed': 'qaSpeedBtn',
            'music': 'qaMusicBtn',
            'trim': 'qaTrimBtn'
        };
        var btn = document.getElementById(btnMap[action]);
        if (!btn) return;

        var overlay = btn.querySelector('.qa-progress-overlay');
        if (overlay) {
            overlay.style.opacity = '0';
            setTimeout(function() {
                if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
            }, 300);
        }
    }

    // Polling status render
    function pollRenderStatus(jobId, action, btn) {
        var attempts = 0;
        var maxAttempts = 120; // 4 menit (2 detik x 120)
        
        var interval = setInterval(async function() {
            attempts++;
            
            try {
                var API = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.apiUrl) || '/api';
                var authToken = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || '';
                
                var r = await fetch(API + '/render-status/' + jobId, {
                    headers: { 'Authorization': 'Bearer ' + authToken }
                });
                
                var st = await r.json();
                console.log('[QuickAction] Poll status:', st.status, st.progress + '%');
                
                // V9.310.0: Update tombol text dengan progress (SIMPLE!)
                updateBtnProgress(btn, action, st.progress || 0, st.status);
                
                if (st.status === 'completed') {
                    clearInterval(interval);
                    
                    // V9.313.0: Toast sesuai action + tampilkan hasil
                    var actionMsg = {
                        'silence': 'Jeda berhasil dihapus!',
                        'speed': 'Video dipercepat 1.5x!',
                        'music': 'Musik berhasil ditambahkan!',
                        'trim': 'Video dipotong 60 detik!'
                    }[action] || 'Video selesai diproses!';
                    
                    showToast('?? ' + actionMsg, 'success', 4000);
                    
                    // Log hasil dari server
                    if (st.result) {
                        console.log('[QuickAction] ? Hasil:', st.result);
                        
                        // Tampilkan video preview hasil
                        if (st.result.downloadUrl) {
                            var video = document.getElementById('editorVideo');
                            if (video) {
                                // Set video preview ke hasil Quick Action
                                var baseUrl = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.baseUrl) || '';
                                video.src = baseUrl + st.result.downloadUrl;
                                video.load();
                                console.log('[QuickAction] Preview updated:', st.result.downloadUrl);
                            }
                        }
                        
                        // Tampilkan tombol download hasil
                        showQuickActionResult(action, st.result);
                    }
                    
                    // V9.312.0: AUTO-REFRESH TIMELINE + STATS
                    console.log('[QuickAction] Auto-refresh timeline...');
                    (function refreshTimeline() {
                        var _pid = new URLSearchParams(window.location.search).get('project');
                        if (!_pid) return;
                        var _tk = (window.CLIPORA_AUTH && window.CLIPORA_AUTH.token) || '';
                        fetch(API + '/projects/' + encodeURIComponent(_pid) + '/use', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + _tk },
                            credentials: 'same-origin'
                        })
                        .then(function(r) { return r.json(); })
                        .then(function(pd) {
                            if (!pd.success) return;
                            if (window.CliporaEditor && typeof window.CliporaEditor.start === 'function') {
                                var nd = pd.analysis || {};
                                nd.analysisId = pd.analysisId;
                                window.CliporaEditor.start(nd);
                            }
                            try {
                                if (typeof currentAnalysisData !== 'undefined') {
                                    currentAnalysisData = JSON.parse(JSON.stringify(pd.analysis));
                                    currentAnalysisData.analysisId = pd.analysisId;
                                }
                            } catch (e) {}
                            setTimeout(function() {
                                if (typeof renderTimeline === 'function') renderTimeline();
                                if (typeof updateStats === 'function') updateStats();
                                console.log('[QuickAction] Timeline + stats refreshed');
                            }, 500);
                        })
                        .catch(function(e) { console.warn('[QuickAction] Refresh error:', e.message); });
                    })();
                    
                    // Reload video preview
                    if (typeof window.loadEditorVideo === 'function') {
                        window.loadEditorVideo();
                    } else if (typeof renderEditor === 'function') {
                        console.log('[QuickAction] Update in-place');
                var video = document.getElementById('editorVideo');
                if (video) { video.load(); }
                    }
                } else if (st.status === 'failed') {
                    clearInterval(interval);
                    showToast(' Proses gagal: ' + (st.error || 'Unknown'), 'error');
                }
            } catch (e) {
                console.warn('[QuickAction] Poll error:', e.message);
                // Fallback: coba ambil btn dari DOM
                if (!btn) {
                    var btnMap = {
                        'silence': 'qaSilenceBtn',
                        'speed': 'qaSpeedBtn',
                        'music': 'qaMusicBtn',
                        'trim': 'qaTrimBtn'
                    };
                    btn = document.getElementById(btnMap[action]);
                }
            }
            
            if (attempts >= maxAttempts) {
                clearInterval(interval);
                showToast(' Proses timeout', 'warning');
            }
        }, 2000);
    }
    
    function showQuickActionResult(action, result) {
    // Buat atau update tombol download di bawah tombol Quick Action
    var btnMap = {
        'silence': 'qaSilenceBtn',
        'speed': 'qaSpeedBtn',
        'music': 'qaMusicBtn',
        'trim': 'qaTrimBtn'
    };
    var btn = document.getElementById(btnMap[action]);
    if (!btn || !result.downloadUrl) return;
    
    // Cari container
    var container = btn.closest('.qa-grid');
    if (!container) return;
    
    // Hapus notif lama kalau ada
    var oldNotif = container.querySelector('.qa-result-notif');
    if (oldNotif) oldNotif.remove();
    
    // Buat notif baru
    var notif = document.createElement('div');
    notif.className = 'qa-result-notif';
    notif.style.cssText = 'grid-column: 1 / -1; padding: 10px 14px; background: linear-gradient(135deg, rgba(34,197,94,0.15), rgba(16,185,129,0.1)); border: 1px solid rgba(34,197,94,0.3); border-radius: 10px; display: flex; align-items: center; gap: 10px; margin-top: 8px; animation: qaResultIn 0.3s ease;';
    notif.innerHTML = 
        '<span style="font-size: 18px;">?</span>' +
        '<span style="flex: 1; font-size: 12px; color: #4ade80; font-weight: 600;">Video hasil siap di-download</span>' +
        '<a href="' + result.downloadUrl + '" download style="padding: 6px 14px; background: linear-gradient(135deg, #22c55e, #16a34a); color: white; border-radius: 8px; font-size: 11px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 5px;">' +
        '  <i class="fas fa-download"></i> Download' +
        '</a>';
    
    container.appendChild(notif);
    
    // Auto remove setelah 30 detik
    setTimeout(function() {
        if (notif.parentNode) {
            notif.style.opacity = '0';
            setTimeout(function() { notif.remove(); }, 300);
        }
    }, 30000);
}

function init() {
        var silenceBtn = document.getElementById('qaSilenceBtn');
        var speedBtn = document.getElementById('qaSpeedBtn');
        var musicBtn = document.getElementById('qaMusicBtn');
        var trimBtn = document.getElementById('qaTrimBtn');
        
        if (silenceBtn) {
            silenceBtn.addEventListener('click', function() {
                quickAction('silence', {});
            });
        }
        if (speedBtn) {
            speedBtn.addEventListener('click', function() {
                quickAction('speed', { rate: 1.5 });
            });
        }
        if (musicBtn) {
            musicBtn.addEventListener('click', function() {
                quickAction('music', { auto: true });
            });
        }
        if (trimBtn) {
            trimBtn.addEventListener('click', function() {
                quickAction('trim', { maxDuration: 60 });
            });
        }
        
        console.log('[QuickActions]  Loaded 4 buttons');
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        setTimeout(init, 500);
    }
    
    // Expose untuk dipakai
    window.qaAction = quickAction;
})();